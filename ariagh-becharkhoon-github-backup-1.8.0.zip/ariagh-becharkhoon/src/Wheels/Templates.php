<?php
/**
 * Theme presets (assets/data/themes.json, shared with the admin) and campaign templates
 * that create a ready wheel + its earning rules in one click.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Wheels;

use Becharkhoon\Core\Lang;
use Becharkhoon\Credits\Rules;

defined( 'ABSPATH' ) || exit;

final class Templates {

	/** @var array|null */
	private static $themes = null;

	public static function themes() {
		if ( null === self::$themes ) {
			$raw          = file_get_contents( BCH_DIR . 'assets/data/themes.json' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$list         = json_decode( (string) $raw, true );
			self::$themes = array();
			foreach ( (array) $list as $t ) {
				self::$themes[ $t['key'] ] = $t;
			}
		}
		return self::$themes;
	}

	/** Apply a theme preset onto a config (design/popup/form/display maps only). */
	public static function apply_theme( array $cfg, $key ) {
		$themes = self::themes();
		if ( ! isset( $themes[ $key ] ) ) {
			return $cfg;
		}
		foreach ( array( 'design', 'popup', 'form', 'display' ) as $section ) {
			foreach ( (array) ( $themes[ $key ][ $section ] ?? array() ) as $k => $v ) {
				if ( array_key_exists( $k, $cfg[ $section ] ) ) {
					$cfg[ $section ][ $k ] = $v;
				}
			}
		}
		$cfg['design']['theme'] = $key;
		return $cfg;
	}

	/**
	 * Campaign templates: key => [title_fa, title_en, desc_fa, desc_en, theme, patch, rules].
	 */
	public static function catalog() {
		$fa = Lang::is_fa();
		return array(
			'welcome'      => array(
				'title' => $fa ? 'گردونه خوش‌آمد (جذب شماره موبایل)' : 'Welcome wheel (lead capture)',
				'desc'  => $fa ? 'هر بازدیدکننده یک‌بار با تایید پیامکی موبایل می‌چرخاند؛ بهترین برای جمع‌کردن شماره مشتری.' : 'Each visitor spins once after verifying their mobile — best for collecting leads.',
				'theme' => 'classic',
				'patch' => array( 'access' => array( 'mode' => 'free', 'require_otp' => true, 'limits' => array( array( 'count' => 1, 'period' => 'lifetime', 'hours' => 24 ) ) ), 'display' => array( 'on_load' => true, 'delay' => 8, 'exit_intent' => true ) ),
				'rules' => array(),
			),
			'first_order'  => array(
				'title' => $fa ? 'هدیه اولین خرید' : 'First order reward',
				'desc'  => $fa ? 'فقط کسانی که اولین سفارش‌شان را ثبت می‌کنند یک شانس می‌گیرند (بعد از پرداخت).' : 'Only customers who place their first order earn a spin (after payment).',
				'theme' => 'gold',
				'patch' => array( 'access' => array( 'mode' => 'credits', 'limits' => array() ), 'display' => array( 'on_load' => false, 'exit_intent' => false, 'thankyou' => true, 'launcher' => true ) ),
				'rules' => array( array( 'title' => $fa ? 'اولین سفارش' : 'First order', 'trigger' => 'first_order', 'qty' => 1, 'expiry_days' => 30 ) ),
			),
			'big_order'    => array(
				'title' => $fa ? 'خرید بالای ۲ میلیون تومان' : 'Orders above a threshold',
				'desc'  => $fa ? 'هر سفارش با مبلغ ۲,۰۰۰,۰۰۰ تومان یا بیشتر = یک شانس چرخاندن. مبلغ قابل تغییر است.' : 'Every order of the set amount or more earns a spin. Amount is editable.',
				'theme' => 'royal',
				'patch' => array( 'access' => array( 'mode' => 'credits', 'limits' => array() ), 'display' => array( 'on_load' => false, 'exit_intent' => false, 'thankyou' => true ) ),
				'rules' => array( array( 'title' => $fa ? 'خرید بالای ۲ میلیون' : 'Big order', 'trigger' => 'order_amount', 'amount' => 2000000, 'qty' => 1, 'expiry_days' => 30 ) ),
			),
			'every_amount' => array(
				'title' => $fa ? 'به ازای هر ۵۰۰ هزار تومان خرید' : 'One spin per amount spent',
				'desc'  => $fa ? 'هرچه بیشتر بخرند، شانس بیشتری می‌گیرند (حداکثر ۱۰ شانس در هر سفارش).' : 'The more they spend the more spins they get (max 10 per order).',
				'theme' => 'casino',
				'patch' => array( 'access' => array( 'mode' => 'credits', 'limits' => array() ), 'display' => array( 'on_load' => false, 'thankyou' => true ) ),
				'rules' => array( array( 'title' => $fa ? 'هر ۵۰۰ هزار تومان' : 'Every 500k', 'trigger' => 'every_amount', 'amount' => 500000, 'qty' => 1, 'max_qty' => 10, 'expiry_days' => 45 ) ),
			),
			'exit_intent'  => array(
				'title' => $fa ? 'جلوگیری از خروج' : 'Exit-intent saver',
				'desc'  => $fa ? 'وقتی کاربر می‌خواهد سایت را ترک کند، گردونه ظاهر می‌شود؛ هر ۷ روز یک‌بار.' : 'Appears when the visitor is about to leave; once every 7 days.',
				'theme' => 'neon',
				'patch' => array( 'display' => array( 'on_load' => false, 'exit_intent' => true, 'frequency' => 'days', 'frequency_days' => 7 ), 'access' => array( 'limits' => array( array( 'count' => 1, 'period' => 'week', 'hours' => 24 ) ) ) ),
				'rules' => array(),
			),
			'daily_member' => array(
				'title' => $fa ? 'چرخش روزانه اعضا' : 'Daily member spin',
				'desc'  => $fa ? 'فقط کاربران عضو، روزی یک‌بار؛ برای وفادارسازی و بازگشت روزانه.' : 'Members only, once a day — builds daily habits.',
				'theme' => 'tech',
				'patch' => array( 'access' => array( 'mode' => 'free', 'require_login' => true, 'limits' => array( array( 'count' => 1, 'period' => 'day', 'hours' => 24 ) ) ), 'display' => array( 'on_load' => false, 'launcher' => true ) ),
				'rules' => array(),
			),
			'vip'          => array(
				'title' => $fa ? 'باشگاه VIP (مجموع خرید بالا)' : 'VIP club (high total spend)',
				'desc'  => $fa ? 'فقط مشتریانی که مجموع خریدشان از ۱۰ میلیون تومان بیشتر است، هر ماه یک‌بار.' : 'Only customers whose total spend exceeds the threshold, once a month.',
				'theme' => 'rose_gold',
				'patch' => array( 'access' => array( 'mode' => 'free', 'require_login' => true, 'limits' => array( array( 'count' => 1, 'period' => 'month', 'hours' => 24 ) ), 'conditions' => array( 'enabled' => true, 'groups' => array( array( array( 'type' => 'total_spent', 'op' => 'gte', 'value' => '10000000' ) ) ) ) ) ),
				'rules' => array(),
			),
			'review'       => array(
				'title' => $fa ? 'جایزه برای دیدگاه محصول' : 'Review reward',
				'desc'  => $fa ? 'برای هر دیدگاه تاییدشده روی محصولات یک شانس (حداکثر ۵ بار).' : 'One spin per approved product review (max 5).',
				'theme' => 'forest',
				'patch' => array( 'access' => array( 'mode' => 'credits', 'limits' => array() ), 'display' => array( 'on_load' => false ) ),
				'rules' => array( array( 'title' => $fa ? 'دیدگاه محصول' : 'Product review', 'trigger' => 'review', 'qty' => 1, 'max_per_user' => 5, 'expiry_days' => 30 ) ),
			),
			'referral'     => array(
				'title' => $fa ? 'دعوت از دوستان' : 'Refer a friend',
				'desc'  => $fa ? 'هر دوستی که با لینک دعوت خرید کند، به دعوت‌کننده یک شانس می‌دهد.' : 'Every friend who buys via the invite link gives the referrer a spin.',
				'theme' => 'kids',
				'patch' => array( 'access' => array( 'mode' => 'hybrid', 'require_login' => true, 'limits' => array( array( 'count' => 1, 'period' => 'lifetime', 'hours' => 24 ) ) ), 'messages' => array( 'show_share' => true ) ),
				'rules' => array( array( 'title' => $fa ? 'خرید دوست دعوت‌شده' : 'Referred friend order', 'trigger' => 'referral_order', 'qty' => 1, 'expiry_days' => 60 ) ),
			),
			'yalda'        => array(
				'title' => $fa ? 'کمپین شب یلدا' : 'Yalda campaign',
				'desc'  => $fa ? 'تم یلدا با شمارش معکوس و پاپ‌آپ تمام‌صفحه؛ تاریخ پایان را تنظیم کنید.' : 'Yalda theme with countdown and full-screen popup.',
				'theme' => 'yalda',
				'patch' => array( 'popup' => array( 'mode' => 'fullscreen', 'countdown' => true ), 'display' => array( 'delay' => 3 ) ),
				'rules' => array(),
			),
			'nowruz'       => array(
				'title' => $fa ? 'کمپین نوروز' : 'Nowruz campaign',
				'desc'  => $fa ? 'تم نوروزی با جایزه‌های ویژه عید و شمارش معکوس.' : 'Nowruz theme with special prizes and countdown.',
				'theme' => 'nowruz',
				'patch' => array( 'popup' => array( 'countdown' => true ) ),
				'rules' => array(),
			),
			'black_friday' => array(
				'title' => $fa ? 'بلک فرایدی' : 'Black Friday',
				'desc'  => $fa ? 'تم سیاه‌وزرد، ورود فوری، شمارش معکوس و نوار کد تخفیف.' : 'Black & yellow, instant popup, countdown and coupon bar.',
				'theme' => 'black_friday',
				'patch' => array( 'popup' => array( 'countdown' => true, 'mode' => 'modal' ), 'display' => array( 'delay' => 2, 'coupon_bar' => true ) ),
				'rules' => array(),
			),
		);
	}

	/**
	 * Create a wheel (and rules) from a template.
	 *
	 * @return int Wheel id.
	 */
	public static function create( $key, $title = '' ) {
		$cat = self::catalog();
		$tpl = $cat[ $key ] ?? $cat['welcome'];
		$cfg = Schema::defaults();
		$cfg = self::apply_theme( $cfg, $tpl['theme'] );
		$cfg = Schema::merge( $cfg, $tpl['patch'] );
		if ( isset( $tpl['patch']['access']['limits'] ) ) {
			$cfg['access']['limits'] = $tpl['patch']['access']['limits'];
		}
		// Template amounts are in Toman; follow the shop currency (Rial ×10, thousand-Toman ÷1000).
		$k = self::money_factor();
		if ( 1.0 !== $k && ! empty( $cfg['access']['conditions']['groups'] ) ) {
			foreach ( $cfg['access']['conditions']['groups'] as $gi => $g ) {
				foreach ( $g as $ci => $c ) {
					if ( in_array( $c['type'] ?? '', array( 'total_spent', 'avg_order', 'cart_total' ), true ) && is_numeric( $c['value'] ?? null ) ) {
						$cfg['access']['conditions']['groups'][ $gi ][ $ci ]['value'] = (string) round( (float) $c['value'] * $k );
					}
				}
			}
		}
		$cfg = Schema::sanitize( $cfg );
		$id  = becharkhoon()->wheels->create( '' !== $title ? $title : $tpl['title'], $cfg, 'draft' );
		if ( $id && $tpl['rules'] ) {
			$rules = Rules::all();
			foreach ( $tpl['rules'] as $r ) {
				if ( isset( $r['amount'] ) ) {
					$r['amount'] = round( $r['amount'] * $k );
				}
				$r['wheel_id'] = $id;
				$r['enabled']  = true;
				$rules[]       = $r;
			}
			Rules::save_all( $rules );
		}
		return $id;
	}

	/** Toman → shop currency factor for the built-in template amounts. */
	public static function money_factor() {
		$cur = function_exists( 'get_woocommerce_currency' ) ? strtoupper( (string) get_woocommerce_currency() ) : 'IRT';
		if ( 'IRR' === $cur ) {
			return 10.0;
		}
		if ( 'IRHT' === $cur ) {
			return 0.001;
		}
		return 1.0;
	}
}
