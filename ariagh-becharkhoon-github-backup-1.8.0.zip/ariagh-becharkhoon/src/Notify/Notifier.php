<?php
/**
 * All outgoing messages: customer email/SMS, admin email/SMS/Bale/Telegram, webhooks, OTP,
 * credit notifications and expiry reminders. Slow work runs after the response is sent.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Notify;

use Becharkhoon\Core\Helpers;
use Becharkhoon\Core\Http;
use Becharkhoon\Core\Lang;
use Becharkhoon\Core\Logger;

defined( 'ABSPATH' ) || exit;

final class Notifier {

	/** @var callable[] */
	private $queue = array();
	/** @var bool */
	private $registered = false;

	/** Run a task after the HTTP response (fastcgi / LiteSpeed finish request). */
	public function defer( callable $task ) {
		if ( defined( 'BCH_SYNC_NOTIFY' ) && BCH_SYNC_NOTIFY ) {
			$task();
			return;
		}
		$this->queue[] = $task;
		if ( ! $this->registered ) {
			$this->registered = true;
			register_shutdown_function( array( $this, 'flush' ) );
		}
	}

	public function flush() {
		if ( ! $this->queue ) {
			return;
		}
		if ( function_exists( 'fastcgi_finish_request' ) ) {
			fastcgi_finish_request();
		} elseif ( function_exists( 'litespeed_finish_request' ) ) {
			litespeed_finish_request();
		}
		ignore_user_abort( true );
		$q           = $this->queue;
		$this->queue = array();
		foreach ( $q as $task ) {
			try {
				$task();
			} catch ( \Throwable $e ) {
				Logger::log( 'system', 'error', 'Notification task failed: ' . $e->getMessage() );
			}
		}
	}

	/* ---------- Spins ---------- */

	/** Wheel-level SMS text that replaces the central template (only when the wheel opts in). */
	public static function wheel_override( array $wheel, $event ) {
		$n = $wheel['config']['notify'];
		if ( empty( $n['sms_override'] ) ) {
			return null;
		}
		if ( 'win' === $event ) {
			return array( 'mode' => $n['sms_mode'], 'text' => $n['sms_text'], 'code' => $n['sms_pattern'], 'params' => $n['sms_pattern_vars'] );
		}
		if ( 'lose' === $event && '' !== trim( (string) $n['sms_lose_text'] ) ) {
			return array( 'mode' => 'text', 'text' => $n['sms_lose_text'] );
		}
		return null;
	}

	public function after_spin( array $spin, array $wheel, array $slice, $ctx ) {
		$n    = $wheel['config']['notify'];
		$vars = $this->vars_for_spin( $spin, $wheel );
		$win  = 'win' === $spin['result'];
		$self = $this;
		$this->defer(
			static function () use ( $self, $spin, $wheel, $n, $vars, $win ) {
				if ( $win && $n['email_customer'] && is_email( $spin['email'] ) ) {
					$self->email( $spin['email'], Helpers::tpl( $n['email_subject'], $vars ), $n['email_heading'], Helpers::tpl( $n['email_body'], array_map( 'esc_html', $vars ) ), $vars['link'], $n['email_button'] );
				}
				if ( '' !== $spin['phone'] ) {
					if ( $win && $n['sms_customer'] ) {
						Sms::send_event( 'win', $vars, $spin['phone'], array( 'override' => self::wheel_override( $wheel, 'win' ), 'wheel_id' => (int) $wheel['id'] ) );
					} elseif ( 'lose' === $spin['result'] && $n['sms_lose'] ) {
						Sms::send_event( 'lose', $vars, $spin['phone'], array( 'override' => self::wheel_override( $wheel, 'lose' ), 'wheel_id' => (int) $wheel['id'] ) );
					}
				}
				if ( ! $n['admin_only_wins'] || $win ) {
					$line = sprintf( "🎡 %s\n%s: %s\n%s %s %s", $wheel['title'], $win ? Lang::t( 'برنده', 'Winner' ) : Lang::t( 'نتیجه', 'Result' ), $spin['slice_label'], $spin['name'], $spin['phone'], $spin['email'] );
					if ( $n['admin_email'] ) {
						foreach ( Helpers::lines( becharkhoon()->settings->get( 'admin_emails' ) ?: get_option( 'admin_email' ) ) as $to ) {
							$self->email( $to, Lang::t( 'گردونه: ', 'Wheel: ' ) . $spin['slice_label'], $wheel['title'], nl2br( esc_html( $line ) ) );
						}
					}
					if ( $n['admin_sms'] ) {
						Sms::send_event( 'admin_spin', $vars, '', array( 'wheel_id' => (int) $wheel['id'] ) );
					}
					if ( $n['admin_messenger'] ) {
						$self->messenger( $line );
					}
				}
				if ( $n['webhooks'] ) {
					$data = $self->public_spin( $spin, $wheel );
					$self->webhook( 'spin', $data );
					$self->webhook( $win ? 'win' : 'lose', $data );
				}
			}
		);
	}

	/** Variables of a spin for SMS / email templates. */
	public function vars_for_spin( array $spin, array $wheel ) {
		$fa    = Lang::is_fa();
		$apply = '';
		if ( '' !== (string) $spin['coupon_code'] && ! empty( $spin['coupon_id'] ) ) {
			$apply = add_query_arg( becharkhoon()->settings->get( 'auto_apply_param' ), rawurlencode( strtoupper( $spin['coupon_code'] ) ), home_url( '/' ) );
		}
		if ( 'link' === $spin['prize_type'] ) {
			foreach ( $wheel['config']['slices'] as $sl ) {
				if ( $sl['id'] === $spin['slice_id'] && '' !== $sl['link_url'] ) {
					$apply = $sl['link_url'];
				}
			}
		}
		$code  = in_array( $spin['prize_type'], array( 'code_pool', 'custom', 'link' ), true ) ? (string) $spin['coupon_code'] : strtoupper( (string) $spin['coupon_code'] );
		if ( 'link' === $spin['prize_type'] ) {
			$code = '';
		}
		$days = '';
		if ( ! empty( $spin['expires_at'] ) ) {
			$days = (string) max( 0, (int) ceil( ( strtotime( $spin['expires_at'] . ' UTC' ) - time() ) / DAY_IN_SECONDS ) );
			$days = $fa ? Helpers::persian_digits( $days ) : $days;
		}
		$results = array( 'win' => Lang::t( 'برنده', 'Win' ), 'lose' => Lang::t( 'پوچ', 'Lose' ), 'respin' => Lang::t( 'دوباره', 'Again' ) );
		$meta    = Helpers::json_decode_array( $spin['meta'] ?? '' );
		$claim   = isset( $meta['claim'] ) && is_array( $meta['claim'] ) ? implode( "\n", array_filter( array_map( 'strval', $meta['claim'] ) ) ) : '';
		return array(
			'name'        => '' !== trim( (string) $spin['name'] ) ? $spin['name'] : Lang::t( 'مشتری', 'customer' ),
			'mobile'      => (string) $spin['phone'],
			'phone'       => (string) $spin['phone'],
			'email'       => (string) $spin['email'],
			'prize'       => $spin['slice_label'],
			'prize_type'  => SmsEvents::type_label( $spin['prize_type'] ),
			'code'        => $code,
			'expiry'      => ! empty( $spin['expires_at'] ) ? Helpers::human_date( $spin['expires_at'] ) : Lang::t( 'نامحدود', 'no expiry' ),
			'expiry_days' => $days,
			'link'        => '' !== $apply ? $apply : home_url( '/' ),
			'wheel'       => $wheel['title'],
			'wheel_link'  => \Becharkhoon\Front\Frontend::wheel_url( $wheel ),
			'result'      => $results[ $spin['result'] ] ?? $spin['result'],
			'spin_id'     => (string) (int) $spin['id'],
			'claim'       => $claim,
		) + SmsEvents::general_vars();
	}

	public function public_spin( array $spin, array $wheel ) {
		return array(
			'id'       => (int) $spin['id'],
			'wheel_id' => (int) $spin['wheel_id'],
			'wheel'    => $wheel['title'],
			'result'   => $spin['result'],
			'prize'    => $spin['slice_label'],
			'type'     => $spin['prize_type'],
			'value'    => $spin['prize_value'],
			'code'     => $spin['coupon_code'],
			'expires'  => $spin['expires_at'],
			'name'     => $spin['name'],
			'phone'    => $spin['phone'],
			'email'    => $spin['email'],
			'user_id'  => (int) $spin['user_id'],
			'source'   => $spin['source'],
			'created'  => $spin['created_at'],
		);
	}

	/** Winner submitted delivery details for a physical prize. */
	public function claimed( array $spin, $wheel ) {
		$vars = $wheel ? $this->vars_for_spin( $spin, $wheel ) : array();
		$text = sprintf( "📦 %s #%d\n%s\n%s", Lang::t( 'درخواست تحویل جایزه', 'Prize claim' ), (int) $spin['id'], $spin['slice_label'], $vars['claim'] ?? '' );
		$self = $this;
		$this->defer(
			static function () use ( $self, $text, $vars, $spin ) {
				$self->messenger( $text );
				foreach ( Helpers::lines( becharkhoon()->settings->get( 'admin_emails' ) ?: get_option( 'admin_email' ) ) as $to ) {
					$self->email( $to, Lang::t( 'درخواست تحویل جایزه گردونه', 'Wheel prize claim' ), Lang::t( 'درخواست تحویل جایزه', 'Prize claim' ), nl2br( esc_html( $text ) ) );
				}
				if ( $vars ) {
					Sms::send_event( 'claim_admin', $vars, '', array( 'wheel_id' => (int) $spin['wheel_id'] ) );
				}
			}
		);
	}

	/** A wheel coupon was used in a paid order. */
	public function redeemed( $spin_id, $order ) {
		global $wpdb;
		$spin = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bch_spins WHERE id = %d", (int) $spin_id ), ARRAY_A );
		$wheel = $spin ? becharkhoon()->wheels->get( (int) $spin['wheel_id'] ) : null;
		if ( ! $spin || ! $wheel ) {
			return;
		}
		$phone = '' !== (string) $spin['phone'] ? $spin['phone'] : ( is_object( $order ) && method_exists( $order, 'get_billing_phone' ) ? Helpers::phone( $order->get_billing_phone() ) : '' );
		if ( '' === $phone || ! Sms::event_enabled( 'redeemed' ) ) {
			return;
		}
		$vars = $this->vars_for_spin( $spin, $wheel );
		if ( is_object( $order ) && method_exists( $order, 'get_order_number' ) ) {
			$vars['order_id']    = (string) $order->get_order_number();
			$vars['order_total'] = Helpers::money( (float) $order->get_total() );
		}
		$this->defer(
			static function () use ( $vars, $phone, $spin ) {
				Sms::send_event( 'redeemed', $vars, $phone, array( 'wheel_id' => (int) $spin['wheel_id'] ) );
			}
		);
	}

	/* ---------- Credits ---------- */

	public function credit_granted( $credit_id, array $rule, $qty, array $who ) {
		$wheel = $rule['wheel_id'] ? becharkhoon()->wheels->get( $rule['wheel_id'] ) : null;
		if ( ! $wheel ) {
			$active = becharkhoon()->wheels->active();
			$wheel  = $active ? $active[0] : null;
		}
		$fa    = Lang::is_fa();
		$phone = Helpers::phone( (string) ( $who['phone'] ?? '' ) );
		if ( '' === $phone && ! empty( $who['user_id'] ) ) {
			$phone = Helpers::phone( get_user_meta( (int) $who['user_id'], 'billing_phone', true ) );
		}
		$email = (string) ( $who['email'] ?? '' );
		if ( '' === $email && ! empty( $who['user_id'] ) ) {
			$u     = get_userdata( (int) $who['user_id'] );
			$email = $u ? $u->user_email : '';
		}
		$name = trim( (string) ( $who['name'] ?? '' ) );
		if ( '' === $name && ! empty( $who['user_id'] ) ) {
			$u    = get_userdata( (int) $who['user_id'] );
			$name = $u ? ( $u->first_name ?? '' ) : '';
			$name = '' !== $name ? $name : ( $u ? $u->display_name : '' );
		}
		$total = 0;
		if ( $wheel ) {
			$ctx                 = new \Becharkhoon\Engine\Context();
			$ctx->user_id        = (int) ( $who['user_id'] ?? 0 );
			$ctx->phone          = $phone;
			$ctx->phone_verified = '' !== $phone;
			$ctx->email          = strtolower( $email );
			$total               = \Becharkhoon\Credits\Ledger::balance( $ctx, (int) $wheel['id'], $wheel['config']['access']['credit_scope'] );
		}
		$num  = static function ( $n ) use ( $fa ) {
			return $fa ? Helpers::persian_digits( (string) $n ) : (string) $n;
		};
		$vars = array(
			'name'          => '' !== $name ? $name : Lang::t( 'مشتری', 'customer' ),
			'mobile'        => $phone,
			'email'         => $email,
			'n'             => $num( $qty ),
			'spins'         => $num( max( $total, (int) $qty ) ),
			'rule'          => '' !== (string) $rule['title'] ? $rule['title'] : Lang::t( 'هدیه', 'gift' ),
			'credit_expiry' => ! empty( $rule['expiry_days'] ) ? Helpers::human_date( time() + (int) $rule['expiry_days'] * DAY_IN_SECONDS ) : Lang::t( 'نامحدود', 'no expiry' ),
			'wheel'         => $wheel ? $wheel['title'] : '',
			'wheel_link'    => \Becharkhoon\Front\Frontend::wheel_url( $wheel ),
		) + SmsEvents::general_vars();
		if ( '' !== $phone ) {
			$vars['wheel_link'] = \Becharkhoon\Front\Guard::personal_link( $vars['wheel_link'], $phone ); // Opens already identified.
		}
		$vars['link'] = $vars['wheel_link'];
		$self = $this;
		// Wheel's own text for this message (wheel → Notifications), or the bulk-SMS text of this grant.
		$override = null;
		if ( isset( $rule['sms_text'] ) && '' !== trim( (string) $rule['sms_text'] ) ) {
			$override = array( 'mode' => 'text', 'text' => (string) $rule['sms_text'] );
		} elseif ( $wheel && ! empty( $wheel['config']['notify']['credit_override'] ) && '' !== trim( (string) $wheel['config']['notify']['credit_text'] ) ) {
			$override = array( 'mode' => 'text', 'text' => (string) $wheel['config']['notify']['credit_text'] );
		}
		$this->defer(
			static function () use ( $self, $rule, $phone, $email, $vars, $credit_id, $wheel, $override ) {
				if ( $rule['notify_sms'] && '' !== $phone ) {
					$opts = array( 'wheel_id' => $wheel ? (int) $wheel['id'] : 0 );
					if ( $override ) {
						$opts['override'] = $override;
						$opts['force']    = true;
					}
					Sms::send_event( 'credit', $vars, $phone, $opts );
				}
				if ( $rule['notify_email'] && is_email( $email ) ) {
					$text = Sms::render( Sms::template( 'credit' )['text'], $vars );
					$self->email( $email, Lang::t( '🎡 شانس چرخاندن گردونه گرفتید!', '🎡 You earned wheel spins!' ), Lang::t( 'شانس جدید!', 'New spins!' ), nl2br( esc_html( $text ) ), $vars['wheel_link'], Lang::t( 'بچرخون', 'Spin now' ) );
				}
				$self->webhook( 'credit', array( 'credit_id' => (int) $credit_id, 'rule' => $rule['id'], 'qty' => $vars['n'], 'phone' => $phone, 'email' => $email ) );
			}
		);
	}

	/* ---------- Channels ---------- */

	/** Free text SMS (bulk / custom) through the central sender + log. */
	public function sms( $to, $text, $tag = 'custom' ) {
		$r = Sms::send_many( array( array( 'mobile' => $to, 'text' => (string) $text ) ), $tag );
		return $r['sent'] > 0;
	}

	public function email( $to, $subject, $heading, $html_body, $button_url = '', $button_text = '' ) {
		$s     = becharkhoon()->settings;
		$color = (string) $s->get( 'email_color' );
		$btn   = '';
		if ( '' !== $button_url && '' !== $button_text ) {
			$btn = '<p style="text-align:center;margin:28px 0 8px"><a href="' . esc_url( $button_url ) . '" style="background:' . esc_attr( $color ) . ';color:#fff;padding:12px 26px;border-radius:10px;text-decoration:none;font-weight:700;display:inline-block">' . esc_html( $button_text ) . '</a></p>';
		}
		$body = wp_kses_post( $html_body ) . $btn;
		if ( 'woocommerce' === $s->get( 'email_template' ) && function_exists( 'WC' ) && WC()->mailer() ) {
			$message = WC()->mailer()->wrap_message( $heading, $body );
		} else {
			$message = $this->email_layout( $heading, $body );
		}
		$headers = array( 'Content-Type: text/html; charset=UTF-8' );
		$from    = (string) $s->get( 'email_from_address' );
		if ( is_email( $from ) ) {
			$name      = (string) $s->get( 'email_from_name' );
			$headers[] = 'From: ' . ( '' !== $name ? $name : get_bloginfo( 'name' ) ) . ' <' . $from . '>';
		}
		$ok = wp_mail( $to, wp_strip_all_tags( $subject ), $message, $headers );
		Logger::log( 'email', $ok ? 'ok' : 'error', ( $ok ? 'Email sent' : 'Email failed' ) . ' → ' . $to, array( 'subject' => $subject ) );
		return $ok;
	}

	private function email_layout( $heading, $body ) {
		$s     = becharkhoon()->settings;
		$color = esc_attr( (string) $s->get( 'email_color' ) );
		$logo  = (string) $s->get( 'email_logo' );
		$dir   = Lang::is_fa() ? 'rtl' : 'ltr';
		$align = Lang::is_fa() ? 'right' : 'left';
		$foot  = (string) $s->get( 'email_footer' );
		$foot  = '' !== $foot ? $foot : get_bloginfo( 'name' ) . ' — ' . home_url( '/' );
		return '<!doctype html><html dir="' . $dir . '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"></head>'
			. '<body style="margin:0;background:#f5f6fa;font-family:Vazirmatn,Tahoma,Arial,sans-serif;direction:' . $dir . '">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f5f6fa;padding:28px 12px"><tr><td align="center">'
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#fff;border-radius:18px;overflow:hidden;border:1px solid #e6e8f0">'
			. '<tr><td style="background:' . $color . ';padding:26px 28px;text-align:center;color:#fff">'
			. ( '' !== $logo ? '<img src="' . esc_url( $logo ) . '" alt="" style="max-height:48px;margin-bottom:10px"><br>' : '' )
			. '<span style="font-size:22px;font-weight:800">' . esc_html( $heading ) . '</span></td></tr>'
			. '<tr><td style="padding:26px 28px;color:#0f172a;font-size:15px;line-height:1.9;text-align:' . $align . '">' . $body . '</td></tr>'
			. '<tr><td style="padding:16px 28px;background:#f9fafc;color:#64748b;font-size:12px;text-align:center">' . esc_html( $foot ) . '</td></tr>'
			. '</table></td></tr></table></body></html>';
	}

	/** Bale + Telegram bots (admin alerts). */
	public function messenger( $text ) {
		$s  = becharkhoon()->settings;
		$ok = false;
		if ( '' !== $s->get( 'bale_token' ) && '' !== $s->get( 'bale_chat_id' ) ) {
			$r  = Http::request( 'POST', 'https://tapi.bale.ai/bot' . $s->get( 'bale_token' ) . '/sendMessage', array( 'json' => true, 'body' => array( 'chat_id' => $s->get( 'bale_chat_id' ), 'text' => $text ) ) );
			$ok = $r['ok'];
			Logger::log( 'messenger', $r['ok'] ? 'ok' : 'error', 'Bale: ' . ( $r['ok'] ? 'sent' : $r['error'] ), array( 'response' => mb_substr( $r['body'], 0, 300 ) ) );
		}
		if ( '' !== $s->get( 'telegram_token' ) && '' !== $s->get( 'telegram_chat_id' ) ) {
			$r  = Http::request( 'POST', rtrim( (string) $s->get( 'telegram_api' ), '/' ) . '/bot' . $s->get( 'telegram_token' ) . '/sendMessage', array( 'json' => true, 'body' => array( 'chat_id' => $s->get( 'telegram_chat_id' ), 'text' => $text ) ) );
			$ok = $ok || $r['ok'];
			Logger::log( 'messenger', $r['ok'] ? 'ok' : 'error', 'Telegram: ' . ( $r['ok'] ? 'sent' : $r['error'] ), array( 'response' => mb_substr( $r['body'], 0, 300 ) ) );
		}
		return $ok;
	}

	/** Signed JSON webhooks (n8n, Zapier, Make, your CRM…). */
	public function webhook( $event, array $data ) {
		foreach ( (array) becharkhoon()->settings->get( 'webhooks' ) as $hook ) {
			if ( empty( $hook['active'] ) || ( $hook['events'] && ! in_array( $event, $hook['events'], true ) ) ) {
				continue;
			}
			$body = wp_json_encode( array( 'event' => $event, 'site' => home_url( '/' ), 'time' => time(), 'data' => $data ), JSON_UNESCAPED_UNICODE );
			$h    = array( 'Content-Type' => 'application/json', 'X-Becharkhoon-Event' => $event );
			if ( '' !== $hook['secret'] ) {
				$h['X-Becharkhoon-Signature'] = 'sha256=' . hash_hmac( 'sha256', $body, $hook['secret'] );
			}
			$r = Http::request( 'POST', $hook['url'], array( 'headers' => $h, 'body' => $body, 'timeout' => 8 ) );
			Logger::log( 'webhook', $r['ok'] ? 'ok' : 'error', $event . ' → ' . $hook['url'] . ' (' . $r['code'] . ')' );
		}
	}

	/* ---------- OTP ---------- */

	public function otp( $phone, $code ) {
		$ttl = (int) becharkhoon()->settings->get( 'otp_ttl' );
		$min = (string) max( 1, (int) ceil( $ttl / 60 ) );
		$r   = Sms::send_event( 'otp', array( 'otp' => (string) $code, 'minutes' => Lang::is_fa() ? Helpers::persian_digits( $min ) : $min, 'mobile' => $phone ), $phone, array( 'force' => true ) );
		return $r['sent'] > 0;
	}

	/* ---------- Reminders (daily cron) ---------- */

	public function reminders() {
		global $wpdb;
		foreach ( becharkhoon()->wheels->active() as $wheel ) {
			$n = $wheel['config']['notify'];
			if ( ! $n['reminder'] ) {
				continue;
			}
			$from = Helpers::now();
			$to   = Helpers::now( max( 1, (int) $n['reminder_days'] ) * DAY_IN_SECONDS );
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bch_spins WHERE wheel_id = %d AND result = 'win' AND status = 'issued' AND expires_at BETWEEN %s AND %s AND (meta NOT LIKE %s OR meta IS NULL) LIMIT 300", $wheel['id'], $from, $to, '%"reminded":1%' ), ARRAY_A );
			foreach ( (array) $rows as $spin ) {
				$vars = $this->vars_for_spin( $spin, $wheel );
				if ( in_array( $n['reminder_channel'], array( 'sms', 'both' ), true ) && '' !== $spin['phone'] ) {
					Sms::send_event( 'reminder', $vars, $spin['phone'], array( 'wheel_id' => (int) $wheel['id'] ) );
				}
				if ( in_array( $n['reminder_channel'], array( 'email', 'both' ), true ) && is_email( $spin['email'] ) ) {
					$body = '' !== trim( wp_strip_all_tags( $n['reminder_email_body'] ) ) ? $n['reminder_email_body'] : nl2br( esc_html( Sms::template( 'reminder' )['text'] ) );
					$this->email( $spin['email'], Lang::t( '⏰ جایزه شما به‌زودی منقضی می‌شود', '⏰ Your prize expires soon' ), Lang::t( 'یادآوری جایزه', 'Prize reminder' ), Helpers::tpl( $body, array_map( 'esc_html', $vars ) ), $vars['link'], $n['email_button'] );
				}
				$meta             = Helpers::json_decode_array( $spin['meta'] );
				$meta['reminded'] = 1;
				$wpdb->update( $wpdb->prefix . 'bch_spins', array( 'meta' => wp_json_encode( $meta, JSON_UNESCAPED_UNICODE ) ), array( 'id' => (int) $spin['id'] ) );
			}
		}
	}
}
