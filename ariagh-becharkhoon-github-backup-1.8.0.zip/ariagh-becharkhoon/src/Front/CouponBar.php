<?php
/**
 * Sticky "your code is active" bar: server-side truth about the stored code.
 *
 * The browser keeps the last won code in localStorage and sends it with the (uncached) boot request.
 * The server answers with its real state so the bar disappears as soon as the code is used:
 *  - active   : not used, not expired → show (until it expires).
 *  - applied  : sitting in the current WooCommerce cart → hide (re-shows if removed from the cart).
 *  - used     : order placed / redeemed / usage limit reached → hide and forget.
 *  - expired  : past its expiry → hide and forget.
 *  - gone     : unknown or deleted → forget.
 *  - off      : the wheel's bar is turned off → hide.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Front;

use Becharkhoon\Engine\Context;
use Becharkhoon\Engine\SpinService;

defined( 'ABSPATH' ) || exit;

final class CouponBar {

	/** Display keys the bar needs in the browser (also sent when the wheel itself is not on this page). */
	public static function display_keys() {
		return array(
			'coupon_bar', 'coupon_bar_position', 'coupon_bar_text', 'coupon_bar_bg', 'coupon_bar_bg2', 'coupon_bar_color', 'coupon_bar_countdown', 'coupon_bar_apply',
			'coupon_bar_layout', 'coupon_bar_style', 'coupon_bar_icon', 'coupon_bar_code_style', 'coupon_bar_code_bg', 'coupon_bar_code_color',
			'coupon_bar_copy', 'coupon_bar_copy_label', 'coupon_bar_copy_bg', 'coupon_bar_copy_color', 'coupon_bar_apply_label', 'coupon_bar_apply_bg', 'coupon_bar_apply_color',
			'coupon_bar_btn_radius', 'coupon_bar_radius', 'coupon_bar_font', 'coupon_bar_shadow', 'coupon_bar_border', 'coupon_bar_close', 'coupon_bar_close_color',
			'coupon_bar_cd_style', 'coupon_bar_cd_color', 'coupon_bar_anim', 'coupon_bar_mobile_compact', 'coupon_bar_hide_applied',
		);
	}

	/** Minimal wheel config for rendering the bar. */
	public static function cfg( array $wheel ) {
		$c = $wheel['config'];
		$d = array();
		foreach ( self::display_keys() as $k ) {
			$d[ $k ] = $c['display'][ $k ] ?? null;
		}
		$resp = array( 'tablet' => array(), 'mobile' => array() );
		foreach ( array( 'tablet', 'mobile' ) as $dev ) {
			foreach ( (array) ( $c['responsive'][ $dev ] ?? array() ) as $k => $v ) {
				if ( 0 === strpos( (string) $k, 'display.coupon_bar' ) ) {
					$resp[ $dev ][ $k ] = $v;
				}
			}
			$resp[ $dev ] = (object) $resp[ $dev ];
		}
		return array(
			'id'       => (int) $wheel['id'],
			'lang'     => $c['lang'],
			'responsive' => $resp,
			'display'  => $d,
			'messages' => array(
				'copy_text'   => $c['messages']['copy_text'],
				'copied_text' => $c['messages']['copied_text'],
				'apply_text'  => $c['messages']['apply_text'],
			),
		);
	}

	/**
	 * @param Context $ctx  Visitor.
	 * @param mixed   $bar  {code, sid, w} from the browser, or empty.
	 * @return array|null
	 */
	public static function state( Context $ctx, $bar ) {
		$bar  = is_array( $bar ) ? $bar : array();
		$code = isset( $bar['code'] ) ? substr( sanitize_text_field( (string) $bar['code'] ), 0, 80 ) : '';
		$spin = null;
		global $wpdb;
		$t = $wpdb->prefix . 'bch_spins';
		if ( '' !== $code ) {
			$sid  = absint( $bar['sid'] ?? 0 );
			$norm = function_exists( 'wc_format_coupon_code' ) ? wc_format_coupon_code( $code ) : strtolower( trim( $code ) ); // WooCommerce codes are stored lower-case.
			if ( $sid ) {
				$spin = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id = %d AND coupon_code IN (%s, %s)", $sid, $code, $norm ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			}
			if ( ! $spin ) {
				$spin = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE coupon_code IN (%s, %s) AND result = 'win' ORDER BY id DESC LIMIT 1", $code, $norm ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			}
			if ( ! $spin ) {
				return array( 'status' => 'gone', 'code' => $code );
			}
		} elseif ( $ctx->user_id > 0 || ( $ctx->phone_verified && '' !== $ctx->phone ) ) {
			// Nothing stored on this device: the bar follows the account (won on another device/browser).
			$spin = self::latest_for( $ctx );
			if ( ! $spin ) {
				return null;
			}
		} else {
			return null;
		}

		$wheel = becharkhoon()->wheels->get( (int) $spin['wheel_id'] );
		if ( ! $wheel ) {
			return array( 'status' => 'gone', 'code' => $spin['coupon_code'] );
		}
		$status = self::status_of( $spin, $ctx );
		if ( '' === $code && 'active' !== $status ) {
			return null; // Account lookup only surfaces live codes.
		}
		if ( '' === $code && empty( $wheel['config']['display']['coupon_bar_account'] ) ) {
			return null;
		}
		if ( 'active' === $status && empty( $wheel['config']['display']['coupon_bar'] ) ) {
			$status = 'off';
		}
		if ( 'applied' === $status && empty( $wheel['config']['display']['coupon_bar_hide_applied'] ) ) {
			$status = 'active';
		}
		$shown = '' !== $code ? $code : self::display_code( $spin );
		$out   = array(
			'status' => $status,
			'code'   => $shown,
			'sid'    => (int) $spin['id'],
			'w'      => (int) $spin['wheel_id'],
		);
		if ( in_array( $status, array( 'active', 'applied' ), true ) ) {
			Frontend::lang_for( $wheel );
			$out['label'] = $spin['slice_label'];
			$out['exp']   = $spin['expires_at'] ? (int) strtotime( $spin['expires_at'] . ' UTC' ) : 0;
			$out['apply'] = SpinService::apply_url( $wheel['config']['messages'], $spin['prize_type'], $shown );
			$out['cfg']   = self::cfg( $wheel );
		}
		return apply_filters( 'becharkhoon_coupon_bar_state', $out, $spin, $ctx );
	}

	/** The code as the customer saw it (WooCommerce stores it lower-case). */
	private static function display_code( array $spin ) {
		if ( (int) $spin['coupon_id'] > 0 && function_exists( 'get_the_title' ) ) {
			$title = (string) get_the_title( (int) $spin['coupon_id'] );
			if ( '' !== $title && strtolower( $title ) === strtolower( (string) $spin['coupon_code'] ) ) {
				return $title;
			}
		}
		return (string) $spin['coupon_code'];
	}

	/** Real usage state of one won code. */
	public static function status_of( array $spin, Context $ctx ) {
		if ( 'redeemed' === $spin['status'] || 'cancelled' === $spin['status'] ) {
			return 'redeemed' === $spin['status'] ? 'used' : 'gone';
		}
		$now = time();
		if ( $spin['expires_at'] && strtotime( $spin['expires_at'] . ' UTC' ) <= $now ) {
			return 'expired';
		}
		$code = (string) $spin['coupon_code'];
		if ( (int) $spin['coupon_id'] > 0 || ( function_exists( 'wc_get_coupon_id_by_code' ) && wc_get_coupon_id_by_code( $code ) ) ) {
			$state = self::wc_state( $code, $spin, $ctx );
			if ( '' !== $state ) {
				return $state;
			}
		}
		if ( self::in_cart( $code ) ) {
			return 'applied';
		}
		return 'active';
	}

	/** WooCommerce coupon checks: deleted, expired, used up, or already used by this winner. */
	private static function wc_state( $code, array $spin, Context $ctx ) {
		if ( ! class_exists( '\WC_Coupon' ) ) {
			return '';
		}
		$id = wc_get_coupon_id_by_code( $code );
		if ( ! $id ) {
			return (int) $spin['coupon_id'] > 0 ? 'gone' : '';
		}
		$c   = new \WC_Coupon( $id );
		$exp = $c->get_date_expires();
		if ( $exp && $exp->getTimestamp() <= time() ) {
			return 'expired';
		}
		$limit = (int) $c->get_usage_limit();
		$count = (int) $c->get_usage_count();
		if ( $limit > 0 && $count >= $limit ) {
			return 'used';
		}
		// Shared/static coupons: used by this person (user id or billing email) counts as used for them.
		$who = array_filter( array( $spin['user_id'] ? (string) $spin['user_id'] : '', $ctx->user_id ? (string) $ctx->user_id : '', strtolower( (string) $spin['email'] ), strtolower( (string) $ctx->email ) ) );
		if ( $who && $count > 0 ) {
			$used_by = array_map( 'strtolower', array_map( 'strval', (array) $c->get_used_by() ) );
			if ( array_intersect( $who, $used_by ) ) {
				$per_user = (int) $c->get_usage_limit_per_user();
				if ( $per_user <= 1 || count( array_intersect( $used_by, $who ) ) >= $per_user ) {
					return 'used';
				}
			}
		}
		return '';
	}

	/** Is the code applied to the visitor's current cart? */
	public static function in_cart( $code ) {
		if ( ! function_exists( 'WC' ) || '' === $code ) {
			return false;
		}
		$wc = WC();
		if ( ! $wc ) {
			return false;
		}
		if ( null === $wc->cart && function_exists( 'wc_load_cart' ) && did_action( 'woocommerce_init' ) ) {
			try {
				wc_load_cart();
			} catch ( \Throwable $e ) {
				return false;
			}
		}
		if ( ! $wc->cart ) {
			return false;
		}
		$code = function_exists( 'wc_format_coupon_code' ) ? wc_format_coupon_code( $code ) : strtolower( $code );
		return (bool) $wc->cart->has_discount( $code );
	}

	/** Newest live coupon won by this account (user id or verified phone). */
	private static function latest_for( Context $ctx ) {
		global $wpdb;
		$t     = $wpdb->prefix . 'bch_spins';
		$where = array();
		$args  = array();
		if ( $ctx->user_id > 0 ) {
			$where[] = 'user_id = %d';
			$args[]  = (int) $ctx->user_id;
		}
		if ( $ctx->phone_verified && '' !== $ctx->phone ) {
			$where[] = 'phone = %s';
			$args[]  = $ctx->phone;
		}
		$args[] = gmdate( 'Y-m-d H:i:s' );
		$args[] = gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS );
		$sql    = "SELECT * FROM {$t} WHERE (" . implode( ' OR ', $where ) . ") AND result = 'win' AND status = 'issued' AND coupon_code <> '' AND (expires_at IS NULL OR expires_at > %s) AND created_at > %s ORDER BY id DESC LIMIT 1";
		return $wpdb->get_row( $wpdb->prepare( $sql, $args ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}
}
