<?php
/**
 * Leads (people who filled the wheel form): upsert by phone → email → account.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Engine;

use Becharkhoon\Core\Helpers;

defined( 'ABSPATH' ) || exit;

final class Leads {

	private static function t() {
		global $wpdb;
		return $wpdb->prefix . 'bch_leads';
	}

	/**
	 * Insert or update a lead.
	 *
	 * @param array $d phone, email, name, user_id, fields, consent, marketing, phone_verified, wheel_id, ip, won(bool).
	 * @return array{id:int,new:bool}
	 */
	public static function upsert( array $d ) {
		global $wpdb;
		$phone = (string) ( $d['phone'] ?? '' );
		$email = (string) ( $d['email'] ?? '' );
		$uid   = (int) ( $d['user_id'] ?? 0 );
		$row   = null;
		if ( '' !== $phone ) {
			$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t() . ' WHERE phone = %s ORDER BY id ASC LIMIT 1', $phone ), ARRAY_A ); // phpcs:ignore
		}
		if ( ! $row && '' !== $email ) {
			$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t() . ' WHERE email = %s ORDER BY id ASC LIMIT 1', $email ), ARRAY_A ); // phpcs:ignore
		}
		if ( ! $row && $uid ) {
			$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t() . ' WHERE user_id = %d ORDER BY id ASC LIMIT 1', $uid ), ARRAY_A ); // phpcs:ignore
		}
		$fields = isset( $d['fields'] ) && is_array( $d['fields'] ) ? $d['fields'] : array();
		$now    = Helpers::now();
		$won    = ! empty( $d['won'] ) ? 1 : 0;
		if ( $row ) {
			$merged = array_merge( Helpers::json_decode_array( $row['fields'] ), $fields );
			$wpdb->query(
				$wpdb->prepare(
					'UPDATE ' . self::t() . ' SET email = %s, phone = %s, name = %s, user_id = %d, fields = %s, consent = %d, marketing = %d, phone_verified = %d, spins = spins + %d, wins = wins + %d, ip = %s, updated_at = %s WHERE id = %d', // phpcs:ignore
					'' !== $email ? $email : $row['email'],
					'' !== $phone ? $phone : $row['phone'],
					'' !== (string) ( $d['name'] ?? '' ) ? $d['name'] : $row['name'],
					$uid ? $uid : (int) $row['user_id'],
					wp_json_encode( $merged, JSON_UNESCAPED_UNICODE ),
					! empty( $d['consent'] ) ? 1 : (int) $row['consent'],
					isset( $d['marketing'] ) ? (int) (bool) $d['marketing'] : (int) $row['marketing'],
					! empty( $d['phone_verified'] ) ? 1 : (int) $row['phone_verified'],
					! empty( $d['count_spin'] ) ? 1 : 0,
					$won,
					(string) ( $d['ip'] ?? '' ),
					$now,
					(int) $row['id']
				)
			);
			return array( 'id' => (int) $row['id'], 'new' => false );
		}
		if ( '' === $phone && '' === $email && ! $uid ) {
			return array( 'id' => 0, 'new' => false );
		}
		$wpdb->insert(
			self::t(),
			array(
				'email'          => $email,
				'phone'          => $phone,
				'name'           => (string) ( $d['name'] ?? '' ),
				'user_id'        => $uid,
				'fields'         => wp_json_encode( $fields, JSON_UNESCAPED_UNICODE ),
				'consent'        => ! empty( $d['consent'] ) ? 1 : 0,
				'marketing'      => ! empty( $d['marketing'] ) ? 1 : 0,
				'phone_verified' => ! empty( $d['phone_verified'] ) ? 1 : 0,
				'wheel_id'       => (int) ( $d['wheel_id'] ?? 0 ),
				'spins'          => ! empty( $d['count_spin'] ) ? 1 : 0,
				'wins'           => $won,
				'ip'             => (string) ( $d['ip'] ?? '' ),
				'created_at'     => $now,
				'updated_at'     => $now,
			)
		);
		$id = (int) $wpdb->insert_id;
		if ( $id ) {
			\Becharkhoon\Stats\Stats::add( (int) ( $d['wheel_id'] ?? 0 ), 'leads', 1 );
			if ( ! empty( $d['phone_verified'] ) || $uid ) {
				do_action( 'becharkhoon_lead_created', $id, $d );
			}
			do_action( 'becharkhoon_lead', $id, $d );
		}
		return array( 'id' => $id, 'new' => (bool) $id );
	}

	public static function query( array $args ) {
		global $wpdb;
		$where  = array( '1=1' );
		$params = array();
		if ( ! empty( $args['search'] ) ) {
			$s       = '%' . $wpdb->esc_like( Helpers::latin_digits( $args['search'] ) ) . '%';
			$where[] = '(phone LIKE %s OR email LIKE %s OR name LIKE %s)';
			$params  = array_merge( $params, array( $s, $s, $s ) );
		}
		if ( ! empty( $args['wheel_id'] ) ) {
			$where[]  = 'wheel_id = %d';
			$params[] = (int) $args['wheel_id'];
		}
		if ( ! empty( $args['marketing'] ) ) {
			$where[] = 'marketing = 1';
		}
		if ( ! empty( $args['verified'] ) ) {
			$where[] = 'phone_verified = 1';
		}
		$w     = implode( ' AND ', $where );
		$per   = max( 1, min( 5000, (int) ( $args['per_page'] ?? 30 ) ) );
		$page  = max( 1, (int) ( $args['page'] ?? 1 ) );
		$total = (int) $wpdb->get_var( $params ? $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::t() . " WHERE $w", $params ) : 'SELECT COUNT(*) FROM ' . self::t() . " WHERE $w" ); // phpcs:ignore
		$q     = array_merge( $params, array( $per, ( $page - 1 ) * $per ) );
		$rows  = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t() . " WHERE $w ORDER BY id DESC LIMIT %d OFFSET %d", $q ), ARRAY_A ); // phpcs:ignore
		foreach ( $rows as &$r ) {
			$r['fields'] = Helpers::json_decode_array( $r['fields'] );
		}
		unset( $r );
		return array( 'items' => $rows, 'total' => $total );
	}
}
