<?php
/**
 * Small pure helpers: types, phones, IPs, digits, dates, templates.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Core;

defined( 'ABSPATH' ) || exit;

final class Helpers {

	public static function bool( $v ) {
		if ( is_string( $v ) ) {
			return in_array( strtolower( $v ), array( '1', 'true', 'yes', 'on' ), true );
		}
		return (bool) $v;
	}

	/** Accept #rgb, #rrggbb, #rrggbbaa, rgb()/rgba()/hsl() and "transparent". */
	public static function color( $v, $fallback = '' ) {
		$v = trim( (string) $v );
		if ( '' === $v ) {
			return $fallback;
		}
		if ( preg_match( '/^#([0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/i', $v ) ) {
			return strtolower( $v );
		}
		if ( preg_match( '/^(rgba?|hsla?)\(\s*[0-9.%\s,\/-]+\)$/i', $v ) || 'transparent' === strtolower( $v ) ) {
			return $v;
		}
		return $fallback;
	}

	/** Convert Persian/Arabic digits to Latin. */
	public static function latin_digits( $s ) {
		return strtr(
			(string) $s,
			array(
				'۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
				'٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
			)
		);
	}

	public static function persian_digits( $s ) {
		return strtr( (string) $s, array( '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴', '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹' ) );
	}

	/**
	 * Normalize a phone number. Iranian mobiles become 09XXXXXXXXX.
	 * Returns '' when the number is not valid.
	 *
	 * @param string $raw     Input.
	 * @param string $country 'IR' or 'INTL'.
	 */
	public static function phone( $raw, $country = 'IR' ) {
		$p = preg_replace( '/[^0-9+]/', '', self::latin_digits( (string) $raw ) );
		if ( '' === $p ) {
			return '';
		}
		if ( 'IR' === $country ) {
			$p = preg_replace( '/^(\+98|0098|98)/', '0', $p );
			if ( preg_match( '/^9\d{9}$/', $p ) ) {
				$p = '0' . $p;
			}
			return preg_match( '/^09\d{9}$/', $p ) ? $p : '';
		}
		$p = preg_replace( '/^00/', '+', $p );
		return preg_match( '/^\+?\d{7,15}$/', $p ) ? $p : '';
	}

	/** International form for gateways that need it (98912...). */
	public static function phone_intl( $phone ) {
		$phone = (string) $phone;
		if ( preg_match( '/^09\d{9}$/', $phone ) ) {
			return '98' . substr( $phone, 1 );
		}
		return ltrim( $phone, '+' );
	}

	public static function email( $raw ) {
		$e = strtolower( trim( self::latin_digits( (string) $raw ) ) );
		return is_email( $e ) ? $e : '';
	}

	/** Visitor IP honouring the configured proxy/CDN header. */
	public static function ip( $source = 'auto' ) {
		$candidates = array();
		if ( 'cloudflare' === $source || 'auto' === $source ) {
			$candidates[] = 'HTTP_CF_CONNECTING_IP';
		}
		if ( 'arvan' === $source || 'auto' === $source ) {
			$candidates[] = 'HTTP_AR_REAL_IP';
		}
		if ( 'xff' === $source ) {
			$candidates[] = 'HTTP_X_FORWARDED_FOR';
		}
		if ( 'auto' === $source ) {
			$candidates[] = 'HTTP_X_REAL_IP';
		}
		foreach ( $candidates as $h ) {
			if ( ! empty( $_SERVER[ $h ] ) ) {
				$ip = trim( explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $h ] ) ) )[0] );
				if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
					return $ip;
				}
			}
		}
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
	}

	/** Country code from CDN headers (Cloudflare / ArvanCloud), '' when unknown. */
	public static function country() {
		foreach ( array( 'HTTP_CF_IPCOUNTRY', 'HTTP_AR_COUNTRY', 'HTTP_X_COUNTRY_CODE', 'GEOIP_COUNTRY_CODE' ) as $h ) {
			if ( ! empty( $_SERVER[ $h ] ) ) {
				$c = strtoupper( substr( sanitize_text_field( wp_unslash( $_SERVER[ $h ] ) ), 0, 2 ) );
				if ( preg_match( '/^[A-Z]{2}$/', $c ) ) {
					return $c;
				}
			}
		}
		return '';
	}

	/** Current time in UTC MySQL format. */
	public static function now( $offset = 0 ) {
		return gmdate( 'Y-m-d H:i:s', time() + (int) $offset );
	}

	/** Site-local "Y-m-d" day. */
	public static function today() {
		return wp_date( 'Y-m-d' );
	}

	/**
	 * Start of a limit window in UTC MySQL format.
	 *
	 * @param string $period lifetime|hour|day|week|month|rolling.
	 * @param int    $hours  For rolling windows.
	 */
	public static function period_start( $period, $hours = 24 ) {
		$tz  = wp_timezone();
		$now = new \DateTimeImmutable( 'now', $tz );
		switch ( $period ) {
			case 'hour':
				$s = $now->setTime( (int) $now->format( 'H' ), 0, 0 );
				break;
			case 'day':
				$s = $now->setTime( 0, 0, 0 );
				break;
			case 'week':
				// Week starts on the site's "start_of_week" (Saturday in Iran).
				$sow  = (int) get_option( 'start_of_week', 6 );
				$dow  = (int) $now->format( 'w' );
				$diff = ( $dow - $sow + 7 ) % 7;
				$s    = $now->setTime( 0, 0, 0 )->modify( '-' . $diff . ' days' );
				break;
			case 'month':
				$s = $now->setTime( 0, 0, 0 )->setDate( (int) $now->format( 'Y' ), (int) $now->format( 'n' ), 1 );
				break;
			case 'rolling':
				$s = $now->modify( '-' . max( 1, (int) $hours ) . ' hours' );
				break;
			default:
				return '1970-01-01 00:00:00';
		}
		return $s->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
	}

	/** End of the current window (for "next spin at" countdowns), unix time or 0. */
	public static function period_end( $period, $hours = 24 ) {
		$start = strtotime( self::period_start( $period, $hours ) . ' UTC' );
		switch ( $period ) {
			case 'hour':
				return $start + HOUR_IN_SECONDS;
			case 'day':
				return ( new \DateTimeImmutable( '@' . $start ) )->setTimezone( wp_timezone() )->modify( '+1 day' )->getTimestamp();
			case 'week':
				return ( new \DateTimeImmutable( '@' . $start ) )->setTimezone( wp_timezone() )->modify( '+7 days' )->getTimestamp();
			case 'month':
				return ( new \DateTimeImmutable( '@' . $start ) )->setTimezone( wp_timezone() )->modify( '+1 month' )->getTimestamp();
		}
		return 0;
	}

	/** Gregorian → Jalali [y, m, d]. */
	public static function g2j( $gy, $gm, $gd ) {
		$g_d_m = array( 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 );
		$gy2   = ( $gm > 2 ) ? ( $gy + 1 ) : $gy;
		$days  = 355666 + ( 365 * $gy ) + (int) ( ( $gy2 + 3 ) / 4 ) - (int) ( ( $gy2 + 99 ) / 100 ) + (int) ( ( $gy2 + 399 ) / 400 ) + $gd + $g_d_m[ $gm - 1 ];
		$jy    = -1595 + ( 33 * (int) ( $days / 12053 ) );
		$days %= 12053;
		$jy   += 4 * (int) ( $days / 1461 );
		$days %= 1461;
		if ( $days > 365 ) {
			$jy  += (int) ( ( $days - 1 ) / 365 );
			$days = ( $days - 1 ) % 365;
		}
		if ( $days < 186 ) {
			$jm = 1 + (int) ( $days / 31 );
			$jd = 1 + ( $days % 31 );
		} else {
			$jm = 7 + (int) ( ( $days - 186 ) / 30 );
			$jd = 1 + ( ( $days - 186 ) % 30 );
		}
		return array( $jy, $jm, $jd );
	}

	/**
	 * Human date for messages (site timezone, Jalali when enabled).
	 *
	 * @param string|int $when UTC MySQL datetime or timestamp.
	 */
	public static function human_date( $when, $with_time = false ) {
		if ( empty( $when ) ) {
			return '';
		}
		$ts = is_numeric( $when ) ? (int) $when : strtotime( $when . ' UTC' );
		$s  = becharkhoon()->settings;
		if ( $s->get( 'jalali_dates' ) && Lang::is_fa() ) {
			$d = new \DateTimeImmutable( '@' . $ts );
			$d = $d->setTimezone( wp_timezone() );
			list( $jy, $jm, $jd ) = self::g2j( (int) $d->format( 'Y' ), (int) $d->format( 'n' ), (int) $d->format( 'j' ) );
			$out = sprintf( '%04d/%02d/%02d', $jy, $jm, $jd ) . ( $with_time ? ' ' . $d->format( 'H:i' ) : '' );
		} else {
			$out = wp_date( get_option( 'date_format', 'Y-m-d' ) . ( $with_time ? ' H:i' : '' ), $ts );
		}
		return $s->get( 'persian_digits' ) && Lang::is_fa() ? self::persian_digits( $out ) : $out;
	}

	/** Mask a name / phone / email for public social-proof displays. */
	public static function mask( $s ) {
		$s = trim( (string) $s );
		if ( '' === $s ) {
			return '';
		}
		if ( preg_match( '/^0?9\d{9}$/', $s ) ) {
			return substr( $s, 0, 4 ) . '***' . substr( $s, -2 );
		}
		if ( false !== strpos( $s, '@' ) ) {
			$parts = explode( '@', $s );
			return mb_substr( $parts[0], 0, 2 ) . '***';
		}
		$first = preg_split( '/\s+/u', $s )[0];
		return mb_strlen( $first ) > 2 ? mb_substr( $first, 0, 2 ) . '***' : $first . '***';
	}

	/** Replace {placeholders} (values are plain text). */
	public static function tpl( $text, array $vars ) {
		$map = array();
		foreach ( $vars as $k => $v ) {
			$map[ '{' . $k . '}' ] = is_scalar( $v ) ? (string) $v : '';
		}
		return strtr( (string) $text, $map );
	}

	/** Money in the shop's format without HTML. */
	public static function money( $amount ) {
		$amount = (float) $amount;
		$label  = (string) becharkhoon()->settings->get( 'currency_label' );
		if ( function_exists( 'wc_price' ) && '' === $label ) {
			$txt = html_entity_decode( wp_strip_all_tags( wc_price( $amount ) ), ENT_QUOTES, 'UTF-8' );
		} else {
			$txt = number_format_i18n( $amount ) . ( '' !== $label ? ' ' . $label : '' );
		}
		return Lang::is_fa() && becharkhoon()->settings->get( 'persian_digits' ) ? self::persian_digits( $txt ) : $txt;
	}

	/** Lines of a textarea as a clean list. */
	public static function lines( $text ) {
		return array_values( array_filter( array_map( 'trim', preg_split( '/[\r\n,]+/', (string) $text ) ) ) );
	}

	/** Random alphanumeric string from a charset, using a CSPRNG. */
	public static function random_string( $length, $charset = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789' ) {
		$out = '';
		$max = strlen( $charset ) - 1;
		for ( $i = 0; $i < $length; $i++ ) {
			$out .= $charset[ random_int( 0, $max ) ];
		}
		return $out;
	}

	/** Stable 64-char token (hex). */
	public static function token() {
		return bin2hex( random_bytes( 24 ) );
	}

	public static function json_decode_array( $json ) {
		if ( is_array( $json ) ) {
			return $json;
		}
		$d = json_decode( (string) $json, true );
		return is_array( $d ) ? $d : array();
	}
}
