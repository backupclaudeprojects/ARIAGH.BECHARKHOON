<?php
/**
 * Spin credits ledger: grants (with expiry, idempotency key) and atomic consumption.
 *
 * A credit row = qty spins, of which `used` were consumed. wheel_id 0 = valid on any wheel.
 * Credits belong to an account (user_id) and/or a phone number; a guest can only use
 * phone credits after verifying that phone with an OTP.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Credits;

use Becharkhoon\Core\Helpers;
use Becharkhoon\Engine\Context;

defined( 'ABSPATH' ) || exit;

final class Ledger {

	public static function t() {
		global $wpdb;
		return $wpdb->prefix . 'bch_credits';
	}

	/**
	 * Grant spins. Returns the new row id, or 0 when the idempotency key already exists.
	 *
	 * @param array $a wheel_id, user_id, phone, email, qty, reason, rule_id, ref_type, ref_id, uniq, note, expires_days, created_by.
	 */
	public static function grant( array $a ) {
		global $wpdb;
		$qty = max( 1, min( 1000, (int) ( $a['qty'] ?? 1 ) ) );
		$uid = (int) ( $a['user_id'] ?? 0 );
		$ph  = Helpers::phone( $a['phone'] ?? '', becharkhoon()->settings->get( 'phone_country' ) );
		$em  = Helpers::email( $a['email'] ?? '' );
		if ( ! $uid && '' === $ph && '' === $em ) {
			return 0;
		}
		if ( $uid && '' === $ph ) {
			$ph = Helpers::phone( get_user_meta( $uid, 'billing_phone', true ) );
		}
		$uniq = isset( $a['uniq'] ) && '' !== $a['uniq'] ? substr( (string) $a['uniq'], 0, 160 ) : null;
		if ( null !== $uniq && $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::t() . ' WHERE uniq = %s', $uniq ) ) ) { // phpcs:ignore
			return 0;
		}
		$days = (int) ( $a['expires_days'] ?? 0 );
		$ok   = $wpdb->insert(
			self::t(),
			array(
				'wheel_id'   => (int) ( $a['wheel_id'] ?? 0 ),
				'user_id'    => $uid,
				'phone'      => $ph,
				'email'      => $em,
				'qty'        => $qty,
				'used'       => 0,
				'reason'     => substr( sanitize_key( $a['reason'] ?? 'manual' ), 0, 40 ),
				'rule_id'    => substr( sanitize_key( $a['rule_id'] ?? '' ), 0, 40 ),
				'ref_type'   => substr( sanitize_key( $a['ref_type'] ?? '' ), 0, 20 ),
				'ref_id'     => (int) ( $a['ref_id'] ?? 0 ),
				'uniq'       => $uniq,
				'note'       => mb_substr( sanitize_text_field( $a['note'] ?? '' ), 0, 255 ),
				'status'     => 'active',
				'created_by' => (int) ( $a['created_by'] ?? 0 ),
				'created_at' => Helpers::now(),
				'expires_at' => $days > 0 ? Helpers::now( $days * DAY_IN_SECONDS ) : null,
			)
		);
		if ( ! $ok ) {
			return 0; // Unique-key race: someone else granted it first.
		}
		$id = (int) $wpdb->insert_id;
		do_action( 'becharkhoon_credit_granted', $id, $a, $qty );
		return $id;
	}

	/**
	 * WHERE clause matching the credits a context may use.
	 *
	 * @return array{0:string,1:array}|null
	 */
	private static function owner_where( Context $ctx ) {
		$parts  = array();
		$params = array();
		if ( $ctx->user_id ) {
			$parts[]  = 'user_id = %d';
			$params[] = (int) $ctx->user_id;
		}
		if ( '' !== $ctx->phone && ( $ctx->user_id || $ctx->phone_verified ) ) {
			$parts[]  = '(phone = %s AND (user_id = 0' . ( $ctx->user_id ? ' OR user_id = %d' : '' ) . '))';
			$params[] = $ctx->phone;
			if ( $ctx->user_id ) {
				$params[] = (int) $ctx->user_id;
			}
		}
		if ( $ctx->user_id && '' !== $ctx->email ) {
			$parts[]  = '(email = %s AND user_id = 0)';
			$params[] = $ctx->email;
		}
		if ( ! $parts ) {
			return null;
		}
		return array( '(' . implode( ' OR ', $parts ) . ')', $params );
	}

	private static function scope_where( $wheel_id, $scope ) {
		return 'this' === $scope ? array( 'wheel_id = %d', array( (int) $wheel_id ) ) : array( '(wheel_id = %d OR wheel_id = 0)', array( (int) $wheel_id ) );
	}

	/** Remaining spins for a context on a wheel. */
	public static function balance( Context $ctx, $wheel_id, $scope = 'any' ) {
		global $wpdb;
		$owner = self::owner_where( $ctx );
		if ( ! $owner ) {
			return 0;
		}
		list( $sw, $sp ) = self::scope_where( $wheel_id, $scope );
		$params          = array_merge( $sp, $owner[1], array( Helpers::now() ) );
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(SUM(qty - used),0) FROM ' . self::t() . " WHERE status = 'active' AND used < qty AND $sw AND {$owner[0]} AND (expires_at IS NULL OR expires_at > %s)", $params ) ); // phpcs:ignore
	}

	/** Consume one spin atomically. Returns the credit row id or 0. */
	public static function consume( Context $ctx, $wheel_id, $scope = 'any' ) {
		global $wpdb;
		$owner = self::owner_where( $ctx );
		if ( ! $owner ) {
			return 0;
		}
		list( $sw, $sp ) = self::scope_where( $wheel_id, $scope );
		$params          = array_merge( $sp, $owner[1], array( Helpers::now() ) );
		// Wheel-specific credits first, then the ones expiring soonest.
		$ids = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM ' . self::t() . " WHERE status = 'active' AND used < qty AND $sw AND {$owner[0]} AND (expires_at IS NULL OR expires_at > %s) ORDER BY (wheel_id = 0) ASC, (expires_at IS NULL) ASC, expires_at ASC, id ASC LIMIT 20", $params ) ); // phpcs:ignore
		foreach ( $ids as $id ) {
			if ( $wpdb->query( $wpdb->prepare( 'UPDATE ' . self::t() . ' SET used = used + 1 WHERE id = %d AND used < qty', $id ) ) ) { // phpcs:ignore
				return (int) $id;
			}
		}
		return 0;
	}

	/** Undo a consumption (fulfilment failed). */
	public static function refund( $credit_id ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::t() . ' SET used = used - 1 WHERE id = %d AND used > 0', $credit_id ) ); // phpcs:ignore
	}

	/** Revoke the unused part of credits granted for a reference (e.g. a refunded order). */
	public static function revoke_ref( $ref_type, $ref_id ) {
		global $wpdb;
		return (int) $wpdb->query( $wpdb->prepare( 'UPDATE ' . self::t() . " SET qty = used, status = 'revoked' WHERE ref_type = %s AND ref_id = %d AND status = 'active'", $ref_type, $ref_id ) ); // phpcs:ignore
	}

	public static function revoke( $id ) {
		global $wpdb;
		return (bool) $wpdb->query( $wpdb->prepare( 'UPDATE ' . self::t() . " SET qty = used, status = 'revoked' WHERE id = %d", $id ) ); // phpcs:ignore
	}

	/** How many credits a rule already granted to an identity (max-per-user rules). */
	public static function granted_by_rule( $rule_id, $user_id, $phone ) {
		global $wpdb;
		$parts  = array();
		$params = array( $rule_id );
		if ( $user_id ) {
			$parts[]  = 'user_id = %d';
			$params[] = (int) $user_id;
		}
		if ( '' !== (string) $phone ) {
			$parts[]  = 'phone = %s';
			$params[] = $phone;
		}
		if ( ! $parts ) {
			return 0;
		}
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(SUM(qty),0) FROM ' . self::t() . ' WHERE rule_id = %s AND (' . implode( ' OR ', $parts ) . ')', $params ) ); // phpcs:ignore
	}

	/** Admin listing. */
	public static function query( array $args ) {
		global $wpdb;
		$where  = array( '1=1' );
		$params = array();
		if ( ! empty( $args['search'] ) ) {
			$s        = '%' . $wpdb->esc_like( Helpers::latin_digits( $args['search'] ) ) . '%';
			$where[]  = '(phone LIKE %s OR email LIKE %s OR note LIKE %s OR user_id IN (SELECT ID FROM ' . $wpdb->users . ' WHERE user_login LIKE %s OR display_name LIKE %s OR user_email LIKE %s))';
			$params   = array_merge( $params, array( $s, $s, $s, $s, $s, $s ) );
		}
		if ( ! empty( $args['wheel_id'] ) ) {
			$where[]  = 'wheel_id = %d';
			$params[] = (int) $args['wheel_id'];
		}
		if ( ! empty( $args['reason'] ) ) {
			$where[]  = 'reason = %s';
			$params[] = sanitize_key( $args['reason'] );
		}
		if ( ! empty( $args['status'] ) ) {
			if ( 'available' === $args['status'] ) {
				$where[]  = "status = 'active' AND used < qty AND (expires_at IS NULL OR expires_at > %s)";
				$params[] = Helpers::now();
			} else {
				$where[]  = 'status = %s';
				$params[] = sanitize_key( $args['status'] );
			}
		}
		$w     = implode( ' AND ', $where );
		$per   = max( 1, min( 200, (int) ( $args['per_page'] ?? 30 ) ) );
		$page  = max( 1, (int) ( $args['page'] ?? 1 ) );
		$total = (int) $wpdb->get_var( $params ? $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::t() . " WHERE $w", $params ) : 'SELECT COUNT(*) FROM ' . self::t() . " WHERE $w" ); // phpcs:ignore
		$q     = array_merge( $params, array( $per, ( $page - 1 ) * $per ) );
		$rows  = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t() . " WHERE $w ORDER BY id DESC LIMIT %d OFFSET %d", $q ), ARRAY_A ); // phpcs:ignore
		foreach ( $rows as &$r ) {
			$r['user_name'] = '';
			if ( (int) $r['user_id'] ) {
				$u              = get_userdata( (int) $r['user_id'] );
				$r['user_name'] = $u ? $u->display_name : '#' . $r['user_id'];
			}
			$r['left'] = max( 0, (int) $r['qty'] - (int) $r['used'] );
		}
		unset( $r );
		return array( 'items' => $rows, 'total' => $total );
	}

	/** Totals for the dashboard. */
	public static function totals() {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT COALESCE(SUM(qty),0) AS granted, COALESCE(SUM(used),0) AS used, COALESCE(SUM(CASE WHEN status = \'active\' AND (expires_at IS NULL OR expires_at > %s) THEN qty - used ELSE 0 END),0) AS available FROM ' . self::t(), Helpers::now() ), ARRAY_A ); // phpcs:ignore
		return array_map( 'intval', (array) $row );
	}
}
