<?php
/**
 * Database schema, activation, upgrades and deactivation.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Core;

defined( 'ABSPATH' ) || exit;

final class Installer {

	const OPTION_DB = 'bch_db_version';

	/** Table names (without prefix). */
	public static function tables() {
		return array( 'bch_wheels', 'bch_spins', 'bch_leads', 'bch_credits', 'bch_stats', 'bch_codes', 'bch_stock', 'bch_log', 'bch_sms', 'bch_orders', 'bch_bulk', 'bch_bulk_items' );
	}

	public static function activate( $network_wide = false ) {
		if ( is_multisite() && $network_wide ) {
			foreach ( get_sites( array( 'fields' => 'ids', 'number' => 500 ) ) as $site_id ) {
				switch_to_blog( $site_id );
				self::install();
				restore_current_blog();
			}
			return;
		}
		self::install();
	}

	public static function install() {
		self::create_tables();
		Capabilities::add();
		if ( false === get_option( Settings::OPTION, false ) ) {
			add_option( Settings::OPTION, Settings::defaults(), '', false );
		}
		if ( ! get_option( 'bch_secret' ) ) {
			add_option( 'bch_secret', wp_generate_password( 64, true, true ), '', false );
		}
		update_option( self::OPTION_DB, BCH_DB_VERSION, false );
		if ( ! get_option( 'bch_installed_at' ) ) {
			add_option( 'bch_installed_at', time(), '', false );
			set_transient( 'bch_activation_redirect', 1, 60 );
		}
		\Becharkhoon\Front\Account::add_endpoint();
		flush_rewrite_rules( false );
		\Becharkhoon\Core\Cron::schedule();
	}

	/** Runs on every load: cheap version check, upgrades when needed. */
	public static function maybe_upgrade() {
		$from = (int) get_option( self::OPTION_DB );
		if ( $from < BCH_DB_VERSION ) {
			self::install();
			if ( $from && $from < 4 ) {
				self::migrate_sms_templates();
			}
			if ( $from < 5 ) {
				// v5: mirror past WooCommerce orders that used wheel codes (real discounts in Reports).
				\Becharkhoon\Stats\Orders::restart( true );
			}
		}
	}

	/** v4: OTP text/pattern moved from separate settings into the central SMS messages. */
	public static function migrate_sms_templates() {
		$opt = get_option( Settings::OPTION, array() );
		if ( ! is_array( $opt ) || isset( $opt['sms_tpl']['otp'] ) ) {
			return;
		}
		$otp = array( 'on' => true, 'mode' => ( $opt['otp_mode'] ?? 'text' ) === 'pattern' ? 'pattern' : 'text' );
		if ( ! empty( $opt['otp_text'] ) ) {
			$otp['text'] = str_replace( '{code}', '{otp}', (string) $opt['otp_text'] );
		}
		if ( ! empty( $opt['otp_pattern'] ) ) {
			$otp['code']   = (string) $opt['otp_pattern'];
			$otp['params'] = ( '' !== (string) ( $opt['otp_pattern_var'] ?? '' ) ? $opt['otp_pattern_var'] : 'code' ) . '={otp}';
		}
		$opt['sms_tpl']        = isset( $opt['sms_tpl'] ) && is_array( $opt['sms_tpl'] ) ? $opt['sms_tpl'] : array();
		$opt['sms_tpl']['otp'] = $otp;
		update_option( Settings::OPTION, $opt, true );
	}

	public static function deactivate() {
		\Becharkhoon\Core\Cron::unschedule();
		flush_rewrite_rules( false );
	}

	public static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		$p = $wpdb->prefix;

		$sql = array();

		$sql[] = "CREATE TABLE {$p}bch_wheels (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			title varchar(190) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT 'draft',
			priority int(11) NOT NULL DEFAULT 10,
			ab_group varchar(40) NOT NULL DEFAULT '',
			config longtext NOT NULL,
			created_at datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
			updated_at datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
			PRIMARY KEY  (id),
			KEY status (status)
		) $c;";

		$sql[] = "CREATE TABLE {$p}bch_spins (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			wheel_id bigint(20) unsigned NOT NULL DEFAULT 0,
			slice_id varchar(40) NOT NULL DEFAULT '',
			slice_label varchar(190) NOT NULL DEFAULT '',
			prize_type varchar(30) NOT NULL DEFAULT '',
			prize_value varchar(190) NOT NULL DEFAULT '',
			result varchar(10) NOT NULL DEFAULT 'lose',
			status varchar(20) NOT NULL DEFAULT 'issued',
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			lead_id bigint(20) unsigned NOT NULL DEFAULT 0,
			email varchar(190) NOT NULL DEFAULT '',
			phone varchar(32) NOT NULL DEFAULT '',
			name varchar(190) NOT NULL DEFAULT '',
			ip varchar(64) NOT NULL DEFAULT '',
			device varchar(64) NOT NULL DEFAULT '',
			coupon_code varchar(80) NOT NULL DEFAULT '',
			coupon_id bigint(20) unsigned NOT NULL DEFAULT 0,
			order_id bigint(20) unsigned NOT NULL DEFAULT 0,
			revenue decimal(20,4) NOT NULL DEFAULT 0,
			credit_id bigint(20) unsigned NOT NULL DEFAULT 0,
			is_free tinyint(1) NOT NULL DEFAULT 1,
			source varchar(30) NOT NULL DEFAULT '',
			page_url varchar(255) NOT NULL DEFAULT '',
			meta longtext NULL,
			created_at datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
			expires_at datetime NULL DEFAULT NULL,
			redeemed_at datetime NULL DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY wheel_created (wheel_id,created_at),
			KEY user_id (user_id),
			KEY phone (phone),
			KEY email (email),
			KEY device (device),
			KEY ip (ip),
			KEY coupon_code (coupon_code),
			KEY status (status)
		) $c;";

		$sql[] = "CREATE TABLE {$p}bch_leads (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			email varchar(190) NOT NULL DEFAULT '',
			phone varchar(32) NOT NULL DEFAULT '',
			name varchar(190) NOT NULL DEFAULT '',
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			fields longtext NULL,
			consent tinyint(1) NOT NULL DEFAULT 0,
			marketing tinyint(1) NOT NULL DEFAULT 0,
			phone_verified tinyint(1) NOT NULL DEFAULT 0,
			wheel_id bigint(20) unsigned NOT NULL DEFAULT 0,
			spins int(11) NOT NULL DEFAULT 0,
			wins int(11) NOT NULL DEFAULT 0,
			ip varchar(64) NOT NULL DEFAULT '',
			tags varchar(255) NOT NULL DEFAULT '',
			created_at datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
			updated_at datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
			PRIMARY KEY  (id),
			KEY email (email),
			KEY phone (phone),
			KEY user_id (user_id)
		) $c;";

		$sql[] = "CREATE TABLE {$p}bch_credits (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			wheel_id bigint(20) unsigned NOT NULL DEFAULT 0,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			phone varchar(32) NOT NULL DEFAULT '',
			email varchar(190) NOT NULL DEFAULT '',
			qty int(11) NOT NULL DEFAULT 1,
			used int(11) NOT NULL DEFAULT 0,
			reason varchar(40) NOT NULL DEFAULT '',
			rule_id varchar(40) NOT NULL DEFAULT '',
			ref_type varchar(20) NOT NULL DEFAULT '',
			ref_id bigint(20) unsigned NOT NULL DEFAULT 0,
			uniq varchar(160) NULL DEFAULT NULL,
			note varchar(255) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT 'active',
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
			expires_at datetime NULL DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY uniq (uniq),
			KEY user_id (user_id),
			KEY phone (phone),
			KEY email (email),
			KEY ref (ref_type,ref_id)
		) $c;";

		$sql[] = "CREATE TABLE {$p}bch_stats (
			wheel_id bigint(20) unsigned NOT NULL DEFAULT 0,
			day date NOT NULL DEFAULT '1970-01-01',
			metric varchar(24) NOT NULL DEFAULT '',
			value decimal(20,4) NOT NULL DEFAULT 0,
			PRIMARY KEY  (wheel_id,day,metric)
		) $c;";

		$sql[] = "CREATE TABLE {$p}bch_codes (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			wheel_id bigint(20) unsigned NOT NULL DEFAULT 0,
			slice_id varchar(40) NOT NULL DEFAULT '',
			code varchar(190) NOT NULL DEFAULT '',
			spin_id bigint(20) unsigned NOT NULL DEFAULT 0,
			assigned_at datetime NULL DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY pool (wheel_id,slice_id,spin_id)
		) $c;";

		$sql[] = "CREATE TABLE {$p}bch_stock (
			wheel_id bigint(20) unsigned NOT NULL DEFAULT 0,
			slice_id varchar(40) NOT NULL DEFAULT '',
			total int(11) NOT NULL DEFAULT 0,
			won int(11) NOT NULL DEFAULT 0,
			PRIMARY KEY  (wheel_id,slice_id)
		) $c;";

		$sql[] = "CREATE TABLE {$p}bch_log (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			channel varchar(20) NOT NULL DEFAULT '',
			level varchar(10) NOT NULL DEFAULT 'info',
			message text NULL,
			context longtext NULL,
			created_at datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
			PRIMARY KEY  (id),
			KEY channel (channel,created_at)
		) $c;";

		$sql[] = "CREATE TABLE {$p}bch_orders (
			order_id bigint(20) unsigned NOT NULL,
			wheel_id bigint(20) unsigned NOT NULL DEFAULT 0,
			spin_id bigint(20) unsigned NOT NULL DEFAULT 0,
			codes varchar(255) NOT NULL DEFAULT '',
			prize varchar(190) NOT NULL DEFAULT '',
			prize_type varchar(30) NOT NULL DEFAULT '',
			status varchar(30) NOT NULL DEFAULT '',
			created_at datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
			paid_at datetime NULL DEFAULT NULL,
			completed_at datetime NULL DEFAULT NULL,
			spin_at datetime NULL DEFAULT NULL,
			total decimal(20,4) NOT NULL DEFAULT 0,
			subtotal decimal(20,4) NOT NULL DEFAULT 0,
			discount decimal(20,4) NOT NULL DEFAULT 0,
			all_discount decimal(20,4) NOT NULL DEFAULT 0,
			gift_value decimal(20,4) NOT NULL DEFAULT 0,
			refunded decimal(20,4) NOT NULL DEFAULT 0,
			items int(11) NOT NULL DEFAULT 0,
			customer_id bigint(20) unsigned NOT NULL DEFAULT 0,
			name varchar(190) NOT NULL DEFAULT '',
			phone varchar(32) NOT NULL DEFAULT '',
			email varchar(190) NOT NULL DEFAULT '',
			synced_at datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
			PRIMARY KEY  (order_id),
			KEY created_at (created_at),
			KEY status (status),
			KEY wheel_id (wheel_id),
			KEY spin_id (spin_id)
		) $c;";

		$sql[] = "CREATE TABLE {$p}bch_sms (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			mobile varchar(20) NOT NULL DEFAULT '',
			message text NULL,
			context varchar(30) NOT NULL DEFAULT '',
			wheel_id bigint(20) unsigned NOT NULL DEFAULT 0,
			provider varchar(40) NOT NULL DEFAULT '',
			status varchar(12) NOT NULL DEFAULT '',
			response text NULL,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
			PRIMARY KEY  (id),
			KEY mobile (mobile),
			KEY context (context,created_at)
		) $c;";

		$sql[] = "CREATE TABLE {$p}bch_bulk (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			title varchar(190) NOT NULL DEFAULT '',
			status varchar(12) NOT NULL DEFAULT 'running',
			filters longtext NULL,
			total int(11) NOT NULL DEFAULT 0,
			batch_size int(11) NOT NULL DEFAULT 100,
			interval_min int(11) NOT NULL DEFAULT 0,
			next_run datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
			batches int(11) NOT NULL DEFAULT 0,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
			finished_at datetime NULL DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY status (status,next_run)
		) $c;";

		$sql[] = "CREATE TABLE {$p}bch_bulk_items (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			bulk_id bigint(20) unsigned NOT NULL DEFAULT 0,
			phone varchar(20) NOT NULL DEFAULT '',
			name varchar(190) NOT NULL DEFAULT '',
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			info longtext NULL,
			status varchar(12) NOT NULL DEFAULT 'pending',
			grant_status varchar(12) NOT NULL DEFAULT '',
			credit_id bigint(20) unsigned NOT NULL DEFAULT 0,
			batch int(11) NOT NULL DEFAULT 0,
			tries int(11) NOT NULL DEFAULT 0,
			message text NULL,
			response text NULL,
			sent_at datetime NULL DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY bulk_status (bulk_id,status),
			KEY phone (phone)
		) $c;";

		foreach ( $sql as $q ) {
			dbDelta( $q );
		}
	}

	/** Remove everything (called from uninstall.php when the user opted in). */
	public static function drop_all() {
		global $wpdb;
		foreach ( self::tables() as $t ) {
			$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$t}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}
		foreach ( array( Settings::OPTION, self::OPTION_DB, 'bch_secret', 'bch_installed_at', 'bch_rules' ) as $o ) {
			delete_option( $o );
		}
		$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_bch\\_%' OR option_name LIKE '\\_transient\\_timeout\\_bch\\_%' OR option_name LIKE 'bch\\_lock\\_%'" );
		$wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'bch\\_%'" );
		Capabilities::remove();
	}
}
