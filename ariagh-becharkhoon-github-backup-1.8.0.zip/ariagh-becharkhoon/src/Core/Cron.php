<?php
/**
 * Daily maintenance: reminders, birthdays, expired prizes, coupon & log cleanup, retention.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Core;

defined( 'ABSPATH' ) || exit;

final class Cron {

	const HOOK = 'becharkhoon_daily';

	public static function schedule() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			// 09:00 site time (good hour for reminder SMS).
			$next = new \DateTimeImmutable( 'tomorrow 09:00', wp_timezone() );
			wp_schedule_event( $next->getTimestamp(), 'daily', self::HOOK );
		}
	}

	public static function unschedule() {
		wp_clear_scheduled_hook( self::HOOK );
	}

	public function register_hooks() {
		add_action( self::HOOK, array( $this, 'run' ), 5 );
	}

	public function run() {
		global $wpdb;
		$s = becharkhoon()->settings;
		becharkhoon()->notifier->reminders();
		// Mark expired, unused prizes.
		$wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}bch_spins SET status = 'expired' WHERE status = 'issued' AND expires_at IS NOT NULL AND expires_at < %s", Helpers::now() ) );
		\Becharkhoon\Prizes\Coupons::cleanup( (int) $s->get( 'coupon_cleanup_days' ) );
		\Becharkhoon\Notify\Sms::prune( (int) $s->get( 'sms_log_days' ) );
		$log_days = (int) $s->get( 'log_retention_days' );
		if ( $log_days > 0 ) {
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}bch_log WHERE created_at < %s", Helpers::now( -$log_days * DAY_IN_SECONDS ) ) );
		}
		$keep = (int) $s->get( 'data_retention_days' );
		if ( $keep > 0 ) {
			$before = Helpers::now( -$keep * DAY_IN_SECONDS );
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}bch_spins WHERE created_at < %s AND status IN ('expired','redeemed','lost','delivered','respin')", $before ) );
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}bch_leads WHERE updated_at < %s", $before ) );
		}
		// Expired lock rows left by crashed requests.
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND CAST(option_value AS UNSIGNED) < %d", $wpdb->esc_like( 'bch_lock_' ) . '%', time() - 60 ) );
	}
}
