<?php
/**
 * Mobile login: after the wheel's SMS code is verified the visitor is also signed in to the SITE
 * (existing account with that mobile, or a new customer account), so the next spin, the cart and
 * "my account" all know them — no second SMS for the second spin.
 *
 * Safety: staff accounts (anyone who can edit posts) are never signed in by SMS code; they keep
 * their normal password login.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Front;

use Becharkhoon\Core\Helpers;

defined( 'ABSPATH' ) || exit;

final class Login {

	const META_KEYS = array( 'billing_phone', 'digits_phone_no', 'digits_phone', 'mobile', 'phone', 'user_phone' );

	/** Spellings a mobile may be stored with. */
	public static function variants( $phone ) {
		$p = Helpers::phone( (string) $phone );
		if ( ! preg_match( '/^09(\d{9})$/', $p, $m ) ) {
			return $p ? array( $p ) : array();
		}
		return array( $p, '9' . $m[1], '+989' . $m[1], '989' . $m[1], '00989' . $m[1] );
	}

	/** Account id that owns this mobile (0 = none). */
	public static function user_by_phone( $phone ) {
		global $wpdb;
		$v = self::variants( $phone );
		if ( ! $v ) {
			return 0;
		}
		$found = 0;
		if ( isset( $wpdb->usermeta ) ) {
			$in    = implode( ',', array_fill( 0, count( $v ), '%s' ) );
			$keys  = implode( ',', array_fill( 0, count( self::META_KEYS ), '%s' ) );
			$found = (int) $wpdb->get_var( $wpdb->prepare( "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key IN ($keys) AND meta_value IN ($in) ORDER BY user_id ASC LIMIT 1", array_merge( self::META_KEYS, $v ) ) ); // phpcs:ignore
		}
		if ( ! $found && function_exists( 'get_user_by' ) ) {
			foreach ( $v as $x ) {
				$u = get_user_by( 'login', $x );
				if ( $u ) {
					$found = (int) $u->ID;
					break;
				}
			}
		}
		return (int) apply_filters( 'becharkhoon_user_by_phone', $found, Helpers::phone( (string) $phone ) );
	}

	private static function is_staff( $uid ) {
		return function_exists( 'user_can' ) && ( user_can( $uid, 'edit_posts' ) || user_can( $uid, 'manage_options' ) || user_can( $uid, 'manage_woocommerce' ) );
	}

	/**
	 * Sign the verified mobile in. Returns array( user_id, created, logged_in, reason ).
	 */
	public static function after_otp( $phone, $name = '' ) {
		$s   = becharkhoon()->settings;
		$out = array( 'user_id' => 0, 'created' => false, 'logged_in' => false, 'reason' => '' );
		$phone = Helpers::phone( (string) $phone );
		if ( '' === $phone || ! $s->get( 'otp_site_login' ) ) {
			$out['reason'] = 'off';
			return $out;
		}
		$cur = get_current_user_id();
		if ( $cur ) {
			// Already signed in: just remember the verified mobile on an account that has none.
			if ( '' === Helpers::phone( (string) get_user_meta( $cur, 'billing_phone', true ) ) && ! self::user_by_phone( $phone ) ) {
				update_user_meta( $cur, 'billing_phone', $phone );
			}
			$out['user_id']   = $cur;
			$out['logged_in'] = true;
			$out['reason']    = 'already';
			return $out;
		}
		$uid = self::user_by_phone( $phone );
		if ( $uid && self::is_staff( $uid ) ) {
			$out['reason'] = 'staff';
			return $out;
		}
		if ( ! $uid ) {
			if ( ! $s->get( 'otp_register' ) || ! function_exists( 'wp_insert_user' ) ) {
				$out['reason'] = 'no_account';
				return $out;
			}
			$login = $phone;
			for ( $i = 2; function_exists( 'username_exists' ) && username_exists( $login ) && $i < 50; $i++ ) {
				$login = $phone . '-' . $i;
			}
			$role = function_exists( 'get_role' ) && get_role( 'customer' ) ? 'customer' : (string) get_option( 'default_role', 'subscriber' );
			$uid  = wp_insert_user(
				array(
					'user_login'   => $login,
					'user_pass'    => wp_generate_password( 24, true, true ),
					'display_name' => '' !== trim( (string) $name ) ? sanitize_text_field( $name ) : $phone,
					'first_name'   => sanitize_text_field( (string) $name ),
					'role'         => $role,
				)
			);
			if ( is_wp_error( $uid ) || ! $uid ) {
				$out['reason'] = 'create_failed';
				return $out;
			}
			update_user_meta( $uid, 'billing_phone', $phone );
			if ( '' !== trim( (string) $name ) ) {
				update_user_meta( $uid, 'billing_first_name', sanitize_text_field( $name ) );
			}
			$out['created'] = true;
			do_action( 'becharkhoon_user_created_by_otp', (int) $uid, $phone );
		}
		$uid  = (int) $uid;
		$user = get_userdata( $uid );
		if ( ! $user ) {
			$out['reason'] = 'no_user';
			return $out;
		}
		if ( function_exists( 'wp_set_current_user' ) ) {
			wp_set_current_user( $uid );
		}
		if ( function_exists( 'wp_set_auth_cookie' ) ) {
			wp_set_auth_cookie( $uid, true, is_ssl() );
		}
		do_action( 'wp_login', $user->user_login, $user );
		$out['user_id']   = $uid;
		$out['logged_in'] = true;
		return $out;
	}
}
