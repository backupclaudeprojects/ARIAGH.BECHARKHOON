/**
 * ARIAGH.BECHARKHOON — Gutenberg block "becharkhoon/wheel" (no build step).
 */
( function ( wp ) {
	'use strict';
	if ( ! wp || ! wp.blocks || ! wp.element ) {
		return;
	}
	var el = wp.element.createElement;
	var C = window.BCH_BLOCK || { wheels: [], fa: false };
	var t = function ( fa, en ) {
		return C.fa ? fa : en;
	};
	var be = wp.blockEditor || wp.editor;
	var comp = wp.components;
	var SSR = wp.serverSideRender;

	var icon = el( 'svg', { width: 24, height: 24, viewBox: '0 0 24 24', fill: 'none', stroke: '#1D4ED8', strokeWidth: 1.8, strokeLinecap: 'round' },
		el( 'circle', { cx: 12, cy: 12, r: 9 } ),
		el( 'circle', { cx: 12, cy: 12, r: 2 } ),
		el( 'path', { d: 'M12 3v7M12 14v7M3 12h7M14 12h7M5.6 5.6l5 5M13.4 13.4l5 5M18.4 5.6l-5 5M10.6 13.4l-5 5' } )
	);

	wp.blocks.registerBlockType( 'becharkhoon/wheel', {
		apiVersion: 2,
		title: t( 'گردونه شانس (بچرخون)', 'Lucky wheel (Becharkhoon)' ),
		description: t( 'نمایش گردونه شانس داخل صفحه یا دکمه بازکردن پاپ‌آپ آن.', 'Show a lucky wheel inline or a button that opens its popup.' ),
		category: 'widgets',
		icon: icon,
		keywords: [ 'wheel', 'spin', 'گردونه', 'شانس', 'becharkhoon' ],
		supports: { html: false, align: [ 'wide', 'full' ] },
		attributes: {
			id: { type: 'number', default: 0 },
			mode: { type: 'string', default: 'inline' },
			text: { type: 'string', default: '' },
		},
		edit: function ( props ) {
			var a = props.attributes;
			var set = props.setAttributes;
			var blockProps = be && be.useBlockProps ? be.useBlockProps() : {};
			var options = [ { value: 0, label: t( '— انتخاب گردونه —', '— Select a wheel —' ) } ].concat( C.wheels || [] );
			var controls = el( be.InspectorControls, null,
				el( comp.PanelBody, { title: t( 'تنظیمات گردونه', 'Wheel settings' ), initialOpen: true },
					el( comp.SelectControl, { label: t( 'گردونه', 'Wheel' ), value: a.id, options: options, onChange: function ( v ) { set( { id: parseInt( v, 10 ) || 0 } ); } } ),
					el( comp.SelectControl, {
						label: t( 'نوع نمایش', 'Display' ),
						value: a.mode,
						options: [ { value: 'inline', label: t( 'داخل صفحه', 'Inline' ) }, { value: 'button', label: t( 'دکمه بازکردن پاپ‌آپ', 'Popup button' ) } ],
						onChange: function ( v ) { set( { mode: v } ); },
					} ),
					a.mode === 'button' ? el( comp.TextControl, { label: t( 'متن دکمه', 'Button text' ), value: a.text, onChange: function ( v ) { set( { text: v } ); } } ) : null
				)
			);
			var body;
			if ( ! a.id ) {
				body = el( comp.Placeholder, { icon: icon, label: t( 'گردونه شانس', 'Lucky wheel' ), instructions: ( C.wheels || [] ).length ? t( 'یک گردونه انتخاب کنید.', 'Choose a wheel.' ) : t( 'هنوز گردونه‌ای نساخته‌اید. از منوی «بچرخون» یک گردونه بسازید.', 'No wheels yet. Create one from the Becharkhoon menu.' ) },
					( C.wheels || [] ).length ? el( comp.SelectControl, { value: a.id, options: options, onChange: function ( v ) { set( { id: parseInt( v, 10 ) || 0 } ); } } ) : null
				);
			} else if ( SSR ) {
				body = el( SSR, { block: 'becharkhoon/wheel', attributes: a } );
			} else {
				body = el( 'div', { style: { padding: '24px', border: '2px dashed #93c5fd', borderRadius: '14px', textAlign: 'center' } }, '🎡 ARIAGH.BECHARKHOON #' + a.id );
			}
			return el( 'div', blockProps, controls, body );
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp );
