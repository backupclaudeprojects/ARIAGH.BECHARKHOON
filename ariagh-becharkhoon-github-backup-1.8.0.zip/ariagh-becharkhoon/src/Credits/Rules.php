<?php
/**
 * Earning rules: who gets how many spins, when.
 *   Examples: "first order → 1 spin", "order ≥ 2,000,000 → 1 spin", "1 spin per 500,000 spent",
 *   "registration → 1 spin", "approved product review → 1 spin", "referral", "birthday".
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Credits;

use Becharkhoon\Core\Helpers;
use Becharkhoon\Core\Lang;
use Becharkhoon\Core\Logger;
use Becharkhoon\Engine\Conditions;
use Becharkhoon\Engine\Context;

defined( 'ABSPATH' ) || exit;

final class Rules {

	const OPTION = 'bch_rules';

	public static function triggers() {
		return array( 'order_paid', 'first_order', 'order_amount', 'every_amount', 'nth_order', 'register', 'review', 'referral_signup', 'referral_order', 'birthday', 'lead' );
	}

	public static function rule_defaults() {
		return array(
			'id'           => '',
			'enabled'      => true,
			'title'        => '',
			'trigger'      => 'order_paid',
			'wheel_id'     => 0,
			'qty'          => 1,
			'amount'       => 0,
			'nth'          => 2,
			'max_qty'      => 10,
			'expiry_days'  => 30,
			'max_per_user' => 0,
			'statuses'     => array(),
			'conditions'   => array( 'enabled' => false, 'groups' => array() ),
			'notify_sms'   => true,
			'notify_email' => false,
			'show_in_popup' => true,
			'hint'         => '',
		);
	}

	public static function all() {
		$rules = get_option( self::OPTION, array() );
		if ( ! is_array( $rules ) ) {
			return array();
		}
		$d = self::rule_defaults();
		return array_values(
			array_map(
				static function ( $r ) use ( $d ) {
					return array_merge( $d, (array) $r );
				},
				$rules
			)
		);
	}

	public static function save_all( array $rules ) {
		$out = array();
		$d   = self::rule_defaults();
		foreach ( array_slice( $rules, 0, 100 ) as $r ) {
			if ( ! is_array( $r ) ) {
				continue;
			}
			$x                 = array();
			$x['id']           = sanitize_key( $r['id'] ?? '' );
			$x['id']           = '' !== $x['id'] ? substr( $x['id'], 0, 40 ) : 'r' . substr( md5( uniqid( '', true ) ), 0, 8 );
			$x['enabled']      = Helpers::bool( $r['enabled'] ?? true );
			$x['title']        = sanitize_text_field( $r['title'] ?? '' );
			$x['trigger']      = in_array( $r['trigger'] ?? '', self::triggers(), true ) ? $r['trigger'] : 'order_paid';
			$x['wheel_id']     = absint( $r['wheel_id'] ?? 0 );
			$x['qty']          = max( 1, min( 100, (int) ( $r['qty'] ?? 1 ) ) );
			$x['amount']       = max( 0, (float) Helpers::latin_digits( $r['amount'] ?? 0 ) );
			$x['nth']          = max( 1, (int) ( $r['nth'] ?? 2 ) );
			$x['max_qty']      = max( 1, min( 1000, (int) ( $r['max_qty'] ?? 10 ) ) );
			$x['expiry_days']  = max( 0, (int) ( $r['expiry_days'] ?? 30 ) );
			$x['max_per_user'] = max( 0, (int) ( $r['max_per_user'] ?? 0 ) );
			$x['statuses']     = array_values( array_filter( array_map( 'sanitize_key', (array) ( $r['statuses'] ?? array() ) ) ) );
			$x['conditions']   = Conditions::sanitize_set( $r['conditions'] ?? array() );
			$x['notify_sms']   = Helpers::bool( $r['notify_sms'] ?? true );
			$x['notify_email'] = Helpers::bool( $r['notify_email'] ?? false );
			$x['show_in_popup'] = Helpers::bool( $r['show_in_popup'] ?? true );
			$x['hint']         = sanitize_text_field( $r['hint'] ?? '' );
			$out[]             = array_merge( $d, $x );
		}
		update_option( self::OPTION, $out, false );
		return $out;
	}

	public function register_hooks() {
		add_action( 'woocommerce_order_status_changed', array( $this, 'on_order_status' ), 20, 4 );
		add_action( 'user_register', array( $this, 'on_register' ), 20 );
		add_action( 'comment_post', array( $this, 'on_comment_post' ), 20, 2 );
		add_action( 'transition_comment_status', array( $this, 'on_comment_status' ), 20, 3 );
		add_action( 'becharkhoon_daily', array( $this, 'birthdays' ) );
		add_action( 'becharkhoon_lead_created', array( $this, 'on_lead' ), 10, 2 );
		add_action( 'init', array( $this, 'capture_referral' ), 5 );
		add_action( 'woocommerce_checkout_create_order', array( $this, 'store_referral_on_order' ), 10, 1 );
		add_action( 'woocommerce_order_status_refunded', array( $this, 'on_refund' ), 10, 1 );
		add_action( 'woocommerce_order_status_cancelled', array( $this, 'on_refund' ), 10, 1 );
		add_action( 'woocommerce_order_status_failed', array( $this, 'on_refund' ), 10, 1 );
	}

	/** Rules for a trigger set. */
	private function rules_for( array $triggers ) {
		return array_filter(
			self::all(),
			static function ( $r ) use ( $triggers ) {
				return $r['enabled'] && in_array( $r['trigger'], $triggers, true );
			}
		);
	}

	/**
	 * Order reached a status.
	 *
	 * @param int       $order_id Order id.
	 * @param string    $from     Old status.
	 * @param string    $to       New status.
	 * @param \WC_Order $order    Order.
	 */
	public function on_order_status( $order_id, $from, $to, $order = null ) {
		$order = $order instanceof \WC_Order ? $order : wc_get_order( $order_id );
		if ( ! $order || 'shop_order' !== $order->get_type() ) {
			return;
		}
		$global = (array) becharkhoon()->settings->get( 'order_statuses' );
		foreach ( $this->rules_for( array( 'order_paid', 'first_order', 'order_amount', 'every_amount', 'nth_order', 'referral_order' ) ) as $rule ) {
			$statuses = $rule['statuses'] ? $rule['statuses'] : $global;
			if ( ! in_array( $to, $statuses, true ) ) {
				continue;
			}
			$this->apply_order_rule( $rule, $order );
		}
	}

	/** Evaluate one order rule (also used by the "re-check old orders" tool). */
	public function apply_order_rule( array $rule, \WC_Order $order ) {
		$ctx = Context::for_order( $order );
		$qty = (int) $rule['qty'];
		switch ( $rule['trigger'] ) {
			case 'first_order':
				if ( 1 !== $ctx->order_number() ) {
					return 0;
				}
				break;
			case 'nth_order':
				if ( (int) $rule['nth'] !== $ctx->order_number() ) {
					return 0;
				}
				break;
			case 'order_amount':
				if ( (float) $order->get_total() < (float) $rule['amount'] ) {
					return 0;
				}
				break;
			case 'every_amount':
				if ( (float) $rule['amount'] <= 0 ) {
					return 0;
				}
				$qty = (int) floor( (float) $order->get_total() / (float) $rule['amount'] ) * (int) $rule['qty'];
				$qty = min( $qty, (int) $rule['max_qty'] );
				if ( $qty < 1 ) {
					return 0;
				}
				break;
			case 'referral_order':
				return $this->referral_order( $rule, $order, $ctx );
		}
		if ( ! Conditions::passes( $rule['conditions'], $ctx ) ) {
			return 0;
		}
		return $this->give( $rule, $ctx->user_id, $ctx->phone, $ctx->email, $qty, 'order', $order->get_id(), 'r:' . $rule['id'] . ':o:' . $order->get_id(), $order->get_billing_first_name() );
	}

	/**
	 * Grant with max-per-user checks + notifications.
	 */
	private function give( array $rule, $user_id, $phone, $email, $qty, $ref_type, $ref_id, $uniq, $name = '' ) {
		if ( $rule['max_per_user'] > 0 ) {
			$had = Ledger::granted_by_rule( $rule['id'], $user_id, $phone );
			if ( $had >= $rule['max_per_user'] ) {
				return 0;
			}
			$qty = min( $qty, $rule['max_per_user'] - $had );
		}
		$id = Ledger::grant(
			array(
				'wheel_id'     => $rule['wheel_id'],
				'user_id'      => $user_id,
				'phone'        => $phone,
				'email'        => $email,
				'qty'          => $qty,
				'reason'       => $rule['trigger'],
				'rule_id'      => $rule['id'],
				'ref_type'     => $ref_type,
				'ref_id'       => $ref_id,
				'uniq'         => $uniq,
				'note'         => $rule['title'],
				'expires_days' => $rule['expiry_days'],
			)
		);
		if ( $id ) {
			becharkhoon()->notifier->credit_granted( $id, $rule, $qty, array( 'user_id' => $user_id, 'phone' => $phone, 'email' => $email, 'name' => $name ) );
			if ( 'order' === $ref_type && function_exists( 'wc_get_order' ) ) {
				$o = wc_get_order( $ref_id );
				if ( $o ) {
					$o->add_order_note( sprintf( Lang::t( 'بچرخون: %1$d شانس گردونه بابت قانون «%2$s» داده شد.', 'Becharkhoon: %1$d wheel spin(s) granted by rule "%2$s".' ), $qty, $rule['title'] ) );
					$o->update_meta_data( '_bch_spins_granted', (int) $o->get_meta( '_bch_spins_granted' ) + $qty );
					$o->update_meta_data( '_bch_spins_wheel', (int) $rule['wheel_id'] );
					$o->save_meta_data();
				}
			}
		}
		return $id;
	}

	public function on_register( $user_id ) {
		$u = get_userdata( $user_id );
		if ( ! $u ) {
			return;
		}
		$phone = Helpers::phone( get_user_meta( $user_id, 'billing_phone', true ) );
		foreach ( $this->rules_for( array( 'register' ) ) as $rule ) {
			$ctx          = new Context();
			$ctx->user_id = (int) $user_id;
			$ctx->email   = strtolower( $u->user_email );
			if ( ! Conditions::passes( $rule['conditions'], $ctx ) ) {
				continue;
			}
			$this->give( $rule, $user_id, $phone, $u->user_email, $rule['qty'], 'user', $user_id, 'r:' . $rule['id'] . ':u:' . $user_id, $u->display_name );
		}
		// Referral (signup).
		$ref = $this->referrer_from_cookie();
		if ( $ref && $ref !== (int) $user_id ) {
			update_user_meta( $user_id, 'bch_referred_by', $ref );
			foreach ( $this->rules_for( array( 'referral_signup' ) ) as $rule ) {
				$this->give( $rule, $ref, '', '', $rule['qty'], 'referral', $user_id, 'r:' . $rule['id'] . ':ref:' . $user_id );
			}
		}
	}

	public function on_comment_post( $comment_id, $approved ) {
		if ( 1 === $approved || '1' === $approved ) {
			$this->review_reward( $comment_id );
		}
	}

	public function on_comment_status( $new, $old, $comment ) {
		if ( 'approved' === $new && 'approved' !== $old && $comment ) {
			$this->review_reward( $comment->comment_ID );
		}
	}

	private function review_reward( $comment_id ) {
		$c = get_comment( $comment_id );
		if ( ! $c || 'product' !== get_post_type( $c->comment_post_ID ) ) {
			return;
		}
		$uid   = (int) $c->user_id;
		$phone = $uid ? Helpers::phone( get_user_meta( $uid, 'billing_phone', true ) ) : '';
		if ( ! $uid && '' === $phone ) {
			return; // Anonymous reviews never earn spins (abuse).
		}
		foreach ( $this->rules_for( array( 'review' ) ) as $rule ) {
			$this->give( $rule, $uid, $phone, $c->comment_author_email, $rule['qty'], 'comment', $comment_id, 'r:' . $rule['id'] . ':c:' . $comment_id, $c->comment_author );
		}
	}

	/** Someone left their details in the wheel form (lead). */
	public function on_lead( $lead_id, $lead ) {
		foreach ( $this->rules_for( array( 'lead' ) ) as $rule ) {
			if ( empty( $lead['phone'] ) && empty( $lead['user_id'] ) ) {
				continue;
			}
			$this->give( $rule, (int) ( $lead['user_id'] ?? 0 ), $lead['phone'] ?? '', $lead['email'] ?? '', $rule['qty'], 'lead', $lead_id, 'r:' . $rule['id'] . ':l:' . ( $lead['phone'] ?? $lead_id ), $lead['name'] ?? '' );
		}
	}

	/** Daily cron: birthday gifts (users with a stored birthday). */
	public function birthdays() {
		$rules = $this->rules_for( array( 'birthday' ) );
		if ( ! $rules ) {
			return;
		}
		global $wpdb;
		$md   = wp_date( 'm-d' );
		$year = wp_date( 'Y' );
		$uids = $wpdb->get_col( $wpdb->prepare( "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = 'bch_birthday' AND meta_value LIKE %s LIMIT 2000", '%-' . $md ) );
		foreach ( $uids as $uid ) {
			$u = get_userdata( (int) $uid );
			if ( ! $u ) {
				continue;
			}
			foreach ( $rules as $rule ) {
				$this->give( $rule, (int) $uid, '', $u->user_email, $rule['qty'], 'birthday', (int) $year, 'r:' . $rule['id'] . ':b:' . $uid . ':' . $year, $u->display_name );
			}
		}
	}

	/* ---------- Referral ---------- */

	public function capture_referral() {
		$s = becharkhoon()->settings;
		if ( ! $s->get( 'referral_enabled' ) ) {
			return;
		}
		$param = (string) $s->get( 'referral_param' );
		if ( empty( $_GET[ $param ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$code = sanitize_text_field( wp_unslash( $_GET[ $param ] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$uid  = self::decode_ref( $code );
		if ( $uid && $uid !== get_current_user_id() && ! headers_sent() ) {
			setcookie( 'bch_ref', $code, time() + DAY_IN_SECONDS * (int) $s->get( 'referral_cookie_days' ), COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true );
			$_COOKIE['bch_ref'] = $code;
		}
	}

	/** Share code for a user (not guessable: id + HMAC). */
	public static function ref_code( $user_id ) {
		$user_id = (int) $user_id;
		return base_convert( (string) $user_id, 10, 36 ) . '-' . substr( hash_hmac( 'sha256', 'ref' . $user_id, (string) get_option( 'bch_secret' ) ), 0, 6 );
	}

	public static function decode_ref( $code ) {
		if ( ! preg_match( '/^([0-9a-z]+)-([0-9a-f]{6})$/', (string) $code, $m ) ) {
			return 0;
		}
		$uid = (int) base_convert( $m[1], 36, 10 );
		return $uid && hash_equals( self::ref_code( $uid ), $code ) && get_userdata( $uid ) ? $uid : 0;
	}

	private function referrer_from_cookie() {
		return isset( $_COOKIE['bch_ref'] ) ? self::decode_ref( sanitize_text_field( wp_unslash( $_COOKIE['bch_ref'] ) ) ) : 0;
	}

	public function store_referral_on_order( $order ) {
		$ref = $this->referrer_from_cookie();
		if ( ! $ref && $order->get_customer_id() ) {
			$ref = (int) get_user_meta( $order->get_customer_id(), 'bch_referred_by', true );
		}
		if ( $ref && $ref !== (int) $order->get_customer_id() ) {
			$order->update_meta_data( '_bch_referred_by', $ref );
		}
	}

	private function referral_order( array $rule, \WC_Order $order, Context $ctx ) {
		$ref = (int) $order->get_meta( '_bch_referred_by' );
		if ( ! $ref || $ref === $ctx->user_id ) {
			return 0;
		}
		if ( ! Conditions::passes( $rule['conditions'], $ctx ) ) {
			return 0;
		}
		$who = $ctx->user_id ? 'u' . $ctx->user_id : 'p' . ( $ctx->phone ? $ctx->phone : $ctx->email );
		// Once per referred customer (their first qualifying order).
		return $this->give( $rule, $ref, '', '', $rule['qty'], 'referral', $order->get_id(), 'r:' . $rule['id'] . ':refo:' . md5( $who ) );
	}

	/** Refunded / cancelled / failed orders lose their unused spins. */
	public function on_refund( $order_id ) {
		if ( becharkhoon()->settings->get( 'revoke_on_refund' ) ) {
			$n = Ledger::revoke_ref( 'order', $order_id );
			if ( $n ) {
				Logger::log( 'system', 'info', sprintf( 'Revoked unused spins of order #%d', $order_id ) );
			}
		}
	}

	/** Human "how to earn spins" lines for the popup. */
	public static function earn_hints( $wheel_id ) {
		$out = array();
		foreach ( self::all() as $r ) {
			if ( ! $r['enabled'] || ! $r['show_in_popup'] || ( $r['wheel_id'] && (int) $r['wheel_id'] !== (int) $wheel_id ) ) {
				continue;
			}
			$out[] = '' !== $r['hint'] ? $r['hint'] : self::describe( $r );
		}
		return array_values( array_unique( array_filter( $out ) ) );
	}

	public static function describe( array $r ) {
		$n     = (int) $r['qty'];
		$money = Helpers::money( $r['amount'] );
		switch ( $r['trigger'] ) {
			case 'first_order':
				return sprintf( Lang::t( 'با ثبت اولین سفارش، %d شانس چرخاندن بگیرید', 'Place your first order to get %d spin(s)' ), $n );
			case 'order_amount':
				return sprintf( Lang::t( 'برای خرید %1$s یا بیشتر، %2$d شانس بگیرید', 'Orders of %1$s or more earn %2$d spin(s)' ), $money, $n );
			case 'every_amount':
				return sprintf( Lang::t( 'به ازای هر %1$s خرید، %2$d شانس بگیرید', 'Earn %2$d spin(s) for every %1$s spent' ), $money, $n );
			case 'nth_order':
				return sprintf( Lang::t( 'با ثبت سفارش شماره %1$d، %2$d شانس بگیرید', 'Your order #%1$d earns %2$d spin(s)' ), (int) $r['nth'], $n );
			case 'order_paid':
				return sprintf( Lang::t( 'با هر خرید، %d شانس چرخاندن بگیرید', 'Every order earns %d spin(s)' ), $n );
			case 'register':
				return sprintf( Lang::t( 'با ثبت‌نام در سایت، %d شانس بگیرید', 'Sign up to get %d spin(s)' ), $n );
			case 'review':
				return sprintf( Lang::t( 'برای هر دیدگاه تاییدشده روی محصولات، %d شانس بگیرید', 'Each approved product review earns %d spin(s)' ), $n );
			case 'referral_signup':
				return sprintf( Lang::t( 'هر دوستی که با لینک شما ثبت‌نام کند = %d شانس', 'Each friend who signs up with your link = %d spin(s)' ), $n );
			case 'referral_order':
				return sprintf( Lang::t( 'هر دوستی که با لینک شما خرید کند = %d شانس', 'Each friend who buys with your link = %d spin(s)' ), $n );
			case 'birthday':
				return sprintf( Lang::t( 'روز تولدتان %d شانس هدیه بگیرید', 'Get %d spin(s) on your birthday' ), $n );
			case 'lead':
				return sprintf( Lang::t( 'با ثبت شماره موبایل، %d شانس بگیرید', 'Leave your number to get %d spin(s)' ), $n );
		}
		return '';
	}
}
