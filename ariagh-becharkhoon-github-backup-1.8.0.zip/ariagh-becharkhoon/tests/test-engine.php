<?php
/**
 * Engine tests (offline): schema, picker, conditions, limits, credits, earning rules,
 * stock atomicity, respin chain, code pool, OTP, boot token, settings encryption, SMS drivers.
 * Run: php tests/test-engine.php
 */
// phpcs:ignoreFile

/* ---- Minimal WooCommerce order mock (only what the engine reads) ---- */
class WC_Order {
	public $d; public $notes = array(); public $meta = array();
	public function __construct( array $d ) { $this->d = array_merge( array( 'id' => 0, 'customer_id' => 0, 'email' => '', 'phone' => '', 'total' => 0, 'status' => 'processing', 'items' => array(), 'payment' => 'cod', 'city' => '', 'first_name' => 'Ali', 'refunded' => 0, 'coupons' => array() ), $d ); }
	public function get_id() { return $this->d['id']; }
	public function get_type() { return 'shop_order'; }
	public function get_status() { return $this->d['status']; }
	public function get_customer_id() { return $this->d['customer_id']; }
	public function get_billing_email() { return $this->d['email']; }
	public function get_billing_phone() { return $this->d['phone']; }
	public function get_billing_first_name() { return $this->d['first_name']; }
	public function get_customer_ip_address() { return '1.2.3.4'; }
	public function get_total() { return $this->d['total']; }
	public function get_subtotal() { return $this->d['total']; }
	public function get_total_refunded() { return $this->d['refunded']; }
	public function get_item_count() { return count( $this->d['items'] ); }
	public function get_items( $t = 'line_item' ) { return $this->d[ 'items_' . $t ] ?? array(); }
	public function get_total_discount( $x = true ) { $d = 0; foreach ( $this->get_items( 'coupon' ) as $c ) { $d += $c->get_discount(); } return $d; }
	public function get_date_paid() { return null; }
	public function get_date_completed() { return 'completed' === $this->d['status'] ? $this->get_date_created() : null; }
	public function get_coupon_codes() { return $this->d['coupons']; }
	public function get_payment_method() { return $this->d['payment']; }
	public function get_shipping_methods() { return array(); }
	public function get_billing_city() { return $this->d['city']; }
	public function get_billing_state() { return ''; }
	public function get_created_via() { return 'checkout'; }
	public function get_date_created() { return new DateTime( $this->d['date'] ?? 'now' ); }
	public function add_order_note( $n ) { $this->notes[] = $n; }
	public function update_meta_data( $k, $v ) { $this->meta[ $k ] = $v; }
	public function get_meta( $k ) { return $this->meta[ $k ] ?? ''; }
	public function save_meta_data() {}
}
$GLOBALS['__orders'] = array();
function wc_get_order( $id ) { return $GLOBALS['__orders'][ (int) $id ] ?? false; }
function wc_get_orders( $a ) {
	$st  = array_map( function ( $s ) { return substr( $s, 3 ); }, (array) $a['status'] );
	$out = array();
	foreach ( $GLOBALS['__orders'] as $o ) {
		if ( ! in_array( $o->d['status'], $st, true ) ) { continue; }
		if ( isset( $a['customer_id'] ) && $o->d['customer_id'] !== $a['customer_id'] ) { continue; }
		if ( isset( $a['billing_phone'] ) && $o->d['phone'] !== $a['billing_phone'] ) { continue; }
		if ( isset( $a['billing_email'] ) && $o->d['email'] !== $a['billing_email'] ) { continue; }
		$out[] = $o->d['id'];
	}
	sort( $out );
	return $out;
}
function bch_order( array $d ) { $o = new WC_Order( $d ); $GLOBALS['__orders'][ $d['id'] ] = $o; return $o; }

require __DIR__ . '/bootstrap.php';

use Becharkhoon\Wheels\Schema;
use Becharkhoon\Engine\Context;
use Becharkhoon\Engine\Conditions;
use Becharkhoon\Engine\Eligibility;
use Becharkhoon\Engine\Picker;
use Becharkhoon\Credits\Ledger;
use Becharkhoon\Credits\Rules;
use Becharkhoon\Front\Guard;
use Becharkhoon\Core\Crypto;
use Becharkhoon\Notify\SmsGateways;

$GLOBALS['__http_responder'] = function ( $url, $args ) { return array( 'code' => 200, 'body' => '{"status":1,"return":{"status":200},"data":{"messageId":1},"result":{"code":200}}' ); };
$repo = becharkhoon()->wheels;
$svc  = new \Becharkhoon\Engine\SpinService();

function mkwheel( array $patch, $title = 'T' ) {
	$cfg = Schema::merge( Schema::defaults( true ), $patch );
	if ( isset( $patch['slices'] ) ) { $cfg['slices'] = $patch['slices']; }
	$cfg = Schema::sanitize( $cfg );
	$id  = becharkhoon()->wheels->create( $title, $cfg, 'active' );
	becharkhoon()->wheels->flush();
	return becharkhoon()->wheels->get( $id );
}
function slice( $id, $type, $weight, array $x = array() ) {
	return array_merge( Schema::slice_defaults( true ), array( 'id' => $id, 'label' => $id, 'type' => $type, 'weight' => $weight ), $x );
}
function guest( $phone = '', $device = '', $verified = true ) {
	$c = new Context();
	$c->phone = $phone; $c->phone_verified = $verified && '' !== $phone; $c->device_id = $device; $c->ip = '10.0.0.' . rand( 1, 250 );
	$c->client = Context::clean_client( array( 'device' => 'desktop' ) );
	return $c;
}
function member( $uid ) { $c = new Context(); $c->user_id = $uid; $c->email = "u$uid@x.ir"; $c->ip = '10.1.1.1'; $c->client = Context::clean_client( array() ); return $c; }

echo "Schema\n";
$s = Schema::sanitize( array( 'design' => array( 'size' => 99999, 'rim_style' => 'evil<script>', 'unknown' => 1 ), 'slices' => array( slice( 'a', 'lose', 1 ) ) ) );
ok( $s['design']['size'] <= 1200, 'size is clamped' );
ok( 'lights' === $s['design']['rim_style'] || in_array( $s['design']['rim_style'], array( 'lights', 'solid' ), true ), 'invalid enum falls back' );
ok( ! isset( $s['design']['unknown'] ), 'unknown key dropped' );
ok( count( $s['slices'] ) >= Schema::MIN_SLICES, 'at least 2 slices enforced' );
$many = array(); for ( $i = 0; $i < 40; $i++ ) { $many[] = slice( 's' . $i, 'lose', 1 ); }
ok( count( Schema::sanitize( array( 'slices' => $many ) )['slices'] ) === Schema::MAX_SLICES, 'max 24 slices enforced' );
$x = Schema::sanitize( array( 'popup' => array( 'title' => '<img src=x onerror=alert(1)>Hi' ) ) );
ok( false === stripos( $x['popup']['title'], 'onerror' ), 'title is stripped of HTML' );

echo "Picker\n";
$cands = array( 0 => slice( 'a', 'coupon_percent', 70 ), 1 => slice( 'b', 'lose', 30 ) );
$hit = array( 0, 0 );
for ( $i = 0; $i < 20000; $i++ ) { $hit[ Picker::draw( $cands ) ]++; }
ok( abs( $hit[0] / 20000 - 0.7 ) < 0.02, 'weighted draw ≈ 70/30 (' . round( $hit[0] / 200, 1 ) . '%)' );
ok( -1 === Picker::draw( array( slice( 'z', 'lose', 0 ) ) ), 'zero weights → -1' );

echo "Conditions\n";
bch_make_user( 10, 'u10@x.ir' );
bch_order( array( 'id' => 101, 'customer_id' => 10, 'email' => 'u10@x.ir', 'phone' => '09120000010', 'total' => 1500000 ) );
bch_order( array( 'id' => 102, 'customer_id' => 10, 'email' => 'u10@x.ir', 'phone' => '09120000010', 'total' => 800000 ) );
$c   = member( 10 );
$big = array( 'enabled' => true, 'groups' => array( array( array( 'type' => 'total_spent', 'op' => 'gte', 'value' => '2000000', 'value2' => '', 'key' => '' ) ) ) );
ok( Conditions::passes( Conditions::sanitize_set( $big ), $c ), 'total_spent 2.3M ≥ 2M passes' );
$c2 = member( 10 );
$new = array( 'enabled' => true, 'groups' => array( array( array( 'type' => 'order_count', 'op' => 'eq', 'value' => '0', 'value2' => '', 'key' => '' ) ) ) );
ok( ! Conditions::passes( Conditions::sanitize_set( $new ), $c2 ), 'order_count = 0 fails for a buyer' );
$or = array( 'enabled' => true, 'groups' => array( $new['groups'][0], array( array( 'type' => 'logged_in', 'op' => 'is_true', 'value' => '', 'value2' => '', 'key' => '' ) ) ) );
ok( Conditions::passes( Conditions::sanitize_set( $or ), member( 10 ) ), 'OR group passes' );
$and = array( 'enabled' => true, 'groups' => array( array( $new['groups'][0][0], array( 'type' => 'logged_in', 'op' => 'is_true', 'value' => '', 'value2' => '', 'key' => '' ) ) ) );
ok( ! Conditions::passes( Conditions::sanitize_set( $and ), member( 10 ) ), 'AND group fails if one fails' );
ok( Conditions::passes( array( 'enabled' => false, 'groups' => array() ), guest() ), 'disabled set always passes' );

echo "Free mode limits\n";
$w = mkwheel( array( 'slices' => array( slice( 'l1', 'lose', 1 ), slice( 'l2', 'lose', 1 ) ), 'access' => array( 'mode' => 'free', 'limits' => array( array( 'count' => 1, 'period' => 'day', 'hours' => 24 ) ) ) ) );
$g = guest( '09121111111', 'dev-aaaaaaaaaaaaaaaa' );
$r = $svc->spin( $w, $g, array( 'name' => 'A' ) );
ok( is_array( $r ) && 'lose' === $r['result'], 'first spin allowed' );
$r2 = $svc->spin( $w, guest( '09121111111', 'dev-bbbbbbbbbbbbbbbb' ) );
ok( is_wp_error( $r2 ), 'second spin same phone (other device) blocked' );
$r3 = $svc->spin( $w, guest( '09122222222', 'dev-aaaaaaaaaaaaaaaa' ) );
ok( is_wp_error( $r3 ), 'same device, other phone blocked' );
global $wpdb;
$wpdb->query( "UPDATE {$wpdb->prefix}bch_spins SET created_at = '" . gmdate( 'Y-m-d H:i:s', time() - 2 * DAY_IN_SECONDS ) . "'" );
ok( is_array( $svc->spin( $w, guest( '09121111111', 'dev-aaaaaaaaaaaaaaaa' ) ) ), 'allowed again the next day' );

echo "Cooldown & max wins\n";
$w = mkwheel( array( 'slices' => array( slice( 'p', 'custom', 1, array( 'custom_text' => 'gift' ) ), slice( 'l', 'lose', 0 ) ), 'access' => array( 'mode' => 'free', 'limits' => array(), 'cooldown_minutes' => 30, 'max_wins' => 0 ) ) );
$g = guest( '09123333333', 'dev-cccccccccccccccc' );
ok( is_array( $svc->spin( $w, $g ) ), 'spin ok' );
$e = Eligibility::check( $w, guest( '09123333333', 'dev-cccccccccccccccc' ) );
ok( ! $e['ok'] && 'cooldown' === $e['reason'] && $e['next_at'] > time(), 'cooldown enforced with next_at' );
$w = mkwheel( array( 'slices' => array( slice( 'p', 'custom', 1 ), slice( 'l', 'lose', 0 ) ), 'access' => array( 'mode' => 'free', 'limits' => array(), 'max_wins' => 1 ) ) );
$g = guest( '09124444444', 'dev-dddddddddddddddd' );
$svc->spin( $w, $g );
$e = Eligibility::check( $w, guest( '09124444444', 'dev-dddddddddddddddd' ) );
ok( ! $e['ok'] && 'max_wins' === $e['reason'], 'max wins per person enforced' );

echo "Credits mode & ledger\n";
$w = mkwheel( array( 'slices' => array( slice( 'l1', 'lose', 1 ), slice( 'l2', 'lose', 1 ) ), 'access' => array( 'mode' => 'credits', 'limits' => array() ) ) );
bch_make_user( 20, 'u20@x.ir' );
$m = member( 20 );
$e = Eligibility::check( $w, $m );
ok( ! $e['ok'] && 'no_credits' === $e['reason'], 'no credits → denied' );
$id1 = Ledger::grant( array( 'user_id' => 20, 'qty' => 2, 'reason' => 'manual', 'uniq' => 'test:1' ) );
$id2 = Ledger::grant( array( 'user_id' => 20, 'qty' => 2, 'reason' => 'manual', 'uniq' => 'test:1' ) );
ok( $id1 > 0 && 0 === $id2, 'grant is idempotent by uniq key' );
ok( 2 === Ledger::balance( member( 20 ), $w['id'] ), 'balance = 2' );
ok( is_array( $svc->spin( $w, member( 20 ) ) ) && is_array( $svc->spin( $w, member( 20 ) ) ), 'two credit spins succeed' );
ok( is_wp_error( $svc->spin( $w, member( 20 ) ) ), 'third spin denied (credits used)' );
ok( 0 === Ledger::balance( member( 20 ), $w['id'] ), 'balance = 0' );
$gid = Ledger::grant( array( 'phone' => '09125555555', 'qty' => 1, 'wheel_id' => $w['id'] ) );
ok( 0 === Ledger::balance( guest( '09125555555', '', false ), $w['id'] ), 'unverified phone cannot use phone credits' );
ok( 1 === Ledger::balance( guest( '09125555555', '', true ), $w['id'] ), 'OTP-verified phone can' );
$exp = Ledger::grant( array( 'user_id' => 20, 'qty' => 1, 'expires_days' => 1 ) );
$wpdb->query( "UPDATE {$wpdb->prefix}bch_credits SET expires_at = '" . gmdate( 'Y-m-d H:i:s', time() - 60 ) . "' WHERE id = $exp" );
ok( 0 === Ledger::balance( member( 20 ), $w['id'] ), 'expired credits are not counted' );
$sc = Ledger::grant( array( 'user_id' => 20, 'qty' => 1, 'wheel_id' => 9999 ) );
ok( 0 === Ledger::balance( member( 20 ), $w['id'] ), 'credits of another wheel are not usable' );

echo "Hybrid mode\n";
$w = mkwheel( array( 'slices' => array( slice( 'l1', 'lose', 1 ), slice( 'l2', 'lose', 1 ) ), 'access' => array( 'mode' => 'hybrid', 'limits' => array( array( 'count' => 1, 'period' => 'day', 'hours' => 24 ) ) ) ) );
bch_make_user( 30, 'u30@x.ir' );
Ledger::grant( array( 'user_id' => 30, 'qty' => 1 ) );
$a = Eligibility::check( $w, member( 30 ) );
ok( $a['ok'] && 'free' === $a['via'], 'free allowance first' );
$svc->spin( $w, member( 30 ) );
$a = Eligibility::check( $w, member( 30 ) );
ok( $a['ok'] && 'credit' === $a['via'], 'then earned credits' );
$svc->spin( $w, member( 30 ) );
ok( ! Eligibility::check( $w, member( 30 ) )['ok'], 'then nothing' );

echo "Earning rules (first order / over 2,000,000 / every 500,000 / refund)\n";
$cw = mkwheel( array( 'slices' => array( slice( 'l1', 'lose', 1 ), slice( 'l2', 'lose', 1 ) ), 'access' => array( 'mode' => 'credits', 'limits' => array() ) ) );
Rules::save_all( array(
	array( 'id' => 'first', 'trigger' => 'first_order', 'qty' => 1, 'wheel_id' => $cw['id'], 'title' => 'اولین خرید' ),
	array( 'id' => 'big', 'trigger' => 'order_amount', 'amount' => 2000000, 'qty' => 1, 'wheel_id' => $cw['id'], 'title' => 'بالای ۲ میلیون' ),
	array( 'id' => 'every', 'trigger' => 'every_amount', 'amount' => 500000, 'qty' => 1, 'max_qty' => 3, 'wheel_id' => $cw['id'], 'title' => 'هر ۵۰۰ هزار' ),
) );
$rules = new Rules();
bch_make_user( 40, 'u40@x.ir' );
$o1 = bch_order( array( 'id' => 401, 'customer_id' => 40, 'email' => 'u40@x.ir', 'total' => 300000 ) );
$rules->on_order_status( 401, 'pending', 'processing', $o1 );
$bal = Ledger::balance( member( 40 ), $cw['id'] );
ok( 1 === $bal, 'first order (300k) → 1 spin (first_order only), got ' . $bal );
$rules->on_order_status( 401, 'processing', 'completed', $o1 );
ok( 1 === Ledger::balance( member( 40 ), $cw['id'] ), 'status change again does not double-grant' );
ok( (int) $o1->get_meta( '_bch_spins_granted' ) === 1 && $o1->notes, 'order note + meta written' );
$o2 = bch_order( array( 'id' => 402, 'customer_id' => 40, 'email' => 'u40@x.ir', 'total' => 2500000 ) );
$rules->on_order_status( 402, 'pending', 'processing', $o2 );
$bal = Ledger::balance( member( 40 ), $cw['id'] );
ok( 1 + 1 + 3 === $bal, 'second order 2.5M → big(1) + every(min(5,3)=3), not first; total ' . $bal );
$o3 = bch_order( array( 'id' => 403, 'customer_id' => 40, 'email' => 'u40@x.ir', 'total' => 1900000 ) );
$rules->on_order_status( 403, 'pending', 'processing', $o3 );
ok( 5 + 3 === Ledger::balance( member( 40 ), $cw['id'] ), '1.9M → no "big", every = 3' );
$rules->on_refund( 403 );
ok( 5 === Ledger::balance( member( 40 ), $cw['id'] ), 'refund revokes the unused spins of that order' );
$o4 = bch_order( array( 'id' => 404, 'customer_id' => 0, 'email' => 'guest@x.ir', 'phone' => '09126666666', 'total' => 2100000 ) );
$rules->on_order_status( 404, 'pending', 'processing', $o4 );
ok( 3 + 1 + 1 === Ledger::balance( guest( '09126666666', '', true ), $cw['id'] ), 'guest order: first + big + every(4→3) → usable after OTP on that phone' );
$o5 = bch_order( array( 'id' => 405, 'customer_id' => 40, 'email' => 'u40@x.ir', 'total' => 9000000, 'status' => 'on-hold' ) );
$rules->on_order_status( 405, 'pending', 'on-hold', $o5 );
ok( 5 === Ledger::balance( member( 40 ), $cw['id'] ), 'unpaid status grants nothing' );
Rules::save_all( array( array( 'id' => 'cap', 'trigger' => 'order_paid', 'qty' => 1, 'max_per_user' => 1, 'wheel_id' => $cw['id'] ) ) );
bch_make_user( 41, 'u41@x.ir' );
foreach ( array( 411, 412 ) as $oid ) { $rules->on_order_status( $oid, 'pending', 'processing', bch_order( array( 'id' => $oid, 'customer_id' => 41, 'email' => 'u41@x.ir', 'total' => 100 ) ) ); }
ok( 1 === Ledger::balance( member( 41 ), $cw['id'] ), 'max_per_user caps a rule' );

echo "Stock atomicity\n";
$w = mkwheel( array( 'slices' => array( slice( 'jackpot', 'custom', 1000, array( 'stock' => 2 ) ), slice( 'l', 'lose', 1 ) ), 'access' => array( 'mode' => 'free', 'limits' => array() ) ) );
$wins = 0;
for ( $i = 0; $i < 15; $i++ ) { $r = $svc->spin( $w, guest( '0912700' . str_pad( $i, 4, '0', STR_PAD_LEFT ), 'dev-st' . str_pad( $i, 14, '0' ) ) ); if ( is_array( $r ) && 'jackpot' === $r['slice_id'] ) { $wins++; } }
ok( 2 === $wins, 'jackpot with stock 2 won exactly twice (' . $wins . ')' );
ok( false === $repo->take_stock( $w['id'], 'jackpot' ), 'take_stock refuses when empty' );

echo "Respin chain, first-spin-win, pity\n";
$w = mkwheel( array( 'slices' => array( slice( 'again', 'respin', 1 ), slice( 'l', 'lose', 0 ) ), 'access' => array( 'mode' => 'free', 'limits' => array( array( 'count' => 1, 'period' => 'day', 'hours' => 24 ) ) ), 'engine' => array( 'max_respins' => 2 ) ) );
$g = function () { return guest( '09128888888', 'dev-rrrrrrrrrrrrrrrr' ); };
$a = $svc->spin( $w, $g() );
ok( 'respin' === $a['result'] && $a['state']['can'], 'respin gives an extra spin' );
$b = $svc->spin( $w, $g() );
$c3 = $svc->spin( $w, $g() );
ok( is_array( $b ) && is_array( $c3 ) && ! $c3['state']['can'], 'chain stops at max_respins (2)' );
$w = mkwheel( array( 'slices' => array( slice( 'prize', 'custom', 1 ), slice( 'l', 'lose', 1000 ) ), 'access' => array( 'mode' => 'free', 'limits' => array() ), 'engine' => array( 'first_spin_win' => true ) ) );
ok( 'win' === $svc->spin( $w, guest( '09129000001', 'dev-fffffffffffffff1' ) )['result'], 'first spin always wins' );
$w = mkwheel( array( 'slices' => array( slice( 'prize', 'custom', 1 ), slice( 'l', 'lose', 100000 ) ), 'access' => array( 'mode' => 'free', 'limits' => array() ), 'engine' => array( 'pity_after' => 2 ) ) );
$p = function () { return guest( '09129000002', 'dev-ppppppppppppppp2' ); };
$res = array( $svc->spin( $w, $p() )['result'], $svc->spin( $w, $p() )['result'], $svc->spin( $w, $p() )['result'] );
ok( 'win' === $res[2], 'pity: win guaranteed after 2 losses (' . implode( ',', $res ) . ')' );

echo "Prize types without WooCommerce\n";
$w = mkwheel( array( 'slices' => array( slice( 'cp', 'coupon_percent', 1000 ), slice( 'l', 'lose', 1 ) ), 'access' => array( 'mode' => 'free', 'limits' => array() ) ) );
ok( 'lose' === $svc->spin( $w, guest( '09129100000', 'dev-wwwwwwwwwwwwwww1' ) )['result'], 'coupon slices are skipped when WooCommerce is missing' );
$w = mkwheel( array( 'slices' => array( slice( 'pool', 'code_pool', 1000 ), slice( 'l', 'lose', 1 ) ), 'access' => array( 'mode' => 'free', 'limits' => array() ) ) );
\Becharkhoon\Prizes\CodePool::import( $w['id'], 'pool', "GIFT-AAA\nGIFT-BBB" );
$codes = array();
for ( $i = 0; $i < 4; $i++ ) { $r = $svc->spin( $w, guest( '0912920000' . $i, 'dev-pool' . str_pad( $i, 12, '0' ) ) ); $codes[] = $r['code']; }
ok( in_array( 'GIFT-AAA', $codes, true ) && in_array( 'GIFT-BBB', $codes, true ) && 2 === count( array_filter( $codes ) ), 'code pool hands out each code once, keeps case: ' . implode( ',', array_filter( $codes ) ) );
$w = mkwheel( array( 'slices' => array( slice( 'lnk', 'link', 1000, array( 'link_url' => 'https://x.ir/file.pdf' ) ), slice( 'l', 'lose', 1 ) ), 'access' => array( 'mode' => 'free', 'limits' => array() ) ) );
$r = $svc->spin( $w, guest( '09129300000', 'dev-link000000000001' ) );
ok( 'https://x.ir/file.pdf' === $r['link'], 'link prize returns its URL' );
$w = mkwheel( array( 'slices' => array( slice( 'phys', 'custom', 1000, array( 'requires_claim' => true ) ), slice( 'l', 'lose', 1 ) ), 'access' => array( 'mode' => 'free', 'limits' => array() ) ) );
$r = $svc->spin( $w, guest( '09129400000', 'dev-claim00000000001' ) );
ok( 'win' === $r['result'] && '' !== $r['claim'], 'physical prize returns a claim token' );
$w = mkwheel( array( 'slices' => array( slice( 'xs', 'extra_spin', 1000, array( 'value' => 2 ) ), slice( 'l', 'lose', 1 ) ), 'access' => array( 'mode' => 'credits', 'limits' => array() ) ) );
bch_make_user( 50, 'u50@x.ir' ); Ledger::grant( array( 'user_id' => 50, 'qty' => 1, 'wheel_id' => $w['id'] ) );
$r = $svc->spin( $w, member( 50 ) );
ok( 'win' === $r['result'] && 2 === Ledger::balance( member( 50 ), $w['id'] ), 'extra_spin prize adds 2 credits' );

echo "Schedule & test mode\n";
$w = mkwheel( array( 'schedule' => array( 'end' => '2000-01-01 00:00' ) ) );
ok( ! Eligibility::is_open( $w ), 'ended campaign is closed' );
$w = mkwheel( array( 'schedule' => array( 'days' => array( (int) wp_date( 'w' ) ) ) ) );
ok( Eligibility::is_open( $w ), 'open on an allowed weekday' );

echo "Security: boot token, OTP, block lists\n";
$t = Guard::issue_token( 'dev-token-0000000001' );
ok( Guard::check_token( $t, 'dev-token-0000000001' ), 'token valid for its device' );
ok( ! Guard::check_token( $t, 'dev-token-0000000002' ), 'token rejected for another device' );
ok( ! Guard::check_token( substr( $t, 0, -1 ) . ( 'a' === substr( $t, -1 ) ? 'b' : 'a' ), 'dev-token-0000000001' ), 'tampered token rejected' );
becharkhoon()->settings->update( array( 'sms_driver' => 'kavenegar', 'sms_fields' => array( 'kavenegar' => array( 'api_key' => 'KAVE-SECRET-KEY', 'sender' => '1000' ) ) ) );
$GLOBALS['__http'] = array();
$sent = Guard::otp_send( '09127777777', '9.9.9.9' );
ok( $sent['ok'], 'OTP sent' );
$req  = end( $GLOBALS['__http'] );
ok( $req && false !== strpos( $req['url'], 'KAVE-SECRET-KEY' ), 'driver used the decrypted API key' );
preg_match( '/:\s*(\d{5})/u', urldecode( $req['url'] . ' ' . ( is_array( $req['args']['body'] ?? null ) ? http_build_query( $req['args']['body'] ) : ( $req['args']['body'] ?? '' ) ) ), $mm );
$code = $mm[1] ?? '';
ok( 5 === strlen( $code ), 'OTP code found in request' );
ok( ! Guard::otp_send( '09127777777', '9.9.9.9' )['ok'], 'resend throttled' );
$err = '';
ok( '' === Guard::otp_verify( '09127777777', '00000', $err ) && '' !== $err, 'wrong code rejected' );
$tok = Guard::otp_verify( '09127777777', $code, $err );
ok( '' !== $tok && '09127777777' === Guard::verified_phone( $tok ), 'right code → verified session' );
ok( '' === Guard::otp_verify( '09127777777', $code, $err ), 'code cannot be reused' );
becharkhoon()->settings->update( array( 'block_phones' => "09121212121" ) );
ok( Eligibility::is_blocked( guest( '09121212121' ) ), 'blocked phone list' );
ok( '' !== Guard::email_error( 'a@mailinator.com' ), 'disposable email rejected' );

echo "Settings encryption\n";
$raw = get_option( 'bch_settings' );
$raw = is_array( $raw ) ? $raw : array();
$stored = $raw['sms_fields']['kavenegar']['api_key'] ?? '';
ok( '' !== $stored && 'KAVE-SECRET-KEY' !== $stored, 'API key stored encrypted' );
ok( 'KAVE-SECRET-KEY' === SmsGateways::config( 'kavenegar' )['api_key'], 'decrypts for sending' );
$adm = becharkhoon()->settings->for_admin();
ok( 'KAVE-SECRET-KEY' !== $adm['sms_fields']['kavenegar']['api_key'], 'masked for the admin UI' );
becharkhoon()->settings->update( array( 'sms_fields' => array( 'kavenegar' => array( 'api_key' => $adm['sms_fields']['kavenegar']['api_key'], 'sender' => '2000' ) ) ) );
ok( 'KAVE-SECRET-KEY' === SmsGateways::config( 'kavenegar' )['api_key'], 'saving the mask keeps the old secret' );
ok( 'x' === Crypto::decrypt( Crypto::encrypt( 'x' ) ), 'crypto round-trip' );

echo "SMS drivers (request built, no fatal)\n";
$soap = class_exists( 'SoapClient' );
foreach ( SmsGateways::drivers() as $id => $d ) {
	if ( $d->soap && ! $soap ) { ok( true, "$id (SOAP — skipped, ext-soap missing)" ); continue; }
	if ( $d->soap ) { ok( true, "$id (SOAP — needs a live endpoint, skipped)" ); continue; }
	$cfg = array();
	foreach ( $d->fields() as $k => $f ) { $cfg[ $k ] = 'select' === $f[1] && ! empty( $f[3] ) ? array_key_first( $f[3] ) : ( 'url' === $f[1] ? 'https://sms.example.ir/api' : 'v' . $k ); }
	$GLOBALS['__http'] = array();
	$r = SmsGateways::send( $id, $cfg, '09121234567', 'سلام' );
	$n = count( $GLOBALS['__http'] );
	ok( $n > 0 && '' === ( $r['error'] === 'invalid mobile' ? 'x' : '' ), "$id → $n request(s)" );
	if ( $d->pattern ) {
		$GLOBALS['__http'] = array();
		SmsGateways::pattern( $id, $cfg, '09121234567', '12345', 'kavenegar' === $id ? array( 'token' => '9876' ) : array( 'code' => '9876', 'prize' => 'جایزه' ) );
		ok( count( $GLOBALS['__http'] ) > 0, "$id pattern → request" );
	}
}

echo "SMS centre (events, templates, pattern, test mode, log)\n";
use Becharkhoon\Notify\Sms;
use Becharkhoon\Notify\SmsEvents;
global $wpdb;
$smsrows = function ( $ctx = '' ) { global $wpdb; return $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}bch_sms" . ( $ctx ? " WHERE context = '$ctx'" : '' ) . ' ORDER BY id DESC', ARRAY_A ); };
becharkhoon()->settings->update( array( 'sms_driver' => 'generic', 'sms_enabled' => true, 'sms_test_mode' => false, 'admin_phones' => "09120000001\n0912 000 0002", 'sms_fields' => array( 'generic' => array( 'url' => 'https://sms.example.ir/send', 'method' => 'POST', 'content_type' => 'json', 'body' => '{"to":"{to}","text":"{text}"}', 'p_url' => 'https://sms.example.ir/pattern', 'p_body' => '{"to":"{to}","code":"{pattern}","params":{params_json}}' ) ) ) );
ok( 'live' === Sms::mode(), 'mode live with a panel' );
ok( count( SmsEvents::all() ) >= 8, 'events registered: ' . implode( ',', array_keys( SmsEvents::all() ) ) );
ok( SmsEvents::unknown_vars( 'otp', 'کد {otp} برای {prize}' ) === array( 'prize' ), 'unknown variable detected for an event' );
ok( "سلام علی\nکد X" === Sms::render( "سلام {name}{nope}\nکد {code}", array( 'name' => 'علی', 'code' => 'X' ) ), 'render replaces vars and drops unknown ones' );
$GLOBALS['__http'] = array();
$r = Sms::send_event( 'win', array( 'name' => 'رضا', 'prize' => '۲۰٪ تخفیف', 'code' => 'WHEEL-ABC', 'expiry' => '۱۴۰۵/۰۸/۰۱' ), '0912 111 2233' );
$row = $smsrows( 'win' )[0] ?? array();
ok( 1 === $r['sent'] && 'sent' === ( $row['status'] ?? '' ) && '09121112233' === $row['mobile'], 'win SMS sent + logged with normalised mobile' );
ok( false !== strpos( $row['message'], 'WHEEL-ABC' ) && false !== strpos( $row['message'], 'رضا' ), 'default win text rendered with variables' );
becharkhoon()->settings->update( array( 'sms_tpl' => array( 'win' => array( 'on' => true, 'mode' => 'pattern', 'text' => 'X {code}', 'code' => '۱۲۳۴۵', 'params' => "name={name}\ncode={code}\nempty={email}" ) ) ) );
$GLOBALS['__http'] = array();
Sms::send_event( 'win', array( 'name' => 'رضا', 'code' => 'WHEEL-ABC' ), '09121112233' );
$req = end( $GLOBALS['__http'] );
$body = json_decode( $req['args']['body'] ?? '{}', true );
ok( false !== strpos( $req['url'], '/pattern' ) && '12345' === ( $body['code'] ?? '' ), 'pattern mode → pattern endpoint, Persian digits in code normalised' );
ok( 'رضا' === ( $body['params']['name'] ?? '' ) && '-' === ( $body['params']['empty'] ?? '' ), 'pattern params rendered, empty param sent as "-"' );
ok( 0 === strpos( $smsrows( 'win' )[0]['message'], '[' ), 'pattern logged as [الگو code] params' );
becharkhoon()->settings->update( array( 'sms_tpl' => array( 'win' => array( 'on' => false, 'mode' => 'text', 'text' => '', 'code' => '', 'params' => '' ) ) ) );
ok( 'off' === Sms::send_event( 'win', array(), '09121112233' )['response'], 'event switched off globally → not sent' );
ok( 1 === Sms::send_event( 'win', array(), '09121112233', array( 'force' => true ) )['sent'], 'force (resend/test) ignores the switch' );
becharkhoon()->settings->update( array( 'sms_tpl' => array( 'win' => array( 'on' => true, 'mode' => 'text', 'text' => '', 'code' => '', 'params' => '' ) ) ) );
$r = Sms::send_event( 'admin_spin', array( 'wheel' => 'W', 'prize' => 'P' ) );
ok( 2 === $r['sent'], 'admin event goes to both admin mobiles' );
becharkhoon()->settings->update( array( 'sms_test_mode' => true ) );
$GLOBALS['__http'] = array();
$r = Sms::send_event( 'win', array( 'code' => 'T' ), '09121112233' );
ok( 'test' === $r['mode'] && 0 === count( $GLOBALS['__http'] ) && 'test' === $smsrows( 'win' )[0]['status'], 'test mode: nothing sent, logged as test' );
becharkhoon()->settings->update( array( 'sms_test_mode' => false, 'sms_enabled' => false ) );
$r = Sms::send_event( 'win', array(), '09121112233' );
ok( 'disabled' === $r['mode'] && 0 === $r['sent'] && 'disabled' === $smsrows( 'win' )[0]['status'], 'sending off: logged as disabled' );
becharkhoon()->settings->update( array( 'sms_enabled' => true ) );
ok( 0 === Sms::send_many( array( array( 'mobile' => '123', 'text' => 'x' ) ) )['sent'], 'invalid mobile rejected' );
$w = mkwheel( array( 'slices' => array( slice( 'pz', 'custom', 1000 ), slice( 'l', 'lose', 1 ) ), 'access' => array( 'mode' => 'free', 'limits' => array() ), 'notify' => array( 'sms_customer' => true, 'admin_sms' => true, 'sms_override' => true, 'sms_text' => 'ویژه این گردونه: {prize}' ) ) );
$before = count( $smsrows() );
$svc->spin( $w, guest( '09123456780', 'dev-smsx000000000001' ), array( 'name' => 'مینا' ) );
$wins = $smsrows( 'win' );
ok( false !== strpos( $wins[0]['message'], 'ویژه این گردونه' ) && (int) $wins[0]['wheel_id'] === (int) $w['id'], 'spin → wheel override text used, wheel id logged' );
ok( count( $smsrows() ) - $before === 3, 'spin also sent the admin SMS to both admins' );
$GLOBALS['__http'] = array();
ok( Guard::otp_send( '09128765432', '8.8.8.8' )['ok'], 'OTP through the central sender' );
ok( false !== strpos( $smsrows( 'otp' )[0]['message'], 'کد تایید' ), 'OTP default text uses {otp}' );
$Q = Sms::log_query( array( 'context' => 'otp' ) );
ok( $Q['total'] >= 1 && isset( $Q['stats']['sent'] ), 'log query + stats' );
ok( Sms::erase_phone( '09128765432' ) >= 1 && 0 === Sms::log_query( array( 'search' => '09128765432' ) )['total'], 'privacy: phone erased from SMS log' );
update_option( 'bch_settings', array_merge( get_option( 'bch_settings' ), array( 'otp_mode' => 'pattern', 'otp_pattern' => '777', 'otp_pattern_var' => 'token', 'otp_text' => 'کد {code}', 'sms_tpl' => array() ) ) );
\Becharkhoon\Core\Installer::migrate_sms_templates();
$mt = get_option( 'bch_settings' )['sms_tpl']['otp'] ?? array();
ok( 'pattern' === $mt['mode'] && '777' === $mt['code'] && 'token={otp}' === $mt['params'] && 'کد {otp}' === $mt['text'], 'v3 → v4 OTP settings migrated' );

echo "SMS pattern fallback + panel marker\n";
$orig = $GLOBALS['__http_responder'];
$GLOBALS['__http_responder'] = function ( $url, $args ) { return false !== strpos( $url, '/pattern' ) ? array( 'code' => 500, 'body' => '{"error":"pattern not approved"}' ) : array( 'code' => 200, 'body' => '{"status":1}' ); };
becharkhoon()->settings->update( array( 'sms_tpl' => array( 'win' => array( 'on' => true, 'mode' => 'pattern', 'text' => 'متن پشتیبان {code}', 'code' => '999', 'params' => 'code={code}', 'fallback' => true ) ) ) );
$GLOBALS['__http'] = array();
$r = Sms::send_event( 'win', array( 'code' => 'FB-1' ), '09121112233' );
$urls = array_map( function ( $x ) { return $x['url']; }, $GLOBALS['__http'] );
ok( 1 === $r['sent'] && 2 === count( $urls ) && false !== strpos( $urls[1], '/send' ), 'pattern rejected → fallback text sent' );
$rows = $smsrows( 'win' );
ok( 'sent' === $rows[0]['status'] && false !== strpos( $rows[0]['message'], 'FB-1' ) && 'failed' === $rows[1]['status'], 'log shows failed pattern + sent fallback' );
becharkhoon()->settings->update( array( 'sms_tpl' => array( 'win' => array( 'on' => true, 'mode' => 'pattern', 'text' => 'x', 'code' => '999', 'params' => 'code={code}', 'fallback' => false ) ) ) );
$r = Sms::send_event( 'win', array( 'code' => 'FB-2' ), '09121112233' );
ok( 0 === $r['sent'] && 1 === $r['failed'], 'no fallback → failure reported' );
$GLOBALS['__http_responder'] = $orig;
ok( '#{}#' === \Becharkhoon\Notify\SmsGateways::marker( 'smsir', 'named' ) && '{{}}' === \Becharkhoon\Notify\SmsGateways::marker( 'melipayamak', 'positional' ) && '%{}%' === \Becharkhoon\Notify\SmsGateways::marker( 'ippanel', 'named' ), 'pattern variable markers per panel' );

echo "Sticky coupon bar state\n";
use Becharkhoon\Front\CouponBar;
global $wpdb;
$w  = mkwheel( array( 'slices' => array( slice( 'pool', 'code_pool', 1000 ), slice( 'l', 'lose', 1 ) ), 'access' => array( 'mode' => 'free', 'limits' => array() ) ) );
\Becharkhoon\Prizes\CodePool::import( $w['id'], 'pool', "BAR-ONE\nBAR-TWO\nBAR-THREE" );
bch_make_user( 70, 'u70@x.ir' );
$rb = $svc->spin( $w, member( 70 ) );
ok( 'BAR-' === substr( $rb['code'], 0, 4 ), 'won a code for the bar' );
$b = CouponBar::state( guest(), array( 'code' => $rb['code'], 'sid' => $rb['spin_id'], 'w' => $w['id'] ) );
ok( 'active' === $b['status'] && $b['code'] === $rb['code'] && isset( $b['cfg']['display']['coupon_bar_layout'] ) && (int) $b['w'] === (int) $w['id'], 'unused code → active, with bar config for every page' );
ok( ! isset( $b['cfg']['display']['launcher'] ) && ! isset( $b['cfg']['slices'] ), 'bar config carries only bar keys' );
$b = CouponBar::state( guest(), array( 'code' => 'NOPE-123' ) );
ok( 'gone' === $b['status'], 'unknown code → gone (browser forgets it)' );
ok( null === CouponBar::state( guest(), null ), 'nothing stored, anonymous → no bar' );
$acc = CouponBar::state( member( 70 ), null );
ok( $acc && 'active' === $acc['status'] && $acc['code'] === $rb['code'], 'logged-in user on a new device → bar follows the account' );
$wpdb->update( $wpdb->prefix . 'bch_spins', array( 'expires_at' => gmdate( 'Y-m-d H:i:s', time() - 60 ) ), array( 'id' => $rb['spin_id'] ) );
ok( 'expired' === CouponBar::state( guest(), array( 'code' => $rb['code'], 'sid' => $rb['spin_id'] ) )['status'], 'past expiry → expired' );
ok( null === CouponBar::state( member( 70 ), null ), 'expired code is not surfaced on other devices' );
$wpdb->update( $wpdb->prefix . 'bch_spins', array( 'expires_at' => gmdate( 'Y-m-d H:i:s', time() + 3600 ), 'status' => 'redeemed' ), array( 'id' => $rb['spin_id'] ) );
ok( 'used' === CouponBar::state( guest(), array( 'code' => $rb['code'], 'sid' => $rb['spin_id'] ) )['status'], 'redeemed (ordered) → used, bar removed for good' );
$rb2 = $svc->spin( $w, guest( '09127700001', 'dev-bar0000000000001' ) );
$cfg = $w['config']; $cfg['display']['coupon_bar'] = false; $repo->update( $w['id'], array( 'config' => $cfg ) ); $repo->flush();
ok( 'off' === CouponBar::state( guest(), array( 'code' => $rb2['code'], 'sid' => $rb2['spin_id'] ) )['status'], 'bar turned off for the wheel → off' );
$cfg['display']['coupon_bar'] = true; $repo->update( $w['id'], array( 'config' => $cfg ) ); $repo->flush();
// Applied to the current cart → hidden (only while it stays in the cart).
if ( ! function_exists( 'WC' ) ) {
	class BCH_Test_Cart { public $codes = array(); public function has_discount( $c ) { return in_array( strtolower( $c ), $this->codes, true ); } }
	$GLOBALS['__wc'] = (object) array( 'cart' => new BCH_Test_Cart() );
	function WC() { return $GLOBALS['__wc']; }
}
$GLOBALS['__wc']->cart->codes = array( strtolower( $rb2['code'] ) );
ok( 'applied' === CouponBar::state( guest(), array( 'code' => $rb2['code'], 'sid' => $rb2['spin_id'] ) )['status'], 'code in the cart → applied (bar hidden)' );
$cfg['display']['coupon_bar_hide_applied'] = false; $repo->update( $w['id'], array( 'config' => $cfg ) ); $repo->flush();
ok( 'active' === CouponBar::state( guest(), array( 'code' => $rb2['code'], 'sid' => $rb2['spin_id'] ) )['status'], '"hide when applied" off → stays visible' );
$cfg['display']['coupon_bar_hide_applied'] = true; $repo->update( $w['id'], array( 'config' => $cfg ) ); $repo->flush();
$GLOBALS['__wc']->cart->codes = array();
ok( 'active' === CouponBar::state( guest(), array( 'code' => $rb2['code'], 'sid' => $rb2['spin_id'] ) )['status'], 'removed from the cart → active again until expiry' );
$GLOBALS['__wc']->cart = null;
$S = Schema::sanitize( array( 'display' => array( 'coupon_bar_layout' => 'evil', 'coupon_bar_font' => 99, 'coupon_bar_copy_bg' => 'red;}', 'coupon_bar_copy_label' => 'کپی کن', 'coupon_bar_icon' => '<b>🎁</b>' ), 'popup' => array( 'code_style' => 'glow', 'copy_bg' => '#ff0000', 'icon_wait' => '⌛' ), 'slices' => array( slice( 'a', 'lose', 1 ), slice( 'b', 'lose', 1 ) ) ) );
ok( 'full' === $S['display']['coupon_bar_layout'] && 22 === $S['display']['coupon_bar_font'] && '' === $S['display']['coupon_bar_copy_bg'] && 'کپی کن' === $S['display']['coupon_bar_copy_label'] && '🎁' === $S['display']['coupon_bar_icon'], 'bar style keys sanitized (enum, range, color, text, emoji)' );
ok( 'glow' === $S['popup']['code_style'] && '#ff0000' === $S['popup']['copy_bg'] && '⌛' === $S['popup']['icon_wait'], 'result/state style keys kept' );

echo "Random gift product\n";
use Becharkhoon\Prizes\Gifts;
$items = Gifts::sanitize_items( array( array( 'name' => 'کیف چرمی', 'image' => 'https://x.ir/a.jpg', 'price' => '۲۵۰۰۰۰' ), array( 'name' => '' ), array( 'name' => 'ماگ', 'price' => 90000, 'weight' => 0 ), array( 'name' => '<b>تیشرت</b>', 'price' => -5, 'weight' => 3 ) ) );
ok( 3 === count( $items ) && 250000.0 === $items[0]['price'] && 'تیشرت' === $items[2]['name'] && 0.0 === $items[2]['price'], 'manual gifts sanitized (empty dropped, Persian digits, HTML stripped, no negative price)' );
$gs = array( 'type' => 'free_product', 'product_ids' => array(), 'gift_items' => $items );
$seen = array();
for ( $i = 0; $i < 400; $i++ ) { $g = Gifts::pick( $gs ); $seen[ $g['name'] ] = ( $seen[ $g['name'] ] ?? 0 ) + 1; }
ok( ! isset( $seen['ماگ'] ) && isset( $seen['کیف چرمی'], $seen['تیشرت'] ) && $seen['تیشرت'] > $seen['کیف چرمی'], 'random pick among the list, weight 0 never drawn, weights respected (' . json_encode( $seen, JSON_UNESCAPED_UNICODE ) . ')' );
ok( null === Gifts::pick( array( 'product_ids' => array(), 'gift_items' => array() ) ), 'empty list → nothing to draw (slice can not be won)' );
$S = Schema::sanitize( array( 'slices' => array( slice( 'g', 'free_product', 1, array( 'gift_items' => array( array( 'name' => 'هدیه', 'price' => 5 ) ) ) ), slice( 'b', 'lose', 1 ) ) ) );
ok( 'هدیه' === $S['slices'][0]['gift_items'][0]['name'], 'schema keeps manual gift items' );

// Cart flow with minimal WooCommerce mocks.
$GLOBALS['__pm'] = array();
if ( ! function_exists( 'get_post_meta' ) ) { function get_post_meta( $id, $k, $single = false ) { return $GLOBALS['__pm'][ $id ][ $k ] ?? ''; } }
if ( ! function_exists( 'wc_format_coupon_code' ) ) { function wc_format_coupon_code( $c ) { return strtolower( trim( (string) $c ) ); } }
if ( ! function_exists( 'wc_get_coupon_id_by_code' ) ) { function wc_get_coupon_id_by_code( $c ) { return array( 'gift-1' => 901, 'gift-2' => 902 )[ strtolower( $c ) ] ?? 0; } }
if ( ! function_exists( 'get_post_status' ) ) { function get_post_status( $id ) { return 'publish'; } }
if ( ! function_exists( 'wc_price' ) ) { function wc_price( $v ) { return number_format( (float) $v ) . ' T'; } }
class BCH_Test_Product { public $id; public $price; public $name; public function __construct( $id, $price, $name ) { $this->id = $id; $this->price = $price; $this->name = $name; } public function get_id() { return $this->id; } public function set_price( $p ) { $this->price = $p; } public function get_price() { return $this->price; } public function set_name( $n ) { $this->name = $n; } public function get_name() { return $this->name; } public function is_purchasable() { return true; } public function is_in_stock() { return true; } public function is_type( $t ) { return false; } }
if ( ! function_exists( 'wc_get_product' ) ) { function wc_get_product( $id ) { return in_array( (int) $id, array( 555, 777 ), true ) ? new BCH_Test_Product( (int) $id, 555 === (int) $id ? 0 : 120000, 555 === (int) $id ? 'vehicle' : 'شال' ) : false; } }
class BCH_Gift_Cart {
	public $cart_contents = array(); public $applied = array();
	public function get_cart() { return $this->cart_contents; }
	public function get_applied_coupons() { return $this->applied; }
	public function get_cart_item( $k ) { return $this->cart_contents[ $k ] ?? array(); }
	public function remove_cart_item( $k ) { unset( $this->cart_contents[ $k ] ); }
	public function add_to_cart( $pid, $qty = 1, $var = 0, $attrs = array(), $data = array() ) { $k = md5( $pid . json_encode( $data ) ); $this->cart_contents[ $k ] = array_merge( $data, array( 'product_id' => $pid, 'quantity' => $qty, 'data' => wc_get_product( $pid ) ) ); return $k; }
}
update_option( 'bch_gift_vehicle', 555 );
$GLOBALS['__pm'][901]['_bch_gift'] = array( 'kind' => 'custom', 'id' => 0, 'key' => 'cabc', 'name' => 'کیف چرمی', 'image' => 'https://x.ir/a.jpg', 'price' => 250000 );
$GLOBALS['__pm'][902]['_bch_gift'] = array( 'kind' => 'product', 'id' => 777, 'key' => 'p777', 'name' => 'شال', 'image' => '', 'price' => 120000 );
$cart = new BCH_Gift_Cart();
$GLOBALS['__wc'] = (object) array( 'cart' => $cart );
$gx = new Gifts();
$cart->applied = array( 'gift-1' ); $gx->on_applied( 'GIFT-1' );
$cart->applied[] = 'gift-2'; $gx->on_applied( 'gift-2' );
$gx->on_applied( 'gift-2' ); // applying twice must not add twice
ok( 2 === count( $cart->cart_contents ), 'applied codes add exactly one gift line each' );
$cart->cart_contents[ array_keys( $cart->cart_contents )[0] ]['quantity'] = 4;
$gx->prices( $cart );
$lines = array_values( $cart->cart_contents );
ok( 0 === $lines[0]['data']->get_price() && 0 === $lines[1]['data']->get_price() && 1 === $lines[0]['quantity'], 'gift lines are free and limited to qty 1' );
ok( 'کیف چرمی' === $lines[0]['data']->get_name() && 555 === $lines[0]['product_id'], 'manual gift travels on the hidden vehicle product with its own name' );
$meta = $gx->item_data( array(), $lines[0] );
ok( false !== strpos( $meta[0]['value'], 'هدیه گردونه شانس' ), 'cart line shows «هدیه گردونه شانس»' );
ok( false !== strpos( $gx->thumbnail( '<img>', $lines[0] ), 'a.jpg' ) && false !== strpos( $gx->price_html( '', $lines[0] ), '<del>' ), 'manual gift shows its image and struck price' );
$ord = new class() { public $m = array(); public $name = ''; public function add_meta_data( $k, $v, $u = false ) { $this->m[ $k ] = $v; } public function set_name( $n ) { $this->name = $n; } };
$gx->order_item( $ord, 'k', $lines[0] );
ok( 'کیف چرمی' === $ord->name && 'GIFT-1' === $ord->m['کد گردونه'] && false !== strpos( $ord->m['هدیه'], 'هدیه گردونه شانس' ), 'order line keeps name, code and the gift note' );
$cart->applied = array( 'gift-2' );
$gx->prices( $cart );
ok( 1 === count( $cart->cart_contents ) && 777 === array_values( $cart->cart_contents )[0]['product_id'], 'code removed → its free gift leaves the cart' );
$gx->on_removed( 'GIFT-2' );
ok( 0 === count( $cart->cart_contents ), 'removing the coupon removes the gift line' );
$GLOBALS['__wc']->cart = null;

echo "Responsive + layout (Elementor-like)\n";
$c = Schema::sanitize( array(
	'slices'     => array( slice( 'a', 'lose', 1 ), slice( 'b', 'lose', 1 ) ),
	'layout'     => array( 'button' => array( 'x' => '12', 'y' => 0, 'align' => 'center', 'w' => 250, 'hide' => 0 ), 'evil' => array( 'x' => 5 ), 'wheel' => array( 'x' => 99999 ) ),
	'responsive' => array(
		'mobile' => array( 'form.button_radius' => '30', 'design.size_mobile' => 99999, 'popup.title' => 'hack', 'layout.button.x' => '-20', 'layout.wheel.hide' => 1, 'form.button_bg' => 'red;}', 'form.button_color' => '#ff0000', 'access.mode' => 'free', 'form.fields' => 'x', 'layout.nope.x' => 3 ),
		'tablet' => array( 'popup.width' => 880 ),
	),
) );
ok( array( 'x' => 12, 'w' => 100, 'align' => 'center' ) == $c['layout']['button'] && 800 === $c['layout']['wheel']['x'] && ! isset( $c['layout']['evil'] ), 'layout sanitized: known elements only, clamped, defaults dropped' );
$m = $c['responsive']['mobile'];
ok( 30 === $m['form.button_radius'] && 520 === $m['design.size_mobile'] && '#ff0000' === $m['form.button_color'], 'device overrides validated with the same rules as desktop (range clamp)' );
ok( ! isset( $m['popup.title'] ) && ! isset( $m['access.mode'] ) && ! isset( $m['form.fields'] ) && ! isset( $m['form.button_bg'] ) && ! isset( $m['layout.nope.x'] ), 'texts, logic, lists, invalid values and unknown elements are not per-device' );
ok( -20 === $m['layout.button.x'] && true === $m['layout.wheel.hide'], 'per-device position / hide kept' );
ok( array() === $c['responsive']['tablet'], 'override equal to desktop is dropped' );
ok( Schema::responsive_ok( 'form.button_radius' ) && ! Schema::responsive_ok( 'form.button_text' ) && ! Schema::responsive_ok( 'messages.win_text' ), 'responsive whitelist' );
$pc = \Becharkhoon\Front\Frontend::public_config( array( 'id' => 1, 'title' => 'x', 'config' => $c ) );
ok( isset( $pc['layout'], $pc['responsive']['mobile'] ) && is_object( $pc['responsive']['tablet'] ), 'browser gets layout + per-device overrides (empty maps as objects)' );

echo "Reports: real WooCommerce discounts (orders mirror)\n";
use Becharkhoon\Stats\Orders;
use Becharkhoon\Stats\Reports;
use Becharkhoon\Stats\People;
class BCH_Coupon_Item { public $c; public $d; public function __construct( $c, $d ) { $this->c = $c; $this->d = $d; } public function get_code() { return $this->c; } public function get_discount() { return $this->d; } public function get_discount_tax() { return 0; } }
global $wpdb;
$wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}woocommerce_order_items (order_item_id INTEGER PRIMARY KEY AUTOINCREMENT, order_item_name TEXT, order_item_type TEXT, order_id INTEGER)" );
$wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}woocommerce_order_itemmeta (meta_id INTEGER PRIMARY KEY AUTOINCREMENT, order_item_id INTEGER, meta_key TEXT, meta_value TEXT)" );
$wpdb->query( "DELETE FROM {$wpdb->prefix}bch_orders" );
$rw = mkwheel( array( 'slices' => array( slice( 'a', 'lose', 1 ), slice( 'b', 'lose', 1 ) ) ) );
$mk = function ( $code, $label, $type, $phone, $ago ) use ( $rw ) { global $wpdb; $wpdb->insert( $wpdb->prefix . 'bch_spins', array( 'wheel_id' => $rw['id'], 'slice_label' => $label, 'prize_type' => $type, 'result' => 'win', 'status' => 'issued', 'coupon_code' => strtolower( $code ), 'phone' => $phone, 'created_at' => \Becharkhoon\Core\Helpers::now( -$ago ), 'source' => 'popup' ) ); return (int) $wpdb->insert_id; };
$mk( 'WHEEL-TEN', '۱۰٪ تخفیف', 'coupon_percent', '09120000001', 3 * 3600 );
$mk( 'WHEEL-50K', '۵۰ هزار تومان', 'coupon_fixed_cart', '09120000002', 30 * 3600 );
$mk( 'WHEEL-OLD', '۲۰٪', 'coupon_percent', '09120000003', 90 * 86400 );
$mk( 'WHEEL-CAN', '۱۰٪ تخفیف', 'coupon_percent', '09120000004', 3600 );
Orders::wheel_codes( true );
$orders = array(
	array( 'id' => 9001, 'status' => 'completed', 'total' => 4500000, 'phone' => '09120000001', 'coupons' => array( 'wheel-ten' ), 'items_coupon' => array( new BCH_Coupon_Item( 'wheel-ten', 500000 ) ), 'date' => '-2 days' ),
	array( 'id' => 9002, 'status' => 'completed', 'total' => 950000, 'phone' => '09120000002', 'coupons' => array( 'wheel-50k', 'other-code' ), 'items_coupon' => array( new BCH_Coupon_Item( 'wheel-50k', 50000 ), new BCH_Coupon_Item( 'other-code', 77000 ) ), 'date' => '-1 day' ),
	array( 'id' => 9003, 'status' => 'cancelled', 'total' => 900000, 'phone' => '09120000004', 'coupons' => array( 'wheel-can' ), 'items_coupon' => array( new BCH_Coupon_Item( 'wheel-can', 100000 ) ), 'date' => '-1 day' ),
	array( 'id' => 9004, 'status' => 'completed', 'total' => 2000000, 'phone' => '09120000003', 'coupons' => array( 'wheel-old' ), 'items_coupon' => array( new BCH_Coupon_Item( 'wheel-old', 400000 ) ), 'date' => '-60 days' ),
	array( 'id' => 9005, 'status' => 'completed', 'total' => 300000, 'phone' => '09120000009', 'coupons' => array( 'not-wheel' ), 'items_coupon' => array( new BCH_Coupon_Item( 'not-wheel', 30000 ) ), 'date' => '-1 day' ),
);
foreach ( $orders as $o ) {
	bch_order( $o );
	foreach ( $o['coupons'] as $c ) { $wpdb->insert( $wpdb->prefix . 'woocommerce_order_items', array( 'order_item_name' => $c, 'order_item_type' => 'coupon', 'order_id' => $o['id'] ) ); }
}
if ( ! function_exists( 'wc_get_order_statuses' ) ) { function wc_get_order_statuses() { return array( 'wc-pending' => 'p', 'wc-processing' => 'pr', 'wc-on-hold' => 'h', 'wc-completed' => 'c', 'wc-cancelled' => 'x', 'wc-refunded' => 'r', 'wc-failed' => 'f' ); } }
Orders::restart( false );
$sync = Orders::backfill( 2 ); // Tiny batches: cursor must advance.
for ( $i = 0; $i < 10 && ! $sync['done']; $i++ ) { $sync = Orders::backfill( 2 ); }
ok( $sync['done'] && 4 === $sync['rows'], 'backfill of past orders: 4 wheel orders mirrored, foreign codes ignored (' . $sync['rows'] . ')' );
$p  = Reports::period( wp_date( 'Y-m-d', time() - 6 * DAY_IN_SECONDS ), wp_date( 'Y-m-d' ) );
$tt = Orders::totals( $p['from_utc'], $p['to_utc'], array( 'completed' ) );
ok( 550000.0 === $tt['discount'] && 2 === $tt['orders'], 'last 7 days, completed only: discount 500,000 + 50,000 = 550,000 (' . $tt['discount'] . ')' );
ok( 5450000.0 === $tt['total'] && 2725000.0 === $tt['avg_order'], 'sales and average order of completed wheel orders' );
$bs = array(); foreach ( Orders::by_status( $p['from_utc'], $p['to_utc'] ) as $x ) { $bs[ $x['status'] ] = (int) $x['orders']; }
ok( 1 === ( $bs['cancelled'] ?? 0 ) && 2 === ( $bs['completed'] ?? 0 ), 'cancelled orders are not counted as sales but shown separately' );
$y  = Reports::period( wp_date( 'Y-m-d', time() - 365 * DAY_IN_SECONDS ), wp_date( 'Y-m-d' ) );
ok( 950000.0 === Orders::totals( $y['from_utc'], $y['to_utc'], array( 'completed' ) )['discount'], 'longer period includes the older order (950,000)' );
ok( 650000.0 === Orders::totals( $p['from_utc'], $p['to_utc'], array( 'completed', 'cancelled' ) )['discount'], 'status filter: completed + cancelled = 650,000' );
// Live: an order cancelled later leaves the sales.
$GLOBALS['__orders'][9001]->d['status'] = 'cancelled';
( new Orders() )->on_status( 9001, 'completed', 'cancelled' );
ok( 50000.0 === Orders::totals( $p['from_utc'], $p['to_utc'], array( 'completed' ) )['discount'], 'order cancelled later → its discount leaves the report immediately' );
$GLOBALS['__orders'][9001]->d['status'] = 'completed';
Orders::sync( 9001 );
$b = Reports::build( array( 'from' => wp_date( 'Y-m-d', time() - 6 * DAY_IN_SECONDS ), 'to' => wp_date( 'Y-m-d' ), 'statuses' => 'completed' ) );
ok( 550000.0 === $b['money']['discount'] && count( $b['series'] ) >= 7 && isset( $b['timing']['avg_hours'], $b['by_type'][0] ), 'full report builds (series, timing, discount by prize type)' );
$sum = 0; foreach ( $b['series'] as $d ) { $sum += $d['discount']; }
ok( 550000.0 === (float) $sum, 'daily discount series adds up to the total' );
$tp = array(); foreach ( $b['prizes'] as $x ) { $tp[ $x['label'] ] = $x['discount']; }
ok( 500000.0 === (float) ( $tp['۱۰٪ تخفیف'] ?? 0 ) && 50000.0 === (float) ( $tp['۵۰ هزار تومان'] ?? 0 ), 'discount per prize' );
$q = Orders::query( $p['from_utc'], $p['to_utc'], array( 'completed' ), 'created', 0, '0912000000' );
ok( 2 === $q['total'], 'order list search by phone' );

echo "User spins: everyone who spun or got spins\n";
$from = '1970-01-01 00:00:00'; $to = '2999-12-31 23:59:59';
$pq = People::query( array( 'from_utc' => $from, 'to_utc' => $to, 'per_page' => 500 ) );
ok( $pq['total'] > 0 && $pq['sum']['spins'] > 0, 'free-mode spins show up (people: ' . $pq['total'] . ', spins: ' . $pq['sum']['spins'] . ')' );
$one = People::query( array( 'from_utc' => $from, 'to_utc' => $to, 'search' => '09120000002' ) );
ok( 1 === $one['total'] && 1 === $one['items'][0]['wins'], 'search a person by mobile' );
$ev = People::events( array( 'from_utc' => $from, 'to_utc' => $to, 'person' => $one['items'][0]['key'] ) );
ok( $ev['total'] >= 1 && 'spin' === $ev['items'][0]['type'], 'person timeline (spins + grants)' );
$recent = People::query( array( 'from_utc' => \Becharkhoon\Core\Helpers::now( -2 * 3600 ), 'to_utc' => \Becharkhoon\Core\Helpers::now( -1800 ) ) );
$phones = array_column( $recent['items'], 'phone' );
ok( in_array( '09120000004', $phones, true ) && ! in_array( '09120000001', $phones, true ), 'exact time filter (last 2 hours): ' . implode( ',', $phones ) );
$ct = People::contacts( array( 'source' => 'all', 'need_phone' => true ) );
$nums = array_column( $ct['rows'], 'phone' );
ok( count( $nums ) === count( array_unique( $nums ) ) && in_array( '09120000002', $nums, true ), 'contacts export: de-duplicated mobiles' );
ok( '989121234567' === People::phone_style( '09121234567', '98' ) && '9121234567' === People::phone_style( '09121234567', '9' ) && '+989121234567' === People::phone_style( '09121234567', '+98' ), 'phone styles for SMS panels' );

echo "Granted spins always usable (bug: free wheel said «no spins»)\n";
$fw = mkwheel( array( 'slices' => array( slice( 'l1', 'lose', 1 ), slice( 'l2', 'lose', 1 ) ), 'access' => array( 'mode' => 'free', 'limits' => array( array( 'count' => 1, 'period' => 'day', 'hours' => 24 ) ) ) ) );
bch_make_user( 80, 'u80@x.ir' );
ok( is_array( $svc->spin( $fw, member( 80 ) ) ), 'free quota spin' );
ok( ! Eligibility::check( $fw, member( 80 ) )['ok'], 'quota used up' );
Ledger::grant( array( 'user_id' => 80, 'qty' => 1, 'wheel_id' => $fw['id'], 'reason' => 'manual' ) );
$e = Eligibility::check( $fw, member( 80 ) );
ok( $e['ok'] && 'credit' === $e['via'], 'admin-granted spin works on a free wheel after the quota' );
ok( is_array( $svc->spin( $fw, member( 80 ) ) ) && ! Eligibility::check( $fw, member( 80 ) )['ok'], 'granted spin consumed exactly once' );
$cw = mkwheel( array( 'slices' => array( slice( 'l1', 'lose', 1 ), slice( 'l2', 'lose', 1 ) ), 'access' => array( 'mode' => 'credits', 'limits' => array( array( 'count' => 1, 'period' => 'day', 'hours' => 24 ) ) ) ) );
bch_make_user( 81, 'u81@x.ir' );
Ledger::grant( array( 'user_id' => 81, 'qty' => 3, 'wheel_id' => $cw['id'], 'reason' => 'manual' ) );
$n = 0; for ( $i = 0; $i < 5; $i++ ) { if ( is_array( $svc->spin( $cw, member( 81 ) ) ) ) { $n++; } }
ok( 3 === $n, 'credits wheel: 3 granted spins = 3 spins even with a 1/day limit (' . $n . ')' );
$g = guest( '', 'dev-ident00000000001', false );
$svc->spin( $fw, $g );
Ledger::grant( array( 'user_id' => 0, 'phone' => '09129998877', 'qty' => 1, 'wheel_id' => $fw['id'], 'reason' => 'bulk' ) );
$ge = Eligibility::check( $fw, $g );
ok( ! $ge['ok'] && 'identify' === $ge['reason'], 'unidentified guest is asked for the mobile when spins were granted to numbers' );

echo "Bulk SMS: real spins for every recipient\n";
use Becharkhoon\Notify\Bulk;
$nums = array(); for ( $i = 0; $i < 100; $i++ ) { $nums[] = '0915' . str_pad( (string) $i, 7, '0', STR_PAD_LEFT ); }
$GLOBALS['__http'] = array();
$start = Bulk::start( array( 'source' => 'manual', 'numbers' => implode( "\n", $nums ) . "\n0915000000x\n09150000001", 'text' => '{name} عزیز، {n} شانس گرفتی: {wheel_link}', 'grant' => 1, 'grant_wheel' => $fw['id'], 'grant_days' => 7 ) );
ok( 100 === $start['total'], 'audience: 100 unique valid numbers (duplicate/invalid dropped)' );
$st = null; do { $st = Bulk::step( $start['job'] ); } while ( ! $st['finished'] );
ok( 100 === $st['granted'] && 100 === $st['sent'], 'job: 100 grants, 100 SMS (' . $st['granted'] . '/' . $st['sent'] . ')' );
$okc = 0;
foreach ( $nums as $ph ) { $c = guest( $ph, 'dev-' . $ph, true ); $ee = Eligibility::check( $fw, $c ); if ( $ee['ok'] && ( 'free' === $ee['via'] || $ee['credits'] >= 1 ) ) { $okc++; } }
ok( 100 === $okc, 'all 100 numbers really have a spin on the wheel (' . $okc . ')' );
$c = guest( $nums[5], 'dev-x5', true );
$svc->spin( $fw, $c ); $c = guest( $nums[5], 'dev-x5', true );
ok( 1 === Eligibility::check( $fw, $c )['credits'] && is_array( $svc->spin( $fw, $c ) ) && ! Eligibility::check( $fw, guest( $nums[5], 'dev-x5', true ) )['ok'], 'free spin + granted spin, then nothing' );
$again = Bulk::step( $start['job'] );
ok( is_wp_error( $again ), 'finished job can not be re-run' );
$tok = Guard::link_token( '09151234567', 30 );
ok( '09151234567' === Guard::verified_phone( $tok ) && '' === Guard::verified_phone( substr( $tok, 0, -1 ) . ( 'a' === substr( $tok, -1 ) ? 'b' : 'a' ) ), 'personal SMS link token proves the mobile; tampering fails' );
$body = end( $GLOBALS['__http'] )['args']['body'] ?? '';
ok( false !== strpos( is_array( $body ) ? json_encode( $body ) : (string) $body, 'bch_v' ), 'SMS carries the personal wheel link' );
$pv = Bulk::preview( array( 'source' => 'manual', 'numbers' => "09121112233,علی", 'text' => 'سلام {name}' ) );
ok( 1 === $pv['total'] && false !== strpos( $pv['samples'][0]['text'], 'علی' ), 'preview renders per-person variables' );


echo "Every template: creates, saves rules, and spins without errors\n";
$uidn = 300;
foreach ( \Becharkhoon\Wheels\Templates::catalog() as $key => $tpl ) {
	$id = \Becharkhoon\Wheels\Templates::create( $key );
	becharkhoon()->wheels->flush();
	$tw = becharkhoon()->wheels->get( $id );
	$tw['status'] = 'active';
	$mode = $tw['config']['access']['mode'];
	$uid  = ++$uidn;
	bch_make_user( $uid, "t$uid@x.ir" );
	$ctx = member( $uid );
	$ctx->phone = '0912' . str_pad( (string) $uid, 7, '0', STR_PAD_LEFT ); $ctx->phone_verified = true;
	if ( 'credits' === $mode ) {
		$pre = Eligibility::check( $tw, $ctx );
		Ledger::grant( array( 'user_id' => $uid, 'qty' => 2, 'wheel_id' => $id, 'reason' => 'manual' ) );
	}
	$cond = ! empty( $tw['config']['access']['conditions']['enabled'] );
	$r = $svc->spin( $tw, $ctx );
	if ( $cond ) {
		ok( is_wp_error( $r ) || is_array( $r ), "template $key: conditional access evaluated (" . ( is_wp_error( $r ) ? $r->get_error_code() : 'spun' ) . ')' );
	} else {
		ok( is_array( $r ) && isset( $r['slice_id'] ), "template $key ($mode): spins" . ( is_wp_error( $r ) ? ' — ' . $r->get_error_message() : '' ) );
	}
	if ( 'credits' === $mode ) {
		ok( ! $pre['ok'] && is_array( $svc->spin( $tw, $ctx ) ), "template $key: no spin before a grant, both granted spins usable" );
	}
	if ( $tpl['rules'] ) {
		$mine = array_filter( \Becharkhoon\Credits\Rules::all(), function ( $x ) use ( $id ) { return (int) ( $x['wheel_id'] ?? 0 ) === (int) $id; } );
		ok( count( $mine ) === count( $tpl['rules'] ), "template $key: rules saved" );
	}
}


echo "Every prize type: a win never errors\n";
if ( ! class_exists( 'WooCommerce' ) ) {
	class WooCommerce {}
	class WC_Coupon {
		public static $store = array();
		public $data = array( 'meta' => array() );
		public function __construct( $id = 0 ) { if ( $id && isset( self::$store[ $id ] ) ) { $this->data = self::$store[ $id ]; } }
		public function __call( $m, $a ) {
			if ( 0 === strpos( $m, 'set_' ) ) { $this->data[ substr( $m, 4 ) ] = $a[0]; return; }
			if ( 0 === strpos( $m, 'get_' ) ) { return $this->data[ substr( $m, 4 ) ] ?? null; }
			return null;
		}
		public function update_meta_data( $k, $v ) { $this->data['meta'][ $k ] = $v; }
		public function get_meta( $k ) { return $this->data['meta'][ $k ] ?? ''; }
		public function is_type( $t ) { return ( $this->data['discount_type'] ?? '' ) === $t; }
		public function save() { $id = count( self::$store ) + 1; self::$store[ $id ] = $this->data; return $id; }
	}
}
if ( ! function_exists( 'wc_get_coupon_id_by_code' ) ) {
	function wc_get_coupon_id_by_code( $c ) { foreach ( WC_Coupon::$store as $i => $d ) { if ( strtolower( $d['code'] ?? '' ) === strtolower( $c ) ) { return $i; } } return 0; }
}
WC_Coupon::$store[] = array( 'code' => 'summer', 'meta' => array() );
$types = array(
	'coupon_percent' => array( 'value' => 10, 'min_spend' => 100000, 'max_discount' => 50000 ),
	'coupon_fixed_cart' => array( 'value' => 50000 ),
	'coupon_fixed_product' => array( 'value' => 20000 ),
	'free_shipping' => array(),
	'existing_coupon' => array( 'coupon_code' => 'summer' ),
	'extra_spin' => array( 'value' => 2 ),
	'respin' => array(),
	'custom' => array( 'custom_text' => 'هدیه' ),
	'link' => array( 'link_url' => 'https://x.ir' ),
	'wallet' => array( 'value' => 1000 ),
	'points' => array( 'value' => 5 ),
);
$uidp = 500;
foreach ( $types as $ty => $x ) {
	$pw = mkwheel( array( 'slices' => array( slice( 'w', $ty, 1, $x ), slice( 'l', 'lose', 0 ) ), 'access' => array( 'mode' => 'free', 'limits' => array() ) ) );
	$u = ++$uidp; bch_make_user( $u, "p$u@x.ir" );
	$r = $svc->spin( $pw, member( $u ) );
	$want = in_array( $ty, array( 'wallet', 'points' ), true ) ? 'lose' : $ty; // no wallet/points plugin here → never offered
	ok( is_array( $r ) && $want === $r['type'], "prize $ty → " . ( is_array( $r ) ? $r['type'] . ( '' !== (string) $r['code'] ? ' ' . $r['code'] : '' ) : $r->get_error_message() ) );
}

$pc = array_values( array_filter( WC_Coupon::$store, function ( $d ) { return 'percent' === ( $d['discount_type'] ?? '' ); } ) )[0] ?? array();
ok( 100000.0 === (float) ( $pc['minimum_amount'] ?? 0 ) && 50000.0 === (float) ( $pc['meta']['_bch_max_discount'] ?? 0 ) && 10.0 === (float) ( $pc['amount'] ?? 0 ), 'percent coupon carries amount, minimum spend and max discount' );
$fc = array_values( array_filter( WC_Coupon::$store, function ( $d ) { return 'fixed_cart' === ( $d['discount_type'] ?? '' ); } ) )[0] ?? array();
ok( 50000.0 === (float) ( $fc['amount'] ?? 0 ), 'fixed-cart coupon amount in shop currency' );


echo "Scheduled bulk campaigns: N every M minutes, per-person report, retry\n";
global $wpdb;
$nums = array(); for ( $i = 0; $i < 297; $i++ ) { $nums[] = '0916' . str_pad( (string) $i, 7, '0', STR_PAD_LEFT ); }
$bad = array( '09160000013', '09160000127', '09160000250' );
$GLOBALS['__http_responder'] = function ( $url, $args ) use ( &$bad ) {
	$b = is_array( $args['body'] ?? null ) ? json_encode( $args['body'] ) : (string) ( $args['body'] ?? '' );
	foreach ( $bad as $x ) { if ( false !== strpos( $b, substr( $x, 1 ) ) ) { return array( 'code' => 500, 'body' => '{"error":"panel down"}' ); } }
	return array( 'code' => 200, 'body' => '{"status":1}' );
};
$cw2 = mkwheel( array( 'slices' => array( slice( 'l1', 'lose', 1 ), slice( 'l2', 'lose', 1 ) ), 'access' => array( 'mode' => 'credits', 'limits' => array() ) ) );
$cp  = Bulk::start( array( 'source' => 'manual', 'numbers' => implode( "\n", $nums ), 'text' => 'سلام {name} {wheel_link}', 'grant' => 1, 'grant_wheel' => $cw2['id'], 'batch_size' => 50, 'interval_min' => 15, 'title' => 'کمپین تست' ) );
ok( 297 === $cp['total'], 'campaign saved with 297 recipients' );
Bulk::run();
$k = Bulk::get( $cp['id'] )['counts'];
ok( 50 === $k['sent'] + $k['failed'] && 247 === $k['pending'], 'first run sends exactly 50 (' . $k['sent'] . '+' . $k['failed'] . ')' );
Bulk::run();
ok( 247 === Bulk::get( $cp['id'] )['counts']['pending'], 'nothing more before 15 minutes pass' );
$next = Bulk::get( $cp['id'] )['next_run'];
ok( abs( strtotime( $next . ' UTC' ) - ( time() + 900 ) ) < 5, 'next batch scheduled in 15 minutes' );
$loops = 0;
while ( 'running' === Bulk::get( $cp['id'] )['status'] && $loops++ < 20 ) {
	$wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}bch_bulk SET next_run = %s WHERE id = %d", \Becharkhoon\Core\Helpers::now( -1 ), $cp['id'] ) );
	Bulk::run();
}
$c1 = Bulk::get( $cp['id'] );
ok( 'done' === $c1['status'] && 6 === $c1['batches'], '297 people = 6 batches (50×5 + 47), then done' );
ok( 294 === $c1['counts']['sent'] && 3 === $c1['counts']['failed'] && 297 === $c1['counts']['granted'], 'report: 294 sent, 3 failed, 297 spins granted' );
$fl = Bulk::items( $cp['id'], array( 'status' => 'failed' ) );
ok( 3 === $fl['total'] && false !== strpos( (string) $fl['items'][0]['response'], 'panel' ) && $fl['items'][0]['message'], 'failed list keeps the error and the exact message' );
ok( 50 === Bulk::items( $cp['id'], array( 'batch' => 2 ) )['total'], 'filter by batch' );
$bad = array();
$rt  = Bulk::action( $cp['id'], 'retry', array( 'scope' => 'failed' ) );
ok( 3 === $rt['queued'] && 'running' === $rt['campaign']['status'], 'retry failed → 3 queued' );
Bulk::run( $cp['id'], true );
$c1 = Bulk::get( $cp['id'] );
ok( 297 === $c1['counts']['sent'] && 'done' === $c1['status'], 'after retry everyone got the SMS' );
$gr = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}bch_credits WHERE ref_type = 'bulk' AND ref_id = %d", $cp['id'] ) );
ok( 297 === $gr, 'retry never grants a spin twice (' . $gr . ' grants)' );
$cc = Bulk::start( array( 'source' => 'manual', 'numbers' => implode( "\n", array_slice( $nums, 0, 10 ) ), 'text' => 'x', 'batch_size' => 3, 'interval_min' => 60 ) );
Bulk::run();
Bulk::action( $cc['id'], 'cancel' );
$k = Bulk::get( $cc['id'] )['counts'];
ok( 3 === $k['sent'] && 7 === $k['cancelled'], 'cancel: 3 sent, 7 not sent' );
ok( 7 === Bulk::items( $cc['id'], array( 'status' => 'unsent' ) )['total'], '"not sent" list' );
Bulk::action( $cc['id'], 'retry', array( 'scope' => 'unsent' ) );
for ( $i = 0; $i < 5; $i++ ) { Bulk::action( $cc['id'], 'send_now' ); }
ok( 10 === Bulk::get( $cc['id'] )['counts']['sent'], 'send the unsent ones again → all 10 sent' );
$pv = Bulk::preview( array( 'source' => 'manual', 'numbers' => implode( "\n", array( $nums[0], '09169999999' ) ), 'spin_now' => 'no', 'grant_wheel' => $cw2['id'], 'text' => 'x' ) );
ok( 1 === $pv['total'] && '09169999999' === $pv['samples'][0]['mobile'], 'filter: people who can NOT spin now' );
$pv = Bulk::preview( array( 'source' => 'manual', 'numbers' => implode( "\n", array( $nums[0], '09169999999' ) ), 'skip_recent' => 1, 'text' => 'x' ) );
ok( 1 === $pv['total'], 'filter: skip people who got a bulk SMS recently' );
unset( $GLOBALS['__http_responder'] );


echo "SMS code also signs the visitor in to the site\n";
if ( ! function_exists( 'user_can' ) ) { function user_can( $u, $cap ) { $x = get_userdata( $u ); return $x && in_array( 'administrator', (array) $x->roles, true ); } }
if ( ! function_exists( 'username_exists' ) ) { function username_exists( $l ) { foreach ( $GLOBALS['__users'] as $u ) { if ( $u->user_login === $l ) { return $u->ID; } } return false; } }
if ( ! function_exists( 'wp_insert_user' ) ) { function wp_insert_user( $a ) { $id = 1000 + count( $GLOBALS['__users'] ); $u = bch_make_user( $id, '', array( $a['role'] ) ); $u->user_login = $a['user_login']; $u->display_name = $a['display_name']; return $id; } }
if ( ! function_exists( 'wp_set_current_user' ) ) { function wp_set_current_user( $id ) { $GLOBALS['__uid'] = (int) $id; } }
if ( ! function_exists( 'wp_set_auth_cookie' ) ) { function wp_set_auth_cookie( $id ) { $GLOBALS['__auth_cookie'] = (int) $id; } }
add_filter( 'becharkhoon_user_by_phone', function ( $f, $ph ) { foreach ( $GLOBALS['__umeta'] as $uid => $m ) { if ( \Becharkhoon\Core\Helpers::phone( (string) ( $m['billing_phone'] ?? '' ) ) === $ph ) { return $uid; } } return $f; }, 10, 2 );
use Becharkhoon\Front\Login;
$GLOBALS['__uid'] = 0;
bch_make_user( 700, 'c700@x.ir' ); update_user_meta( 700, 'billing_phone', '+989171234567' );
$lg = Login::after_otp( '09171234567' );
ok( $lg['logged_in'] && 700 === $lg['user_id'] && 700 === get_current_user_id() && 700 === ( $GLOBALS['__auth_cookie'] ?? 0 ), 'existing customer with that mobile is signed in' );
$fw3 = mkwheel( array( 'slices' => array( slice( 'l1', 'lose', 1 ), slice( 'l2', 'lose', 1 ) ), 'access' => array( 'mode' => 'credits', 'limits' => array() ) ) );
Ledger::grant( array( 'user_id' => 0, 'phone' => '09171234567', 'qty' => 2, 'wheel_id' => $fw3['id'], 'reason' => 'bulk' ) );
$mc = member( 700 ); $mc->phone = '09171234567';
ok( is_array( $svc->spin( $fw3, $mc ) ) && is_array( $svc->spin( $fw3, $mc ) ), 'two spins with one SMS code (signed in)' );
$GLOBALS['__uid'] = 0;
$lg = Login::after_otp( '09179998877', 'سارا' );
ok( $lg['created'] && $lg['logged_in'] && '09179998877' === get_user_meta( $lg['user_id'], 'billing_phone', true ) && '' !== (string) get_userdata( $lg['user_id'] )->roles[0], 'new mobile → new customer account, signed in' );
$GLOBALS['__uid'] = 0;
bch_make_user( 701, 'admin@x.ir', array( 'administrator' ) ); update_user_meta( 701, 'billing_phone', '09170000001' );
$lg = Login::after_otp( '09170000001' );
ok( ! $lg['logged_in'] && 'staff' === $lg['reason'] && 0 === get_current_user_id(), 'admin accounts are never signed in by SMS code' );
becharkhoon()->settings->update( array( 'otp_site_login' => false ) );
ok( ! Login::after_otp( '09171234567' )['logged_in'], 'can be turned off' );
becharkhoon()->settings->update( array( 'otp_site_login' => true ) );
$GLOBALS['__uid'] = 0;

done();
