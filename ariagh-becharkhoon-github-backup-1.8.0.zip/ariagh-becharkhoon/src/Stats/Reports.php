<?php
/**
 * Advanced reports: wheel activity read straight from the real tables (spins, leads, ledger)
 * + real WooCommerce money from `bch_orders` (discounts, gifts, sales, refunds, statuses).
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Stats;

use Becharkhoon\Core\Helpers;

defined( 'ABSPATH' ) || exit;

final class Reports {

	/**
	 * Parse a period: 'Y-m-d' or 'Y-m-d H:i' (site time). Date-only "to" means the end of that day.
	 *
	 * @return array{from:string,to:string,from_utc:string,to_utc:string,days:int}
	 */
	public static function period( $from, $to ) {
		$re   = '/^\d{4}-\d{2}-\d{2}( \d{2}:\d{2}(:\d{2})?)?$/';
		$from = preg_match( $re, (string) $from ) ? (string) $from : wp_date( 'Y-m-d', time() - 29 * DAY_IN_SECONDS );
		$to   = preg_match( $re, (string) $to ) ? (string) $to : wp_date( 'Y-m-d' );
		$f    = strlen( $from ) === 10 ? $from . ' 00:00:00' : ( strlen( $from ) === 16 ? $from . ':00' : $from );
		$t    = strlen( $to ) === 10 ? $to . ' 23:59:59' : ( strlen( $to ) === 16 ? $to . ':59' : $to );
		if ( $f > $t ) {
			list( $f, $t ) = array( $t, $f );
		}
		$fu   = Stats::utc( $f );
		$tu   = Stats::utc( $t );
		$days = max( 1, (int) ceil( ( strtotime( $tu ) - strtotime( $fu ) + 1 ) / DAY_IN_SECONDS ) );
		return array( 'from' => $f, 'to' => $t, 'from_utc' => $fu, 'to_utc' => $tu, 'days' => $days );
	}

	/** The same length right before the period (for ▲▼ comparisons). */
	public static function previous( array $p ) {
		$len = strtotime( $p['to_utc'] ) - strtotime( $p['from_utc'] ) + 1;
		$tu  = gmdate( 'Y-m-d H:i:s', strtotime( $p['from_utc'] ) - 1 );
		$fu  = gmdate( 'Y-m-d H:i:s', strtotime( $p['from_utc'] ) - $len );
		return array( 'from_utc' => $fu, 'to_utc' => $tu );
	}

	/** Spin activity from the spins table (all history, nothing depends on counters). */
	public static function activity( $fu, $tu, $wheel_id = 0 ) {
		global $wpdb;
		$s      = $wpdb->prefix . 'bch_spins';
		$w      = "created_at BETWEEN %s AND %s AND source <> 'preview'";
		$params = array( $fu, $tu );
		if ( $wheel_id ) {
			$w       .= ' AND wheel_id = %d';
			$params[] = (int) $wheel_id;
		}
		$r = (array) $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS spins, COALESCE(SUM(CASE WHEN result = 'win' THEN 1 ELSE 0 END),0) AS wins, COALESCE(SUM(CASE WHEN result = 'lose' THEN 1 ELSE 0 END),0) AS losses, COALESCE(SUM(CASE WHEN result = 'respin' THEN 1 ELSE 0 END),0) AS respins, COALESCE(SUM(CASE WHEN coupon_code <> '' AND result = 'win' THEN 1 ELSE 0 END),0) AS codes, COALESCE(SUM(CASE WHEN status = 'redeemed' THEN 1 ELSE 0 END),0) AS redeemed, COALESCE(SUM(CASE WHEN status = 'expired' THEN 1 ELSE 0 END),0) AS expired, COALESCE(SUM(CASE WHEN status = 'issued' AND coupon_code <> '' THEN 1 ELSE 0 END),0) AS open_codes, COALESCE(SUM(CASE WHEN is_free = 0 THEN 1 ELSE 0 END),0) AS credit_spins, COUNT(DISTINCT CASE WHEN user_id > 0 THEN user_id END) AS members, COUNT(DISTINCT CASE WHEN user_id = 0 AND phone <> '' THEN phone END) AS phones FROM $s WHERE $w", $params ), ARRAY_A ); // phpcs:ignore
		$out = array_map( 'intval', $r );
		$out['people']      = $out['members'] + $out['phones'];
		$out['win_rate']    = $out['spins'] ? round( $out['wins'] / $out['spins'] * 100, 1 ) : 0;
		$out['redeem_rate'] = $out['codes'] ? round( $out['redeemed'] / $out['codes'] * 100, 1 ) : 0;
		$lp                 = array( $fu, $tu );
		$lw                 = 'created_at BETWEEN %s AND %s';
		if ( $wheel_id ) {
			$lw  .= ' AND wheel_id = %d';
			$lp[] = (int) $wheel_id;
		}
		$out['leads']   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}bch_leads WHERE $lw", $lp ) ); // phpcs:ignore
		$cr             = (array) $wpdb->get_row( $wpdb->prepare( "SELECT COALESCE(SUM(qty),0) AS g, COUNT(*) AS n FROM {$wpdb->prefix}bch_credits WHERE created_at BETWEEN %s AND %s", $fu, $tu ), ARRAY_A );
		$out['granted'] = (int) ( $cr['g'] ?? 0 );
		return $out;
	}

	/** Counters that only exist as events (impressions, opens…). */
	public static function counters( $fu, $tu, $wheel_id = 0 ) {
		return Stats::totals( wp_date( 'Y-m-d', strtotime( $fu . ' UTC' ) ), wp_date( 'Y-m-d', strtotime( $tu . ' UTC' ) ), $wheel_id );
	}

	/** Day (or hour for ≤ 2 days) buckets in site time. */
	public static function buckets( array $p ) {
		$hourly = $p['days'] <= 2;
		$out    = array();
		$t      = strtotime( $p['from_utc'] . ' UTC' );
		$end    = strtotime( $p['to_utc'] . ' UTC' );
		$i      = 0;
		while ( $t <= $end && $i++ < 800 ) {
			$k         = wp_date( $hourly ? 'Y-m-d H:00' : 'Y-m-d', $t );
			$out[ $k ] = array( 'spins' => 0, 'wins' => 0, 'leads' => 0, 'orders' => 0, 'sales' => 0, 'discount' => 0, 'gift' => 0 );
			$t        += $hourly ? HOUR_IN_SECONDS : DAY_IN_SECONDS;
		}
		$last = wp_date( $hourly ? 'Y-m-d H:00' : 'Y-m-d', $end );
		if ( ! isset( $out[ $last ] ) ) {
			$out[ $last ] = array( 'spins' => 0, 'wins' => 0, 'leads' => 0, 'orders' => 0, 'sales' => 0, 'discount' => 0, 'gift' => 0 );
		}
		return array( $out, $hourly ? 'Y-m-d H:00' : 'Y-m-d' );
	}

	public static function series( array $p, array $statuses, $basis, $wheel_id = 0 ) {
		global $wpdb;
		list( $b, $fmt ) = self::buckets( $p );
		$w      = "created_at BETWEEN %s AND %s AND source <> 'preview'";
		$params = array( $p['from_utc'], $p['to_utc'] );
		if ( $wheel_id ) {
			$w       .= ' AND wheel_id = %d';
			$params[] = (int) $wheel_id;
		}
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT created_at, result FROM {$wpdb->prefix}bch_spins WHERE $w ORDER BY id DESC LIMIT 100000", $params ), ARRAY_A ) as $r ) { // phpcs:ignore
			$k = wp_date( $fmt, strtotime( $r['created_at'] . ' UTC' ) );
			if ( isset( $b[ $k ] ) ) {
				++$b[ $k ]['spins'];
				if ( 'win' === $r['result'] ) {
					++$b[ $k ]['wins'];
				}
			}
		}
		$lp = array( $p['from_utc'], $p['to_utc'] );
		foreach ( (array) $wpdb->get_col( $wpdb->prepare( "SELECT created_at FROM {$wpdb->prefix}bch_leads WHERE created_at BETWEEN %s AND %s LIMIT 100000", $lp ) ) as $t ) {
			$k = wp_date( $fmt, strtotime( $t . ' UTC' ) );
			if ( isset( $b[ $k ] ) ) {
				++$b[ $k ]['leads'];
			}
		}
		foreach ( Orders::rows( $p['from_utc'], $p['to_utc'], $statuses, $basis, $wheel_id ) as $o ) {
			$k = wp_date( $fmt, strtotime( $o['d'] . ' UTC' ) );
			if ( isset( $b[ $k ] ) ) {
				++$b[ $k ]['orders'];
				$b[ $k ]['sales']    += (float) $o['total'] - (float) $o['refunded'];
				$b[ $k ]['discount'] += (float) $o['discount'];
				$b[ $k ]['gift']     += (float) $o['gift_value'];
			}
		}
		return $b;
	}

	/** Prize table: issued in the period (spins) + money from orders that used those prizes. */
	public static function prizes( array $p, array $statuses, $basis, $wheel_id = 0 ) {
		$money = array();
		foreach ( Orders::group( 'prize', $p['from_utc'], $p['to_utc'], $statuses, $basis, $wheel_id, 200 ) as $g ) {
			$money[ $g['prize'] . '|' . $g['prize_type'] ] = $g;
		}
		$out = array();
		foreach ( Stats::prizes( $p['from'], $p['to'], $wheel_id ) as $r ) {
			$k = $r['slice_label'] . '|' . $r['prize_type'];
			if ( isset( $out[ $k ] ) ) {
				$out[ $k ]['n']        += (int) $r['n'];
				$out[ $k ]['redeemed'] += (int) $r['redeemed'];
				continue;
			}
			$m          = $money[ $k ] ?? array();
			$out[ $k ]  = array(
				'label'    => $r['slice_label'],
				'type'     => $r['prize_type'],
				'result'   => $r['result'],
				'n'        => (int) $r['n'],
				'redeemed' => (int) $r['redeemed'],
				'orders'   => (int) ( $m['orders'] ?? 0 ),
				'sales'    => (float) ( $m['total'] ?? 0 ) - (float) ( $m['refunded'] ?? 0 ),
				'discount' => (float) ( $m['discount'] ?? 0 ),
				'gift'     => (float) ( $m['gift_value'] ?? 0 ),
			);
			unset( $money[ $k ] );
		}
		foreach ( $money as $m ) { // Orders in the period for prizes won earlier.
			$out[] = array( 'label' => $m['prize'], 'type' => $m['prize_type'], 'result' => 'win', 'n' => 0, 'redeemed' => 0, 'orders' => (int) $m['orders'], 'sales' => (float) $m['total'] - (float) $m['refunded'], 'discount' => (float) $m['discount'], 'gift' => (float) $m['gift_value'] );
		}
		return array_values( $out );
	}

	/** Discount by kind: percent / fixed / free shipping / gift product / existing coupon. */
	public static function by_type( array $prizes ) {
		$out = array();
		foreach ( $prizes as $r ) {
			if ( ! $r['orders'] ) {
				continue;
			}
			$k = $r['type'] ? $r['type'] : 'other';
			if ( ! isset( $out[ $k ] ) ) {
				$out[ $k ] = array( 'type' => $k, 'orders' => 0, 'sales' => 0, 'discount' => 0, 'gift' => 0 );
			}
			$out[ $k ]['orders']   += $r['orders'];
			$out[ $k ]['sales']    += $r['sales'];
			$out[ $k ]['discount'] += $r['discount'];
			$out[ $k ]['gift']     += $r['gift'];
		}
		return array_values( $out );
	}

	/** How long after winning people buy (hours) + purchases by hour/weekday. */
	public static function timing( array $p, array $statuses, $basis, $wheel_id = 0 ) {
		$lag   = array();
		$hours = array_fill( 0, 24, 0 );
		$week  = array_fill( 0, 7, 0 );
		foreach ( Orders::rows( $p['from_utc'], $p['to_utc'], $statuses, $basis, $wheel_id ) as $o ) {
			$t = strtotime( $o['d'] . ' UTC' );
			++$hours[ (int) wp_date( 'G', $t ) ];
			++$week[ (int) wp_date( 'w', $t ) ];
			if ( $o['spin_at'] ) {
				$lag[] = max( 0, ( $t - strtotime( $o['spin_at'] . ' UTC' ) ) / HOUR_IN_SECONDS );
			}
		}
		sort( $lag );
		$n      = count( $lag );
		$bins   = array( 'h1' => 0, 'h24' => 0, 'd3' => 0, 'd7' => 0, 'more' => 0 );
		foreach ( $lag as $h ) {
			$bins[ $h <= 1 ? 'h1' : ( $h <= 24 ? 'h24' : ( $h <= 72 ? 'd3' : ( $h <= 168 ? 'd7' : 'more' ) ) ) ]++;
		}
		return array(
			'avg_hours'    => $n ? round( array_sum( $lag ) / $n, 1 ) : 0,
			'median_hours' => $n ? round( $lag[ (int) floor( ( $n - 1 ) / 2 ) ], 1 ) : 0,
			'bins'         => $bins,
			'hours'        => $hours,
			'weekdays'     => $week,
		);
	}

	/** Devices of spinners (from spin meta). */
	public static function devices( $fu, $tu, $wheel_id = 0 ) {
		global $wpdb;
		$w      = "created_at BETWEEN %s AND %s AND source <> 'preview'";
		$params = array( $fu, $tu );
		if ( $wheel_id ) {
			$w       .= ' AND wheel_id = %d';
			$params[] = (int) $wheel_id;
		}
		$out = array();
		foreach ( (array) $wpdb->get_col( $wpdb->prepare( "SELECT meta FROM {$wpdb->prefix}bch_spins WHERE $w ORDER BY id DESC LIMIT 20000", $params ) ) as $m ) { // phpcs:ignore
			$d         = Helpers::json_decode_array( $m );
			$k         = ! empty( $d['device'] ) ? (string) $d['device'] : 'other';
			$out[ $k ] = ( $out[ $k ] ?? 0 ) + 1;
		}
		arsort( $out );
		return $out;
	}

	/**
	 * Everything for the Reports page.
	 *
	 * @param array $a from, to, wheel, statuses[], basis.
	 */
	public static function build( array $a ) {
		$p        = self::period( $a['from'] ?? '', $a['to'] ?? '' );
		$prev     = self::previous( $p );
		$wheel    = (int) ( $a['wheel'] ?? 0 );
		$basis    = in_array( $a['basis'] ?? '', array( 'created', 'paid', 'completed' ), true ) ? $a['basis'] : 'created';
		$statuses = self::statuses( $a['statuses'] ?? null );
		$prizes   = self::prizes( $p, $statuses, $basis, $wheel );
		return array(
			'period'    => $p,
			'statuses'  => $statuses,
			'basis'     => $basis,
			'sync'      => Orders::state(),
			'money'     => Orders::totals( $p['from_utc'], $p['to_utc'], $statuses, $basis, $wheel ),
			'money_prev' => Orders::totals( $prev['from_utc'], $prev['to_utc'], $statuses, $basis, $wheel ),
			'by_status' => Orders::by_status( $p['from_utc'], $p['to_utc'], $basis, $wheel ),
			'activity'  => self::activity( $p['from_utc'], $p['to_utc'], $wheel ),
			'activity_prev' => self::activity( $prev['from_utc'], $prev['to_utc'], $wheel ),
			'counters'  => self::counters( $p['from_utc'], $p['to_utc'], $wheel ),
			'series'    => self::series( $p, $statuses, $basis, $wheel ),
			'prizes'    => $prizes,
			'by_type'   => self::by_type( $prizes ),
			'wheels'    => Orders::group( 'wheel', $p['from_utc'], $p['to_utc'], $statuses, $basis, $wheel, 50 ),
			'customers' => Orders::group( 'customer', $p['from_utc'], $p['to_utc'], $statuses, $basis, $wheel, 10 ),
			'timing'    => self::timing( $p, $statuses, $basis, $wheel ),
			'sources'   => Stats::by_source( $p['from'], $p['to'], $wheel ),
			'devices'   => self::devices( $p['from_utc'], $p['to_utc'], $wheel ),
		);
	}

	/** Order statuses counted as a sale; default = completed (as asked: only finished purchases). */
	public static function statuses( $raw ) {
		$all = function_exists( 'wc_get_order_statuses' ) ? array_map( static function ( $k ) { return substr( $k, 3 ); }, array_keys( wc_get_order_statuses() ) ) : array( 'pending', 'processing', 'on-hold', 'completed', 'cancelled', 'refunded', 'failed' );
		$in  = is_array( $raw ) ? $raw : ( is_string( $raw ) && '' !== $raw ? explode( ',', $raw ) : array( 'completed' ) );
		$out = array_values( array_intersect( array_map( 'sanitize_key', $in ), $all ) );
		return $out ? $out : array( 'completed' );
	}
}
