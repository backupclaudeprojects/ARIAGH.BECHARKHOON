<?php
/**
 * Elementor widget registration (the widget class is loaded only when Elementor exists).
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Integrations;

defined( 'ABSPATH' ) || exit;

final class Elementor {

	public function register_hooks() {
		add_action( 'elementor/widgets/register', array( $this, 'register' ) );
	}

	public function register( $manager ) {
		if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
			return;
		}
		require_once __DIR__ . '/ElementorWidget.php';
		$manager->register( new ElementorWidget() );
	}
}
