<?php
/**
 * Advanced bulk SMS: audience builder (leads / spinners / WooCommerce customers / pasted numbers + filters),
 * custom text or panel pattern with per-person variables, optional REAL spin grants (one ledger row per
 * mobile, idempotent per campaign) and a personal link that opens the wheel already identified.
 *
 * Campaigns are stored (bch_bulk + one bch_bulk_items row per mobile): start() freezes the audience, run() sends
 * the next batch of N every M minutes (WP-Cron + the open admin page), and every recipient keeps its own SMS/grant
 * status, so failed / unsent / not-granted people can be retried at any time.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Notify;

use Becharkhoon\Core\Helpers;
use Becharkhoon\Core\Lang;
use Becharkhoon\Credits\Ledger;
use Becharkhoon\Front\Frontend;
use Becharkhoon\Front\Guard;
use Becharkhoon\Stats\People;

defined( 'ABSPATH' ) || exit;

final class Bulk {

	const BATCH = 100;

	/** Clean the dialog input. */
	public static function clean( array $f ) {
		$src = sanitize_key( (string) ( $f['source'] ?? 'all' ) );
		return array(
			'source'         => in_array( $src, array( 'all', 'leads', 'people', 'customers', 'manual' ), true ) ? $src : 'all',
			'numbers'        => (string) ( $f['numbers'] ?? '' ),
			'exclude'        => (string) ( $f['exclude'] ?? '' ),
			'from'           => (string) ( $f['from'] ?? '' ),
			'to'             => (string) ( $f['to'] ?? '' ),
			'wheel_id'       => absint( $f['wheel_id'] ?? 0 ),
			'marketing'      => ! empty( $f['marketing'] ),
			'verified'       => ! empty( $f['verified'] ),
			'winners'        => sanitize_key( (string) ( $f['winners'] ?? '' ) ), // '' | yes | no
			'inactive_days'  => max( 0, (int) ( $f['inactive_days'] ?? 0 ) ),
			'min_spins'      => max( 0, (int) ( $f['min_spins'] ?? 0 ) ),
			'balance'        => sanitize_key( (string) ( $f['balance'] ?? '' ) ), // '' | has | none
			'unused_code'    => ! empty( $f['unused_code'] ),
			'min_orders'     => max( 0, (int) ( $f['min_orders'] ?? 0 ) ),
			'min_spent'      => max( 0, (float) ( $f['min_spent'] ?? 0 ) ),
			'limit'          => max( 0, (int) ( $f['limit'] ?? 0 ) ),
			'mode'           => 'pattern' === ( $f['mode'] ?? '' ) ? 'pattern' : 'text',
			'text'           => sanitize_textarea_field( (string) ( $f['text'] ?? '' ) ),
			'code'           => sanitize_text_field( (string) ( $f['code'] ?? '' ) ),
			'params'         => sanitize_textarea_field( (string) ( $f['params'] ?? '' ) ),
			'fallback'       => ! empty( $f['fallback'] ),
			'grant'          => max( 0, min( 100, (int) ( $f['grant'] ?? 0 ) ) ),
			'grant_wheel'    => absint( $f['grant_wheel'] ?? 0 ),
			'grant_days'     => max( 0, (int) ( $f['grant_days'] ?? 0 ) ),
			'grant_note'     => mb_substr( sanitize_text_field( (string) ( $f['grant_note'] ?? '' ) ), 0, 120 ),
			'send_sms'       => ! isset( $f['send_sms'] ) || ! empty( $f['send_sms'] ),
			'spin_now'       => in_array( ( $f['spin_now'] ?? '' ), array( 'yes', 'no' ), true ) ? $f['spin_now'] : '',
			'spun'           => in_array( ( $f['spun'] ?? '' ), array( 'yes', 'no' ), true ) ? $f['spun'] : '',
			'account'        => in_array( ( $f['account'] ?? '' ), array( 'user', 'guest' ), true ) ? $f['account'] : '',
			'min_wins'       => max( 0, (int) ( $f['min_wins'] ?? 0 ) ),
			'has_email'      => ! empty( $f['has_email'] ),
			'skip_recent'    => max( 0, (int) ( $f['skip_recent'] ?? 0 ) ),
			'batch_size'     => max( 1, min( 500, (int) ( $f['batch_size'] ?? 100 ) ) ),
			'interval_min'   => max( 0, min( 1440, (int) ( $f['interval_min'] ?? 0 ) ) ),
			'title'          => mb_substr( sanitize_text_field( (string) ( $f['title'] ?? '' ) ), 0, 190 ),
		);
	}

	/**
	 * Recipients (unique mobiles) for the filters.
	 *
	 * @return array<int,array{phone:string,name:string,email:string,user_id:int,spins:int,wins:int,balance:int}>
	 */
	public static function audience( array $f ) {
		$f    = self::clean( $f );
		$rows = array();
		$per  = ( '' !== $f['from'] || '' !== $f['to'] ) ? \Becharkhoon\Stats\Reports::period( $f['from'], $f['to'] ) : array( 'from_utc' => '1970-01-01 00:00:00', 'to_utc' => '2999-12-31 23:59:59' );
		if ( 'manual' === $f['source'] ) {
			// One per line as «mobile» or «mobile, name»; several mobiles on one line also work.
			foreach ( preg_split( '/[\r\n]+/', Helpers::latin_digits( $f['numbers'] ) ) as $line ) {
				$parts = array_values( array_filter( array_map( 'trim', preg_split( '/[,،;\t]+/u', (string) $line ) ), 'strlen' ) );
				if ( ! $parts ) {
					continue;
				}
				$all_phones = count( $parts ) > 1 && '' !== Helpers::phone( $parts[1] );
				foreach ( $all_phones ? $parts : array( $parts[0] ) as $k => $cell ) {
					$ph = Helpers::phone( $cell );
					if ( '' !== $ph && ! isset( $rows[ $ph ] ) ) {
						$rows[ $ph ] = array( 'phone' => $ph, 'name' => $all_phones ? '' : trim( (string) ( $parts[1] ?? '' ) ), 'email' => '', 'user_id' => 0, 'spins' => 0, 'wins' => 0, 'balance' => 0, 'last_at' => '', 'marketing' => true, 'verified' => false );
					}
				}
			}
		} elseif ( 'customers' === $f['source'] ) {
			$ids = function_exists( 'get_users' ) ? get_users( array( 'fields' => 'ID', 'number' => 20000, 'meta_key' => 'billing_phone', 'meta_compare' => 'EXISTS' ) ) : array(); // phpcs:ignore WordPress.DB.SlowDBQuery
			foreach ( $ids as $uid ) {
				$uid = (int) $uid;
				$ph  = Helpers::phone( (string) get_user_meta( $uid, 'billing_phone', true ) );
				if ( '' === $ph ) {
					continue;
				}
				if ( $f['min_orders'] > 0 && function_exists( 'wc_get_customer_order_count' ) && wc_get_customer_order_count( $uid ) < $f['min_orders'] ) {
					continue;
				}
				if ( $f['min_spent'] > 0 && function_exists( 'wc_get_customer_total_spent' ) && (float) wc_get_customer_total_spent( $uid ) < $f['min_spent'] ) {
					continue;
				}
				$u            = get_userdata( $uid );
				$name         = trim( (string) get_user_meta( $uid, 'billing_first_name', true ) );
				$rows[ $ph ]  = array( 'phone' => $ph, 'name' => '' !== $name ? $name : ( $u ? $u->display_name : '' ), 'email' => $u ? $u->user_email : '', 'user_id' => $uid, 'spins' => 0, 'wins' => 0, 'balance' => 0, 'last_at' => '', 'marketing' => true, 'verified' => true );
			}
		} else {
			$res = People::contacts( array( 'source' => $f['source'], 'from_utc' => $per['from_utc'], 'to_utc' => $per['to_utc'], 'wheel_id' => $f['wheel_id'], 'marketing' => $f['marketing'], 'verified' => $f['verified'], 'winners' => 'yes' === $f['winners'], 'need_phone' => true ) );
			foreach ( $res['rows'] as $c ) {
				if ( 'no' === $f['winners'] && $c['wins'] > 0 ) {
					continue;
				}
				if ( $f['min_spins'] > 0 && (int) $c['spins'] < $f['min_spins'] ) {
					continue;
				}
				if ( 'has' === $f['balance'] && (int) $c['balance'] <= 0 ) {
					continue;
				}
				if ( 'none' === $f['balance'] && (int) $c['balance'] > 0 ) {
					continue;
				}
				if ( $f['inactive_days'] > 0 && $c['last_at'] && strtotime( $c['last_at'] . ' UTC' ) > time() - $f['inactive_days'] * DAY_IN_SECONDS ) {
					continue;
				}
				$rows[ $c['phone'] ] = array( 'phone' => $c['phone'], 'name' => (string) $c['name'], 'email' => (string) $c['email'], 'user_id' => (int) $c['user_id'], 'spins' => (int) $c['spins'], 'wins' => (int) $c['wins'], 'balance' => (int) $c['balance'], 'last_at' => (string) $c['last_at'], 'marketing' => (bool) $c['marketing'], 'verified' => (bool) $c['verified'] );
			}
		}
		if ( $f['unused_code'] ) {
			global $wpdb;
			$have = array_flip( (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT phone FROM {$wpdb->prefix}bch_spins WHERE status = 'issued' AND coupon_code <> '' AND phone <> '' AND (expires_at IS NULL OR expires_at > %s)", Helpers::now() ) ) );
			$rows = array_intersect_key( $rows, $have );
		}
		$rows = self::more_filters( $rows, $f );
		if ( '' !== trim( $f['exclude'] ) ) {
			foreach ( Helpers::lines( Helpers::latin_digits( $f['exclude'] ) ) as $x ) {
				unset( $rows[ Helpers::phone( $x ) ] );
			}
		}
		$rows = array_values( $rows );
		if ( $f['limit'] > 0 ) {
			$rows = array_slice( $rows, 0, $f['limit'] );
		}
		return $rows;
	}

	/** Variables for one person. */
	public static function vars( array $r, array $f, $wheel ) {
		$link = Frontend::wheel_url( $wheel );
		$vars = array(
			'name'       => '' !== trim( (string) $r['name'] ) ? $r['name'] : Lang::t( 'مشتری', 'customer' ),
			'mobile'     => $r['phone'],
			'email'      => $r['email'],
			'wheel'      => $wheel ? $wheel['title'] : '',
			'wheel_link' => Guard::personal_link( $link, $r['phone'] ),
			'n'          => (string) $f['grant'],
			'spins'      => (string) ( (int) $r['balance'] + (int) $f['grant'] ),
			'wins'       => (string) (int) $r['wins'],
		) + SmsEvents::general_vars();
		$vars['link'] = $vars['wheel_link'];
		if ( Lang::is_fa() && becharkhoon()->settings->get( 'persian_digits' ) ) {
			foreach ( array( 'n', 'spins', 'wins' ) as $k ) {
				$vars[ $k ] = Helpers::persian_digits( $vars[ $k ] );
			}
		}
		return $vars;
	}

	public static function message( array $r, array $f, $wheel ) {
		$vars = self::vars( $r, $f, $wheel );
		$msg  = array( 'mobile' => $r['phone'], 'text' => Sms::render( $f['text'], $vars ) );
		if ( 'pattern' === $f['mode'] && '' !== $f['code'] ) {
			$params = array();
			foreach ( SmsEvents::parse_params( $f['params'] ) as $k => $v ) {
				$v            = Sms::render( $v, $vars );
				$params[ $k ] = '' === $v ? '-' : $v;
			}
			$msg['pattern'] = array( 'code' => Helpers::latin_digits( $f['code'] ), 'params' => $params );
			if ( $f['fallback'] && '' !== trim( $msg['text'] ) ) {
				$msg['fallback'] = true;
			}
		}
		return $msg;
	}

	private static function wheel( array $f ) {
		$id = $f['grant_wheel'] ? $f['grant_wheel'] : $f['wheel_id'];
		$w  = $id ? becharkhoon()->wheels->get( $id ) : null;
		if ( ! $w ) {
			$active = becharkhoon()->wheels->active();
			$w      = $active ? $active[0] : null;
		}
		return $w;
	}

	/** Count + sample messages (no sending). */
	public static function preview( array $f ) {
		$f     = self::clean( $f );
		$rows  = self::audience( $f );
		$wheel = self::wheel( $f );
		$samples = array();
		foreach ( array_slice( $rows, 0, 3 ) as $r ) {
			$m         = self::message( $r, $f, $wheel );
			$samples[] = array( 'mobile' => $r['phone'], 'name' => $r['name'], 'text' => $m['text'], 'pattern' => $m['pattern'] ?? null );
		}
		return array( 'total' => count( $rows ), 'samples' => $samples, 'wheel' => $wheel ? array( 'id' => (int) $wheel['id'], 'title' => $wheel['title'], 'link' => Frontend::wheel_url( $wheel ) ) : null, 'mode' => Sms::mode() );
	}

	/** Extra audience filters that work for every source. */
	private static function more_filters( array $rows, array $f ) {
		global $wpdb;
		if ( $f['account'] || $f['has_email'] || $f['min_wins'] || $f['spun'] ) {
			$rows = array_filter(
				$rows,
				static function ( $r ) use ( $f ) {
					if ( 'user' === $f['account'] && ! $r['user_id'] ) {
						return false;
					}
					if ( 'guest' === $f['account'] && $r['user_id'] ) {
						return false;
					}
					if ( $f['has_email'] && '' === (string) $r['email'] ) {
						return false;
					}
					if ( $f['min_wins'] > 0 && (int) $r['wins'] < $f['min_wins'] ) {
						return false;
					}
					if ( 'yes' === $f['spun'] && (int) $r['spins'] <= 0 ) {
						return false;
					}
					if ( 'no' === $f['spun'] && (int) $r['spins'] > 0 ) {
						return false;
					}
					return true;
				}
			);
		}
		if ( $f['skip_recent'] > 0 && $rows ) {
			// Not people who already got a bulk message in the last N days.
			$got  = array_flip( (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT phone FROM {$wpdb->prefix}bch_bulk_items WHERE status = 'sent' AND sent_at >= %s", Helpers::now( -$f['skip_recent'] * DAY_IN_SECONDS ) ) ) );
			$rows = array_diff_key( $rows, $got );
		}
		if ( '' !== $f['spin_now'] && $rows ) {
			// Can this person spin the wheel RIGHT NOW (free quota or spins left)? Same check the wheel itself runs.
			$wheel = self::wheel( $f );
			if ( $wheel ) {
				$rows = array_filter(
					$rows,
					static function ( $r ) use ( $wheel, $f ) {
						$c                 = new \Becharkhoon\Engine\Context();
						$c->user_id        = (int) $r['user_id'];
						$c->phone          = $r['phone'];
						$c->phone_verified = true;
						$c->email          = (string) $r['email'];
						$c->client         = \Becharkhoon\Engine\Context::clean_client( array() );
						$ok                = ! empty( \Becharkhoon\Engine\Eligibility::check( $wheel, $c )['ok'] );
						return 'yes' === $f['spin_now'] ? $ok : ! $ok;
					}
				);
			}
		}
		return $rows;
	}

	/* ================================================================== Campaigns */

	const HOOK = 'becharkhoon_bulk_tick';

	public static function t() {
		global $wpdb;
		return $wpdb->prefix . 'bch_bulk';
	}

	public static function ti() {
		global $wpdb;
		return $wpdb->prefix . 'bch_bulk_items';
	}

	public static function register_hooks() {
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) ); // phpcs:ignore WordPress.WP.CronInterval
		add_action( self::HOOK, array( __CLASS__, 'cron' ) );
	}

	public static function schedules( $s ) {
		$s['bch_minute'] = array( 'interval' => 60, 'display' => 'Every minute (ARIAGH bulk SMS)' );
		return $s;
	}

	private static function ensure_cron() {
		if ( function_exists( 'wp_next_scheduled' ) && ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + 60, 'bch_minute', self::HOOK );
		}
	}

	/** WP-Cron: send every due batch; stop the minute timer when nothing is left. */
	public static function cron() {
		self::run();
		global $wpdb;
		if ( ! (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::t() . " WHERE status = 'running'" ) && function_exists( 'wp_clear_scheduled_hook' ) ) {
			wp_clear_scheduled_hook( self::HOOK );
		}
	}

	/** Freeze the audience into a scheduled campaign. */
	public static function start( array $f ) {
		global $wpdb;
		$f = self::clean( $f );
		if ( $f['send_sms'] && ( 'text' === $f['mode'] ? '' === trim( $f['text'] ) : '' === $f['code'] ) ) {
			return new \WP_Error( 'invalid', Lang::t( 'متن پیامک یا کد الگو را وارد کنید.', 'Enter the SMS text or the pattern code.' ), array( 'status' => 400 ) );
		}
		if ( ! $f['send_sms'] && ! $f['grant'] ) {
			return new \WP_Error( 'invalid', Lang::t( 'نه پیامکی انتخاب شده نه شانسی.', 'Nothing to do: no SMS and no spins.' ), array( 'status' => 400 ) );
		}
		$rows = self::audience( $f );
		if ( ! $rows ) {
			return new \WP_Error( 'empty', Lang::t( 'با این فیلترها هیچ گیرنده‌ای پیدا نشد.', 'No recipients match these filters.' ), array( 'status' => 400 ) );
		}
		$now   = Helpers::now();
		$title = '' !== $f['title'] ? $f['title'] : sprintf( Lang::t( 'ارسال گروهی %s', 'Bulk send %s' ), wp_date( 'Y-m-d H:i' ) );
		$wpdb->insert(
			self::t(),
			array(
				'title'        => $title,
				'status'       => 'running',
				'filters'      => wp_json_encode( $f, JSON_UNESCAPED_UNICODE ),
				'total'        => count( $rows ),
				'batch_size'   => $f['batch_size'],
				'interval_min' => $f['interval_min'],
				'next_run'     => $now,
				'created_by'   => (int) get_current_user_id(),
				'created_at'   => $now,
			)
		);
		$id = (int) $wpdb->insert_id;
		if ( ! $id ) {
			return new \WP_Error( 'db', Lang::t( 'ذخیره کمپین ناموفق بود.', 'Could not save the campaign.' ), array( 'status' => 500 ) );
		}
		foreach ( $rows as $r ) {
			$wpdb->insert(
				self::ti(),
				array(
					'bulk_id' => $id,
					'phone'   => $r['phone'],
					'name'    => mb_substr( (string) $r['name'], 0, 190 ),
					'user_id' => (int) $r['user_id'],
					'info'    => wp_json_encode( array( 'email' => (string) $r['email'], 'spins' => (int) $r['spins'], 'wins' => (int) $r['wins'], 'balance' => (int) $r['balance'] ), JSON_UNESCAPED_UNICODE ),
					'status'  => 'pending',
				)
			);
		}
		self::ensure_cron();
		return array( 'id' => $id, 'job' => $id, 'total' => count( $rows ) );
	}

	/**
	 * Send due batches. $id = one campaign (the admin page "tick"), 0 = all due ones (cron).
	 * One batch per campaign per call keeps every request short (no PHP / gateway timeouts).
	 */
	public static function run( $id = 0, $force = false ) {
		global $wpdb;
		$lock = 'bch_bulk_lock';
		if ( get_transient( $lock ) ) {
			return 0;
		}
		set_transient( $lock, 1, 120 );
		$done = 0;
		try {
			$where = $id ? $wpdb->prepare( 'id = %d', $id ) : '1=1';
			$due   = $force ? '' : $wpdb->prepare( ' AND next_run <= %s', Helpers::now() );
			$list  = $wpdb->get_results( 'SELECT * FROM ' . self::t() . " WHERE status = 'running' AND {$where}{$due} ORDER BY next_run ASC LIMIT 5", ARRAY_A ); // phpcs:ignore
			foreach ( (array) $list as $c ) {
				$done += self::batch( $c );
			}
		} finally {
			delete_transient( $lock );
		}
		return $done;
	}

	/** Process the next batch of one campaign. */
	private static function batch( array $c ) {
		global $wpdb;
		$f     = self::clean( (array) json_decode( (string) $c['filters'], true ) );
		$wheel = self::wheel( $f );
		$items = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::ti() . " WHERE bulk_id = %d AND status = 'pending' ORDER BY id ASC LIMIT %d", $c['id'], max( 1, (int) $c['batch_size'] ) ), ARRAY_A ); // phpcs:ignore
		$bno   = (int) $c['batches'] + 1;
		$msgs  = array();
		$state = array();
		foreach ( (array) $items as $it ) {
			$info = (array) json_decode( (string) $it['info'], true );
			$r    = array( 'phone' => $it['phone'], 'name' => $it['name'], 'email' => (string) ( $info['email'] ?? '' ), 'user_id' => (int) $it['user_id'], 'spins' => (int) ( $info['spins'] ?? 0 ), 'wins' => (int) ( $info['wins'] ?? 0 ), 'balance' => (int) ( $info['balance'] ?? 0 ) );
			$up   = array( 'batch' => $bno, 'tries' => (int) $it['tries'] + 1 );
			if ( $f['grant'] > 0 && 'granted' !== $it['grant_status'] ) {
				$uniq = 'bulk:c' . $c['id'] . ':' . $it['phone'];
				$cid  = Ledger::grant(
					array(
						'wheel_id'     => (int) $f['grant_wheel'],
						// On the mobile: a logged-in owner (billing phone), an OTP-verified guest and the personal SMS link all match it.
						'user_id'      => 0,
						'phone'        => $it['phone'],
						'qty'          => $f['grant'],
						'reason'       => 'bulk',
						'ref_type'     => 'bulk',
						'ref_id'       => (int) $c['id'],
						'uniq'         => $uniq,
						'note'         => '' !== $f['grant_note'] ? $f['grant_note'] : Lang::t( 'هدیه پیامکی', 'SMS gift' ),
						'expires_days' => $f['grant_days'],
						'created_by'   => (int) $c['created_by'],
					)
				);
				if ( ! $cid ) {
					$cid = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . Ledger::t() . ' WHERE uniq = %s', $uniq ) ); // phpcs:ignore — already granted by an earlier try.
				}
				$up['grant_status'] = $cid ? 'granted' : 'failed';
				$up['credit_id']    = $cid;
			}
			if ( $f['send_sms'] ) {
				$m             = self::message( $r, $f, $wheel );
				$msgs[]        = $m;
				$up['message'] = mb_substr( ! empty( $m['pattern'] ) ? '[' . $m['pattern']['code'] . '] ' . wp_json_encode( $m['pattern']['params'], JSON_UNESCAPED_UNICODE ) : $m['text'], 0, 1000 );
			} else {
				$up['status']  = 'granted' === ( $up['grant_status'] ?? '' ) ? 'done' : 'failed';
				$up['sent_at'] = Helpers::now();
			}
			$state[ $it['phone'] ] = array( 'id' => (int) $it['id'], 'up' => $up );
		}
		if ( $msgs ) {
			$out = Sms::send_many( $msgs, 'bulk', $wheel ? (int) $wheel['id'] : 0 );
			foreach ( $state as $ph => $x ) {
				if ( ! isset( $x['up']['message'] ) ) {
					continue;
				}
				$res                           = $out['items'][ $ph ] ?? array( 'status' => 'failed', 'response' => (string) ( $out['response'] ?? '' ) );
				$st                            = in_array( $res['status'], array( 'sent', 'test' ), true ) ? 'sent' : 'failed';
				$state[ $ph ]['up']['status']   = $st;
				$state[ $ph ]['up']['response'] = mb_substr( wp_strip_all_tags( (string) $res['response'] ), 0, 1000 );
				$state[ $ph ]['up']['sent_at']  = Helpers::now();
			}
		}
		foreach ( $state as $x ) {
			$wpdb->update( self::ti(), $x['up'], array( 'id' => $x['id'] ) );
		}
		$left = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::ti() . " WHERE bulk_id = %d AND status = 'pending'", $c['id'] ) ); // phpcs:ignore
		$upd  = array( 'batches' => $bno, 'next_run' => Helpers::now( (int) $c['interval_min'] * MINUTE_IN_SECONDS ) );
		if ( ! $left ) {
			$upd['status']      = 'done';
			$upd['finished_at'] = Helpers::now();
			$sum                = self::counts( (int) $c['id'] );
			\Becharkhoon\Core\Logger::log( 'sms', 'info', sprintf( 'Bulk campaign #%d "%s": %d recipients, %d sent, %d failed, %d spin grants', $c['id'], $c['title'], $sum['total'], $sum['sent'], $sum['failed'], $sum['granted'] ) );
		}
		$wpdb->update( self::t(), $upd, array( 'id' => $c['id'] ) );
		return count( (array) $items );
	}

	/** Status counts of one campaign. */
	public static function counts( $id ) {
		global $wpdb;
		$out  = array( 'total' => 0, 'pending' => 0, 'sent' => 0, 'failed' => 0, 'cancelled' => 0, 'done' => 0, 'granted' => 0, 'grant_failed' => 0 );
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT status, grant_status, COUNT(*) AS n FROM ' . self::ti() . ' WHERE bulk_id = %d GROUP BY status, grant_status', $id ), ARRAY_A ); // phpcs:ignore
		foreach ( (array) $rows as $r ) {
			$n             = (int) $r['n'];
			$out['total'] += $n;
			if ( isset( $out[ $r['status'] ] ) ) {
				$out[ $r['status'] ] += $n;
			}
			if ( 'granted' === $r['grant_status'] ) {
				$out['granted'] += $n;
			} elseif ( 'failed' === $r['grant_status'] ) {
				$out['grant_failed'] += $n;
			}
		}
		return $out;
	}

	private static function shape( array $c ) {
		$f = (array) json_decode( (string) $c['filters'], true );
		return array(
			'id'           => (int) $c['id'],
			'title'        => $c['title'],
			'status'       => $c['status'],
			'total'        => (int) $c['total'],
			'batch_size'   => (int) $c['batch_size'],
			'interval_min' => (int) $c['interval_min'],
			'batches'      => (int) $c['batches'],
			'next_run'     => $c['next_run'],
			'created_at'   => $c['created_at'],
			'finished_at'  => $c['finished_at'],
			'grant'        => (int) ( $f['grant'] ?? 0 ),
			'grant_wheel'  => (int) ( $f['grant_wheel'] ?? 0 ),
			'send_sms'     => ! empty( $f['send_sms'] ),
			'mode'         => $f['mode'] ?? 'text',
			'text'         => (string) ( $f['text'] ?? '' ),
			'source'       => (string) ( $f['source'] ?? '' ),
			'counts'       => self::counts( (int) $c['id'] ),
		);
	}

	/** Campaign list (newest first). */
	public static function campaigns( array $a = array() ) {
		global $wpdb;
		$page = max( 1, (int) ( $a['page'] ?? 1 ) );
		$per  = max( 1, min( 100, (int) ( $a['per_page'] ?? 20 ) ) );
		$w    = '1=1';
		if ( ! empty( $a['status'] ) ) {
			$w .= $wpdb->prepare( ' AND status = %s', sanitize_key( $a['status'] ) );
		}
		if ( ! empty( $a['search'] ) ) {
			$w .= $wpdb->prepare( ' AND title LIKE %s', '%' . $wpdb->esc_like( $a['search'] ) . '%' );
		}
		$total = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::t() . " WHERE {$w}" ); // phpcs:ignore
		$rows  = $wpdb->get_results( 'SELECT * FROM ' . self::t() . " WHERE {$w} ORDER BY id DESC" . $wpdb->prepare( ' LIMIT %d OFFSET %d', $per, ( $page - 1 ) * $per ), ARRAY_A ); // phpcs:ignore
		return array( 'total' => $total, 'items' => array_map( array( __CLASS__, 'shape' ), (array) $rows ), 'mode' => Sms::mode(), 'cron' => ! ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) );
	}

	public static function get( $id ) {
		global $wpdb;
		$c = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t() . ' WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore
		return $c ? self::shape( $c ) : null;
	}

	/** Recipients of a campaign with filters. */
	public static function items( $id, array $a = array() ) {
		global $wpdb;
		$page = max( 1, (int) ( $a['page'] ?? 1 ) );
		$per  = max( 1, min( 5000, (int) ( $a['per_page'] ?? 50 ) ) );
		$w    = $wpdb->prepare( 'bulk_id = %d', $id );
		$w   .= self::item_where( $a );
		$total = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::ti() . " WHERE {$w}" ); // phpcs:ignore
		$rows  = $wpdb->get_results( 'SELECT id, phone, name, user_id, status, grant_status, credit_id, batch, tries, message, response, sent_at FROM ' . self::ti() . " WHERE {$w} ORDER BY id ASC" . $wpdb->prepare( ' LIMIT %d OFFSET %d', $per, ( $page - 1 ) * $per ), ARRAY_A ); // phpcs:ignore
		return array( 'total' => $total, 'items' => (array) $rows, 'counts' => self::counts( $id ) );
	}

	private static function item_where( array $a ) {
		global $wpdb;
		$w = '';
		switch ( sanitize_key( (string) ( $a['status'] ?? '' ) ) ) {
			case 'sent':
				$w .= " AND status = 'sent'";
				break;
			case 'failed':
				$w .= " AND status = 'failed'";
				break;
			case 'pending':
				$w .= " AND status = 'pending'";
				break;
			case 'cancelled':
				$w .= " AND status = 'cancelled'";
				break;
			case 'unsent': // Everyone who did not get the SMS: failed + waiting + cancelled.
				$w .= " AND status IN ('failed','pending','cancelled')";
				break;
			case 'no_grant':
				$w .= " AND grant_status = 'failed'";
				break;
			case 'problem': // Anything to retry.
				$w .= " AND (status IN ('failed','cancelled') OR grant_status = 'failed')";
				break;
		}
		if ( ! empty( $a['batch'] ) ) {
			$w .= $wpdb->prepare( ' AND batch = %d', (int) $a['batch'] );
		}
		if ( ! empty( $a['search'] ) ) {
			$q  = '%' . $wpdb->esc_like( Helpers::latin_digits( (string) $a['search'] ) ) . '%';
			$w .= $wpdb->prepare( ' AND (phone LIKE %s OR name LIKE %s OR response LIKE %s)', $q, $q, $q );
		}
		return $w;
	}

	/**
	 * pause | resume | cancel | retry (scope: failed | unsent | no_grant | problem | selected ids) | delete | send_now.
	 */
	public static function action( $id, $do, array $a = array() ) {
		global $wpdb;
		$c = self::get( $id );
		if ( ! $c ) {
			return new \WP_Error( 'not_found', Lang::t( 'کمپین پیدا نشد.', 'Campaign not found.' ), array( 'status' => 404 ) );
		}
		switch ( $do ) {
			case 'pause':
				$wpdb->update( self::t(), array( 'status' => 'paused' ), array( 'id' => $id ) );
				break;
			case 'resume':
				$wpdb->update( self::t(), array( 'status' => 'running', 'next_run' => Helpers::now(), 'finished_at' => null ), array( 'id' => $id ) );
				self::ensure_cron();
				break;
			case 'cancel':
				$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::ti() . " SET status = 'cancelled' WHERE bulk_id = %d AND status = 'pending'", $id ) ); // phpcs:ignore
				$wpdb->update( self::t(), array( 'status' => 'cancelled', 'finished_at' => Helpers::now() ), array( 'id' => $id ) );
				break;
			case 'send_now':
				$wpdb->update( self::t(), array( 'next_run' => Helpers::now() ), array( 'id' => $id ) );
				self::run( $id, true );
				break;
			case 'delete':
				$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::ti() . ' WHERE bulk_id = %d', $id ) ); // phpcs:ignore
				$wpdb->delete( self::t(), array( 'id' => $id ) );
				return array( 'ok' => true, 'deleted' => true );
			case 'retry':
				$w = $wpdb->prepare( 'bulk_id = %d', $id );
				if ( ! empty( $a['ids'] ) ) {
					$ids = array_filter( array_map( 'absint', (array) $a['ids'] ) );
					$w  .= $ids ? ' AND id IN (' . implode( ',', $ids ) . ')' : ' AND 0';
				} else {
					$w .= self::item_where( array( 'status' => $a['scope'] ?? 'problem' ) );
				}
				// The SMS goes again (and a missing spin is granted); a spin already granted is never granted twice.
				$n = (int) $wpdb->query( 'UPDATE ' . self::ti() . " SET status = 'pending' WHERE {$w} AND status <> 'pending'" ); // phpcs:ignore
				if ( $n || (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::ti() . " WHERE {$w} AND status = 'pending'" ) ) { // phpcs:ignore
					$wpdb->update( self::t(), array( 'status' => 'running', 'next_run' => Helpers::now(), 'finished_at' => null ), array( 'id' => $id ) );
					self::ensure_cron();
				}
				return array( 'ok' => true, 'queued' => $n, 'campaign' => self::get( $id ) );
			default:
				return new \WP_Error( 'invalid', 'Unknown action', array( 'status' => 400 ) );
		}
		return array( 'ok' => true, 'campaign' => self::get( $id ) );
	}

	/** Back-compat for the 1.7 dialog: process the next batch right away. */
	public static function step( $job ) {
		$c = self::get( absint( $job ) );
		if ( ! $c || 'running' !== $c['status'] ) {
			return new \WP_Error( 'expired', Lang::t( 'این ارسال تمام شده یا متوقف است.', 'This send is finished or stopped.' ), array( 'status' => 404 ) );
		}
		self::run( (int) $c['id'], true );
		$c = self::get( (int) $c['id'] );
		$k = $c['counts'];
		return array( 'done' => $k['total'] - $k['pending'], 'total' => $k['total'], 'sent' => $k['sent'], 'failed' => $k['failed'], 'granted' => $k['granted'], 'finished' => 'running' !== $c['status'], 'mode' => Sms::mode() );
	}
}
