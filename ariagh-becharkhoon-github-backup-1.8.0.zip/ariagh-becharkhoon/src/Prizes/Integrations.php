<?php
/**
 * Wallet and points prizes through popular plugins (detected automatically).
 *   Wallet: TeraWallet (woo-wallet), YITH Account Funds, custom via filter.
 *   Points: WooCommerce Points & Rewards, myCRED, GamiPress, YITH Points, custom via filter.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Prizes;

defined( 'ABSPATH' ) || exit;

final class Integrations {

	public static function wallet_provider() {
		$pref = (string) becharkhoon()->settings->get( 'wallet_provider' );
		$have = array(
			'terawallet' => function_exists( 'woo_wallet' ),
			'yith_funds' => function_exists( 'ywf_get_user_funds' ) || class_exists( 'YITH_YWF_Customer' ),
			'custom'     => (bool) has_filter( 'becharkhoon_wallet_credit' ),
		);
		if ( 'auto' !== $pref ) {
			return ! empty( $have[ $pref ] ) ? $pref : '';
		}
		foreach ( $have as $k => $ok ) {
			if ( $ok ) {
				return $k;
			}
		}
		return '';
	}

	public static function points_provider() {
		$pref = (string) becharkhoon()->settings->get( 'points_provider' );
		$have = array(
			'wc_points' => class_exists( 'WC_Points_Rewards_Manager' ),
			'mycred'    => function_exists( 'mycred_add' ),
			'gamipress' => function_exists( 'gamipress_award_points_to_user' ),
			'yith_points' => function_exists( 'ywpar_increase_points' ) || class_exists( 'YITH_WC_Points_Rewards' ),
			'custom'    => (bool) has_filter( 'becharkhoon_points_credit' ),
		);
		if ( 'auto' !== $pref ) {
			return ! empty( $have[ $pref ] ) ? $pref : '';
		}
		foreach ( $have as $k => $ok ) {
			if ( $ok ) {
				return $k;
			}
		}
		return '';
	}

	/** Detected providers (for the admin). */
	public static function detected() {
		return array(
			'wallet'      => self::wallet_provider(),
			'points'      => self::points_provider(),
			'woocommerce' => class_exists( 'WooCommerce' ),
			'elementor'   => did_action( 'elementor/loaded' ) > 0,
			'wpml'        => defined( 'ICL_SITEPRESS_VERSION' ),
			'polylang'    => function_exists( 'pll_current_language' ),
			'digits'      => function_exists( 'digits_get_mobile' ) || defined( 'digits_version' ),
		);
	}

	/**
	 * Add money to a user's wallet.
	 *
	 * @return bool
	 */
	public static function credit_wallet( $user_id, $amount, $note ) {
		$p = self::wallet_provider();
		if ( ! $user_id || $amount <= 0 ) {
			return false;
		}
		switch ( $p ) {
			case 'terawallet':
				$tx = woo_wallet()->wallet->credit( $user_id, $amount, $note );
				return (bool) $tx;
			case 'yith_funds':
				if ( class_exists( 'YITH_YWF_Customer' ) ) {
					$c = new \YITH_YWF_Customer( $user_id );
					$c->add_funds( $amount );
					return true;
				}
				return false;
			case 'custom':
				return (bool) apply_filters( 'becharkhoon_wallet_credit', false, $user_id, $amount, $note );
		}
		return false;
	}

	public static function credit_points( $user_id, $points, $note ) {
		$p = self::points_provider();
		if ( ! $user_id || $points <= 0 ) {
			return false;
		}
		switch ( $p ) {
			case 'wc_points':
				\WC_Points_Rewards_Manager::increase_points( $user_id, (int) $points, 'becharkhoon', array( 'note' => $note ) );
				return true;
			case 'mycred':
				return (bool) mycred_add( 'becharkhoon', $user_id, (int) $points, $note );
			case 'gamipress':
				$types = function_exists( 'gamipress_get_points_types_slugs' ) ? gamipress_get_points_types_slugs() : array();
				gamipress_award_points_to_user( $user_id, (int) $points, $types ? $types[0] : '' );
				return true;
			case 'yith_points':
				if ( function_exists( 'ywpar_increase_points' ) ) {
					ywpar_increase_points( $user_id, (int) $points, $note );
					return true;
				}
				return false;
			case 'custom':
				return (bool) apply_filters( 'becharkhoon_points_credit', false, $user_id, $points, $note );
		}
		return false;
	}
}
