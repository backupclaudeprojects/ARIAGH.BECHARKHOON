<?php
/**
 * "User spins" — everyone who spun or received spins, built from the real tables:
 * every spin ever made (free or credit) + every granted spin, so the page is never empty
 * (free-mode wheels never create ledger rows).
 *
 * A person = WordPress user, else mobile, else email, else device.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Stats;

use Becharkhoon\Core\Helpers;

defined( 'ABSPATH' ) || exit;

final class People {

	/** UNION of spins + grants inside the period, with a person key (uid, ident). */
	private static function union( $from_utc, $to_utc, $wheel_id, &$params ) {
		global $wpdb;
		$s      = $wpdb->prefix . 'bch_spins';
		$c      = $wpdb->prefix . 'bch_credits';
		$ws     = $wheel_id ? ' AND wheel_id = %d' : '';
		$spins  = "SELECT CASE WHEN user_id > 0 THEN user_id ELSE 0 END AS uid, CASE WHEN user_id > 0 THEN '' WHEN phone <> '' THEN phone WHEN email <> '' THEN email ELSE device END AS ident, user_id, phone, email, name, 1 AS spins, CASE WHEN result = 'win' THEN 1 ELSE 0 END AS wins, CASE WHEN is_free = 0 THEN 1 ELSE 0 END AS paid, CASE WHEN status = 'redeemed' THEN 1 ELSE 0 END AS redeemed, 0 AS granted, created_at AS t FROM $s WHERE created_at BETWEEN %s AND %s AND source <> 'preview'$ws";
		$grants = "SELECT CASE WHEN user_id > 0 THEN user_id ELSE 0 END AS uid, CASE WHEN user_id > 0 THEN '' WHEN phone <> '' THEN phone ELSE email END AS ident, user_id, phone, email, '' AS name, 0 AS spins, 0 AS wins, 0 AS paid, 0 AS redeemed, qty AS granted, created_at AS t FROM $c WHERE created_at BETWEEN %s AND %s" . ( $wheel_id ? ' AND (wheel_id = %d OR wheel_id = 0)' : '' );
		$params = array( $from_utc, $to_utc );
		if ( $wheel_id ) {
			$params[] = (int) $wheel_id;
		}
		$params = array_merge( $params, array( $from_utc, $to_utc ) );
		if ( $wheel_id ) {
			$params[] = (int) $wheel_id;
		}
		return "($spins UNION ALL $grants)";
	}

	/**
	 * @param array $a from_utc, to_utc, wheel_id, search, only (winners|credit|has_credits), sort, page, per_page.
	 */
	public static function query( array $a ) {
		global $wpdb;
		$u      = self::union( $a['from_utc'], $a['to_utc'], (int) ( $a['wheel_id'] ?? 0 ), $params );
		$having = array();
		$hp     = array();
		if ( ! empty( $a['search'] ) ) {
			$s        = '%' . $wpdb->esc_like( Helpers::latin_digits( (string) $a['search'] ) ) . '%';
			$having[] = "(MAX(phone) LIKE %s OR MAX(email) LIKE %s OR MAX(name) LIKE %s OR uid IN (SELECT ID FROM {$wpdb->users} WHERE display_name LIKE %s OR user_email LIKE %s OR user_login LIKE %s))";
			$hp       = array_merge( $hp, array( $s, $s, $s, $s, $s, $s ) );
		}
		$only = (string) ( $a['only'] ?? '' );
		if ( 'winners' === $only ) {
			$having[] = 'SUM(wins) > 0';
		} elseif ( 'spinners' === $only ) {
			$having[] = 'SUM(spins) > 0';
		} elseif ( 'granted' === $only ) {
			$having[] = 'SUM(granted) > 0';
		} elseif ( 'redeemed' === $only ) {
			$having[] = 'SUM(redeemed) > 0';
		}
		$h     = $having ? ' HAVING ' . implode( ' AND ', $having ) : '';
		$order = array( 'spins' => 'spins DESC', 'wins' => 'wins DESC', 'granted' => 'granted DESC', 'first' => 'first_at ASC' )[ $a['sort'] ?? '' ] ?? 'last_at DESC';
		$base  = "SELECT uid, ident, MAX(user_id) AS user_id, MAX(phone) AS phone, MAX(email) AS email, MAX(name) AS name, SUM(spins) AS spins, SUM(wins) AS wins, SUM(paid) AS paid, SUM(redeemed) AS redeemed, SUM(granted) AS granted, MIN(t) AS first_at, MAX(t) AS last_at FROM $u x GROUP BY uid, ident$h";
		$all   = array_merge( $params, $hp );
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM ($base) c", $all ) ); // phpcs:ignore
		$sum   = (array) $wpdb->get_row( $wpdb->prepare( "SELECT COALESCE(SUM(spins),0) AS spins, COALESCE(SUM(wins),0) AS wins, COALESCE(SUM(paid),0) AS paid, COALESCE(SUM(granted),0) AS granted, COALESCE(SUM(redeemed),0) AS redeemed FROM ($base) c", $all ), ARRAY_A ); // phpcs:ignore
		$per   = max( 1, min( 5000, (int) ( $a['per_page'] ?? 25 ) ) );
		$page  = max( 1, (int) ( $a['page'] ?? 1 ) );
		$rows  = (array) $wpdb->get_results( $wpdb->prepare( "$base ORDER BY $order LIMIT %d OFFSET %d", array_merge( $all, array( $per, ( $page - 1 ) * $per ) ) ), ARRAY_A ); // phpcs:ignore
		$items = array();
		foreach ( $rows as $r ) {
			$items[] = self::decorate( $r );
		}
		return array( 'items' => $items, 'total' => $total, 'sum' => array_map( 'intval', $sum ) );
	}

	/** Names, current spin balance and lead details for a row. */
	private static function decorate( array $r ) {
		global $wpdb;
		$r['user_name'] = '';
		$uid            = (int) $r['uid'];
		if ( $uid && function_exists( 'get_userdata' ) ) {
			$u = get_userdata( $uid );
			if ( $u ) {
				$r['user_name'] = $u->display_name;
				if ( '' === (string) $r['email'] ) {
					$r['email'] = $u->user_email;
				}
				if ( '' === (string) $r['phone'] ) {
					$r['phone'] = Helpers::phone( (string) get_user_meta( $uid, 'billing_phone', true ) );
				}
			}
		}
		// Balance right now (any wheel).
		$cw = array();
		$cp = array();
		if ( $uid ) {
			$cw[] = 'user_id = %d';
			$cp[] = $uid;
		}
		if ( '' !== (string) $r['phone'] ) {
			$cw[] = 'phone = %s';
			$cp[] = $r['phone'];
		}
		$r['balance'] = 0;
		$r['granted_all'] = 0;
		if ( $cw ) {
			$cp[] = Helpers::now();
			$b    = (array) $wpdb->get_row( $wpdb->prepare( "SELECT COALESCE(SUM(qty),0) AS g, COALESCE(SUM(CASE WHEN status = 'active' AND (expires_at IS NULL OR expires_at > %s) THEN qty - used ELSE 0 END),0) AS b FROM {$wpdb->prefix}bch_credits WHERE (" . implode( ' OR ', $cw ) . ')', array_merge( array( end( $cp ) ), array_slice( $cp, 0, -1 ) ) ), ARRAY_A ); // phpcs:ignore
			$r['balance']     = (int) ( $b['b'] ?? 0 );
			$r['granted_all'] = (int) ( $b['g'] ?? 0 );
		}
		$r['key']   = $uid ? 'u' . $uid : 'i' . $r['ident'];
		$r['wins']  = (int) $r['wins'];
		$r['spins'] = (int) $r['spins'];
		$r['paid']  = (int) $r['paid'];
		$r['granted'] = (int) $r['granted'];
		$r['redeemed'] = (int) $r['redeemed'];
		return $r;
	}

	/**
	 * Timeline: every spin (one chance used) and every grant, newest first.
	 *
	 * @param array $a from_utc, to_utc, wheel_id, search, person (u123 | i09…), type (spin|grant), page, per_page.
	 */
	public static function events( array $a ) {
		global $wpdb;
		$s      = $wpdb->prefix . 'bch_spins';
		$c      = $wpdb->prefix . 'bch_credits';
		$ws     = ! empty( $a['wheel_id'] ) ? ' AND wheel_id = %d' : '';
		$pw     = '';
		$pp     = array();
		$person = (string) ( $a['person'] ?? '' );
		if ( '' !== $person ) {
			$pw = ' AND uid = %d AND ident = %s';
			$pp = 'u' === $person[0] ? array( (int) substr( $person, 1 ), '' ) : array( 0, (string) substr( $person, 1 ) );
		}
		$sw = '';
		$sp = array();
		if ( ! empty( $a['search'] ) ) {
			$q  = '%' . $wpdb->esc_like( Helpers::latin_digits( (string) $a['search'] ) ) . '%';
			$sw = ' AND (phone LIKE %s OR email LIKE %s OR label LIKE %s)';
			$sp = array( $q, $q, $q );
		}
		$sk        = "CASE WHEN user_id > 0 THEN user_id ELSE 0 END AS uid, CASE WHEN user_id > 0 THEN '' WHEN phone <> '' THEN phone WHEN email <> '' THEN email ELSE device END AS ident";
		$ck        = "CASE WHEN user_id > 0 THEN user_id ELSE 0 END AS uid, CASE WHEN user_id > 0 THEN '' WHEN phone <> '' THEN phone ELSE email END AS ident";
		$spin_sql  = "SELECT $sk, 'spin' AS type, id, wheel_id, user_id, phone, email, name, slice_label AS label, result, status, is_free, source, coupon_code AS code, 1 AS qty, created_at AS t FROM $s WHERE created_at BETWEEN %s AND %s AND source <> 'preview'$ws";
		$grant_sql = "SELECT $ck, 'grant' AS type, id, wheel_id, user_id, phone, email, '' AS name, CASE WHEN note <> '' THEN note ELSE reason END AS label, '' AS result, status, 0 AS is_free, reason AS source, '' AS code, qty, created_at AS t FROM $c WHERE created_at BETWEEN %s AND %s$ws";
		$type      = (string) ( $a['type'] ?? '' );
		$parts     = array();
		$params    = array();
		foreach ( array( 'spin' => $spin_sql, 'grant' => $grant_sql ) as $k => $sql ) {
			if ( '' !== $type && $type !== $k ) {
				continue;
			}
			$parts[] = "SELECT * FROM ($sql) z WHERE 1=1" . $pw . $sw;
			$params  = array_merge( $params, array( $a['from_utc'], $a['to_utc'] ), ! empty( $a['wheel_id'] ) ? array( (int) $a['wheel_id'] ) : array(), $pp, $sp );
		}
		$u     = implode( ' UNION ALL ', $parts );
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM ($u) e", $params ) ); // phpcs:ignore
		$per   = max( 1, min( 500, (int) ( $a['per_page'] ?? 30 ) ) );
		$page  = max( 1, (int) ( $a['page'] ?? 1 ) );
		$items = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM ($u) e ORDER BY t DESC, id DESC LIMIT %d OFFSET %d", array_merge( $params, array( $per, ( $page - 1 ) * $per ) ) ), ARRAY_A ); // phpcs:ignore
		foreach ( $items as &$it ) {
			$it['user_name'] = '';
			if ( (int) $it['user_id'] && function_exists( 'get_userdata' ) && ( $u = get_userdata( (int) $it['user_id'] ) ) ) {
				$it['user_name'] = $u->display_name;
			}
		}
		unset( $it );
		return array( 'items' => $items, 'total' => $total );
	}

	/** 09121234567 → chosen style for SMS panels / customer clubs. */
	public static function phone_style( $phone, $style ) {
		if ( ! preg_match( '/^09\d{9}$/', (string) $phone ) ) {
			return (string) $phone;
		}
		if ( '9' === $style ) {
			return substr( $phone, 1 );
		}
		if ( '98' === $style ) {
			return '98' . substr( $phone, 1 );
		}
		if ( '+98' === $style ) {
			return '+98' . substr( $phone, 1 );
		}
		return $phone;
	}

	/**
	 * Contact list for bulk SMS / customer club, de-duplicated by mobile (else email).
	 *
	 * @param array $a source (leads|people|all), from_utc, to_utc, wheel_id, marketing, verified, winners, need_phone.
	 * @return array{rows:array,fields:array}
	 */
	public static function contacts( array $a ) {
		global $wpdb;
		$src    = in_array( $a['source'] ?? 'all', array( 'leads', 'people', 'all' ), true ) ? $a['source'] : 'all';
		$rows   = array();
		$fields = array();
		$put    = static function ( array $c ) use ( &$rows ) {
			$k = '' !== $c['phone'] ? 'p' . $c['phone'] : ( '' !== $c['email'] ? 'e' . strtolower( $c['email'] ) : '' );
			if ( '' === $k ) {
				return;
			}
			if ( ! isset( $rows[ $k ] ) ) {
				$rows[ $k ] = $c;
				return;
			}
			$o = &$rows[ $k ];
			foreach ( array( 'name', 'email', 'phone', 'user_id' ) as $f ) {
				if ( empty( $o[ $f ] ) && ! empty( $c[ $f ] ) ) {
					$o[ $f ] = $c[ $f ];
				}
			}
			foreach ( array( 'spins', 'wins', 'granted', 'balance', 'redeemed' ) as $f ) {
				$o[ $f ] = max( (int) $o[ $f ], (int) $c[ $f ] );
			}
			$o['verified']  = $o['verified'] || $c['verified'];
			$o['marketing'] = $o['marketing'] || $c['marketing'];
			$o['lead']      = $o['lead'] || $c['lead'];
			$o['fields']    = array_merge( $c['fields'], $o['fields'] );
			$o['first_at']  = min( $o['first_at'] ? $o['first_at'] : $c['first_at'], $c['first_at'] ? $c['first_at'] : $o['first_at'] );
			$o['last_at']   = max( $o['last_at'], $c['last_at'] );
			unset( $o );
		};
		if ( 'people' !== $src ) {
			$w = array( '1=1' );
			$p = array();
			if ( ! empty( $a['from_utc'] ) ) {
				$w[] = 'updated_at >= %s';
				$p[] = $a['from_utc'];
			}
			if ( ! empty( $a['to_utc'] ) ) {
				$w[] = 'created_at <= %s';
				$p[] = $a['to_utc'];
			}
			if ( ! empty( $a['wheel_id'] ) ) {
				$w[] = 'wheel_id = %d';
				$p[] = (int) $a['wheel_id'];
			}
			$sql = "SELECT * FROM {$wpdb->prefix}bch_leads WHERE " . implode( ' AND ', $w ) . ' ORDER BY id DESC LIMIT 100000';
			foreach ( (array) $wpdb->get_results( $p ? $wpdb->prepare( $sql, $p ) : $sql, ARRAY_A ) as $l ) { // phpcs:ignore
				$f = Helpers::json_decode_array( $l['fields'] );
				foreach ( array_keys( $f ) as $fk ) {
					$fields[ $fk ] = true;
				}
				$put( array( 'name' => (string) $l['name'], 'phone' => (string) $l['phone'], 'email' => (string) $l['email'], 'user_id' => (int) $l['user_id'], 'verified' => (bool) $l['phone_verified'], 'marketing' => (bool) $l['marketing'], 'lead' => true, 'spins' => (int) $l['spins'], 'wins' => (int) $l['wins'], 'granted' => 0, 'balance' => 0, 'redeemed' => 0, 'fields' => $f, 'first_at' => $l['created_at'], 'last_at' => $l['updated_at'] ) );
			}
		}
		if ( 'leads' !== $src ) {
			$res = self::query( array( 'from_utc' => $a['from_utc'] ?? '1970-01-01 00:00:00', 'to_utc' => $a['to_utc'] ?? '2999-12-31 23:59:59', 'wheel_id' => (int) ( $a['wheel_id'] ?? 0 ), 'per_page' => 5000, 'page' => 1 ) );
			$pages = (int) ceil( $res['total'] / 5000 );
			for ( $pg = 1; $pg <= min( $pages, 40 ); $pg++ ) {
				if ( $pg > 1 ) {
					$res = self::query( array( 'from_utc' => $a['from_utc'] ?? '1970-01-01 00:00:00', 'to_utc' => $a['to_utc'] ?? '2999-12-31 23:59:59', 'wheel_id' => (int) ( $a['wheel_id'] ?? 0 ), 'per_page' => 5000, 'page' => $pg ) );
				}
				foreach ( $res['items'] as $r ) {
					$put( array( 'name' => '' !== (string) $r['name'] ? (string) $r['name'] : (string) $r['user_name'], 'phone' => Helpers::phone( (string) $r['phone'] ), 'email' => (string) $r['email'], 'user_id' => (int) $r['uid'], 'verified' => false, 'marketing' => false, 'lead' => false, 'spins' => $r['spins'], 'wins' => $r['wins'], 'granted' => $r['granted_all'], 'balance' => $r['balance'], 'redeemed' => $r['redeemed'], 'fields' => array(), 'first_at' => $r['first_at'], 'last_at' => $r['last_at'] ) );
				}
			}
		}
		$out = array();
		foreach ( $rows as $c ) {
			if ( ! empty( $a['marketing'] ) && ! $c['marketing'] ) {
				continue;
			}
			if ( ! empty( $a['verified'] ) && ! $c['verified'] ) {
				continue;
			}
			if ( ! empty( $a['winners'] ) && ! $c['wins'] ) {
				continue;
			}
			if ( ! empty( $a['need_phone'] ) && '' === $c['phone'] ) {
				continue;
			}
			$out[] = $c;
		}
		return array( 'rows' => $out, 'fields' => array_keys( $fields ) );
	}
}
