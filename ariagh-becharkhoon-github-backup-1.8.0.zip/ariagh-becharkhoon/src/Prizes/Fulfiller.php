<?php
/**
 * Turns a won slice into a real reward.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Prizes;

use Becharkhoon\Core\Helpers;
use Becharkhoon\Core\Lang;
use Becharkhoon\Credits\Ledger;
use Becharkhoon\Engine\Context;
use Becharkhoon\Engine\Eligibility;

defined( 'ABSPATH' ) || exit;

final class Fulfiller {

	/**
	 * @param array   $wheel   Wheel.
	 * @param array   $slice   Slice.
	 * @param Context $ctx     Winner.
	 * @param int     $spin_id Spin id.
	 * @return array{status:string,code:string,coupon_id:int,expires:string,value:string,link:string}|\WP_Error
	 */
	public static function fulfill( array $wheel, array $slice, Context $ctx, $spin_id ) {
		$out = array( 'status' => 'issued', 'code' => '', 'coupon_id' => 0, 'expires' => '', 'value' => '', 'link' => '' );
		$note = sprintf( Lang::t( 'گردونه شانس «%1$s»: %2$s', 'Lucky wheel "%1$s": %2$s' ), $wheel['title'], $slice['label'] );
		switch ( $slice['type'] ) {
			case 'coupon_percent':
			case 'coupon_fixed_cart':
			case 'coupon_fixed_product':
			case 'free_shipping':
			case 'free_product':
				$gift = null;
				if ( 'free_product' === $slice['type'] ) {
					$gift = Gifts::pick( $slice ); // Random gift from the list (site + manual products).
					if ( ! $gift ) {
						return new \WP_Error( 'gift', 'No gift product available' );
					}
					$out['gift'] = $gift;
				}
				$c = Coupons::create( $wheel, $slice, $ctx, $spin_id, $gift );
				if ( is_wp_error( $c ) ) {
					return $c;
				}
				$out['code']      = $c['code'];
				$out['coupon_id'] = $c['id'];
				$out['expires']   = $c['expires'];
				$out['value']     = self::value_text( $slice );
				return $out;

			case 'existing_coupon':
				$out['code']  = strtoupper( $slice['coupon_code'] );
				$id           = function_exists( 'wc_get_coupon_id_by_code' ) ? wc_get_coupon_id_by_code( $slice['coupon_code'] ) : 0;
				if ( $id ) {
					$cp  = new \WC_Coupon( $id );
					$exp = $cp->get_date_expires();
					if ( $exp ) {
						$out['expires'] = gmdate( 'Y-m-d H:i:s', $exp->getTimestamp() );
					}
				}
				return $out;

			case 'wallet':
				if ( ! Integrations::credit_wallet( $ctx->user_id, (float) $slice['value'], $note ) ) {
					return new \WP_Error( 'wallet', 'Wallet credit failed' );
				}
				$out['status'] = 'delivered';
				$out['value']  = Helpers::money( $slice['value'] );
				return $out;

			case 'points':
				if ( ! Integrations::credit_points( $ctx->user_id, (int) $slice['value'], $note ) ) {
					return new \WP_Error( 'points', 'Points credit failed' );
				}
				$out['status'] = 'delivered';
				$out['value']  = (string) (int) $slice['value'];
				return $out;

			case 'extra_spin':
				$n = max( 1, (int) $slice['value'] );
				if ( $ctx->user_id || ( '' !== $ctx->phone && $ctx->phone_verified ) ) {
					Ledger::grant(
						array(
							'wheel_id'     => (int) $wheel['id'],
							'user_id'      => $ctx->user_id,
							'phone'        => $ctx->phone_verified || $ctx->user_id ? $ctx->phone : '',
							'email'        => $ctx->email,
							'qty'          => $n,
							'reason'       => 'prize',
							'ref_type'     => 'spin',
							'ref_id'       => $spin_id,
							'uniq'         => 'spin:' . $spin_id,
							'expires_days' => 30,
							'note'         => $slice['label'],
						)
					);
				} else {
					Eligibility::add_bonus( $wheel['id'], $ctx, $n );
				}
				$out['status'] = 'delivered';
				$out['value']  = (string) $n;
				return $out;

			case 'code_pool':
				$code = CodePool::claim( $wheel['id'], $slice['id'], $spin_id );
				if ( '' === $code ) {
					return new \WP_Error( 'pool', 'Code pool is empty' );
				}
				$out['code'] = $code;
				if ( (int) $slice['expiry_days'] > 0 ) {
					$out['expires'] = Helpers::now( (int) $slice['expiry_days'] * DAY_IN_SECONDS );
				}
				return $out;

			case 'link':
				$out['status'] = 'delivered';
				$out['link']   = $slice['link_url'];
				return $out;

			case 'custom':
				$out['status'] = $slice['requires_claim'] ? 'pending' : 'issued';
				$out['value']  = wp_strip_all_tags( $slice['custom_text'] );
				return $out;

			case 'respin':
				$out['status'] = 'respin';
				return $out;
		}
		$out['status'] = 'lost';
		return $out;
	}

	/** "10%" / "50,000 تومان" style value text. */
	public static function value_text( array $slice ) {
		switch ( $slice['type'] ) {
			case 'coupon_percent':
				$v = rtrim( rtrim( number_format( (float) $slice['value'], 2, '.', '' ), '0' ), '.' ) . '%';
				return Lang::is_fa() ? Helpers::persian_digits( $v ) : $v;
			case 'coupon_fixed_cart':
			case 'coupon_fixed_product':
			case 'wallet':
				return Helpers::money( $slice['value'] );
			case 'free_shipping':
				return Lang::t( 'ارسال رایگان', 'Free shipping' );
			case 'free_product':
				$p = function_exists( 'wc_get_product' ) && $slice['product_ids'] ? wc_get_product( $slice['product_ids'][0] ) : null;
				return $p ? $p->get_name() : Lang::t( 'محصول هدیه', 'Free gift' );
		}
		return '';
	}
}
