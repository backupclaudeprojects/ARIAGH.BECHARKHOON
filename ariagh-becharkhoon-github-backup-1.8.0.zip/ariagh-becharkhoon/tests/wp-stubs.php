<?php
/**
 * Minimal WordPress runtime for offline tests: hooks, options, transients, users,
 * sanitizers and a $wpdb backed by SQLite (MySQL syntax translated).
 */
// phpcs:ignoreFile

define( 'ABSPATH', __DIR__ . '/fakewp/' );
define( 'WPINC', 'wp-includes' );
define( 'MINUTE_IN_SECONDS', 60 );
define( 'HOUR_IN_SECONDS', 3600 );
define( 'DAY_IN_SECONDS', 86400 );
define( 'WEEK_IN_SECONDS', 604800 );
define( 'ARRAY_A', 'ARRAY_A' );
define( 'OBJECT', 'OBJECT' );
define( 'COOKIEPATH', '/' );
define( 'COOKIE_DOMAIN', '' );
define( 'EP_ROOT', 64 );
define( 'EP_PAGES', 4096 );
define( 'AUTH_KEY', 'test-auth-key' );
define( 'SECURE_AUTH_SALT', 'test-salt' );
define( 'BCH_SYNC_NOTIFY', true );
@mkdir( ABSPATH . 'wp-admin/includes', 0777, true );
@mkdir( ABSPATH . 'wp-includes', 0777, true );
file_put_contents( ABSPATH . 'wp-admin/includes/upgrade.php', '<?php ' );
file_put_contents( ABSPATH . 'wp-includes/class-phpass.php', '<?php ' );

$GLOBALS['__origin']  = getenv( 'BCH_ORIGIN' ) ?: 'https://shop.test';
$GLOBALS['__hooks']   = array();
$GLOBALS['__options'] = array();
// Optional persistence for the browser dev server (tests/devserver.php): BCH_STATE=/path/prefix.
if ( getenv( 'BCH_STATE' ) ) {
	$__sf = getenv( 'BCH_STATE' ) . '.options';
	if ( is_file( $__sf ) ) { $GLOBALS['__options'] = unserialize( file_get_contents( $__sf ) ) ?: array(); }
	register_shutdown_function( function () use ( $__sf ) {
		$o = array_filter( $GLOBALS['__options'], function ( $v ) { return ! is_object( $v ); } );
		file_put_contents( $__sf, serialize( $o ) );
	} );
}
$GLOBALS['__users']   = array();
$GLOBALS['__umeta']   = array();
$GLOBALS['__uid']     = 0;
$GLOBALS['__http']    = array();
$GLOBALS['__mail']    = array();
$GLOBALS['__locale']  = 'fa_IR';
$GLOBALS['__now']     = null;

class WP_Error {
	public $code; public $msg; public $data;
	public function __construct( $c = '', $m = '', $d = null ) { $this->code = $c; $this->msg = $m; $this->data = $d; }
	public function get_error_message() { return $this->msg; }
	public function get_error_code() { return $this->code; }
	public function get_error_data() { return $this->data; }
}
function is_wp_error( $x ) { return $x instanceof WP_Error; }

function add_action( $h, $cb, $p = 10, $a = 1 ) { $GLOBALS['__hooks'][ $h ][ $p ][] = array( $cb, $a ); return true; }
function add_filter( $h, $cb, $p = 10, $a = 1 ) { return add_action( $h, $cb, $p, $a ); }
function has_filter( $h, $cb = false ) { return ! empty( $GLOBALS['__hooks'][ $h ] ); }
function has_action( $h, $cb = false ) { return ! empty( $GLOBALS['__hooks'][ $h ] ); }
function remove_all_actions( $h ) { unset( $GLOBALS['__hooks'][ $h ] ); }
function do_action( $h, ...$args ) {
	$GLOBALS['__did'][ $h ] = ( $GLOBALS['__did'][ $h ] ?? 0 ) + 1;
	if ( empty( $GLOBALS['__hooks'][ $h ] ) ) { return; }
	ksort( $GLOBALS['__hooks'][ $h ] );
	foreach ( $GLOBALS['__hooks'][ $h ] as $list ) { foreach ( $list as $x ) { call_user_func_array( $x[0], array_slice( $args, 0, $x[1] ) ); } }
}
function did_action( $h ) { return $GLOBALS['__did'][ $h ] ?? 0; }
function apply_filters( $h, $v, ...$args ) {
	if ( empty( $GLOBALS['__hooks'][ $h ] ) ) { return $v; }
	ksort( $GLOBALS['__hooks'][ $h ] );
	foreach ( $GLOBALS['__hooks'][ $h ] as $list ) { foreach ( $list as $x ) { $v = call_user_func_array( $x[0], array_slice( array_merge( array( $v ), $args ), 0, $x[1] ) ); } }
	return $v;
}
function register_activation_hook() {} function register_deactivation_hook() {}
function plugin_dir_path( $f ) { return dirname( $f ) . '/'; }
function plugin_dir_url( $f ) { return $GLOBALS['__origin'] . '/wp-content/plugins/' . basename( dirname( $f ) ) . '/'; }
function plugin_basename( $f ) { return basename( dirname( $f ) ) . '/' . basename( $f ); }
function load_plugin_textdomain() {}
function __( $s ) { return $s; } function esc_html__( $s ) { return $s; }
function is_admin() { return ! empty( $GLOBALS['__is_admin'] ); }
function wp_doing_ajax() { return ! empty( $GLOBALS['__ajax'] ); }
function is_multisite() { return false; }

// Options.
function get_option( $k, $d = false ) { return array_key_exists( $k, $GLOBALS['__options'] ) ? $GLOBALS['__options'][ $k ] : $d; }
function update_option( $k, $v, $a = null ) { $GLOBALS['__options'][ $k ] = $v; return true; }
function add_option( $k, $v = '', $d = '', $a = null ) { if ( array_key_exists( $k, $GLOBALS['__options'] ) ) { return false; } $GLOBALS['__options'][ $k ] = $v; return true; }
function delete_option( $k ) { unset( $GLOBALS['__options'][ $k ] ); return true; }
function get_transient( $k ) { $v = $GLOBALS['__options'][ '_t_' . $k ] ?? null; if ( ! $v || ( $v[1] && $v[1] < bch_t() ) ) { return false; } return $v[0]; }
function set_transient( $k, $v, $e = 0 ) { $GLOBALS['__options'][ '_t_' . $k ] = array( $v, $e ? bch_t() + $e : 0 ); return true; }
function delete_transient( $k ) { unset( $GLOBALS['__options'][ '_t_' . $k ] ); return true; }
function bch_t() { return $GLOBALS['__now'] ?? time(); }
function wp_using_ext_object_cache() { return false; }
function wp_cache_get() { return false; } function wp_cache_set() { return true; } function wp_cache_delete() { return true; } function wp_cache_add() { return true; } function wp_cache_incr() { return 1; }

// Users.
function get_current_user_id() { return $GLOBALS['__uid']; }
function is_user_logged_in() { return $GLOBALS['__uid'] > 0; }
function get_userdata( $id ) { return $GLOBALS['__users'][ (int) $id ] ?? false; }
function get_user_by( $f, $v ) { foreach ( $GLOBALS['__users'] as $u ) { if ( 'email' === $f && strtolower( $u->user_email ) === strtolower( $v ) ) { return $u; } } return false; }
function get_user_meta( $id, $k, $single = false ) { return $GLOBALS['__umeta'][ (int) $id ][ $k ] ?? ( $single ? '' : array() ); }
function update_user_meta( $id, $k, $v ) { $GLOBALS['__umeta'][ (int) $id ][ $k ] = $v; return true; }
function delete_user_meta( $id, $k ) { unset( $GLOBALS['__umeta'][ (int) $id ][ $k ] ); return true; }
function current_user_can( $cap ) { $u = get_userdata( get_current_user_id() ); return $u && in_array( 'administrator', $u->roles, true ); }
function bch_make_user( $id, $email, $roles = array( 'customer' ), $registered = '2025-01-01 00:00:00' ) {
	$u = (object) array( 'ID' => $id, 'user_email' => $email, 'display_name' => 'User ' . $id, 'roles' => $roles, 'user_registered' => $registered, 'user_login' => 'u' . $id );
	$GLOBALS['__users'][ $id ] = $u;
	return $u;
}
function wp_get_current_user() { return get_userdata( get_current_user_id() ) ?: (object) array( 'ID' => 0, 'display_name' => '' ); }

// Locale / time.
function get_locale() { return $GLOBALS['__locale']; }
function determine_locale() { return $GLOBALS['__locale']; }
function get_user_locale() { return $GLOBALS['__locale']; }
function is_rtl() { return 0 === strpos( $GLOBALS['__locale'], 'fa' ); }
function wp_timezone() { return new DateTimeZone( 'Asia/Tehran' ); }
function wp_timezone_string() { return 'Asia/Tehran'; }
function wp_date( $f, $ts = null ) { $d = new DateTime( '@' . ( $ts ?? bch_t() ) ); $d->setTimezone( wp_timezone() ); return $d->format( $f ); }
function get_date_from_gmt( $s ) { return wp_date( 'Y-m-d H:i:s', strtotime( $s . ' UTC' ) ); }
function human_time_diff( $a, $b = null ) { return max( 1, (int) ( ( ( $b ?? time() ) - $a ) / 60 ) ) . ' mins'; }
function number_format_i18n( $n, $d = 0 ) { return number_format( (float) $n, $d ); }

// Sanitizers / escaping.
function sanitize_text_field( $s ) { return trim( preg_replace( '/[\r\n\t ]+/', ' ', strip_tags( (string) $s ) ) ); }
function sanitize_textarea_field( $s ) { return trim( strip_tags( (string) $s ) ); }
function sanitize_key( $s ) { return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $s ) ); }
function sanitize_title( $s ) { return trim( preg_replace( '/[^a-z0-9\-]+/', '-', strtolower( (string) $s ) ), '-' ); }
function sanitize_html_class( $s ) { return preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $s ); }
function sanitize_email( $s ) { return trim( $s ); }
function is_email( $e ) { return (bool) filter_var( $e, FILTER_VALIDATE_EMAIL ); }
function wp_unslash( $s ) { return $s; }
function wp_kses_post( $s ) { return preg_replace( '#<script.*?</script>#is', '', (string) $s ); }
function wp_strip_all_tags( $s ) { return trim( strip_tags( (string) $s ) ); }
function wp_check_invalid_utf8( $s ) { return $s; }
function esc_html( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES ); }
function esc_attr( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES ); }
function esc_url( $s ) { return (string) $s; }
function esc_url_raw( $s, $p = null ) { $s = trim( (string) $s ); return ( '' === $s || preg_match( '#^(https?:)?//|^/#i', $s ) ) ? $s : ( preg_match( '#^[a-z]+:#i', $s ) ? '' : 'http://' . $s ); }
function esc_attr__( $s ) { return $s; }
function absint( $n ) { return abs( (int) $n ); }
function trailingslashit( $s ) { return rtrim( (string) $s, '/\\' ) . '/'; }
function untrailingslashit( $s ) { return rtrim( (string) $s, '/\\' ); }
function wp_json_encode( $d, $o = 0 ) { return json_encode( $d, $o ); }
function wp_specialchars_decode( $s ) { return htmlspecialchars_decode( (string) $s ); }
function wp_parse_args( $a, $d = array() ) { return array_merge( $d, (array) $a ); }
function wp_parse_url( $u, $c = -1 ) { return parse_url( $u, $c ); }
function wp_list_pluck( $l, $f ) { return array_map( function ( $x ) use ( $f ) { return is_array( $x ) ? $x[ $f ] : $x->$f; }, $l ); }
function wp_generate_password( $n = 12 ) { return substr( bin2hex( random_bytes( $n ) ), 0, $n ); }
function wp_generate_uuid4() { return bin2hex( random_bytes( 16 ) ); }
function wp_hash_password( $p ) { return password_hash( $p, PASSWORD_BCRYPT ); }
function wp_check_password( $p, $h ) { return password_verify( $p, $h ); }
function wp_create_nonce() { return 'nonce'; }
function wp_http_validate_url( $u ) { return filter_var( $u, FILTER_VALIDATE_URL ) ? $u : false; }
function home_url( $p = '' ) { return $GLOBALS['__origin'] . ( $p ? '/' . ltrim( $p, '/' ) : '' ); }
function admin_url( $p = '' ) { return $GLOBALS['__origin'] . '/wp-admin/' . $p; }
function rest_url( $p = '' ) { return $GLOBALS['__origin'] . '/wp-json/' . $p; }
function wp_login_url() { return $GLOBALS['__origin'] . '/wp-login.php'; }
function get_bloginfo( $k = '' ) { return 'version' === $k ? '6.8' : 'فروشگاه تست'; }
function add_query_arg( ...$a ) {
	if ( is_array( $a[0] ) ) { $params = $a[0]; $url = $a[1] ?? ''; } else { $params = array( $a[0] => $a[1] ); $url = $a[2] ?? ''; }
	return $url . ( false === strpos( $url, '?' ) ? '?' : '&' ) . http_build_query( $params );
}
class BCH_Test_Roles {
	public $role_objects = array();
	public function get_names() { return array( 'administrator' => 'Administrator', 'editor' => 'Editor', 'customer' => 'Customer', 'subscriber' => 'Subscriber' ); }
}
function wp_roles() { static $r; return $r ?: ( $r = new BCH_Test_Roles() ); }

/* ---------------- REST (routes captured, dispatched in-process) ---------------- */
$GLOBALS['__routes'] = array();
function register_rest_route( $ns, $route, $args ) { $GLOBALS['__routes'][] = array( $ns, $route, isset( $args['methods'] ) ? $args : $args[0] ); return true; }
class WP_REST_Request implements ArrayAccess {
	private $p; private $body; private $m; private $h;
	public function __construct( $m = 'GET', $params = array(), $body = null, $headers = array() ) { $this->m = $m; $this->p = $params; $this->body = $body; $this->h = $headers; }
	public function get_param( $k ) { if ( is_array( $this->body ) && array_key_exists( $k, $this->body ) ) { return $this->body[ $k ]; } return $this->p[ $k ] ?? null; }
	public function get_params() { return array_merge( $this->p, is_array( $this->body ) ? $this->body : array() ); }
	public function get_json_params() { return is_array( $this->body ) ? $this->body : array(); }
	public function get_body_params() { return $this->get_json_params(); }
	public function get_query_params() { return $this->p; }
	public function get_body() { return json_encode( $this->body ); }
	public function get_method() { return $this->m; }
	public function get_header( $k ) { return $this->h[ strtolower( $k ) ] ?? null; }
	public function set_param( $k, $v ) { $this->p[ $k ] = $v; }
	public function offsetExists( $k ): bool { return null !== $this->get_param( $k ); }
	#[\ReturnTypeWillChange] public function offsetGet( $k ) { return $this->get_param( $k ); }
	public function offsetSet( $k, $v ): void { $this->p[ $k ] = $v; }
	public function offsetUnset( $k ): void { unset( $this->p[ $k ] ); }
}
class WP_REST_Response {
	public $data; public $status; public $headers = array();
	public function __construct( $d = null, $s = 200 ) { $this->data = $d; $this->status = $s; }
	public function header( $k, $v ) { $this->headers[ $k ] = $v; }
	public function get_data() { return $this->data; }
	public function get_status() { return $this->status; }
	public function set_status( $s ) { $this->status = $s; }
}
function rest_ensure_response( $r ) {
	if ( $r instanceof WP_REST_Response ) { return $r; }
	if ( is_wp_error( $r ) ) { $d = $r->get_error_data(); return new WP_REST_Response( array( 'code' => $r->get_error_code(), 'message' => $r->get_error_message() ), is_array( $d ) && isset( $d['status'] ) ? $d['status'] : 400 ); }
	return new WP_REST_Response( $r, 200 );
}
/** Dispatch "METHOD /becharkhoon/v1/path" against captured routes → [status, data]. */
function bch_rest( $method, $path, $query = array(), $body = null ) {
	if ( empty( $GLOBALS['__rest_init'] ) ) { $GLOBALS['__rest_init'] = 1; do_action( 'rest_api_init' ); }
	$path = '/' . trim( $path, '/' );
	foreach ( $GLOBALS['__routes'] as $r ) {
		$re = '#^/' . trim( $r[0], '/' ) . $r[1] . '$#';
		$methods = array_map( 'trim', explode( ',', is_array( $r[2]['methods'] ) ? implode( ',', $r[2]['methods'] ) : $r[2]['methods'] ) );
		if ( preg_match( $re, $path, $m ) && in_array( $method, $methods, true ) ) {
			foreach ( $m as $k => $v ) { if ( ! is_int( $k ) ) { $query[ $k ] = $v; } }
			$req = new WP_REST_Request( $method, $query, $body );
			if ( isset( $r[2]['permission_callback'] ) && ! call_user_func( $r[2]['permission_callback'], $req ) ) { return array( 403, array( 'message' => 'Forbidden' ) ); }
			$res = rest_ensure_response( call_user_func( $r[2]['callback'], $req ) );
			return array( $res->status, $res->data );
		}
	}
	return array( 404, array( 'message' => 'No route ' . $method . ' ' . $path ) );
}
function get_role() { return null; }
function add_rewrite_endpoint() {} function flush_rewrite_rules() {}
function wp_next_scheduled() { return time() + 100; } function wp_schedule_event() {} function wp_clear_scheduled_hook() {}
function get_post_type() { return 'product'; }
function get_ancestors() { return array(); }
function wp_get_post_terms() { return array(); }
function is_ssl() { return true; }
function get_comment() { return null; }
function translate_user_role( $n ) { return $n; }

// HTTP (recorded, scripted responses).
function wp_remote_request( $url, $args ) {
	$GLOBALS['__http'][] = array( 'url' => $url, 'args' => $args );
	$fn = $GLOBALS['__http_responder'] ?? null;
	$r  = $fn ? $fn( $url, $args ) : array( 'code' => 200, 'body' => '{}' );
	return array( 'response' => array( 'code' => $r['code'] ), 'body' => $r['body'] );
}
function wp_remote_retrieve_response_code( $r ) { return $r['response']['code']; }
function wp_remote_retrieve_body( $r ) { return $r['body']; }
function wp_mail( $to, $s, $m, $h = array() ) { $GLOBALS['__mail'][] = compact( 'to', 's', 'm' ); return true; }

/* ---------------- $wpdb on SQLite ---------------- */
class BCH_Test_DB {
	public $prefix = 'wp_';
	public $options = 'wp_options';
	public $users = 'wp_users';
	public $usermeta = 'wp_usermeta';
	public $posts = 'wp_posts';
	public $postmeta = 'wp_postmeta';
	public $insert_id = 0;
	public $last_error = '';
	public $queries = 0;
	/** @var PDO */
	public $pdo;
	public function __construct() {
		$this->pdo = new PDO( getenv( 'BCH_STATE' ) ? 'sqlite:' . getenv( 'BCH_STATE' ) . '.sqlite' : 'sqlite::memory:' );
		$this->pdo->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_SILENT );
		$this->pdo->exec( 'CREATE TABLE IF NOT EXISTS wp_options (option_id INTEGER PRIMARY KEY AUTOINCREMENT, option_name TEXT UNIQUE, option_value TEXT, autoload TEXT)' );
		$this->pdo->exec( 'CREATE TABLE IF NOT EXISTS wp_users (ID INTEGER PRIMARY KEY, user_login TEXT, display_name TEXT, user_email TEXT)' );
		$this->pdo->exec( 'CREATE TABLE IF NOT EXISTS wp_usermeta (umeta_id INTEGER PRIMARY KEY, user_id INTEGER, meta_key TEXT, meta_value TEXT)' );
	}
	public function get_charset_collate() { return ''; }
	public function esc_like( $s ) { return addcslashes( $s, '_%\\' ); }
	public function prepare( $q, ...$args ) {
		if ( isset( $args[0] ) && is_array( $args[0] ) && 1 === count( $args ) ) { $args = $args[0]; }
		$i = 0;
		$q = str_replace( "'%s'", '%s', $q );
		return preg_replace_callback( '/%[dsf]/', function ( $m ) use ( &$i, $args ) {
			$v = $args[ $i++ ] ?? null;
			if ( '%d' === $m[0] ) { return (string) (int) $v; }
			if ( '%f' === $m[0] ) { return (string) (float) $v; }
			return $this->pdo->quote( (string) $v );
		}, $q );
	}
	public function tr( $q ) {
		$q = preg_replace( '/INSERT IGNORE INTO/i', 'INSERT OR IGNORE INTO', $q );
		$q = preg_replace( '/ON DUPLICATE KEY UPDATE value = value \+ VALUES\(value\)/i', 'ON CONFLICT(wheel_id, day, metric) DO UPDATE SET value = value + excluded.value', $q );
		$q = str_replace( 'AS UNSIGNED', 'AS INTEGER', $q );
		$q = preg_replace( "/^SHOW TABLES LIKE ('[^']*')$/i", "SELECT name FROM sqlite_master WHERE type = 'table' AND name LIKE $1", trim( $q ) );
		return $q;
	}
	public function query( $q ) {
		$this->queries++;
		$q = $this->tr( $q );
		$r = $this->pdo->exec( $q );
		if ( false === $r ) { $this->last_error = implode( ' ', $this->pdo->errorInfo() ); fwrite( STDERR, "SQL ERR: {$this->last_error}\n$q\n" ); return false; }
		return $r;
	}
	private function fetch( $q ) {
		$this->queries++;
		$st = $this->pdo->query( $this->tr( $q ) );
		if ( ! $st ) { $this->last_error = implode( ' ', $this->pdo->errorInfo() ); fwrite( STDERR, "SQL ERR: {$this->last_error}\n$q\n" ); return array(); }
		return $st->fetchAll( PDO::FETCH_ASSOC );
	}
	public function get_var( $q ) { $r = $this->fetch( $q ); return $r ? array_values( $r[0] )[0] : null; }
	public function get_row( $q, $o = OBJECT ) { $r = $this->fetch( $q ); return $r ? ( ARRAY_A === $o ? $r[0] : (object) $r[0] ) : null; }
	public function get_results( $q, $o = OBJECT ) { $r = $this->fetch( $q ); return ARRAY_A === $o ? $r : array_map( function ( $x ) { return (object) $x; }, $r ); }
	public function get_col( $q ) { return array_map( function ( $x ) { return array_values( $x )[0]; }, $this->fetch( $q ) ); }
	public function insert( $t, $data ) {
		$cols = array_keys( $data );
		$vals = array_map( function ( $v ) { return null === $v ? 'NULL' : $this->pdo->quote( (string) $v ); }, array_values( $data ) );
		$r    = $this->query( "INSERT INTO $t (" . implode( ',', $cols ) . ') VALUES (' . implode( ',', $vals ) . ')' );
		$this->insert_id = (int) $this->pdo->lastInsertId();
		return false === $r ? false : 1;
	}
	public function replace( $t, $data ) {
		$cols = array_keys( $data );
		$vals = array_map( function ( $v ) { return null === $v ? 'NULL' : $this->pdo->quote( (string) $v ); }, array_values( $data ) );
		$r    = $this->query( "INSERT OR REPLACE INTO $t (" . implode( ',', $cols ) . ') VALUES (' . implode( ',', $vals ) . ')' );
		return false === $r ? false : 1;
	}
	public function update( $t, $data, $where ) {
		$set = array(); foreach ( $data as $k => $v ) { $set[] = "$k = " . ( null === $v ? 'NULL' : $this->pdo->quote( (string) $v ) ); }
		$w = array(); foreach ( $where as $k => $v ) { $w[] = "$k = " . $this->pdo->quote( (string) $v ); }
		return $this->query( "UPDATE $t SET " . implode( ', ', $set ) . ' WHERE ' . implode( ' AND ', $w ) );
	}
	public function delete( $t, $where ) {
		$w = array(); foreach ( $where as $k => $v ) { $w[] = "$k = " . $this->pdo->quote( (string) $v ); }
		return $this->query( "DELETE FROM $t WHERE " . implode( ' AND ', $w ) );
	}
}
$GLOBALS['wpdb'] = new BCH_Test_DB();

/** dbDelta → SQLite DDL. */
function dbDelta( $sql ) {
	global $wpdb;
	$sql = preg_replace( '/\)\s*;?\s*$/', ')', trim( $sql ) );
	$sql = preg_replace( '/^CREATE TABLE/i', 'CREATE TABLE IF NOT EXISTS', $sql );
	$sql = preg_replace( '/bigint\(20\) unsigned NOT NULL AUTO_INCREMENT/i', 'INTEGER', $sql );
	$sql = preg_replace( '/\b(big)?int\(\d+\)( unsigned)?/i', 'INTEGER', $sql );
	$sql = preg_replace( '/decimal\(\d+,\d+\)/i', 'REAL', $sql );
	$sql = preg_replace( '/PRIMARY KEY\s+\(id\)/i', 'PRIMARY KEY (id AUTOINCREMENT)', $sql );
	$sql = preg_replace( '/PRIMARY KEY\s+\(/i', 'PRIMARY KEY (', $sql );
	$sql = preg_replace( '/UNIQUE KEY \w+ \(/i', 'UNIQUE (', $sql );
	$sql = preg_replace( '/,\s*KEY \w+ \([^)]*\)/i', '', $sql );
	$sql = str_replace( 'id INTEGER NOT NULL', 'id INTEGER', $sql );
	$sql = preg_replace( '/PRIMARY KEY \(id AUTOINCREMENT\)/', 'PRIMARY KEY (id)', $sql );
	$wpdb->query( $sql );
}

// Asset capture (the dev server prints these into the page).
$GLOBALS['__assets'] = array( 'js' => array(), 'css' => array(), 'l10n' => array() );
function wp_enqueue_script( $h, $src = '', $deps = array(), $v = false, $f = false ) { if ( $src ) { $GLOBALS['__assets']['js'][ $h ] = $src; $GLOBALS['__assets']['head'][ $h ] = ! $f; } return true; }
function wp_add_inline_script( $h, $code, $pos = 'after' ) { $GLOBALS['__assets']['inline'][ $h ][] = $code; return true; }
function wp_register_script( $h, $src = '', $deps = array(), $v = false, $f = false ) { $GLOBALS['__assets']['reg'][ $h ] = $src; return true; }
function wp_enqueue_style( $h, $src = '', $deps = array(), $v = false ) { if ( $src ) { $GLOBALS['__assets']['css'][ $h ] = $src; } return true; }
function wp_register_style( $h, $src = '', $deps = array(), $v = false ) { return true; }
function wp_localize_script( $h, $name, $data ) { $GLOBALS['__assets']['l10n'][ $name ] = $data; return true; }
// No-op / simple stubs.
foreach ( array( 'add_shortcode', 'wp_enqueue_style', 'wp_enqueue_script', 'wp_register_style', 'wp_register_script', 'wp_localize_script', 'wp_script_add_data', 'wp_add_dashboard_widget', 'add_menu_page', 'add_submenu_page', 'wp_enqueue_media', 'register_block_type', 'nocache_headers', 'wp_add_privacy_policy_content', 'setcookie_stub' ) as $__f ) {
	if ( ! function_exists( $__f ) ) { eval( "function $__f() { return true; }" ); }
}
function shortcode_atts( $d, $a ) { return array_merge( $d, (array) $a ); }
function wp_script_is( $h = '' ) { return isset( $GLOBALS['__assets']['js'][ $h ] ); }
function is_plugin_active_for_network() { return false; }
function get_sites() { return array(); }
function wc_get_order_statuses() { return array(); }

// Extra stubs used by the browser dev server.
if ( ! function_exists( 'wp_nonce_url' ) ) { function wp_nonce_url( $u, $a = -1 ) { return $u . ( false === strpos( $u, '?' ) ? '?' : '&' ) . '_wpnonce=nonce'; } }
if ( ! function_exists( 'get_queried_object_id' ) ) { function get_queried_object_id() { return 0; } }
if ( ! function_exists( 'get_queried_object' ) ) { function get_queried_object() { return null; } }
if ( ! function_exists( 'is_front_page' ) ) { function is_front_page() { return true; } }
if ( ! function_exists( 'is_home' ) ) { function is_home() { return false; } }
if ( ! function_exists( 'is_singular' ) ) { function is_singular() { return false; } }
if ( ! function_exists( 'is_page' ) ) { function is_page() { return false; } }
if ( ! function_exists( 'is_single' ) ) { function is_single() { return false; } }
if ( ! function_exists( 'is_search' ) ) { function is_search() { return false; } }
if ( ! function_exists( 'is_404' ) ) { function is_404() { return false; } }
if ( ! function_exists( 'is_archive' ) ) { function is_archive() { return false; } }
if ( ! function_exists( 'is_category' ) ) { function is_category() { return false; } }
if ( ! function_exists( 'is_customize_preview' ) ) { function is_customize_preview() { return false; } }
if ( ! function_exists( 'is_admin_bar_showing' ) ) { function is_admin_bar_showing() { return false; } }
if ( ! function_exists( 'do_shortcode' ) ) { function do_shortcode( $s ) { return $s; } }
if ( ! function_exists( 'wp_get_referer' ) ) { function wp_get_referer() { return ''; } }
if ( ! function_exists( 'get_permalink' ) ) { function get_permalink( $id = 0 ) { return home_url( '/?p=' . (int) $id ); } }
if ( ! function_exists( 'get_the_title' ) ) { function get_the_title( $id = 0 ) { return 'Post ' . (int) $id; } }
if ( ! function_exists( 'wp_get_attachment_url' ) ) { function wp_get_attachment_url( $id ) { return ''; } }
if ( ! function_exists( 'get_avatar_url' ) ) { function get_avatar_url( $id ) { return ''; } }
