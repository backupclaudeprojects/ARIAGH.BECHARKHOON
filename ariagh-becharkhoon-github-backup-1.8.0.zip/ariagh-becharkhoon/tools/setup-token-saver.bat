@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-token-saver.ps1"
