<?php
/**
 * Global plugin settings (one autoloaded option, typed defaults, safe sanitizing).
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Core;

defined( 'ABSPATH' ) || exit;

final class Settings {

	const OPTION = 'bch_settings';
	const MASK   = '••••••••';

	/** @var array|null */
	private $cache = null;

	public static function defaults() {
		return array(
			// General.
			'enabled'               => true,
			'test_mode'             => false,
			'ui_language'           => 'auto',
			'admin_theme'           => 'light',
			'admin_webfont'         => true,
			'brand_name'            => '',
			'front_font'            => 'vazirmatn',
			'front_font_url'        => '',
			'load_front_webfont'    => true,
			'persian_digits'        => true,
			'jalali_dates'          => true,
			'currency_label'        => '',
			'powered_by'            => false,
			'z_index'               => 999999,
			'cache_bust'            => true,
			'ajax_mode'             => 'admin-ajax',
			'fast_boot'             => false,
			'sms_magic_link'        => true,
			'otp_site_login'        => true,
			'otp_register'          => true,
			'sms_magic_days'        => 30,
			'tracking_enabled'      => true,
			'track_sample'          => 100,
			'respect_dnt'           => false,
			'data_retention_days'   => 0,
			'log_retention_days'    => 60,
			'coupon_cleanup_days'   => 30,
			'delete_on_uninstall'   => false,
			'myaccount_tab'         => true,
			'myaccount_title'       => '',
			'myaccount_slug'        => 'lucky-wheel',
			'myaccount_position'    => 3,
			'thankyou_notice'       => true,
			'cart_notice'           => true,
			'auto_apply_param'      => 'bch_apply',
			'open_param'            => 'bch_open',
			'referral_enabled'      => false,
			'referral_param'        => 'bref',
			'referral_cookie_days'  => 30,
			'order_statuses'        => array( 'processing', 'completed' ),
			'revoke_on_refund'      => true,
			// Security / anti-fraud.
			'rate_limit_per_minute' => 20,
			'ip_daily_limit'        => 0,
			'block_ips'             => '',
			'block_emails'          => '',
			'block_phones'          => '',
			'email_domain_mode'     => 'off',
			'email_domains'         => '',
			'block_disposable'      => true,
			'check_mx'              => false,
			'honeypot'              => true,
			'min_fill_seconds'      => 2,
			'captcha'               => 'off',
			'captcha_site_key'      => '',
			'captcha_secret'        => '',
			'recaptcha_threshold'   => 0.5,
			'ip_source'             => 'auto',
			'phone_country'         => 'IR',
			// SMS.
			'sms_enabled'           => true,
			'sms_test_mode'         => false,
			'sms_driver'            => '',
			'sms_fields'            => array(),
			'admin_phones'          => '',
			'sms_tpl'               => array(),
			'sms_log_days'          => 180,
			'otp_length'            => 5,
			'otp_ttl'               => 180,
			'otp_resend'            => 60,
			'otp_max_attempts'      => 5,
			'otp_daily_per_phone'   => 6,
			// Email.
			'email_from_name'       => '',
			'email_from_address'    => '',
			'email_template'        => 'branded',
			'email_logo'            => '',
			'email_color'           => '#1D4ED8',
			'email_footer'          => '',
			'admin_emails'          => '',
			// Messengers + webhooks.
			'bale_token'            => '',
			'bale_chat_id'          => '',
			'telegram_token'        => '',
			'telegram_chat_id'      => '',
			'telegram_api'          => 'https://api.telegram.org',
			'webhooks'              => array(),
			// Integrations.
			'wallet_provider'       => 'auto',
			'points_provider'       => 'auto',
		);
	}

	/** Keys never sent to the browser in clear text. */
	public static function secret_keys() {
		return array( 'captcha_secret', 'bale_token', 'telegram_token' );
	}

	public function all() {
		if ( null === $this->cache ) {
			$stored      = get_option( self::OPTION, array() );
			$this->cache = array_merge( self::defaults(), is_array( $stored ) ? $stored : array() );
		}
		return $this->cache;
	}

	public function get( $key, $fallback = null ) {
		$all = $this->all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $fallback;
	}

	/** Settings for the admin UI: secrets masked. */
	public function for_admin() {
		$all = $this->all();
		foreach ( self::secret_keys() as $k ) {
			if ( ! empty( $all[ $k ] ) ) {
				$all[ $k ] = self::MASK;
			}
		}
		if ( ! empty( $all['sms_fields'] ) && is_array( $all['sms_fields'] ) ) {
			foreach ( $all['sms_fields'] as $driver => $cfg ) {
				if ( ! is_array( $cfg ) ) {
					continue;
				}
				foreach ( \Becharkhoon\Notify\SmsGateways::secret_fields( $driver ) as $k ) {
					if ( isset( $cfg[ $k ] ) && '' !== $cfg[ $k ] ) {
						$all['sms_fields'][ $driver ][ $k ] = self::MASK;
					}
				}
			}
		}
		return $all;
	}

	public static function is_secret_field( $key ) {
		return (bool) preg_match( '/(key|pass|token|secret)/i', (string) $key );
	}

	/**
	 * Merge + sanitize incoming values. Masked secrets keep their stored value.
	 *
	 * @param array $input Partial settings.
	 * @return array Saved settings.
	 */
	public function update( array $input ) {
		$current  = $this->all();
		$defaults = self::defaults();
		foreach ( $input as $key => $value ) {
			if ( ! array_key_exists( $key, $defaults ) ) {
				continue;
			}
			if ( in_array( $key, self::secret_keys(), true ) && self::MASK === $value ) {
				continue;
			}
			$current[ $key ] = $this->sanitize( $key, $value, $defaults[ $key ], $current[ $key ] );
		}
		update_option( self::OPTION, $current, true );
		$this->cache = $current;
		return $current;
	}

	private function sanitize( $key, $value, $default, $old ) {
		switch ( $key ) {
			case 'sms_fields':
				// { driver_id: { field: value } } — password-type fields are encrypted; masks keep the stored value.
				$out = is_array( $old ) ? $old : array();
				foreach ( (array) $value as $driver => $cfg ) {
					$driver = sanitize_key( $driver );
					$drv    = \Becharkhoon\Notify\SmsGateways::driver( $driver );
					if ( ! $drv || ! is_array( $cfg ) ) {
						continue;
					}
					$secret = \Becharkhoon\Notify\SmsGateways::secret_fields( $driver );
					$prev   = isset( $out[ $driver ] ) && is_array( $out[ $driver ] ) ? $out[ $driver ] : array();
					$clean  = array();
					foreach ( $drv->fields() as $k => $f ) {
						$v = isset( $cfg[ $k ] ) && is_scalar( $cfg[ $k ] ) ? trim( wp_unslash( (string) $cfg[ $k ] ) ) : '';
						if ( in_array( $k, $secret, true ) ) {
							$clean[ $k ] = self::MASK === $v ? ( $prev[ $k ] ?? '' ) : \Becharkhoon\Core\Crypto::encrypt( $v );
						} elseif ( 'textarea' === $f[1] ) {
							$clean[ $k ] = wp_check_invalid_utf8( $v );
						} elseif ( 'url' === $f[1] ) {
							$clean[ $k ] = esc_url_raw( $v );
						} else {
							$clean[ $k ] = sanitize_text_field( $v );
						}
					}
					$out[ $driver ] = $clean;
				}
				return $out;
			case 'sms_driver':
				$d = sanitize_key( (string) $value );
				return '' === $d || \Becharkhoon\Notify\SmsGateways::driver( $d ) ? $d : '';
			case 'webhooks':
				$out = array();
				foreach ( (array) $value as $hook ) {
					if ( ! is_array( $hook ) || empty( $hook['url'] ) ) {
						continue;
					}
					$url = esc_url_raw( $hook['url'], array( 'http', 'https' ) );
					if ( ! $url ) {
						continue;
					}
					$out[] = array(
						'url'    => $url,
						'events' => array_values( array_intersect( (array) ( $hook['events'] ?? array() ), array( 'spin', 'win', 'lose', 'lead', 'credit', 'redeem' ) ) ),
						'secret' => sanitize_text_field( $hook['secret'] ?? '' ),
						'active' => ! empty( $hook['active'] ),
					);
				}
				return array_slice( $out, 0, 20 );
			case 'order_statuses':
				return array_values( array_filter( array_map( 'sanitize_key', (array) $value ) ) );
			case 'sms_tpl':
				$out = is_array( $old ) ? $old : array();
				foreach ( (array) $value as $event => $row ) {
					$event = sanitize_key( $event );
					if ( ! \Becharkhoon\Notify\SmsEvents::get( $event ) || ! is_array( $row ) ) {
						continue;
					}
					$out[ $event ] = array(
						'on'     => Helpers::bool( $row['on'] ?? true ),
						'mode'   => 'pattern' === ( $row['mode'] ?? '' ) ? 'pattern' : 'text',
						'text'   => mb_substr( sanitize_textarea_field( (string) ( $row['text'] ?? '' ) ), 0, 1000 ),
						'code'   => mb_substr( sanitize_text_field( Helpers::latin_digits( (string) ( $row['code'] ?? '' ) ) ), 0, 80 ),
						'params'   => mb_substr( sanitize_textarea_field( (string) ( $row['params'] ?? '' ) ), 0, 1000 ),
						'fallback' => Helpers::bool( $row['fallback'] ?? false ),
						'sample'   => mb_substr( sanitize_textarea_field( (string) ( $row['sample'] ?? '' ) ), 0, 1000 ),
					);
				}
				return $out;
			case 'email_footer':
				return sanitize_textarea_field( (string) $value );
			case 'block_ips':
			case 'block_emails':
			case 'block_phones':
			case 'email_domains':
			case 'admin_phones':
			case 'admin_emails':
				return sanitize_textarea_field( (string) $value );
			case 'email_color':
				return Helpers::color( $value, $default );
			case 'front_font_url':
			case 'email_logo':
			case 'telegram_api':
				$u = esc_url_raw( (string) $value );
				return $u ? untrailingslashit( $u ) : ( 'telegram_api' === $key ? $default : '' );
			case 'myaccount_slug':
			case 'auto_apply_param':
			case 'open_param':
			case 'referral_param':
				$s = sanitize_title( (string) $value );
				return '' === $s ? $default : $s;
		}
		if ( is_bool( $default ) ) {
			return Helpers::bool( $value );
		}
		if ( is_int( $default ) ) {
			return (int) $value;
		}
		if ( is_float( $default ) ) {
			return (float) $value;
		}
		if ( is_array( $default ) ) {
			return array_map( 'sanitize_text_field', (array) $value );
		}
		return sanitize_text_field( (string) $value );
	}
}
