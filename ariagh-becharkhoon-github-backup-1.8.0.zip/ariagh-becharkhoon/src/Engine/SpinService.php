<?php
/**
 * The spin transaction: lock → eligibility → consume allowance/credit → draw → reserve stock
 * → fulfil → record → notify. Every failure after a consumption is rolled back.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Engine;

use Becharkhoon\Core\Helpers;
use Becharkhoon\Core\Lang;
use Becharkhoon\Core\Lock;
use Becharkhoon\Core\Logger;
use Becharkhoon\Credits\Ledger;
use Becharkhoon\Prizes\Fulfiller;
use Becharkhoon\Stats\Stats;

defined( 'ABSPATH' ) || exit;

final class SpinService {

	/**
	 * @param array   $wheel Wheel.
	 * @param Context $ctx   Visitor (phone/email/name already validated).
	 * @param array   $lead  name, fields, consent, marketing.
	 * @param array   $meta  source, page_url.
	 * @return array|\WP_Error Payload for the browser.
	 */
	public function spin( array $wheel, Context $ctx, array $lead = array(), array $meta = array() ) {
		$ctx->wheel_id = (int) $wheel['id'];
		$acc           = $wheel['config']['access'];
		$keys          = array();
		foreach ( Limits::identity( $ctx, null ) as $col => $val ) {
			$keys[] = 'spin:' . $wheel['id'] . ':' . $col . ':' . $val;
		}
		sort( $keys );
		$held = array();
		foreach ( $keys as $k ) {
			if ( ! Lock::acquire( $k, 20, 4 ) ) {
				foreach ( $held as $h ) {
					Lock::release( $h );
				}
				return new \WP_Error( 'busy', Lang::t( 'درخواست قبلی شما هنوز در حال پردازش است.', 'Your previous spin is still being processed.' ), array( 'status' => 429 ) );
			}
			$held[] = $k;
		}
		try {
			return $this->locked_spin( $wheel, $ctx, $lead, $meta );
		} finally {
			foreach ( $held as $h ) {
				Lock::release( $h );
			}
		}
	}

	private function locked_spin( array $wheel, Context $ctx, array $lead, array $meta ) {
		$elig = Eligibility::check( $wheel, $ctx );
		if ( ! $elig['ok'] ) {
			return new \WP_Error( 'not_allowed', self::reason_message( $wheel, $elig ), array( 'status' => 403, 'state' => self::public_state( $wheel, $elig ) ) );
		}

		$credit_id = 0;
		$kind      = 1;
		if ( 'bonus' === $elig['via'] ) {
			Eligibility::use_bonus( $wheel['id'], $ctx );
			$kind = $wheel['config']['engine']['respin_counts'] ? 1 : 2;
		} elseif ( 'credit' === $elig['via'] ) {
			$credit_id = Ledger::consume( $ctx, $wheel['id'], $wheel['config']['access']['credit_scope'] );
			if ( ! $credit_id ) {
				return new \WP_Error( 'no_credits', self::msg( $wheel, 'no_spins_text' ), array( 'status' => 403 ) );
			}
			$kind = 0;
		}
		$rollback = function () use ( $credit_id, $elig, $wheel, $ctx ) {
			if ( $credit_id ) {
				Ledger::refund( $credit_id );
			}
			if ( 'bonus' === $elig['via'] ) {
				Eligibility::add_bonus( $wheel['id'], $ctx, 1 );
			}
		};

		$ids        = Limits::identity( $ctx, $wheel['config']['access'] );
		$candidates = Picker::candidates( $wheel, $ctx, $ids );
		$repo       = becharkhoon()->wheels;
		$index      = -1;
		$took_stock = false;
		for ( $try = 0; $try < 12 && $candidates; $try++ ) {
			$i = Picker::draw( $candidates );
			if ( $i < 0 ) {
				break;
			}
			$s = $wheel['config']['slices'][ $i ];
			if ( (int) $s['stock'] >= 0 ) {
				if ( ! $repo->take_stock( $wheel['id'], $s['id'] ) ) {
					unset( $candidates[ $i ] );
					continue;
				}
				$took_stock = true;
			}
			$index = $i;
			break;
		}
		if ( $index < 0 ) {
			$index = Picker::fallback_index( $wheel );
			if ( $index < 0 ) {
				$rollback();
				return new \WP_Error( 'exhausted', self::msg( $wheel, 'closed_text' ), array( 'status' => 410 ) );
			}
		}
		$slice  = $wheel['config']['slices'][ $index ];
		$result = Picker::is_win_type( $slice['type'] ) ? 'win' : ( 'respin' === $slice['type'] ? 'respin' : 'lose' );

		global $wpdb;
		$now = Helpers::now();
		$wpdb->insert(
			$wpdb->prefix . 'bch_spins',
			array(
				'wheel_id'    => (int) $wheel['id'],
				'slice_id'    => (string) $slice['id'],
				'slice_label' => mb_substr( wp_strip_all_tags( $slice['label'] . ( '' !== $slice['sublabel'] ? ' ' . $slice['sublabel'] : '' ) ), 0, 190 ),
				'prize_type'  => $slice['type'],
				'prize_value' => (string) $slice['value'],
				'result'      => $result,
				'status'      => 'pending',
				'user_id'     => (int) $ctx->user_id,
				'email'       => $ctx->email,
				'phone'       => $ctx->phone,
				'name'        => mb_substr( (string) ( $lead['name'] ?? '' ), 0, 190 ),
				'ip'          => $ctx->ip,
				'device'      => $ctx->device_id,
				'credit_id'   => $credit_id,
				'is_free'     => $kind,
				'source'      => substr( sanitize_key( $meta['source'] ?? 'popup' ), 0, 30 ),
				'page_url'    => mb_substr( esc_url_raw( (string) ( $meta['page_url'] ?? '' ) ), 0, 255 ),
				'meta'        => wp_json_encode( array( 'device' => $ctx->client( 'device' ), 'utm' => $ctx->client( 'utm_source' ), 'via' => $elig['via'], 'country' => Helpers::country() ), JSON_UNESCAPED_UNICODE ),
				'created_at'  => $now,
			)
		);
		$spin_id = (int) $wpdb->insert_id;
		if ( ! $spin_id ) {
			if ( $took_stock ) {
				$repo->give_back_stock( $wheel['id'], $slice['id'] );
			}
			$rollback();
			Logger::log( 'system', 'error', 'Spin insert failed: ' . $wpdb->last_error );
			return new \WP_Error( 'db', self::msg( $wheel, 'error_text' ), array( 'status' => 500 ) );
		}

		$prize = Fulfiller::fulfill( $wheel, $slice, $ctx, $spin_id );
		if ( is_wp_error( $prize ) ) {
			if ( $took_stock ) {
				$repo->give_back_stock( $wheel['id'], $slice['id'] );
			}
			$rollback();
			$wpdb->delete( $wpdb->prefix . 'bch_spins', array( 'id' => $spin_id ) );
			Logger::log( 'system', 'error', 'Prize fulfilment failed: ' . $prize->get_error_message(), array( 'wheel' => $wheel['id'], 'slice' => $slice['id'] ) );
			return new \WP_Error( 'fulfil', self::msg( $wheel, 'error_text' ), array( 'status' => 500 ) );
		}

		$wpdb->update(
			$wpdb->prefix . 'bch_spins',
			array(
				'status'      => $prize['status'],
				'coupon_code' => mb_substr( in_array( $slice['type'], array( 'code_pool', 'custom', 'link' ), true ) ? (string) $prize['code'] : wc_format_coupon_code_safe( $prize['code'] ), 0, 80 ),
				'coupon_id'   => (int) $prize['coupon_id'],
				'expires_at'  => '' !== $prize['expires'] ? $prize['expires'] : null,
			),
			array( 'id' => $spin_id )
		);
		if ( ! empty( $prize['gift'] ) ) {
			// Which gift was drawn: visible in reports, SMS/email ({prize}), the coupon bar and "my prizes".
			$meta         = json_decode( (string) $wpdb->get_var( $wpdb->prepare( "SELECT meta FROM {$wpdb->prefix}bch_spins WHERE id = %d", $spin_id ) ), true );
			$meta         = is_array( $meta ) ? $meta : array();
			$meta['gift'] = \Becharkhoon\Prizes\Gifts::public_pick( $prize['gift'] ) + array( 'id' => (int) $prize['gift']['id'] );
			$wpdb->update(
				$wpdb->prefix . 'bch_spins',
				array(
					'slice_label' => mb_substr( $prize['gift']['name'], 0, 190 ),
					'meta'        => wp_json_encode( $meta, JSON_UNESCAPED_UNICODE ),
				),
				array( 'id' => $spin_id )
			);
		}

		// Re-spin chain.
		if ( 'respin' === $result ) {
			$chain_key = 'bch_chain_' . md5( $wheel['id'] . Limits::primary_key( $ctx ) );
			$chain     = (int) get_transient( $chain_key );
			if ( $chain < (int) $wheel['config']['engine']['max_respins'] ) {
				Eligibility::add_bonus( $wheel['id'], $ctx, 1 );
				set_transient( $chain_key, $chain + 1, HOUR_IN_SECONDS );
			}
		} else {
			delete_transient( 'bch_chain_' . md5( $wheel['id'] . Limits::primary_key( $ctx ) ) );
		}

		// Lead + stats.
		$lead_res = Leads::upsert(
			array(
				'phone'          => $ctx->phone,
				'email'          => $ctx->email,
				'name'           => (string) ( $lead['name'] ?? '' ),
				'user_id'        => $ctx->user_id,
				'fields'         => $lead['fields'] ?? array(),
				'consent'        => ! empty( $lead['consent'] ),
				'marketing'      => ! empty( $lead['marketing'] ),
				'phone_verified' => $ctx->phone_verified,
				'wheel_id'       => (int) $wheel['id'],
				'ip'             => $ctx->ip,
				'won'            => 'win' === $result,
				'count_spin'     => true,
			)
		);
		if ( $lead_res['id'] ) {
			$wpdb->update( $wpdb->prefix . 'bch_spins', array( 'lead_id' => $lead_res['id'] ), array( 'id' => $spin_id ) );
		}
		Stats::add( $wheel['id'], 'spins' );
		Stats::add( $wheel['id'], 'win' === $result ? 'wins' : 'losses' );
		delete_transient( 'bch_today_' . (int) $wheel['id'] . '_' . Helpers::today() );
		if ( 'win' === $result ) {
			delete_transient( 'bch_winners_' . (int) $wheel['id'] );
		}

		$spin = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bch_spins WHERE id = %d", $spin_id ), ARRAY_A );
		do_action( 'becharkhoon_spin', $spin, $wheel, $slice, $ctx );
		becharkhoon()->notifier->after_spin( $spin, $wheel, $slice, $ctx );

		// Remaining state after this spin.
		$after = Eligibility::check( $wheel, $ctx );
		return $this->payload( $wheel, $index, $slice, $spin, $prize, $after, $lead );
	}

	private function payload( array $wheel, $index, array $slice, array $spin, array $prize, array $after, array $lead ) {
		$m       = $wheel['config']['messages'];
		$name    = trim( (string) ( $lead['name'] ?? '' ) );
		$expiry  = $spin['expires_at'] ? Helpers::human_date( $spin['expires_at'] ) : '';
		$value   = '' !== $prize['value'] ? $prize['value'] : '';
		$vars    = array(
			'name'   => '' !== $name ? $name : '',
			'prize'  => ! empty( $prize['gift'] ) ? $prize['gift']['name'] : $slice['label'] . ( '' !== $slice['sublabel'] ? ' ' . $slice['sublabel'] : '' ),
			'gift'   => ! empty( $prize['gift'] ) ? $prize['gift']['name'] : '',
			'code'   => $prize['code'],
			'expiry' => $expiry,
			'value'  => $value,
		);
		$result  = $spin['result'];
		if ( 'win' === $result ) {
			$title = Helpers::tpl( $m['win_title'], $vars );
			$text  = Helpers::tpl( '' !== trim( wp_strip_all_tags( $slice['message'] ) ) ? $slice['message'] : $m['win_text'], array_map( 'esc_html', $vars ) );
		} elseif ( 'respin' === $result ) {
			$title = $slice['label'];
			$text  = esc_html( $m['respin_text'] );
		} else {
			$title = Helpers::tpl( $m['lose_title'], $vars );
			$text  = Helpers::tpl( '' !== trim( wp_strip_all_tags( $slice['message'] ) ) ? $slice['message'] : $m['lose_text'], array_map( 'esc_html', $vars ) );
		}
		$title = trim( preg_replace( '/\s+([!؛،.,])/u', '$1', str_replace( array( '  ' ), ' ', $title ) ) );
		$apply = self::apply_url( $m, $slice['type'], $prize['code'] );
		$out = array(
			'spin_id'   => (int) $spin['id'],
			'index'     => (int) $index,
			'slice_id'  => $slice['id'],
			'result'    => $result,
			'type'      => $slice['type'],
			'label'     => $slice['label'],
			'title'     => $title,
			'text'      => wp_kses_post( $text ),
			'code'      => $prize['code'],
			'expiry'    => $expiry,
			'expires_ts' => $spin['expires_at'] ? strtotime( $spin['expires_at'] . ' UTC' ) : 0,
			'apply_url' => $apply,
			'link'      => $prize['link'],
			'gift'      => ! empty( $prize['gift'] ) ? \Becharkhoon\Prizes\Gifts::public_pick( $prize['gift'] ) : null,
			'link_text' => '' !== $slice['link_text'] ? $slice['link_text'] : Lang::t( 'دریافت', 'Get it' ),
			'claim'     => 'pending' === $spin['status'] ? self::claim_token( (int) $spin['id'] ) : '',
			'claim_fields' => $slice['claim_fields'],
			'redirect'  => 'win' === $result ? (string) $wheel['config']['advanced']['redirect_win'] : '',
			'state'     => self::public_state( $wheel, $after ),
		);
		return apply_filters( 'becharkhoon_spin_payload', $out, $spin, $wheel, $slice );
	}

	/** "Apply to cart" link for a WooCommerce coupon prize ('' when not applicable). */
	public static function apply_url( array $m, $type, $code ) {
		if ( '' === (string) $code || ! class_exists( 'WooCommerce' ) || ! in_array( $type, array( 'coupon_percent', 'coupon_fixed_cart', 'coupon_fixed_product', 'free_shipping', 'free_product', 'existing_coupon' ), true ) ) {
			return '';
		}
		$param = becharkhoon()->settings->get( 'auto_apply_param' );
		$to    = $m['apply_redirect'];
		return 'custom' === $to && '' !== $m['apply_url']
			? add_query_arg( array( $param => rawurlencode( $code ), 'bch_to' => 'stay' ), $m['apply_url'] )
			: add_query_arg( array( $param => rawurlencode( $code ), 'bch_to' => $to ), home_url( '/' ) );
	}

	public static function claim_token( $spin_id ) {
		return substr( hash_hmac( 'sha256', 'claim|' . (int) $spin_id, (string) get_option( 'bch_secret' ) ), 0, 32 );
	}

	/** Eligibility state for the browser (no internals). */
	public static function public_state( array $wheel, array $e ) {
		return array(
			'can'       => (bool) $e['ok'],
			'reason'    => (string) $e['reason'],
			'via'       => (string) $e['via'],
			'free_left' => $e['free_left'] >= 999 ? -1 : (int) $e['free_left'],
			'credits'   => (int) $e['credits'],
			'bonus'     => (int) $e['bonus'],
			'next_at'   => (int) $e['next_at'],
			'message'   => $e['ok'] ? '' : self::reason_message( $wheel, $e ),
		);
	}

	public static function msg( array $wheel, $key ) {
		return (string) ( $wheel['config']['messages'][ $key ] ?? '' );
	}

	public static function reason_message( array $wheel, array $e ) {
		switch ( $e['reason'] ) {
			case 'closed':
				return self::msg( $wheel, 'closed_text' );
			case 'login':
				return (string) $wheel['config']['form']['login_text'];
			case 'cooldown':
				return Helpers::tpl( self::msg( $wheel, 'cooldown_text' ), array( 'time' => $e['next_at'] ? Helpers::human_date( $e['next_at'], true ) : '' ) );
			case 'limit':
			case 'max_wins':
				return self::msg( $wheel, 'limit_text' );
			case 'no_credits':
				return self::msg( $wheel, 'no_spins_text' );
			case 'identify':
				return Lang::t( 'اگر شانس چرخاندن هدیه گرفته‌اید، شماره موبایل‌تان را تایید کنید تا شانس‌تان فعال شود.', 'If you received free spins, verify your mobile number to use them.' );
			case 'blocked':
			case 'not_eligible':
				return self::msg( $wheel, 'not_eligible_text' );
		}
		return self::msg( $wheel, 'error_text' );
	}
}

/** wc_format_coupon_code() when WooCommerce is present. */
function wc_format_coupon_code_safe( $code ) {
	$code = (string) $code;
	return function_exists( 'wc_format_coupon_code' ) ? wc_format_coupon_code( $code ) : strtolower( trim( $code ) );
}
