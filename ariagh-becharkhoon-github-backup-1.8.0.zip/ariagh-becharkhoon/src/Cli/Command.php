<?php
/**
 * WP-CLI: wp becharkhoon <stats|grant|wheels|cron>
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Cli;

use Becharkhoon\Core\Helpers;
use Becharkhoon\Credits\Ledger;
use Becharkhoon\Stats\Stats;

defined( 'ABSPATH' ) || exit;

final class Command {

	/**
	 * Show totals for the last N days.
	 *
	 * [--days=<days>]
	 *
	 * @param array $args Args.
	 * @param array $assoc Assoc.
	 */
	public function stats( $args, $assoc ) {
		$days = max( 1, (int) ( $assoc['days'] ?? 30 ) );
		$t    = Stats::totals( wp_date( 'Y-m-d', time() - ( $days - 1 ) * DAY_IN_SECONDS ), Helpers::today() );
		$rows = array();
		foreach ( $t as $k => $v ) {
			$rows[] = array( 'metric' => $k, 'value' => $v );
		}
		\WP_CLI\Utils\format_items( 'table', $rows, array( 'metric', 'value' ) );
	}

	/**
	 * List wheels.
	 */
	public function wheels() {
		$rows = array();
		foreach ( becharkhoon()->wheels->all() as $w ) {
			$rows[] = array( 'id' => $w['id'], 'title' => $w['title'], 'status' => $w['status'], 'mode' => $w['config']['access']['mode'], 'slices' => count( $w['config']['slices'] ) );
		}
		\WP_CLI\Utils\format_items( 'table', $rows, array( 'id', 'title', 'status', 'mode', 'slices' ) );
	}

	/**
	 * Grant spins.
	 *
	 * --qty=<n> [--wheel=<id>] [--user=<id>] [--phone=<mobile>] [--days=<expiry>] [--note=<text>]
	 *
	 * @param array $args Args.
	 * @param array $assoc Assoc.
	 */
	public function grant( $args, $assoc ) {
		$id = Ledger::grant(
			array(
				'wheel_id'     => (int) ( $assoc['wheel'] ?? 0 ),
				'user_id'      => (int) ( $assoc['user'] ?? 0 ),
				'phone'        => (string) ( $assoc['phone'] ?? '' ),
				'qty'          => (int) ( $assoc['qty'] ?? 1 ),
				'reason'       => 'manual',
				'note'         => (string) ( $assoc['note'] ?? 'WP-CLI' ),
				'expires_days' => (int) ( $assoc['days'] ?? 0 ),
			)
		);
		$id ? \WP_CLI::success( 'Credit #' . $id ) : \WP_CLI::error( 'Nothing granted (needs --user or --phone).' );
	}

	/**
	 * Run the daily maintenance now.
	 */
	public function cron() {
		( new \Becharkhoon\Core\Cron() )->run();
		\WP_CLI::success( 'Done' );
	}
}
