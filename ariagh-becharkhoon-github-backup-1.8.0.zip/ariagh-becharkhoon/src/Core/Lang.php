<?php
/**
 * Bilingual (Persian / English) strings without .mo files: every message is a pair.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Core;

defined( 'ABSPATH' ) || exit;

final class Lang {

	/** @var bool|null */
	private static $fa = null;

	public static function is_fa() {
		if ( null === self::$fa ) {
			$pref = function_exists( 'becharkhoon' ) && becharkhoon()->settings ? becharkhoon()->settings->get( 'ui_language' ) : 'auto';
			if ( 'fa' === $pref ) {
				self::$fa = true;
			} elseif ( 'en' === $pref ) {
				self::$fa = false;
			} else {
				$loc      = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();
				self::$fa = 0 === strpos( (string) $loc, 'fa' );
			}
		}
		return self::$fa;
	}

	/** Front-end requests follow the site language (or a wheel's forced language). */
	public static function use_site_locale( $force = '' ) {
		if ( 'fa' === $force || 'en' === $force ) {
			self::$fa = 'fa' === $force;
			return;
		}
		self::$fa = 0 === strpos( (string) get_locale(), 'fa' );
	}

	/** Reset the cached language (after settings change). */
	public static function reset() {
		self::$fa = null;
	}

	/**
	 * Translate: Persian first, English second. A filter lets translators override.
	 *
	 * @param string $fa Persian.
	 * @param string $en English.
	 */
	public static function t( $fa, $en ) {
		$s = self::is_fa() ? $fa : $en;
		return (string) apply_filters( 'becharkhoon_string', $s, $fa, $en );
	}
}
