<?php
/**
 * Plugin Name:       ARIAGH.BECHARKHOON – بچرخون
 * Plugin URI:        https://ariagh.ir/becharkhoon
 * Description:       گردونه شانس حرفه‌ای وردپرس و ووکامرس: ۳۶ تم، گردونه سفارشی، پاپ‌آپ‌ساز کامل، قوانین «چه کسی چند بار بچرخاند» (اولین سفارش، خرید بالای X و...)، کوپن خودکار، پیامک و OTP ایرانی، گزارش و ضدتقلب. Spin-to-win wheel & rewards engine.
 * Version:           1.8.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            ARIAGH
 * Author URI:        https://ariagh.ir
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       becharkhoon
 * Domain Path:       /languages
 * WC requires at least: 6.0
 * WC tested up to:   9.9
 *
 * @package Becharkhoon
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'BCH_VERSION' ) ) {
	return; // Another copy is already loaded.
}

define( 'BCH_VERSION', '1.8.0' );
define( 'BCH_DB_VERSION', 6 );
define( 'BCH_FILE', __FILE__ );
define( 'BCH_DIR', plugin_dir_path( __FILE__ ) );
define( 'BCH_URL', plugin_dir_url( __FILE__ ) );
define( 'BCH_BASENAME', plugin_basename( __FILE__ ) );

if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
	add_action(
		'admin_notices',
		static function () {
			echo '<div class="notice notice-error"><p>ARIAGH.BECHARKHOON: PHP 7.4+ required / نسخه PHP باید ۷.۴ یا بالاتر باشد.</p></div>';
		}
	);
	return;
}

require_once BCH_DIR . 'src/Autoloader.php';
\Becharkhoon\Autoloader::register();

register_activation_hook( __FILE__, array( '\Becharkhoon\Core\Installer', 'activate' ) );
register_deactivation_hook( __FILE__, array( '\Becharkhoon\Core\Installer', 'deactivate' ) );

// WooCommerce HPOS + cart/checkout blocks compatibility.
add_action(
	'before_woocommerce_init',
	static function () {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
		}
	}
);

add_action( 'plugins_loaded', array( '\Becharkhoon\Plugin', 'instance' ), 20 );

/**
 * Public helper: the plugin container.
 *
 * @return \Becharkhoon\Plugin
 */
function becharkhoon() {
	return \Becharkhoon\Plugin::instance();
}
