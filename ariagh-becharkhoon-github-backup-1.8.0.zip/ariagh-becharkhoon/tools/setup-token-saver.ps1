# ARIAGH - install token-saver tools and extract the project.
# Run: double-click setup-token-saver.bat in this folder.
$ErrorActionPreference = 'Continue'
$Root    = Split-Path -Parent $MyInvocation.MyCommand.Path
$Project = Join-Path $Root 'ariagh-becharkhoon'
$Zip     = Join-Path $Root 'ariagh-becharkhoon-source.zip'
$Log     = Join-Path $Root 'setup-token-saver.log'
Start-Transcript -Path $Log -Force | Out-Null

function Step($t) { Write-Host "`n=== $t ===" -ForegroundColor Cyan }

Step '1) Extract project'
if (Test-Path $Zip) {
  if (Test-Path $Project) { Write-Host "Already extracted: $Project" }
  else { Expand-Archive -Path $Zip -DestinationPath $Root -Force; Write-Host "Project: $Project" }
} else { Write-Host 'Zip not found, skipping.' -ForegroundColor Yellow }

Step '2) rtk'
if (Get-Command rtk -ErrorAction SilentlyContinue) { rtk --version }
elseif (Get-Command winget -ErrorAction SilentlyContinue) {
  winget install --id rtk-ai.rtk -e --accept-source-agreements --accept-package-agreements
} else { Write-Host 'winget not found: install rtk manually.' -ForegroundColor Yellow }

Step '3) Python (real install, not the Microsoft Store alias)'
function Find-Python {
  $c = @()
  foreach ($n in 'py','python','python3') { $g = Get-Command $n -ErrorAction SilentlyContinue; if ($g -and $g.Source -notlike '*WindowsApps*') { $c += $g.Source } }
  $c += Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe","C:\Program Files\Python3*\python.exe" -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | ForEach-Object FullName
  foreach ($x in $c) {
    try {
      $exe = if ($x -like '*\py.exe') { (& $x -3 -c "import sys;print(sys.executable)" 2>$null) } else { (& $x -c "import sys;print(sys.executable)" 2>$null) }
      if ($exe -and (Test-Path $exe) -and ($exe -notlike '*WindowsApps*')) { return $exe.Trim() }
    } catch {}
  }
  return $null
}
$PY = Find-Python
if (-not $PY -and (Get-Command winget -ErrorAction SilentlyContinue)) {
  winget install --id Python.Python.3.12 -e --scope user --accept-source-agreements --accept-package-agreements
  $PY = Find-Python
}
if (-not $PY) {
  Write-Host 'Python could not be installed automatically. Install it from https://www.python.org/downloads/ (tick "Add python.exe to PATH"), then run this file again.' -ForegroundColor Red
} else {
  & $PY --version
  New-Item -ItemType Directory -Force -Path 'C:\tools' | Out-Null

  $PIPNET = @('--timeout','180','--retries','10')

  Step '4) code-review-graph'
  $cv  = 'C:\tools\crg-venv'
  $crg = "$cv\Scripts\code-review-graph.exe"
  if (Test-Path $crg) { Write-Host 'Already installed.' }
  else {
    if (-not (Test-Path "$cv\Scripts\python.exe")) { & $PY -m venv $cv }
    & "$cv\Scripts\python.exe" -m pip install @PIPNET --upgrade code-review-graph
    if (Test-Path $crg) { & $crg install --platform claude-code } else { Write-Host 'code-review-graph install failed (see log).' -ForegroundColor Red }
  }
  if ((Test-Path $crg) -and (Test-Path $Project)) { Push-Location $Project; & $crg build; Pop-Location }

  Step '5) token-savior-recall (retries on slow network)'
  $venv = 'C:\tools\ts-venv'
  if (-not (Test-Path "$venv\Scripts\python.exe")) { & $PY -m venv $venv }
  for ($i = 1; $i -le 3 -and -not (Test-Path "$venv\Scripts\token-savior.exe"); $i++) {
    Write-Host "Attempt $i ..."
    & "$venv\Scripts\python.exe" -m pip install @PIPNET "token-savior-recall[mcp]"
  }
}

Step '6) Claude desktop config (backup kept)'
$ts  = 'C:\tools\ts-venv\Scripts\token-savior.exe'
$cfg = Join-Path $env:APPDATA 'Claude\claude_desktop_config.json'
New-Item -ItemType Directory -Force -Path (Split-Path $cfg) | Out-Null
if (Test-Path $cfg) { Copy-Item $cfg ($cfg + '.bak-' + (Get-Date -Format 'yyyyMMdd-HHmmss')); $j = Get-Content $cfg -Raw | ConvertFrom-Json } else { $j = [pscustomobject]@{} }
if (-not $j.PSObject.Properties['mcpServers']) { $j | Add-Member -NotePropertyName mcpServers -NotePropertyValue ([pscustomobject]@{}) }
if (Test-Path $ts) {
  $srv = [pscustomobject]@{ command = $ts; env = [pscustomobject]@{ WORKSPACE_ROOTS = $Project; TOKEN_SAVIOR_CLIENT = 'claude-code'; TOKEN_SAVIOR_PROFILE = 'optimized' } }
  $j.mcpServers | Add-Member -NotePropertyName 'token-savior-recall' -NotePropertyValue $srv -Force
  Write-Host 'token-savior registered.' -ForegroundColor Green
} elseif ($j.mcpServers.PSObject.Properties['token-savior-recall']) {
  $j.mcpServers.PSObject.Properties.Remove('token-savior-recall')
  Write-Host 'token-savior not installed: removed its (broken) entry.' -ForegroundColor Yellow
}
$crgPy = 'C:\tools\crg-venv\Scripts\python.exe'
if ((Test-Path $crgPy) -and (Test-Path $Project)) {
  $c2 = [pscustomobject]@{ command = $crgPy; args = @('-m','code_review_graph','serve'); cwd = $Project }
  $j.mcpServers | Add-Member -NotePropertyName 'code-review-graph' -NotePropertyValue $c2 -Force
  Write-Host 'code-review-graph registered.' -ForegroundColor Green
}
[IO.File]::WriteAllText($cfg, ($j | ConvertTo-Json -Depth 20), (New-Object System.Text.UTF8Encoding($false)))

Step 'Check'
if (Get-Command rtk -ErrorAction SilentlyContinue) { rtk --version } else { Write-Host 'rtk: not found' -ForegroundColor Yellow }
if (Test-Path 'C:\tools\crg-venv\Scripts\code-review-graph.exe') { & 'C:\tools\crg-venv\Scripts\code-review-graph.exe' --version } else { Write-Host 'code-review-graph: NOT installed' -ForegroundColor Red }
if (Test-Path 'C:\tools\ts-venv\Scripts\token-savior.exe') { Write-Host 'token-savior: OK' -ForegroundColor Green } else { Write-Host 'token-savior: NOT installed' -ForegroundColor Red }
Stop-Transcript | Out-Null
Write-Host "`nDone. Log: $Log - Now fully quit Claude desktop and open it again." -ForegroundColor Green
Read-Host 'Press Enter to close'
