<?php
// phpcs:ignoreFile
require __DIR__ . '/wp-stubs.php';
require dirname( __DIR__ ) . '/becharkhoon.php';
do_action( 'plugins_loaded' );
\Becharkhoon\Core\Installer::install();
$GLOBALS['__fails'] = 0; $GLOBALS['__passes'] = 0;
function ok( $cond, $name ) {
	if ( $cond ) { $GLOBALS['__passes']++; echo "  ✓ $name\n"; }
	else { $GLOBALS['__fails']++; echo "  ✗ FAIL: $name\n"; }
}
function done() { echo "\n{$GLOBALS['__passes']} passed, {$GLOBALS['__fails']} failed\n"; exit( $GLOBALS['__fails'] ? 1 : 0 ); }
