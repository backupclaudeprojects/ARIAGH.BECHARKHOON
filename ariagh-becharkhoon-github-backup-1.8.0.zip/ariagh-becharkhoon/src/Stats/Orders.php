<?php
/**
 * WooCommerce orders that used a wheel prize (coupon code or free gift line), mirrored into
 * `bch_orders` so reports show REAL money: order totals, the exact discount WooCommerce applied,
 * gift values, refunds and status (completed / processing / cancelled / refunded…).
 *
 *  - Live: every order status change, checkout, refund, admin edit, trash/delete re-syncs that order.
 *  - Past orders: a batched backfill scans WooCommerce coupon lines (HPOS and classic storage alike —
 *    `woocommerce_order_items` is shared), started automatically on plugin update and from Reports.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Stats;

use Becharkhoon\Core\Helpers;

defined( 'ABSPATH' ) || exit;

final class Orders {

	const OPTION = 'bch_orders_sync';
	const HOOK   = 'becharkhoon_orders_sync';

	/** @var array|null lower-case wheel code → true */
	private static $codes = null;

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'bch_orders';
	}

	public function register_hooks() {
		add_action( self::HOOK, array( __CLASS__, 'cron' ) );
		add_action( 'woocommerce_order_status_changed', array( $this, 'on_status' ), 40, 4 );
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'on_id' ), 40, 1 );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'on_order' ), 40, 1 );
		add_action( 'woocommerce_order_refunded', array( $this, 'on_id' ), 40, 1 );
		add_action( 'woocommerce_process_shop_order_meta', array( $this, 'on_id' ), 90, 1 );
		add_action( 'woocommerce_trash_order', array( __CLASS__, 'forget' ), 10, 1 );
		add_action( 'woocommerce_delete_order', array( __CLASS__, 'forget' ), 10, 1 );
		add_action( 'wp_trash_post', array( $this, 'on_post_gone' ), 10, 1 );
		add_action( 'before_delete_post', array( $this, 'on_post_gone' ), 10, 1 );
		add_action( 'untrashed_post', array( $this, 'on_id' ), 10, 1 );
	}

	public function on_status( $id, $from = '', $to = '', $order = null ) {
		self::sync( $order instanceof \WC_Order ? $order : (int) $id );
	}

	public function on_id( $id ) {
		self::sync( (int) $id );
	}

	public function on_order( $order ) {
		self::sync( $order );
	}

	public function on_post_gone( $post_id ) {
		if ( function_exists( 'get_post_type' ) && in_array( get_post_type( $post_id ), array( 'shop_order', 'shop_order_placehold' ), true ) ) {
			self::forget( $post_id );
		}
	}

	public static function forget( $order_id ) {
		global $wpdb;
		$wpdb->delete( self::table(), array( 'order_id' => (int) $order_id ) );
	}

	/** Every code the wheel ever handed out (lower-case). */
	public static function wheel_codes( $refresh = false ) {
		if ( null === self::$codes || $refresh ) {
			global $wpdb;
			self::$codes = array();
			foreach ( (array) $wpdb->get_col( "SELECT DISTINCT coupon_code FROM {$wpdb->prefix}bch_spins WHERE coupon_code <> ''" ) as $c ) {
				self::$codes[ strtolower( trim( (string) $c ) ) ] = true;
			}
		}
		return self::$codes;
	}

	private static function fmt( $code ) {
		return function_exists( 'wc_format_coupon_code' ) ? wc_format_coupon_code( $code ) : strtolower( trim( (string) $code ) );
	}

	private static function utc( $date ) {
		return $date && method_exists( $date, 'getTimestamp' ) ? gmdate( 'Y-m-d H:i:s', $date->getTimestamp() ) : null;
	}

	/**
	 * Mirror one order. Removes the row when the order no longer carries a wheel prize.
	 *
	 * @param \WC_Order|int $order Order.
	 * @return bool Whether the order is a wheel order.
	 */
	public static function sync( $order ) {
		if ( ! $order instanceof \WC_Order ) {
			$order = function_exists( 'wc_get_order' ) ? wc_get_order( (int) $order ) : null;
		}
		if ( ! $order || ! is_object( $order ) || ( method_exists( $order, 'get_type' ) && 'shop_order' !== $order->get_type() ) ) {
			return false;
		}
		global $wpdb;
		$id    = (int) $order->get_id();
		$known = self::wheel_codes();
		$codes = array();
		foreach ( (array) $order->get_coupon_codes() as $c ) {
			$c = self::fmt( $c );
			if ( isset( $known[ $c ] ) ) {
				$codes[ $c ] = true;
			}
		}
		// Free gift lines (random gift prize) count even when the coupon was later removed by hand.
		$gift_value = 0.0;
		foreach ( (array) $order->get_items( 'line_item' ) as $item ) {
			$g = method_exists( $item, 'get_meta' ) ? (string) $item->get_meta( '_bch_gift' ) : '';
			if ( '' === $g ) {
				continue;
			}
			$codes[ self::fmt( $g ) ] = true;
			$v = (float) $item->get_meta( '_bch_gift_value' );
			if ( $v <= 0 && method_exists( $item, 'get_product' ) && ( $p = $item->get_product() ) ) {
				$v = (float) $p->get_regular_price();
			}
			$gift_value += $v * max( 1, (int) $item->get_quantity() );
		}
		if ( ! $codes ) {
			self::forget( $id );
			return false;
		}
		$discount = 0.0;
		foreach ( (array) $order->get_items( 'coupon' ) as $ci ) {
			if ( isset( $codes[ self::fmt( $ci->get_code() ) ] ) ) {
				$discount += (float) $ci->get_discount() + (float) $ci->get_discount_tax();
			}
		}
		// The spin behind the code (prefer the one won by this customer).
		$list  = array_keys( $codes );
		$ph    = implode( ',', array_fill( 0, count( $list ), '%s' ) );
		$spins = (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, wheel_id, slice_label, prize_type, user_id, phone, email, created_at, coupon_code FROM {$wpdb->prefix}bch_spins WHERE coupon_code IN ($ph) AND result = 'win' ORDER BY id DESC", $list ), ARRAY_A ); // phpcs:ignore
		$email = strtolower( (string) $order->get_billing_email() );
		$phone = Helpers::phone( (string) $order->get_billing_phone() );
		$cust  = (int) $order->get_customer_id();
		$spin  = $spins ? $spins[0] : null;
		foreach ( $spins as $s ) {
			if ( ( $cust && (int) $s['user_id'] === $cust ) || ( '' !== $phone && $s['phone'] === $phone ) || ( '' !== $email && strtolower( $s['email'] ) === $email ) ) {
				$spin = $s;
				break;
			}
		}
		$name = trim( (string) $order->get_billing_first_name() . ' ' . ( method_exists( $order, 'get_billing_last_name' ) ? (string) $order->get_billing_last_name() : '' ) );
		$row  = array(
			'order_id'     => $id,
			'wheel_id'     => $spin ? (int) $spin['wheel_id'] : 0,
			'spin_id'      => $spin ? (int) $spin['id'] : 0,
			'codes'        => mb_substr( strtoupper( implode( ',', $list ) ), 0, 255 ),
			'prize'        => $spin ? mb_substr( (string) $spin['slice_label'], 0, 190 ) : '',
			'prize_type'   => $spin ? (string) $spin['prize_type'] : '',
			'status'       => (string) $order->get_status(),
			'created_at'   => self::utc( $order->get_date_created() ) ?? Helpers::now(),
			'paid_at'      => method_exists( $order, 'get_date_paid' ) ? self::utc( $order->get_date_paid() ) : null,
			'completed_at' => method_exists( $order, 'get_date_completed' ) ? self::utc( $order->get_date_completed() ) : null,
			'spin_at'      => $spin ? $spin['created_at'] : null,
			'total'        => (float) $order->get_total(),
			'subtotal'     => (float) $order->get_subtotal(),
			'discount'     => round( $discount, 4 ),
			'all_discount' => method_exists( $order, 'get_total_discount' ) ? (float) $order->get_total_discount( false ) : $discount,
			'gift_value'   => round( $gift_value, 4 ),
			'refunded'     => (float) $order->get_total_refunded(),
			'items'        => (int) $order->get_item_count(),
			'customer_id'  => $cust,
			'name'         => mb_substr( $name, 0, 190 ),
			'phone'        => $phone,
			'email'        => mb_substr( $email, 0, 190 ),
			'synced_at'    => Helpers::now(),
		);
		$wpdb->replace( self::table(), $row );
		return true;
	}

	/* ------------------------------------------------------------------ backfill of past orders */

	public static function state() {
		$s = get_option( self::OPTION, array() );
		$s = is_array( $s ) ? $s : array();
		global $wpdb;
		return array_merge(
			array( 'cursor' => 0, 'done' => false, 'scanned' => 0, 'found' => 0, 'started' => 0, 'finished' => 0, 'gifts' => false ),
			$s,
			array(
				'rows'      => (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::table() ), // phpcs:ignore
				'woo'       => self::woo_ready(),
				'total'     => self::woo_ready() ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}woocommerce_order_items WHERE order_item_type = 'coupon'" ) : 0,
			)
		);
	}

	public static function woo_ready() {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return false;
		}
		global $wpdb;
		$t = $wpdb->prefix . 'woocommerce_order_items';
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $t ) );
	}

	/** Start over (keeps existing rows; they are refreshed). */
	public static function restart( $schedule = true ) {
		update_option( self::OPTION, array( 'cursor' => 0, 'done' => false, 'scanned' => 0, 'found' => 0, 'started' => time(), 'finished' => 0, 'gifts' => false ), false );
		if ( $schedule && function_exists( 'wp_schedule_single_event' ) && ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_single_event( time() + 30, self::HOOK );
		}
	}

	/**
	 * One batch: scan the next coupon lines of all WooCommerce orders and mirror the wheel ones.
	 *
	 * @return array State after the batch.
	 */
	public static function backfill( $limit = 400 ) {
		$st = get_option( self::OPTION, array() );
		$st = array_merge( array( 'cursor' => 0, 'done' => false, 'scanned' => 0, 'found' => 0, 'started' => time(), 'finished' => 0, 'gifts' => false ), is_array( $st ) ? $st : array() );
		if ( ! self::woo_ready() ) {
			$st['done'] = true;
			update_option( self::OPTION, $st, false );
			return self::state();
		}
		global $wpdb;
		$codes = self::wheel_codes( 0 === (int) $st['cursor'] );
		$todo  = array();
		if ( empty( $st['gifts'] ) ) {
			foreach ( (array) $wpdb->get_col( "SELECT DISTINCT oi.order_id FROM {$wpdb->prefix}woocommerce_order_itemmeta m INNER JOIN {$wpdb->prefix}woocommerce_order_items oi ON oi.order_item_id = m.order_item_id WHERE m.meta_key = '_bch_gift'" ) as $oid ) {
				$todo[ (int) $oid ] = true;
			}
			$st['gifts'] = true;
		}
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT order_item_id, order_id, order_item_name FROM {$wpdb->prefix}woocommerce_order_items WHERE order_item_type = 'coupon' AND order_item_id > %d ORDER BY order_item_id ASC LIMIT %d", (int) $st['cursor'], max( 50, min( 2000, (int) $limit ) ) ), ARRAY_A );
		foreach ( $rows as $r ) {
			$st['cursor'] = (int) $r['order_item_id'];
			++$st['scanned'];
			if ( isset( $codes[ self::fmt( $r['order_item_name'] ) ] ) ) {
				$todo[ (int) $r['order_id'] ] = true;
			}
		}
		foreach ( array_keys( $todo ) as $oid ) {
			if ( self::sync( $oid ) ) {
				++$st['found'];
			}
		}
		if ( count( $rows ) < max( 50, min( 2000, (int) $limit ) ) ) {
			$st['done']     = true;
			$st['finished'] = time();
		}
		update_option( self::OPTION, $st, false );
		return self::state();
	}

	/** WP-Cron: run batches for ~20 s, continue a minute later until done. */
	public static function cron() {
		$t = microtime( true );
		do {
			$s = self::backfill( 500 );
		} while ( ! $s['done'] && microtime( true ) - $t < 20 );
		if ( ! $s['done'] && function_exists( 'wp_schedule_single_event' ) ) {
			wp_schedule_single_event( time() + 60, self::HOOK );
		}
	}

	/* ------------------------------------------------------------------ report queries */

	/**
	 * @param string $from_utc  UTC from (Y-m-d H:i:s).
	 * @param string $to_utc    UTC to.
	 * @param array  $statuses  Order statuses counted as sales (without wc-).
	 * @param string $basis     created|paid|completed — which date decides the period.
	 * @param int    $wheel_id  0 = all.
	 */
	public static function where( $from_utc, $to_utc, array $statuses, $basis, $wheel_id, &$params ) {
		$col    = array( 'paid' => 'COALESCE(paid_at, created_at)', 'completed' => 'COALESCE(completed_at, paid_at, created_at)' )[ $basis ] ?? 'created_at';
		$w      = "$col BETWEEN %s AND %s";
		$params = array( $from_utc, $to_utc );
		if ( $statuses ) {
			$w     .= ' AND status IN (' . implode( ',', array_fill( 0, count( $statuses ), '%s' ) ) . ')';
			$params = array_merge( $params, array_values( $statuses ) );
		}
		if ( $wheel_id ) {
			$w       .= ' AND wheel_id = %d';
			$params[] = (int) $wheel_id;
		}
		return array( $w, $col );
	}

	public static function totals( $from_utc, $to_utc, array $statuses, $basis = 'created', $wheel_id = 0 ) {
		global $wpdb;
		list( $w ) = self::where( $from_utc, $to_utc, $statuses, $basis, $wheel_id, $params );
		$r = (array) $wpdb->get_row( $wpdb->prepare( 'SELECT COUNT(*) AS orders, COALESCE(SUM(total),0) AS total, COALESCE(SUM(subtotal),0) AS subtotal, COALESCE(SUM(discount),0) AS discount, COALESCE(SUM(all_discount),0) AS all_discount, COALESCE(SUM(gift_value),0) AS gift_value, COALESCE(SUM(refunded),0) AS refunded, COALESCE(SUM(items),0) AS items, COUNT(DISTINCT CASE WHEN customer_id > 0 THEN customer_id END) AS members, COUNT(DISTINCT CASE WHEN customer_id = 0 THEN email END) AS guests FROM ' . self::table() . " WHERE $w", $params ), ARRAY_A ); // phpcs:ignore
		$out = array_map( 'floatval', $r );
		$out['orders']      = (int) $out['orders'];
		$out['customers']   = (int) ( $out['members'] + $out['guests'] );
		$out['net']         = $out['total'] - $out['refunded'];
		$out['avg_order']   = $out['orders'] ? round( $out['total'] / $out['orders'], 2 ) : 0;
		$out['avg_discount'] = $out['orders'] ? round( $out['discount'] / $out['orders'], 2 ) : 0;
		$gross              = $out['total'] + $out['discount'] + $out['gift_value'];
		$out['discount_pct'] = $gross > 0 ? round( ( $out['discount'] + $out['gift_value'] ) / $gross * 100, 1 ) : 0;
		$out['per_toman']    = ( $out['discount'] + $out['gift_value'] ) > 0 ? round( $out['net'] / ( $out['discount'] + $out['gift_value'] ), 1 ) : 0;
		return $out;
	}

	/** Every status in the period (to see cancelled / pending / refunded wheel orders). */
	public static function by_status( $from_utc, $to_utc, $basis = 'created', $wheel_id = 0 ) {
		global $wpdb;
		list( $w ) = self::where( $from_utc, $to_utc, array(), $basis, $wheel_id, $params );
		return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT status, COUNT(*) AS orders, COALESCE(SUM(total),0) AS total, COALESCE(SUM(discount),0) AS discount FROM ' . self::table() . " WHERE $w GROUP BY status ORDER BY orders DESC", $params ), ARRAY_A ); // phpcs:ignore
	}

	/** Rows of the period (for series, time-to-use, hours). */
	public static function rows( $from_utc, $to_utc, array $statuses, $basis = 'created', $wheel_id = 0, $limit = 50000 ) {
		global $wpdb;
		list( $w, $col ) = self::where( $from_utc, $to_utc, $statuses, $basis, $wheel_id, $params );
		$params[]        = (int) $limit;
		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT order_id, $col AS d, spin_at, total, discount, gift_value, refunded FROM " . self::table() . " WHERE $w ORDER BY d ASC LIMIT %d", $params ), ARRAY_A ); // phpcs:ignore
	}

	public static function group( $field, $from_utc, $to_utc, array $statuses, $basis = 'created', $wheel_id = 0, $limit = 50 ) {
		global $wpdb;
		$allowed = array( 'prize' => 'prize, prize_type', 'wheel' => 'wheel_id', 'customer' => 'phone, email, customer_id' );
		$g       = $allowed[ $field ] ?? 'prize, prize_type';
		list( $w ) = self::where( $from_utc, $to_utc, $statuses, $basis, $wheel_id, $params );
		$params[]  = (int) $limit;
		$extra     = 'customer' === $field ? ', MAX(name) AS name' : '';
		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT $g$extra, COUNT(*) AS orders, COALESCE(SUM(total),0) AS total, COALESCE(SUM(discount),0) AS discount, COALESCE(SUM(gift_value),0) AS gift_value, COALESCE(SUM(refunded),0) AS refunded FROM " . self::table() . " WHERE $w GROUP BY $g ORDER BY total DESC LIMIT %d", $params ), ARRAY_A ); // phpcs:ignore
	}

	/** Paged order list. */
	public static function query( $from_utc, $to_utc, array $statuses, $basis = 'created', $wheel_id = 0, $search = '', $page = 1, $per = 25 ) {
		global $wpdb;
		list( $w, $col ) = self::where( $from_utc, $to_utc, $statuses, $basis, $wheel_id, $params );
		if ( '' !== $search ) {
			$s       = '%' . $wpdb->esc_like( Helpers::latin_digits( $search ) ) . '%';
			$w      .= ' AND (codes LIKE %s OR phone LIKE %s OR email LIKE %s OR name LIKE %s OR order_id = %d)';
			$params  = array_merge( $params, array( $s, $s, $s, $s, (int) Helpers::latin_digits( $search ) ) );
		}
		$total  = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::table() . " WHERE $w", $params ) ); // phpcs:ignore
		$per    = max( 1, min( 5000, (int) $per ) );
		$q      = array_merge( $params, array( $per, ( max( 1, (int) $page ) - 1 ) * $per ) );
		$items  = (array) $wpdb->get_results( $wpdb->prepare( "SELECT *, $col AS d FROM " . self::table() . " WHERE $w ORDER BY d DESC LIMIT %d OFFSET %d", $q ), ARRAY_A ); // phpcs:ignore
		foreach ( $items as $k => $it ) {
			$items[ $k ]['edit_url'] = self::edit_url( (int) $it['order_id'] );
		}
		return array( 'items' => $items, 'total' => $total );
	}

	/** Order edit screen (HPOS or classic). */
	public static function edit_url( $id ) {
		$hpos = class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
		return $hpos ? admin_url( 'admin.php?page=wc-orders&action=edit&id=' . (int) $id ) : admin_url( 'post.php?post=' . (int) $id . '&action=edit' );
	}
}
