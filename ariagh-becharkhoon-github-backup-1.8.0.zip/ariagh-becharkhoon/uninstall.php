<?php
/**
 * Uninstall: removes data only when "Delete all data on uninstall" is enabled.
 *
 * @package Becharkhoon
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$bch_settings = get_option( 'bch_settings', array() );
if ( empty( $bch_settings['delete_on_uninstall'] ) ) {
	return;
}

define( 'BCH_DIR', plugin_dir_path( __FILE__ ) );
require_once BCH_DIR . 'src/Autoloader.php';
\Becharkhoon\Autoloader::register();

if ( ! function_exists( 'becharkhoon' ) ) {
	/** Minimal container for uninstall. */
	function becharkhoon() {
		return null;
	}
}

wp_clear_scheduled_hook( 'becharkhoon_daily' );
\Becharkhoon\Core\Installer::drop_all();
