<?php
/**
 * Cross-request mutex. Uses an atomic INSERT IGNORE on the options table so it
 * works on every MySQL/MariaDB host without GET_LOCK privileges or an object cache.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Core;

defined( 'ABSPATH' ) || exit;

final class Lock {

	/** @var string[] Locks held by this request (released on shutdown as a safety net). */
	private static $held = array();

	private static function name( $key ) {
		return 'bch_lock_' . md5( (string) $key );
	}

	/**
	 * Try to acquire a lock, waiting up to $wait seconds.
	 *
	 * @param string $key  Lock key.
	 * @param int    $ttl  Seconds before a stale lock may be stolen.
	 * @param float  $wait Seconds to wait.
	 */
	public static function acquire( $key, $ttl = 15, $wait = 3.0 ) {
		global $wpdb;
		$name     = self::name( $key );
		$deadline = microtime( true ) + $wait;
		do {
			$inserted = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')", $name, (string) ( time() + $ttl ) ) );
			if ( $inserted ) {
				if ( empty( self::$held ) ) {
					register_shutdown_function( array( __CLASS__, 'release_all' ) );
				}
				self::$held[ $name ] = true;
				return true;
			}
			// Steal stale locks (a crashed request).
			$expires = (int) $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $name ) );
			if ( $expires && $expires < time() ) {
				$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s", $name, (string) $expires ) );
				continue;
			}
			usleep( 150000 );
		} while ( microtime( true ) < $deadline );
		return false;
	}

	public static function release( $key ) {
		global $wpdb;
		$name = self::name( $key );
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s", $name ) );
		unset( self::$held[ $name ] );
	}

	public static function release_all() {
		global $wpdb;
		foreach ( array_keys( self::$held ) as $name ) {
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s", $name ) );
		}
		self::$held = array();
	}
}
