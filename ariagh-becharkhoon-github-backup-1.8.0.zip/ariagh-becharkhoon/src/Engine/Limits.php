<?php
/**
 * Spin/win counting per identity (account, phone, email, device, IP) and time window.
 *
 * Spin kinds stored in bch_spins.is_free: 1 = free allowance, 0 = paid with a credit, 2 = bonus (re-spin).
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Engine;

defined( 'ABSPATH' ) || exit;

final class Limits {

	/**
	 * Identity values used for counting, according to the wheel's access settings.
	 *
	 * @param Context $ctx    Context.
	 * @param array   $access Wheel access config (null = every key).
	 * @return array<string,string|int> column => value
	 */
	public static function identity( Context $ctx, $access = null ) {
		$use = static function ( $k ) use ( $access ) {
			return null === $access || ! empty( $access[ 'limit_' . $k ] );
		};
		$ids = array();
		if ( $ctx->user_id && $use( 'user' ) ) {
			$ids['user_id'] = (int) $ctx->user_id;
		}
		if ( '' !== $ctx->phone && $use( 'phone' ) ) {
			$ids['phone'] = $ctx->phone;
		}
		if ( '' !== $ctx->email && $use( 'email' ) ) {
			$ids['email'] = $ctx->email;
		}
		if ( '' !== $ctx->device_id && $use( 'device' ) ) {
			$ids['device'] = $ctx->device_id;
		}
		if ( $use( 'ip' ) && '' !== $ctx->ip ) {
			$ids['ip'] = $ctx->ip;
		}
		if ( ! $ids ) {
			// Never count "nobody": fall back to the device, then the IP.
			if ( '' !== $ctx->device_id ) {
				$ids['device'] = $ctx->device_id;
			} else {
				$ids['ip'] = $ctx->ip;
			}
		}
		return $ids;
	}

	/** Primary key for per-visitor transients (bonus spins, OTP sessions). */
	public static function primary_key( Context $ctx ) {
		if ( $ctx->user_id ) {
			return 'u' . $ctx->user_id;
		}
		if ( '' !== $ctx->phone && $ctx->phone_verified ) {
			return 'p' . $ctx->phone;
		}
		if ( '' !== $ctx->device_id ) {
			return 'd' . $ctx->device_id;
		}
		return 'i' . $ctx->ip;
	}

	/**
	 * Build "(user_id = %d OR phone = %s ...)" with params.
	 *
	 * @return array{0:string,1:array}
	 */
	private static function where_identity( array $ids ) {
		$parts  = array();
		$params = array();
		foreach ( $ids as $col => $val ) {
			$parts[]  = 'user_id' === $col ? 'user_id = %d' : $col . ' = %s';
			$params[] = $val;
		}
		return array( '(' . implode( ' OR ', $parts ) . ')', $params );
	}

	/**
	 * Count spins of a wheel for an identity since a datetime.
	 *
	 * @param int    $wheel_id Wheel.
	 * @param array  $ids      Identity.
	 * @param string $since    UTC datetime.
	 * @param array  $kinds    is_free values to include (null = all).
	 * @param bool   $wins     Only wins.
	 * @param string $slice_id Only this slice.
	 */
	public static function count( $wheel_id, array $ids, $since = '1970-01-01 00:00:00', $kinds = null, $wins = false, $slice_id = '' ) {
		global $wpdb;
		list( $w, $params ) = self::where_identity( $ids );
		$sql = "SELECT COUNT(*) FROM {$wpdb->prefix}bch_spins WHERE wheel_id = %d AND created_at >= %s AND $w";
		array_unshift( $params, (int) $wheel_id, $since );
		if ( is_array( $kinds ) && $kinds ) {
			$sql .= ' AND is_free IN (' . implode( ',', array_map( 'intval', $kinds ) ) . ')';
		}
		if ( $wins ) {
			$sql .= " AND result = 'win'";
		}
		if ( '' !== $slice_id ) {
			$sql     .= ' AND slice_id = %s';
			$params[] = $slice_id;
		}
		return (int) $wpdb->get_var( $wpdb->prepare( $sql, $params ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
	}

	/** Last spin time (unix) for an identity on a wheel, 0 when none. */
	public static function last_spin( $wheel_id, array $ids ) {
		global $wpdb;
		list( $w, $params ) = self::where_identity( $ids );
		array_unshift( $params, (int) $wheel_id );
		$t = $wpdb->get_var( $wpdb->prepare( "SELECT MAX(created_at) FROM {$wpdb->prefix}bch_spins WHERE wheel_id = %d AND is_free <> 2 AND $w", $params ) ); // phpcs:ignore
		return $t ? strtotime( $t . ' UTC' ) : 0;
	}

	/** Results of the last N counted spins (newest first). */
	public static function last_results( $wheel_id, array $ids, $n ) {
		global $wpdb;
		list( $w, $params ) = self::where_identity( $ids );
		array_unshift( $params, (int) $wheel_id );
		$params[] = (int) $n;
		return (array) $wpdb->get_col( $wpdb->prepare( "SELECT result FROM {$wpdb->prefix}bch_spins WHERE wheel_id = %d AND $w ORDER BY id DESC LIMIT %d", $params ) ); // phpcs:ignore
	}

	/** Wins of a slice today (site timezone) across everyone. */
	public static function slice_wins_today( $wheel_id, $slice_id ) {
		global $wpdb;
		$since = \Becharkhoon\Core\Helpers::period_start( 'day' );
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}bch_spins WHERE wheel_id = %d AND slice_id = %s AND result = 'win' AND created_at >= %s", $wheel_id, $slice_id, $since ) );
	}

	/** Wins on a wheel since a datetime across everyone. */
	public static function wheel_wins_since( $wheel_id, $since ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}bch_spins WHERE wheel_id = %d AND result = 'win' AND created_at >= %s", $wheel_id, $since ) );
	}

	/** Spins from an IP today on any wheel (global anti-abuse). */
	public static function ip_spins_today( $ip ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}bch_spins WHERE ip = %s AND created_at >= %s", $ip, \Becharkhoon\Core\Helpers::period_start( 'day' ) ) );
	}

	/** Used by the wheel_spins / wheel_wins conditions. */
	public static function count_for_context( Context $ctx, $what ) {
		if ( ! $ctx->wheel_id ) {
			return 0;
		}
		return self::count( $ctx->wheel_id, self::identity( $ctx ), '1970-01-01 00:00:00', null, 'wins' === $what );
	}
}
