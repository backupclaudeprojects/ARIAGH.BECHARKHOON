<?php
/**
 * "Free gift product" prizes: a random gift from a list (site products + manual products),
 * added to the cart as a free line marked «هدیه گردونه شانس» when the winner applies the code.
 *
 * Flow:
 *  1. Spin → Gifts::pick() draws one in-stock item at random; the coupon (amount 0, just a key)
 *     carries the pick in `_bch_gift`.
 *  2. Code applied (cart form, ?bch_apply link, popup auto-apply) → the gift line is added.
 *  3. Every totals calculation: gift lines are free (price 0, qty 1) while their code is applied;
 *     if the code is removed the line is removed too (no free product without the code).
 *  4. Checkout → the order line keeps «هدیه گردونه شانس» + the code (+ name/image/price for manual items).
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Prizes;

use Becharkhoon\Core\Helpers;
use Becharkhoon\Core\Lang;

defined( 'ABSPATH' ) || exit;

final class Gifts {

	const MAX_ITEMS = 40;

	public function register_hooks() {
		add_action( 'woocommerce_applied_coupon', array( $this, 'on_applied' ), 10, 1 );
		add_action( 'woocommerce_removed_coupon', array( $this, 'on_removed' ), 10, 1 );
		add_action( 'woocommerce_before_calculate_totals', array( $this, 'prices' ), 50, 1 );
		add_filter( 'woocommerce_get_item_data', array( $this, 'item_data' ), 20, 2 );
		add_filter( 'woocommerce_cart_item_thumbnail', array( $this, 'thumbnail' ), 20, 2 );
		add_filter( 'woocommerce_cart_item_quantity', array( $this, 'quantity' ), 20, 3 );
		add_filter( 'woocommerce_cart_item_price', array( $this, 'price_html' ), 20, 2 );
		add_filter( 'woocommerce_cart_item_subtotal', array( $this, 'price_html' ), 20, 2 );
		add_action( 'woocommerce_checkout_create_order_line_item', array( $this, 'order_item' ), 20, 3 );
		add_filter( 'woocommerce_order_item_thumbnail', array( $this, 'order_thumbnail' ), 20, 2 );
		add_filter( 'woocommerce_cart_totals_coupon_html', array( $this, 'coupon_html' ), 20, 3 );
	}

	/** The gift code row in cart totals: "🎁 lucky wheel gift" instead of "-0". */
	public function coupon_html( $html, $coupon, $discount_html = '' ) {
		if ( ! $coupon instanceof \WC_Coupon || ! $coupon->get_meta( '_bch_gift' ) ) {
			return $html;
		}
		$remove = '<a href="' . esc_url( add_query_arg( 'remove_coupon', rawurlencode( $coupon->get_code() ), function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '' ) ) . '" class="woocommerce-remove-coupon" data-coupon="' . esc_attr( $coupon->get_code() ) . '">' . esc_html__( '[Remove]', 'woocommerce' ) . '</a>';
		return esc_html( self::note() ) . ' ' . $remove;
	}

	/* ------------------------------------------------------------------ pool & pick */

	/** Clean manual gift items from the editor. */
	public static function sanitize_items( $raw ) {
		$out = array();
		foreach ( array_slice( (array) $raw, 0, self::MAX_ITEMS ) as $it ) {
			if ( ! is_array( $it ) ) {
				continue;
			}
			$name = mb_substr( sanitize_text_field( (string) ( $it['name'] ?? '' ) ), 0, 120 );
			if ( '' === $name ) {
				continue;
			}
			$key = preg_replace( '/[^a-z0-9]/', '', strtolower( (string) ( $it['key'] ?? '' ) ) );
			$out[] = array(
				'key'    => '' !== $key ? substr( $key, 0, 16 ) : substr( md5( $name . count( $out ) ), 0, 10 ),
				'name'   => $name,
				'image'  => esc_url_raw( (string) ( $it['image'] ?? '' ) ),
				'price'  => max( 0.0, (float) Helpers::latin_digits( (string) ( $it['price'] ?? 0 ) ) ),
				'weight' => max( 0.0, min( 1000.0, (float) ( $it['weight'] ?? 1 ) ) ),
			);
		}
		return $out;
	}

	/**
	 * Everything that can be drawn for this slice (in-stock site products + manual products).
	 *
	 * @return array<int,array{kind:string,id:int,key:string,name:string,image:string,price:float,weight:float}>
	 */
	public static function pool( array $slice ) {
		$items = array();
		if ( function_exists( 'wc_get_product' ) ) {
			foreach ( (array) ( $slice['product_ids'] ?? array() ) as $pid ) {
				$p = wc_get_product( (int) $pid );
				if ( ! $p || ! $p->is_purchasable() || ! $p->is_in_stock() || $p->is_type( array( 'variable', 'grouped', 'external' ) ) ) {
					continue;
				}
				$img     = wp_get_attachment_image_url( $p->get_image_id(), 'woocommerce_thumbnail' );
				$items[] = array(
					'kind'   => 'product',
					'id'     => (int) $p->get_id(),
					'key'    => 'p' . (int) $p->get_id(),
					'name'   => $p->get_name(),
					'image'  => $img ? $img : '',
					'price'  => (float) $p->get_price(),
					'weight' => 1.0,
				);
			}
		}
		foreach ( self::sanitize_items( $slice['gift_items'] ?? array() ) as $it ) {
			$items[] = array(
				'kind'   => 'custom',
				'id'     => 0,
				'key'    => 'c' . $it['key'],
				'name'   => $it['name'],
				'image'  => $it['image'],
				'price'  => (float) $it['price'],
				'weight' => (float) $it['weight'],
			);
		}
		return apply_filters( 'becharkhoon_gift_pool', $items, $slice );
	}

	/** Random (weighted, crypto-safe) gift from the pool; null when nothing is available. */
	public static function pick( array $slice ) {
		$pool = array_values( array_filter( self::pool( $slice ), static function ( $i ) { return $i['weight'] > 0; } ) );
		if ( ! $pool ) {
			return null;
		}
		$scale = 1000;
		$total = 0;
		foreach ( $pool as $i ) {
			$total += (int) round( $i['weight'] * $scale );
		}
		$r = random_int( 1, max( 1, $total ) );
		foreach ( $pool as $i ) {
			$r -= (int) round( $i['weight'] * $scale );
			if ( $r <= 0 ) {
				return $i;
			}
		}
		return $pool[ count( $pool ) - 1 ];
	}

	/** Public, display-safe description of a pick (popup, SMS, emails). */
	public static function public_pick( array $g ) {
		return array(
			'kind'  => $g['kind'],
			'name'  => $g['name'],
			'image' => $g['image'],
			'price' => $g['price'] > 0 ? Helpers::money( $g['price'] ) : '',
		);
	}

	/* ------------------------------------------------------------------ cart */

	public static function note() {
		return (string) apply_filters( 'becharkhoon_gift_note', Lang::t( '🎁 هدیه گردونه شانس', '🎁 Lucky wheel gift' ) );
	}

	/** Gift stored on a coupon (new format) or legacy `_bch_gift_products`. */
	public static function for_code( $code ) {
		if ( ! function_exists( 'wc_get_coupon_id_by_code' ) || '' === (string) $code ) {
			return null;
		}
		$id = wc_get_coupon_id_by_code( $code );
		if ( ! $id ) {
			return null;
		}
		$g = get_post_meta( $id, '_bch_gift', true );
		if ( is_array( $g ) && ! empty( $g['kind'] ) ) {
			return $g;
		}
		$legacy = array_filter( array_map( 'absint', (array) get_post_meta( $id, '_bch_gift_products', true ) ) );
		if ( $legacy ) {
			return array( 'kind' => 'product', 'id' => (int) reset( $legacy ), 'legacy' => true );
		}
		return null;
	}

	/** Hidden 0-price product used as the cart vehicle for manual gifts. */
	public static function vehicle_id() {
		$id = (int) get_option( 'bch_gift_vehicle' );
		if ( $id && function_exists( 'wc_get_product' ) && wc_get_product( $id ) && 'trash' !== get_post_status( $id ) ) {
			return $id;
		}
		if ( ! class_exists( '\WC_Product_Simple' ) ) {
			return 0;
		}
		$p = new \WC_Product_Simple();
		$p->set_name( Lang::t( 'هدیه گردونه شانس', 'Lucky wheel gift' ) );
		$p->set_status( 'publish' );
		$p->set_catalog_visibility( 'hidden' );
		$p->set_regular_price( '0' );
		$p->set_price( '0' );
		$p->set_sold_individually( false );
		$p->set_reviews_allowed( false );
		$p->update_meta_data( '_bch_gift_vehicle', 1 );
		$id = (int) $p->save();
		update_option( 'bch_gift_vehicle', $id, false );
		return $id;
	}

	private static function cart() {
		return function_exists( 'WC' ) && WC() && WC()->cart ? WC()->cart : null;
	}

	private static function applied( $cart, $code ) {
		$code = wc_format_coupon_code( $code );
		return in_array( $code, array_map( 'wc_format_coupon_code', (array) $cart->get_applied_coupons() ), true );
	}

	/** Add the gift line for a code (once). Returns true when the line is in the cart. */
	public static function add_line( $code ) {
		$cart = self::cart();
		$g    = self::for_code( $code );
		if ( ! $cart || ! $g ) {
			return false;
		}
		$code = wc_format_coupon_code( $code );
		foreach ( $cart->get_cart() as $item ) {
			if ( isset( $item['bch_gift'] ) && $item['bch_gift'] === $code ) {
				return true;
			}
		}
		$data = array( 'bch_gift' => $code );
		if ( 'custom' === $g['kind'] ) {
			$pid = self::vehicle_id();
			if ( ! $pid ) {
				return false;
			}
			$data['bch_gift_item'] = array( 'name' => (string) $g['name'], 'image' => (string) ( $g['image'] ?? '' ), 'price' => (float) ( $g['price'] ?? 0 ) );
			$key = $cart->add_to_cart( $pid, 1, 0, array(), $data );
			return (bool) $key;
		}
		$p = wc_get_product( (int) $g['id'] );
		if ( ! $p || ! $p->is_purchasable() || ! $p->is_in_stock() ) {
			if ( function_exists( 'wc_add_notice' ) ) {
				wc_add_notice( Lang::t( 'متأسفانه محصول هدیه شما فعلاً موجود نیست؛ با پشتیبانی تماس بگیرید.', 'Sorry, your gift product is out of stock right now; please contact support.' ), 'error' );
			}
			return false;
		}
		$parent = $p->is_type( 'variation' ) ? $p->get_parent_id() : $p->get_id();
		$var    = $p->is_type( 'variation' ) ? $p->get_id() : 0;
		$attrs  = $p->is_type( 'variation' ) ? $p->get_variation_attributes() : array();
		return (bool) $cart->add_to_cart( $parent, 1, $var, $attrs, $data );
	}

	public function on_applied( $code ) {
		if ( self::for_code( $code ) ) {
			self::add_line( $code );
		}
	}

	public function on_removed( $code ) {
		$cart = self::cart();
		if ( ! $cart ) {
			return;
		}
		$code = wc_format_coupon_code( $code );
		foreach ( $cart->get_cart() as $key => $item ) {
			if ( isset( $item['bch_gift'] ) && $item['bch_gift'] === $code ) {
				$cart->remove_cart_item( $key );
			}
		}
	}

	/** Free while the code is applied; removed when it is not. */
	public function prices( $cart ) {
		if ( ! $cart || ( is_admin() && ! wp_doing_ajax() ) ) {
			return;
		}
		foreach ( $cart->get_cart() as $key => $item ) {
			if ( empty( $item['bch_gift'] ) ) {
				continue;
			}
			if ( ! self::applied( $cart, $item['bch_gift'] ) ) {
				unset( $cart->cart_contents[ $key ] );
				continue;
			}
			if ( (int) $item['quantity'] !== 1 ) {
				$cart->cart_contents[ $key ]['quantity'] = 1;
			}
			$item['data']->set_price( 0 );
			if ( ! empty( $item['bch_gift_item']['name'] ) ) {
				$item['data']->set_name( $item['bch_gift_item']['name'] );
			}
		}
	}

	public function item_data( $data, $item ) {
		if ( ! empty( $item['bch_gift'] ) ) {
			$data[] = array( 'key' => Lang::t( 'هدیه', 'Gift' ), 'value' => self::note(), 'display' => esc_html( self::note() ) );
		}
		return $data;
	}

	public function thumbnail( $html, $item ) {
		if ( ! empty( $item['bch_gift_item']['image'] ) ) {
			return '<img src="' . esc_url( $item['bch_gift_item']['image'] ) . '" alt="' . esc_attr( $item['bch_gift_item']['name'] ) . '" class="attachment-woocommerce_thumbnail" width="64" height="64" />';
		}
		return $html;
	}

	public function quantity( $html, $key, $item = null ) {
		if ( null === $item && ( $c = self::cart() ) ) {
			$item = $c->get_cart_item( $key );
		}
		return ! empty( $item['bch_gift'] ) ? '1' : $html;
	}

	public function price_html( $html, $item ) {
		if ( empty( $item['bch_gift'] ) ) {
			return $html;
		}
		$orig = 0.0;
		if ( ! empty( $item['bch_gift_item'] ) ) {
			$orig = (float) $item['bch_gift_item']['price'];
		} elseif ( isset( $item['data'] ) && ( $fresh = wc_get_product( $item['data']->get_id() ) ) ) {
			$orig = (float) $fresh->get_price();
		}
		$free = '<span class="bch-gift-free">' . esc_html( Lang::t( 'رایگان', 'Free' ) ) . '</span>';
		return $orig > 0 ? '<del>' . wc_price( $orig ) . '</del> ' . $free : $free;
	}

	/** Order line: keep the gift marker, code and manual product details. */
	public function order_item( $line, $cart_key, $values ) {
		if ( empty( $values['bch_gift'] ) ) {
			return;
		}
		$line->add_meta_data( Lang::t( 'هدیه', 'Gift' ), self::note(), true );
		$line->add_meta_data( Lang::t( 'کد گردونه', 'Wheel code' ), strtoupper( (string) $values['bch_gift'] ), true );
		$line->add_meta_data( '_bch_gift', (string) $values['bch_gift'], true );
		// Value of the free gift (reports: "value of gifts given").
		$gv = ! empty( $values['bch_gift_item'] ) ? (float) $values['bch_gift_item']['price'] : 0.0;
		if ( $gv <= 0 && isset( $values['data'] ) && is_object( $values['data'] ) && function_exists( 'wc_get_product' ) ) {
			$fresh = wc_get_product( $values['data']->get_id() );
			$gv    = $fresh ? (float) $fresh->get_regular_price() : 0.0;
		}
		$line->add_meta_data( '_bch_gift_value', $gv, true );
		if ( ! empty( $values['bch_gift_item'] ) ) {
			$gi = $values['bch_gift_item'];
			$line->set_name( (string) $gi['name'] );
			if ( (float) $gi['price'] > 0 ) {
				$line->add_meta_data( Lang::t( 'ارزش', 'Value' ), wp_strip_all_tags( wc_price( (float) $gi['price'] ) ), true );
			}
			if ( ! empty( $gi['image'] ) ) {
				$line->add_meta_data( '_bch_gift_image', esc_url_raw( $gi['image'] ), true );
			}
		}
	}

	public function order_thumbnail( $html, $item ) {
		$img = is_object( $item ) && method_exists( $item, 'get_meta' ) ? (string) $item->get_meta( '_bch_gift_image' ) : '';
		return '' !== $img ? '<img src="' . esc_url( $img ) . '" alt="" width="64" height="64" />' : $html;
	}
}
