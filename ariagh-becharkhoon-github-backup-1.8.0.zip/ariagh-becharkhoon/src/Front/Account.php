<?php
/**
 * WooCommerce "My Account" tab: spins left, prizes (codes, status, expiry), credits, referral.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Front;

use Becharkhoon\Core\Helpers;
use Becharkhoon\Core\Lang;
use Becharkhoon\Credits\Rules;
use Becharkhoon\Engine\Context;
use Becharkhoon\Engine\Eligibility;
use Becharkhoon\Prizes\Coupons;

defined( 'ABSPATH' ) || exit;

final class Account {

	public static function slug() {
		$s = function_exists( 'becharkhoon' ) && becharkhoon()->settings ? (string) becharkhoon()->settings->get( 'myaccount_slug' ) : 'lucky-wheel';
		return '' !== $s ? $s : 'lucky-wheel';
	}

	public static function add_endpoint() {
		add_rewrite_endpoint( self::slug(), EP_ROOT | EP_PAGES );
	}

	public function register_hooks() {
		if ( ! becharkhoon()->settings->get( 'myaccount_tab' ) ) {
			return;
		}
		add_action( 'init', array( __CLASS__, 'add_endpoint' ) );
		add_filter( 'woocommerce_get_query_vars', array( $this, 'query_vars' ) );
		add_filter( 'woocommerce_account_menu_items', array( $this, 'menu' ), 20 );
		add_action( 'woocommerce_account_' . self::slug() . '_endpoint', array( $this, 'content' ) );
		add_filter( 'woocommerce_endpoint_' . self::slug() . '_title', array( $this, 'title' ) );
	}

	public function query_vars( $vars ) {
		$vars[ self::slug() ] = self::slug();
		return $vars;
	}

	public function title() {
		$t = (string) becharkhoon()->settings->get( 'myaccount_title' );
		return '' !== $t ? $t : Lang::t( 'گردونه شانس من', 'My lucky wheel' );
	}

	public function menu( $items ) {
		$pos   = max( 0, (int) becharkhoon()->settings->get( 'myaccount_position' ) );
		$new   = array( self::slug() => $this->title() );
		$items = array_slice( $items, 0, $pos, true ) + $new + array_slice( $items, $pos, null, true );
		return $items;
	}

	public function content() {
		Shortcodes::ensure_assets();
		$uid = get_current_user_id();
		$ctx = Context::current();
		echo '<div class="bch-account">';
		$cards = '';
		foreach ( becharkhoon()->wheels->active() as $w ) {
			if ( $w['config']['advanced']['shortcode_only'] && 'free' === $w['config']['access']['mode'] ) {
				continue;
			}
			$e    = Eligibility::check( $w, $ctx );
			$left = 'free' === $w['config']['access']['mode'] ? ( $e['ok'] ? max( 1, min( 99, (int) $e['free_left'] ) ) : 0 ) : (int) $e['credits'] + ( 'free' === $e['via'] ? max( 0, min( 99, (int) $e['free_left'] ) ) : 0 );
			$num  = Lang::is_fa() ? Helpers::persian_digits( (string) $left ) : (string) $left;
			$cards .= '<div class="bch-acc-card"><div class="bch-acc-card__ic">🎡</div><div class="bch-acc-card__body"><b>' . esc_html( $w['title'] ) . '</b><span>' . esc_html( sprintf( Lang::t( '%s شانس چرخاندن', '%s spins available' ), $num ) ) . '</span></div>';
			$cards .= $e['ok'] ? '<button type="button" class="bch-open-btn" data-bch-open="' . (int) $w['id'] . '">' . esc_html( Lang::t( 'بچرخون', 'Spin' ) ) . '</button>' : '<small class="bch-muted">' . esc_html( \Becharkhoon\Engine\SpinService::reason_message( $w, $e ) ) . '</small>';
			$cards .= '</div>';
			if ( 'free' !== $w['config']['access']['mode'] && ! $e['ok'] ) {
				$hints = Rules::earn_hints( $w['id'] );
				if ( $hints ) {
					$cards .= '<ul class="bch-earn">';
					foreach ( $hints as $h ) {
						$cards .= '<li>' . esc_html( $h ) . '</li>';
					}
					$cards .= '</ul>';
				}
			}
		}
		if ( '' !== $cards ) {
			echo '<div class="bch-acc-cards">' . $cards . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
		}
		if ( becharkhoon()->settings->get( 'referral_enabled' ) ) {
			$link = add_query_arg( becharkhoon()->settings->get( 'referral_param' ), Rules::ref_code( $uid ), home_url( '/' ) );
			echo '<h3>' . esc_html( Lang::t( 'دعوت از دوستان', 'Invite friends' ) ) . '</h3><div class="bch-ref"><input type="text" readonly value="' . esc_attr( $link ) . '" onclick="this.select()"> <button type="button" class="bch-copy" data-copy="' . esc_attr( $link ) . '">' . esc_html( Lang::t( 'کپی', 'Copy' ) ) . '</button></div>';
		}
		echo '<h3>' . esc_html( Lang::t( 'جوایز من', 'My prizes' ) ) . '</h3>';
		echo self::render_prizes( $uid ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
		echo self::render_credits( $uid ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
		echo '</div>';
	}

	/** Where the customer's spins came from (earned / used / expiry). */
	public static function render_credits( $user_id ) {
		global $wpdb;
		$phone = Helpers::phone( get_user_meta( $user_id, 'billing_phone', true ) );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bch_credits WHERE user_id = %d OR (phone <> '' AND phone = %s AND user_id = 0) ORDER BY id DESC LIMIT 30", $user_id, $phone ), ARRAY_A );
		if ( ! $rows ) {
			return '';
		}
		$out = '<h3>' . esc_html( Lang::t( 'شانس‌های دریافتی', 'Earned spins' ) ) . '</h3><div class="bch-table-wrap"><table class="bch-table shop_table"><thead><tr><th>' . esc_html( Lang::t( 'بابت', 'For' ) ) . '</th><th>' . esc_html( Lang::t( 'تعداد', 'Spins' ) ) . '</th><th>' . esc_html( Lang::t( 'استفاده‌شده', 'Used' ) ) . '</th><th>' . esc_html( Lang::t( 'انقضا', 'Expires' ) ) . '</th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$for  = '' !== $r['note'] ? $r['note'] : $r['reason'];
			$out .= '<tr><td>' . esc_html( $for ) . ( 'order' === $r['ref_type'] ? ' <small>#' . (int) $r['ref_id'] . '</small>' : '' ) . '</td><td>' . (int) $r['qty'] . '</td><td>' . (int) $r['used'] . '</td><td>' . esc_html( $r['expires_at'] ? Helpers::human_date( $r['expires_at'] ) : '—' ) . '</td></tr>';
		}
		return $out . '</tbody></table></div>';
	}

	public static function render_prizes( $user_id ) {
		global $wpdb;
		$u     = get_userdata( $user_id );
		$phone = Helpers::phone( get_user_meta( $user_id, 'billing_phone', true ) );
		$where = 'user_id = %d';
		$args  = array( $user_id );
		if ( '' !== $phone ) {
			$where .= ' OR phone = %s';
			$args[] = $phone;
		}
		if ( $u ) {
			$where .= ' OR email = %s';
			$args[] = strtolower( $u->user_email );
		}
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bch_spins WHERE result = 'win' AND ($where) ORDER BY id DESC LIMIT 50", $args ), ARRAY_A ); // phpcs:ignore
		if ( ! $rows ) {
			return '<p class="bch-muted">' . esc_html( Lang::t( 'هنوز جایزه‌ای نبرده‌اید. گردونه را بچرخانید!', 'No prizes yet — give the wheel a spin!' ) ) . '</p>';
		}
		$labels = array(
			'active'   => array( Lang::t( 'فعال', 'Active' ), 'ok' ),
			'used'     => array( Lang::t( 'استفاده‌شده', 'Used' ), 'muted' ),
			'expired'  => array( Lang::t( 'منقضی', 'Expired' ), 'bad' ),
			'deleted'  => array( Lang::t( 'نامعتبر', 'Invalid' ), 'bad' ),
			'redeemed' => array( Lang::t( 'استفاده‌شده', 'Used' ), 'muted' ),
			'pending'  => array( Lang::t( 'در انتظار ثبت آدرس', 'Awaiting details' ), 'warn' ),
			'claimed'  => array( Lang::t( 'در حال ارسال', 'Being processed' ), 'warn' ),
			'delivered' => array( Lang::t( 'تحویل شد', 'Delivered' ), 'ok' ),
			'issued'   => array( Lang::t( 'فعال', 'Active' ), 'ok' ),
		);
		$param = (string) becharkhoon()->settings->get( 'auto_apply_param' );
		$out   = '<div class="bch-table-wrap"><table class="bch-table shop_table"><thead><tr><th>' . esc_html( Lang::t( 'جایزه', 'Prize' ) ) . '</th><th>' . esc_html( Lang::t( 'کد', 'Code' ) ) . '</th><th>' . esc_html( Lang::t( 'وضعیت', 'Status' ) ) . '</th><th>' . esc_html( Lang::t( 'اعتبار تا', 'Valid until' ) ) . '</th><th></th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$state = $r['status'];
			if ( $r['coupon_id'] ) {
				$cs    = Coupons::state( $r['coupon_code'] );
				$state = 'redeemed' === $r['status'] ? 'redeemed' : ( '' !== $cs ? $cs : $state );
			} elseif ( 'issued' === $state && $r['expires_at'] && strtotime( $r['expires_at'] . ' UTC' ) < time() ) {
				$state = 'expired';
			}
			$lab  = $labels[ $state ] ?? array( $state, 'muted' );
			$code = $r['coupon_id'] ? strtoupper( $r['coupon_code'] ) : $r['coupon_code'];
			$out .= '<tr><td>' . esc_html( $r['slice_label'] ) . '</td><td>' . ( '' !== $code ? '<code class="bch-code">' . esc_html( $code ) . '</code>' : '—' ) . '</td>';
			$out .= '<td><span class="bch-badge is-' . esc_attr( $lab[1] ) . '">' . esc_html( $lab[0] ) . '</span></td>';
			$out .= '<td>' . esc_html( $r['expires_at'] ? Helpers::human_date( $r['expires_at'] ) : '—' ) . '</td><td class="bch-actions">';
			if ( '' !== $code && in_array( $state, array( 'active', 'issued' ), true ) ) {
				$out .= '<button type="button" class="bch-copy" data-copy="' . esc_attr( $code ) . '">' . esc_html( Lang::t( 'کپی', 'Copy' ) ) . '</button>';
				if ( $r['coupon_id'] ) {
					$out .= ' <a class="button" href="' . esc_url( add_query_arg( $param, rawurlencode( $code ), home_url( '/' ) ) ) . '">' . esc_html( Lang::t( 'استفاده', 'Use' ) ) . '</a>';
				}
			}
			$out .= '</td></tr>';
		}
		return $out . '</tbody></table></div>';
	}
}
