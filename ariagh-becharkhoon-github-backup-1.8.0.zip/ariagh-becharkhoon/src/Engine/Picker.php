<?php
/**
 * Server-side prize selection: weighted CSPRNG draw over the slices that are actually
 * available to this visitor (stock, daily caps, per-user caps, slice conditions, win caps),
 * plus "first spin wins" and "guaranteed win after N losses".
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Engine;

use Becharkhoon\Core\Helpers;

defined( 'ABSPATH' ) || exit;

final class Picker {

	const LOSING = array( 'lose', 'respin' );

	public static function is_win_type( $type ) {
		return ! in_array( $type, self::LOSING, true );
	}

	/** Does the site support this prize type right now? */
	public static function type_supported( array $slice, Context $ctx ) {
		$woo = class_exists( 'WooCommerce' );
		switch ( $slice['type'] ) {
			case 'coupon_percent':
			case 'coupon_fixed_cart':
			case 'coupon_fixed_product':
			case 'free_shipping':
				return $woo;
			case 'free_product':
				return $woo && count( \Becharkhoon\Prizes\Gifts::pool( $slice ) ) > 0;
			case 'existing_coupon':
				return $woo && '' !== $slice['coupon_code'];
			case 'wallet':
				return $ctx->user_id > 0 && \Becharkhoon\Prizes\Integrations::wallet_provider();
			case 'points':
				return $ctx->user_id > 0 && \Becharkhoon\Prizes\Integrations::points_provider();
			case 'code_pool':
				return \Becharkhoon\Prizes\CodePool::available( $ctx->wheel_id, $slice['id'] ) > 0;
		}
		return true;
	}

	/**
	 * Slices that may be won (index => slice), after all availability rules.
	 *
	 * @param array   $wheel Wheel row.
	 * @param Context $ctx   Context.
	 * @param array   $ids   Identity for per-user caps.
	 */
	public static function candidates( array $wheel, Context $ctx, array $ids ) {
		$cfg    = $wheel['config'];
		$stock  = becharkhoon()->wheels->stock( $wheel['id'] );
		$out    = array();
		$eng    = $cfg['engine'];
		$no_win = false;
		if ( (int) $eng['daily_win_cap'] > 0 && Limits::wheel_wins_since( $wheel['id'], Helpers::period_start( 'day' ) ) >= (int) $eng['daily_win_cap'] ) {
			$no_win = true;
		}
		if ( (int) $eng['total_win_cap'] > 0 && Limits::wheel_wins_since( $wheel['id'], '1970-01-01 00:00:00' ) >= (int) $eng['total_win_cap'] ) {
			$no_win = true;
		}
		foreach ( $cfg['slices'] as $i => $s ) {
			if ( (float) $s['weight'] <= 0 ) {
				continue;
			}
			$win = self::is_win_type( $s['type'] );
			if ( $win && $no_win ) {
				continue;
			}
			if ( (int) $s['stock'] >= 0 ) {
				$st = $stock[ $s['id'] ] ?? array( 'left' => (int) $s['stock'] );
				if ( $st['left'] <= 0 ) {
					continue;
				}
			}
			if ( (int) $s['daily_cap'] > 0 && Limits::slice_wins_today( $wheel['id'], $s['id'] ) >= (int) $s['daily_cap'] ) {
				continue;
			}
			if ( (int) $s['user_cap'] > 0 && Limits::count( $wheel['id'], $ids, '1970-01-01 00:00:00', null, true, $s['id'] ) >= (int) $s['user_cap'] ) {
				continue;
			}
			if ( ! Conditions::passes( $s['conditions'], $ctx ) ) {
				continue;
			}
			if ( ! self::type_supported( $s, $ctx ) ) {
				continue;
			}
			$out[ $i ] = $s;
		}

		$wins = array_filter(
			$out,
			static function ( $s ) {
				return Picker::is_win_type( $s['type'] );
			}
		);
		if ( $wins ) {
			$force = false;
			if ( $eng['first_spin_win'] && 0 === Limits::count( $wheel['id'], $ids ) ) {
				$force = true;
			}
			if ( (int) $eng['pity_after'] > 0 ) {
				$last = Limits::last_results( $wheel['id'], $ids, (int) $eng['pity_after'] );
				if ( count( $last ) >= (int) $eng['pity_after'] && ! in_array( 'win', $last, true ) ) {
					$force = true;
				}
			}
			if ( $force ) {
				$out = $wins;
			}
			// VIP boost: returning customers get better odds on highlighted (big) prizes.
			if ( (int) $eng['vip_boost'] > 0 && $ctx->user_id && $ctx->order_count() > 0 ) {
				foreach ( $out as $i => $s ) {
					if ( ! empty( $s['highlight'] ) ) {
						$out[ $i ]['weight'] = (float) $s['weight'] * ( 1 + (int) $eng['vip_boost'] / 100 );
					}
				}
			}
		}
		return $out;
	}

	/**
	 * Weighted draw. Returns the slice index or -1.
	 *
	 * @param array $candidates index => slice.
	 */
	public static function draw( array $candidates ) {
		$total = 0;
		$table = array();
		foreach ( $candidates as $i => $s ) {
			$w = (int) round( (float) $s['weight'] * 1000 );
			if ( $w <= 0 ) {
				continue;
			}
			$total    += $w;
			$table[ $i ] = $total;
		}
		if ( $total <= 0 ) {
			return -1;
		}
		$r = random_int( 1, $total );
		foreach ( $table as $i => $edge ) {
			if ( $r <= $edge ) {
				return (int) $i;
			}
		}
		return -1;
	}

	/** Index of a visual "losing" slice to land on when nothing can be won. */
	public static function fallback_index( array $wheel ) {
		$slices = $wheel['config']['slices'];
		$fb     = (string) $wheel['config']['engine']['fallback_slice'];
		foreach ( $slices as $i => $s ) {
			if ( '' !== $fb && $s['id'] === $fb && ! Picker::is_win_type( $s['type'] ) ) {
				return $i;
			}
		}
		foreach ( $slices as $i => $s ) {
			if ( 'lose' === $s['type'] ) {
				return $i;
			}
		}
		return -1;
	}

	/** Theoretical win probability per slice (admin "odds" table). */
	public static function odds( array $slices ) {
		$sum = 0.0;
		foreach ( $slices as $s ) {
			$sum += max( 0, (float) $s['weight'] );
		}
		$out = array();
		foreach ( $slices as $s ) {
			$out[ $s['id'] ] = $sum > 0 ? round( max( 0, (float) $s['weight'] ) / $sum * 100, 2 ) : 0;
		}
		return $out;
	}
}
