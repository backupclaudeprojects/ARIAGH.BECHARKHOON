<?php
/**
 * Anti-fraud: signed boot tokens, OTP verification sessions, captcha providers,
 * honeypot/timing checks and email/phone validation.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Front;

use Becharkhoon\Core\Helpers;
use Becharkhoon\Core\Http;
use Becharkhoon\Core\Lang;
use Becharkhoon\Core\RateLimit;

defined( 'ABSPATH' ) || exit;

final class Guard {

	/* ---------- Boot tokens (CSRF replacement that survives page caching) ---------- */

	/** A short-lived token bound to the device id, issued by the uncached boot request. */
	public static function issue_token( $device_id ) {
		$ts  = time();
		$sig = hash_hmac( 'sha256', 'boot|' . $device_id . '|' . $ts, (string) get_option( 'bch_secret' ) );
		return $ts . '.' . substr( $sig, 0, 40 );
	}

	public static function check_token( $token, $device_id, $max_age = 6 * HOUR_IN_SECONDS ) {
		if ( ! preg_match( '/^(\d{9,11})\.([a-f0-9]{40})$/', (string) $token, $m ) ) {
			return false;
		}
		if ( time() - (int) $m[1] > $max_age || (int) $m[1] > time() + 60 ) {
			return false;
		}
		$sig = substr( hash_hmac( 'sha256', 'boot|' . $device_id . '|' . $m[1], (string) get_option( 'bch_secret' ) ), 0, 40 );
		return hash_equals( $sig, $m[2] );
	}

	/* ---------- OTP ---------- */

	/**
	 * Send a verification code.
	 *
	 * @return array{ok:bool,message:string,resend:int}
	 */
	public static function otp_send( $phone, $ip ) {
		$s = becharkhoon()->settings;
		if ( '' === (string) $s->get( 'sms_driver' ) ) {
			return array( 'ok' => false, 'message' => Lang::t( 'سرویس پیامک تنظیم نشده است.', 'SMS is not configured.' ), 'resend' => 0 );
		}
		if ( ! RateLimit::hit( 'otp_ip:' . $ip, 8, 600 ) ) {
			return array( 'ok' => false, 'message' => Lang::t( 'تعداد درخواست‌ها زیاد است. چند دقیقه دیگر تلاش کنید.', 'Too many requests. Try again later.' ), 'resend' => 600 );
		}
		$k    = 'bch_otp_' . md5( $phone );
		$cur  = get_transient( $k );
		$wait = (int) $s->get( 'otp_resend' );
		if ( is_array( $cur ) && ( time() - (int) $cur['sent'] ) < $wait ) {
			$left = $wait - ( time() - (int) $cur['sent'] );
			return array( 'ok' => false, 'message' => sprintf( Lang::t( 'لطفاً %d ثانیه دیگر دوباره تلاش کنید.', 'Please wait %d seconds.' ), $left ), 'resend' => $left );
		}
		$day = 'bch_otpd_' . md5( $phone . Helpers::today() );
		$cnt = (int) get_transient( $day );
		if ( $cnt >= (int) $s->get( 'otp_daily_per_phone' ) ) {
			return array( 'ok' => false, 'message' => Lang::t( 'سقف ارسال کد برای این شماره امروز پر شده است.', 'Daily code limit reached for this number.' ), 'resend' => 0 );
		}
		$len  = max( 4, min( 8, (int) $s->get( 'otp_length' ) ) );
		$code = (string) random_int( (int) str_pad( '1', $len, '0' ), (int) str_repeat( '9', $len ) );
		$ok   = becharkhoon()->notifier->otp( $phone, $code );
		if ( ! $ok ) {
			return array( 'ok' => false, 'message' => Lang::t( 'ارسال پیامک ناموفق بود. دوباره تلاش کنید.', 'Could not send the SMS. Please try again.' ), 'resend' => 0 );
		}
		set_transient( $k, array( 'hash' => wp_hash_password( $code ), 'sent' => time(), 'tries' => 0 ), (int) $s->get( 'otp_ttl' ) );
		set_transient( $day, $cnt + 1, DAY_IN_SECONDS );
		return array( 'ok' => true, 'message' => Lang::t( 'کد تایید پیامک شد.', 'Verification code sent.' ), 'resend' => $wait );
	}

	/**
	 * Verify a code; returns a verification session token or ''.
	 */
	public static function otp_verify( $phone, $code, &$error = '' ) {
		$s   = becharkhoon()->settings;
		$k   = 'bch_otp_' . md5( $phone );
		$cur = get_transient( $k );
		if ( ! is_array( $cur ) ) {
			$error = Lang::t( 'کد منقضی شده است. دوباره ارسال کنید.', 'The code expired. Request a new one.' );
			return '';
		}
		if ( (int) $cur['tries'] >= (int) $s->get( 'otp_max_attempts' ) ) {
			delete_transient( $k );
			$error = Lang::t( 'تعداد تلاش‌ها زیاد بود. کد جدید بگیرید.', 'Too many attempts. Request a new code.' );
			return '';
		}
		require_once ABSPATH . WPINC . '/class-phpass.php';
		if ( ! wp_check_password( Helpers::latin_digits( trim( (string) $code ) ), $cur['hash'] ) ) {
			$cur['tries'] = (int) $cur['tries'] + 1;
			set_transient( $k, $cur, (int) $s->get( 'otp_ttl' ) );
			$error = Lang::t( 'کد وارد شده صحیح نیست.', 'Incorrect code.' );
			return '';
		}
		delete_transient( $k );
		$token = Helpers::token();
		set_transient( 'bch_vs_' . hash( 'sha256', $token ), $phone, 7 * DAY_IN_SECONDS ); // Kept on this device: no second SMS for the next spin.
		return $token;
	}

	/**
	 * Personal SMS link token: whoever opens the link from the SMS sent to this mobile is treated as that
	 * mobile (like an OTP), so spins granted to the number are usable at once. Format l<exp><09…><sig>.
	 */
	public static function link_token( $phone, $days = 30 ) {
		$phone = Helpers::phone( (string) $phone );
		if ( ! preg_match( '/^09\d{9}$/', $phone ) ) {
			return '';
		}
		$exp = time() + max( 1, (int) $days ) * DAY_IN_SECONDS;
		return 'l' . $exp . $phone . substr( hash_hmac( 'sha256', 'link|' . $phone . '|' . $exp, (string) get_option( 'bch_secret' ) ), 0, 24 );
	}

	/** Add the personal token to a link (when the setting is on). */
	public static function personal_link( $url, $phone ) {
		if ( ! becharkhoon()->settings->get( 'sms_magic_link' ) ) {
			return $url;
		}
		$t = self::link_token( $phone, (int) becharkhoon()->settings->get( 'sms_magic_days' ) );
		return '' !== $t ? add_query_arg( 'bch_v', $t, $url ) : $url;
	}

	/** Phone proven by an OTP session token (or a personal SMS link token), or ''. */
	public static function verified_phone( $token ) {
		if ( preg_match( '/^l(\d{10})(09\d{9})([a-f0-9]{24})$/', (string) $token, $m ) ) {
			if ( (int) $m[1] < time() ) {
				return '';
			}
			$sig = substr( hash_hmac( 'sha256', 'link|' . $m[2] . '|' . $m[1], (string) get_option( 'bch_secret' ) ), 0, 24 );
			return hash_equals( $sig, $m[3] ) ? $m[2] : '';
		}
		if ( ! preg_match( '/^[a-f0-9]{48}$/', (string) $token ) ) {
			return '';
		}
		$p = get_transient( 'bch_vs_' . hash( 'sha256', $token ) );
		return is_string( $p ) ? $p : '';
	}

	/* ---------- Captcha ---------- */

	public static function captcha_ok( $response, $ip ) {
		$s    = becharkhoon()->settings;
		$type = (string) $s->get( 'captcha' );
		if ( 'off' === $type || '' === $type ) {
			return true;
		}
		$secret = (string) $s->get( 'captcha_secret' );
		if ( '' === $secret || '' === (string) $response ) {
			return false;
		}
		switch ( $type ) {
			case 'recaptcha_v2':
			case 'recaptcha_v3':
				$r = Http::request( 'POST', 'https://www.google.com/recaptcha/api/siteverify', array( 'body' => array( 'secret' => $secret, 'response' => $response, 'remoteip' => $ip ) ) );
				if ( empty( $r['json']['success'] ) ) {
					return false;
				}
				return 'recaptcha_v2' === $type || (float) ( $r['json']['score'] ?? 0 ) >= (float) $s->get( 'recaptcha_threshold' );
			case 'turnstile':
				$r = Http::request( 'POST', 'https://challenges.cloudflare.com/turnstile/v0/siteverify', array( 'body' => array( 'secret' => $secret, 'response' => $response, 'remoteip' => $ip ) ) );
				return ! empty( $r['json']['success'] );
			case 'hcaptcha':
				$r = Http::request( 'POST', 'https://hcaptcha.com/siteverify', array( 'body' => array( 'secret' => $secret, 'response' => $response, 'remoteip' => $ip ) ) );
				return ! empty( $r['json']['success'] );
			case 'arcaptcha':
				$r = Http::request( 'POST', 'https://api.arcaptcha.ir/arcaptcha/api/verify', array( 'json' => true, 'body' => array( 'challenge_id' => $response, 'site_key' => (string) $s->get( 'captcha_site_key' ), 'secret_key' => $secret ) ) );
				return ! empty( $r['json']['success'] );
		}
		return true;
	}

	/* ---------- Email ---------- */

	public static function disposable_domains() {
		return array( 'mailinator.com', '10minutemail.com', 'guerrillamail.com', 'guerrillamail.net', 'sharklasers.com', 'yopmail.com', 'yopmail.net', 'tempmail.com', 'temp-mail.org', 'temp-mail.io', 'throwawaymail.com', 'getnada.com', 'nada.email', 'dispostable.com', 'maildrop.cc', 'mailnesia.com', 'trashmail.com', 'trashmail.de', 'fakeinbox.com', 'mintemail.com', 'mohmal.com', 'emailondeck.com', 'mailcatch.com', 'spamgourmet.com', 'tempinbox.com', 'tempr.email', 'discard.email', 'moakt.com', 'mytemp.email', 'tmail.ws', 'tmpmail.org', 'tmpmail.net', 'burnermail.io', 'inboxkitten.com', 'mail.tm', 'emailfake.com', 'fakemail.net', 'jetable.org', 'spambox.us', 'mailpoof.com', 'linshiyouxiang.net', '33mail.com', 'anonaddy.me', 'mailsac.com', 'harakirimail.com', 'tempmailo.com', 'luxusmail.org', 'byom.de', 'trbvm.com', 'grr.la', 'guerrillamailblock.com', 'pokemail.net', 'spam4.me', 'wegwerfmail.de', 'einrot.com', 'cuvox.de', 'armyspy.com', 'dayrep.com', 'fleckens.hu', 'gustr.com', 'jourrapide.com', 'rhyta.com', 'superrito.com', 'teleworm.us' );
	}

	/**
	 * Validate an email against settings. Returns '' when OK, else an error message.
	 */
	public static function email_error( $email ) {
		$s      = becharkhoon()->settings;
		$domain = strtolower( substr( strrchr( $email, '@' ), 1 ) );
		$list   = array_map( 'strtolower', Helpers::lines( $s->get( 'email_domains' ) ) );
		if ( 'whitelist' === $s->get( 'email_domain_mode' ) && $list && ! in_array( $domain, $list, true ) ) {
			return Lang::t( 'این دامنه ایمیل پذیرفته نمی‌شود.', 'This email domain is not accepted.' );
		}
		if ( 'blacklist' === $s->get( 'email_domain_mode' ) && in_array( $domain, $list, true ) ) {
			return Lang::t( 'این دامنه ایمیل پذیرفته نمی‌شود.', 'This email domain is not accepted.' );
		}
		if ( $s->get( 'block_disposable' ) && in_array( $domain, self::disposable_domains(), true ) ) {
			return Lang::t( 'ایمیل موقت پذیرفته نمی‌شود.', 'Temporary emails are not accepted.' );
		}
		if ( $s->get( 'check_mx' ) && function_exists( 'checkdnsrr' ) && ! checkdnsrr( $domain, 'MX' ) && ! checkdnsrr( $domain, 'A' ) ) {
			return Lang::t( 'دامنه ایمیل معتبر نیست.', 'The email domain does not exist.' );
		}
		return '';
	}
}
