@echo off
REM ARIAGH.BECHARKHOON - first push of this folder to a PRIVATE GitHub repo.
REM Needs Git for Windows; GitHub CLI (gh) optional. Run from the project folder (double-click).
cd /d "%~dp0.."
where git >nul 2>nul || (echo Git is not installed. Install: winget install Git.Git & pause & exit /b 1)
if not exist .git (
  git init -b main
)
git add -A
git commit -m "Backup: ARIAGH.BECHARKHOON 1.8.0 + handoff docs" || echo Nothing new to commit.
where gh >nul 2>nul && (
  gh auth status >nul 2>nul || gh auth login
  git remote get-url origin >nul 2>nul || gh repo create ariagh-becharkhoon --private --source . --remote origin
  git push -u origin main
  echo.
  echo Done. Open: gh repo view --web
  pause
  exit /b 0
)
echo.
echo GitHub CLI not found. Either install it (winget install GitHub.cli) and run this again,
echo or create an EMPTY private repo on github.com and run:
echo   git remote add origin https://github.com/YOUR-USER/ariagh-becharkhoon.git
echo   git push -u origin main
pause
