<?php
/**
 * Admin REST API (becharkhoon/v1) used by the admin SPA. Cookie + wp_rest nonce.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Admin;

use Becharkhoon\Core\Capabilities;
use Becharkhoon\Core\Helpers;
use Becharkhoon\Core\Installer;
use Becharkhoon\Core\Lang;
use Becharkhoon\Core\Logger;
use Becharkhoon\Credits\Ledger;
use Becharkhoon\Credits\Rules;
use Becharkhoon\Engine\Conditions;
use Becharkhoon\Engine\Leads;
use Becharkhoon\Engine\Picker;
use Becharkhoon\Notify\Sms;
use Becharkhoon\Notify\SmsEvents;
use Becharkhoon\Notify\SmsGateways;
use Becharkhoon\Prizes\CodePool;
use Becharkhoon\Prizes\Integrations;
use Becharkhoon\Stats\Stats;
use Becharkhoon\Wheels\Schema;
use Becharkhoon\Wheels\Templates;

defined( 'ABSPATH' ) || exit;

final class Rest {

	const NS = 'becharkhoon/v1';

	public function register_hooks() {
		add_action( 'rest_api_init', array( $this, 'routes' ) );
	}

	private function r( $path, $methods, $cb, $manage = true ) {
		register_rest_route(
			self::NS,
			$path,
			array(
				'methods'             => $methods,
				'callback'            => function ( \WP_REST_Request $req ) use ( $cb ) {
					$admin_lang = becharkhoon()->settings->get( 'ui_language' );
					if ( 'auto' === $admin_lang ) {
						Lang::use_site_locale( 0 === strpos( get_user_locale(), 'fa' ) ? 'fa' : 'en' );
					} else {
						Lang::use_site_locale( $admin_lang );
					}
					try {
						$res = call_user_func( $cb, $req );
					} catch ( \Throwable $e ) {
						Logger::log( 'system', 'error', 'Admin API: ' . $e->getMessage(), array( 'file' => basename( $e->getFile() ) . ':' . $e->getLine() ) );
						return new \WP_REST_Response( array( 'message' => $e->getMessage() ), 500 );
					}
					$r = rest_ensure_response( $res );
					$r->header( 'Cache-Control', 'no-store' );
					return $r;
				},
				'permission_callback' => function () use ( $manage ) {
					return $manage ? Capabilities::can_manage() : Capabilities::can_view();
				},
			)
		);
	}

	public function routes() {
		$this->r( '/bootstrap', 'GET', array( $this, 'bootstrap' ), false );
		$this->r( '/dashboard', 'GET', array( $this, 'dashboard' ), false );
		$this->r( '/wheels', 'GET', array( $this, 'wheels' ), false );
		$this->r( '/wheels', 'POST', array( $this, 'wheel_create' ) );
		$this->r( '/wheels/import', 'POST', array( $this, 'wheel_import' ) );
		$this->r( '/wheels/(?P<id>\d+)', 'GET', array( $this, 'wheel_get' ), false );
		$this->r( '/wheels/(?P<id>\d+)', 'PUT', array( $this, 'wheel_save' ) );
		$this->r( '/wheels/(?P<id>\d+)', 'DELETE', array( $this, 'wheel_delete' ) );
		$this->r( '/wheels/(?P<id>\d+)/duplicate', 'POST', array( $this, 'wheel_duplicate' ) );
		$this->r( '/wheels/(?P<id>\d+)/status', 'POST', array( $this, 'wheel_status' ) );
		$this->r( '/wheels/(?P<id>\d+)/reset-stock', 'POST', array( $this, 'wheel_reset_stock' ) );
		$this->r( '/wheels/(?P<id>\d+)/simulate', 'POST', array( $this, 'wheel_simulate' ) );
		$this->r( '/wheels/(?P<id>\d+)/export', 'GET', array( $this, 'wheel_export' ) );
		$this->r( '/wheels/(?P<id>\d+)/codes', 'POST', array( $this, 'wheel_codes' ) );
		$this->r( '/spins', 'GET', array( $this, 'spins' ), false );
		$this->r( '/spins/(?P<id>\d+)', 'PUT', array( $this, 'spin_update' ) );
		$this->r( '/spins/(?P<id>\d+)', 'DELETE', array( $this, 'spin_delete' ) );
		$this->r( '/spins/(?P<id>\d+)/resend', 'POST', array( $this, 'spin_resend' ) );
		$this->r( '/leads', 'GET', array( $this, 'leads' ), false );
		$this->r( '/leads/(?P<id>\d+)', 'DELETE', array( $this, 'lead_delete' ) );
		$this->r( '/leads/sms', 'POST', array( $this, 'leads_sms' ) );
		$this->r( '/bulk/preview', 'POST', array( $this, 'bulk_preview' ) );
		$this->r( '/bulk/start', 'POST', array( $this, 'bulk_start' ) );
		$this->r( '/bulk/step', 'POST', array( $this, 'bulk_step' ) );
		$this->r( '/bulk/campaigns', 'GET', array( $this, 'bulk_campaigns' ) );
		$this->r( '/bulk/tick', 'POST', array( $this, 'bulk_tick' ) );
		$this->r( '/bulk/(?P<id>\d+)', 'GET', array( $this, 'bulk_get' ) );
		$this->r( '/bulk/(?P<id>\d+)/items', 'GET', array( $this, 'bulk_items' ) );
		$this->r( '/bulk/(?P<id>\d+)/action', 'POST', array( $this, 'bulk_action' ) );
		$this->r( '/credits', 'GET', array( $this, 'credits' ) );
		$this->r( '/people', 'GET', array( $this, 'people' ), false );
		$this->r( '/people/events', 'GET', array( $this, 'people_events' ), false );
		$this->r( '/contacts/count', 'GET', array( $this, 'contacts_count' ), false );
		$this->r( '/reports', 'GET', array( $this, 'reports' ), false );
		$this->r( '/reports/orders', 'GET', array( $this, 'reports_orders' ), false );
		$this->r( '/reports/sync', 'POST', array( $this, 'reports_sync' ) );
		$this->r( '/credits', 'POST', array( $this, 'credits_grant' ) );
		$this->r( '/credits/bulk', 'POST', array( $this, 'credits_bulk' ) );
		$this->r( '/credits/(?P<id>\d+)/revoke', 'POST', array( $this, 'credit_revoke' ) );
		$this->r( '/rules', 'GET', array( $this, 'rules' ) );
		$this->r( '/rules', 'PUT', array( $this, 'rules_save' ) );
		$this->r( '/rules/backfill', 'POST', array( $this, 'rules_backfill' ) );
		$this->r( '/settings', 'GET', array( $this, 'settings' ) );
		$this->r( '/settings', 'PUT', array( $this, 'settings_save' ) );
		$this->r( '/test/(?P<what>[a-z]+)', 'POST', array( $this, 'test' ) );
		$this->r( '/sms/log', 'GET', array( $this, 'sms_log' ), false );
		$this->r( '/sms/log', 'DELETE', array( $this, 'sms_log_clear' ) );
		$this->r( '/sms/preview', 'POST', array( $this, 'sms_preview' ) );
		$this->r( '/logs', 'GET', array( $this, 'logs' ), false );
		$this->r( '/logs', 'DELETE', array( $this, 'logs_clear' ) );
		$this->r( '/search/(?P<what>[a-z_]+)', 'GET', array( $this, 'search' ), false );
		$this->r( '/tools/status', 'GET', array( $this, 'status' ), false );
		$this->r( '/tools/(?P<what>[a-z_]+)', 'POST', array( $this, 'tool' ) );
		$this->r( '/users/(?P<id>\d+)/block', 'POST', array( $this, 'user_block' ) );
	}

	/* ---------- bootstrap ---------- */

	public function bootstrap() {
		$roles = array( array( 'value' => 'guest', 'label' => Lang::t( 'مهمان', 'Guest' ) ) );
		foreach ( wp_roles()->get_names() as $k => $n ) {
			$roles[] = array( 'value' => $k, 'label' => translate_user_role( $n ) );
		}
		$payments = array();
		$shipping = array();
		$statuses = array();
		if ( function_exists( 'WC' ) ) {
			foreach ( WC()->payment_gateways() ? WC()->payment_gateways()->payment_gateways() : array() as $id => $g ) {
				$payments[] = array( 'value' => $id, 'label' => wp_strip_all_tags( $g->get_title() ) );
			}
			foreach ( WC()->shipping() ? WC()->shipping()->get_shipping_methods() : array() as $id => $m ) {
				$shipping[] = array( 'value' => $id, 'label' => wp_strip_all_tags( $m->get_method_title() ) );
			}
			foreach ( wc_get_order_statuses() as $k => $l ) {
				$statuses[] = array( 'value' => substr( $k, 3 ), 'label' => $l );
			}
		}
		$cond = array();
		foreach ( Conditions::catalog() as $k => $c ) {
			$cond[ $k ] = array( 'group' => $c[0], 'input' => $c[1], 'ops' => $c[2], 'ctx' => $c[3] );
		}
		$tpl = array();
		foreach ( Templates::catalog() as $k => $t ) {
			$tpl[] = array( 'key' => $k, 'title' => $t['title'], 'desc' => $t['desc'], 'theme' => $t['theme'] );
		}
		return array(
			'settings'   => becharkhoon()->settings->for_admin(),
			'themes'     => array_values( Templates::themes() ),
			'templates'  => $tpl,
			'sms'        => SmsGateways::catalog(),
			'sms_events' => SmsEvents::for_admin(),
			'sms_mode'   => Sms::mode(),
			'server_ip'  => isset( $_SERVER['SERVER_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_ADDR'] ) ) : '',
			'conditions' => $cond,
			'triggers'   => Rules::triggers(),
			'rule_defaults' => Rules::rule_defaults(),
			'roles'      => $roles,
			'payments'   => $payments,
			'shipping'   => $shipping,
			'statuses'   => $statuses,
			'integrations' => Integrations::detected(),
			'defaults'   => Schema::defaults(),
			'slice_defaults' => Schema::slice_defaults(),
			'field_defaults' => Schema::field_defaults(),
			'prize_types' => Schema::prize_types(),
			'currency'   => function_exists( 'get_woocommerce_currency_symbol' ) ? html_entity_decode( get_woocommerce_currency_symbol() ) : '',
			'site'       => array( 'name' => get_bloginfo( 'name' ), 'url' => home_url( '/' ), 'locale' => get_locale(), 'tz' => wp_timezone_string() ),
			'wheels'     => $this->wheel_list(),
			'shortcodes' => array( '[becharkhoon id="1"]', '[becharkhoon_button id="1" text=""]', '[becharkhoon_spins id="1"]', '[becharkhoon_my_prizes]', '[becharkhoon_winners id="1" count="10"]', '[becharkhoon_referral]' ),
		);
	}

	private function wheel_list() {
		global $wpdb;
		$counts = array();
		foreach ( (array) $wpdb->get_results( "SELECT wheel_id, COUNT(*) AS spins, SUM(result = 'win') AS wins, SUM(status = 'redeemed') AS redeemed, SUM(revenue) AS revenue FROM {$wpdb->prefix}bch_spins GROUP BY wheel_id", ARRAY_A ) as $r ) {
			$counts[ (int) $r['wheel_id'] ] = $r;
		}
		$out = array();
		foreach ( becharkhoon()->wheels->all() as $w ) {
			$c     = $counts[ $w['id'] ] ?? array( 'spins' => 0, 'wins' => 0, 'redeemed' => 0, 'revenue' => 0 );
			$out[] = array(
				'id'       => $w['id'],
				'title'    => $w['title'],
				'status'   => $w['status'],
				'priority' => $w['priority'],
				'ab_group' => $w['ab_group'],
				'theme'    => $w['config']['design']['theme'],
				'mode'     => $w['config']['access']['mode'],
				'display'  => $w['config']['display']['mode'],
				'slices'   => count( $w['config']['slices'] ),
				'preview'  => \Becharkhoon\Front\Frontend::public_config( $w ),
				'spins'    => (int) $c['spins'],
				'wins'     => (int) $c['wins'],
				'redeemed' => (int) $c['redeemed'],
				'revenue'  => (float) $c['revenue'],
				'updated'  => $w['updated_at'],
				'open'     => \Becharkhoon\Engine\Eligibility::is_open( $w ),
			);
		}
		return $out;
	}

	/* ---------- dashboard ---------- */

	private function range( \WP_REST_Request $r ) {
		$to   = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $r['to'] ) ? (string) $r['to'] : Helpers::today();
		$from = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $r['from'] ) ? (string) $r['from'] : wp_date( 'Y-m-d', time() - 29 * DAY_IN_SECONDS );
		if ( $from > $to ) {
			list( $from, $to ) = array( $to, $from );
		}
		return array( $from, $to );
	}

	public function dashboard( \WP_REST_Request $r ) {
		global $wpdb;
		list( $from, $to ) = $this->range( $r );
		$wheel             = absint( $r['wheel'] );
		$days              = (int) ( ( strtotime( $to ) - strtotime( $from ) ) / DAY_IN_SECONDS ) + 1;
		$pfrom             = wp_date( 'Y-m-d', strtotime( $from ) - $days * DAY_IN_SECONDS );
		$pto               = wp_date( 'Y-m-d', strtotime( $from ) - DAY_IN_SECONDS );
		$recent            = $wpdb->get_results( "SELECT id, wheel_id, slice_label, result, status, name, phone, email, coupon_code, created_at FROM {$wpdb->prefix}bch_spins ORDER BY id DESC LIMIT 12", ARRAY_A );
		// Spins/wins/leads straight from the real tables (complete history, not only counters).
		$per    = \Becharkhoon\Stats\Reports::period( $from, $to );
		$pper   = \Becharkhoon\Stats\Reports::period( $pfrom, $pto );
		$paid   = array_values( array_map( 'strval', (array) becharkhoon()->settings->get( 'order_statuses' ) ) );
		$totals = Stats::totals( $from, $to, $wheel );
		$prev   = Stats::totals( $pfrom, $pto, $wheel );
		foreach ( array( array( &$totals, $per ), array( &$prev, $pper ) ) as $pair ) {
			$act               = \Becharkhoon\Stats\Reports::activity( $pair[1]['from_utc'], $pair[1]['to_utc'], $wheel );
			$pair[0]['spins']  = $act['spins'];
			$pair[0]['wins']   = $act['wins'];
			$pair[0]['leads']  = $act['leads'];
			$pair[0]['redeemed'] = max( (float) $pair[0]['redeemed'], (float) $act['redeemed'] );
			$money             = \Becharkhoon\Stats\Orders::totals( $pair[1]['from_utc'], $pair[1]['to_utc'], $paid, 'created', $wheel );
			$pair[0]['revenue']  = $money['orders'] ? $money['net'] : (float) $pair[0]['revenue'];
			$pair[0]['discount'] = $money['discount'];
			$pair[0]['win_rate'] = $pair[0]['spins'] > 0 ? round( $pair[0]['wins'] / $pair[0]['spins'] * 100, 1 ) : 0;
			$pair[0]['conversion'] = $pair[0]['opens'] > 0 ? round( $pair[0]['spins'] / $pair[0]['opens'] * 100, 1 ) : 0;
			$pair[0]['redeem_rate'] = $pair[0]['wins'] > 0 ? round( $pair[0]['redeemed'] / $pair[0]['wins'] * 100, 1 ) : 0;
		}
		unset( $pair );
		$series = Stats::series( $from, $to, $wheel );
		foreach ( \Becharkhoon\Stats\Reports::series( $per, $paid, 'created', $wheel ) as $day => $v ) {
			if ( isset( $series[ $day ] ) ) {
				$series[ $day ]['spins']   = $v['spins'];
				$series[ $day ]['wins']    = $v['wins'];
				$series[ $day ]['leads']   = $v['leads'];
				$series[ $day ]['revenue'] = $v['sales'];
			}
		}
		return array(
			'from'     => $from,
			'to'       => $to,
			'totals'   => $totals,
			'previous' => $prev,
			'series'   => $series,
			'prizes'   => Stats::prizes( $from, $to, $wheel ),
			'sources'  => Stats::by_source( $from, $to, $wheel ),
			'hours'    => Stats::by_hour( $from, $to, $wheel ),
			'credits'  => Ledger::totals(),
			'recent'   => $recent,
			'wheels'   => $this->wheel_list(),
			'checks'   => $this->health(),
		);
	}

	/** Setup checklist for the dashboard. */
	private function health() {
		$s      = becharkhoon()->settings;
		$wheels = becharkhoon()->wheels->all();
		$active = array_filter(
			$wheels,
			static function ( $w ) {
				return 'active' === $w['status'];
			}
		);
		$needs_sms = false;
		foreach ( $wheels as $w ) {
			if ( $w['config']['notify']['sms_customer'] || $w['config']['access']['require_otp'] || $w['config']['form']['phone_otp'] ) {
				$needs_sms = true;
			}
		}
		$credit_wheels = array_filter(
			$active,
			static function ( $w ) {
				return 'free' !== $w['config']['access']['mode'];
			}
		);
		return array(
			array( 'key' => 'wheel', 'ok' => (bool) $wheels ),
			array( 'key' => 'active', 'ok' => (bool) $active ),
			array( 'key' => 'woo', 'ok' => class_exists( 'WooCommerce' ) ),
			array( 'key' => 'sms', 'ok' => ! $needs_sms || '' !== (string) $s->get( 'sms_driver' ) ),
			array( 'key' => 'rules', 'ok' => ! $credit_wheels || (bool) array_filter( Rules::all(), static function ( $r ) {
				return $r['enabled'];
			} ) ),
			array( 'key' => 'cron', 'ok' => (bool) wp_next_scheduled( \Becharkhoon\Core\Cron::HOOK ) ),
			array( 'key' => 'test', 'ok' => ! $s->get( 'test_mode' ) ),
		);
	}

	/* ---------- wheels ---------- */

	public function wheels() {
		return $this->wheel_list();
	}

	public function wheel_create( \WP_REST_Request $r ) {
		$title = sanitize_text_field( (string) $r['title'] );
		$tpl   = sanitize_key( (string) $r['template'] );
		if ( '' !== $tpl ) {
			$id = Templates::create( $tpl, $title );
		} else {
			$cfg = Schema::defaults();
			if ( $r['theme'] ) {
				$cfg = Templates::apply_theme( $cfg, sanitize_key( $r['theme'] ) );
			}
			$id = becharkhoon()->wheels->create( '' !== $title ? $title : Lang::t( 'گردونه جدید', 'New wheel' ), Schema::sanitize( $cfg ), 'draft' );
		}
		return array( 'id' => $id );
	}

	public function wheel_get( \WP_REST_Request $r ) {
		$w = becharkhoon()->wheels->get( (int) $r['id'] );
		if ( ! $w ) {
			return new \WP_Error( 'not_found', 'Wheel not found', array( 'status' => 404 ) );
		}
		return array(
			'wheel' => $w,
			'odds'  => Picker::odds( $w['config']['slices'] ),
			'stock' => becharkhoon()->wheels->stock( $w['id'] ),
			'pools' => CodePool::summary( $w['id'] ),
			'today' => Stats::totals( Helpers::today(), Helpers::today(), $w['id'] ),
		);
	}

	public function wheel_save( \WP_REST_Request $r ) {
		$id = (int) $r['id'];
		$w  = becharkhoon()->wheels->get( $id );
		if ( ! $w ) {
			return new \WP_Error( 'not_found', 'Wheel not found', array( 'status' => 404 ) );
		}
		$data = array();
		foreach ( array( 'title', 'status', 'priority', 'ab_group' ) as $k ) {
			if ( null !== $r[ $k ] ) {
				$data[ $k ] = $r[ $k ];
			}
		}
		if ( is_array( $r['config'] ) ) {
			$data['config'] = Schema::sanitize( $r['config'] );
		}
		becharkhoon()->wheels->update( $id, $data );
		return $this->wheel_get( $r );
	}

	public function wheel_delete( \WP_REST_Request $r ) {
		becharkhoon()->wheels->delete( (int) $r['id'] );
		return array( 'ok' => true );
	}

	public function wheel_duplicate( \WP_REST_Request $r ) {
		return array( 'id' => becharkhoon()->wheels->duplicate( (int) $r['id'] ) );
	}

	public function wheel_status( \WP_REST_Request $r ) {
		becharkhoon()->wheels->update( (int) $r['id'], array( 'status' => sanitize_key( (string) $r['status'] ) ) );
		return array( 'ok' => true );
	}

	public function wheel_reset_stock( \WP_REST_Request $r ) {
		becharkhoon()->wheels->reset_stock( (int) $r['id'] );
		return array( 'ok' => true, 'stock' => becharkhoon()->wheels->stock( (int) $r['id'] ) );
	}

	/** Monte-Carlo check of the configured odds (pure weights, no visitor rules). */
	public function wheel_simulate( \WP_REST_Request $r ) {
		$w = becharkhoon()->wheels->get( (int) $r['id'] );
		if ( ! $w ) {
			return new \WP_Error( 'not_found', 'Wheel not found', array( 'status' => 404 ) );
		}
		$slices = is_array( $r['slices'] ) ? array_map( array( Schema::class, 'sanitize_slice' ), $r['slices'] ) : $w['config']['slices'];
		$n      = max( 100, min( 100000, (int) ( $r['n'] ?? 10000 ) ) );
		$cands  = array();
		foreach ( $slices as $i => $s ) {
			if ( (float) $s['weight'] > 0 ) {
				$cands[ $i ] = $s;
			}
		}
		$hits = array_fill( 0, count( $slices ), 0 );
		for ( $k = 0; $k < $n; $k++ ) {
			$i = Picker::draw( $cands );
			if ( $i >= 0 ) {
				++$hits[ $i ];
			}
		}
		$out = array();
		foreach ( $slices as $i => $s ) {
			$out[] = array( 'id' => $s['id'], 'label' => $s['label'], 'hits' => $hits[ $i ], 'pct' => round( $hits[ $i ] / $n * 100, 2 ) );
		}
		return array( 'n' => $n, 'rows' => $out, 'expected' => Picker::odds( $slices ) );
	}

	public function wheel_export( \WP_REST_Request $r ) {
		$w = becharkhoon()->wheels->get( (int) $r['id'] );
		if ( ! $w ) {
			return new \WP_Error( 'not_found', 'Wheel not found', array( 'status' => 404 ) );
		}
		$rules = array_values(
			array_filter(
				Rules::all(),
				static function ( $x ) use ( $w ) {
					return (int) $x['wheel_id'] === (int) $w['id'];
				}
			)
		);
		return array( 'becharkhoon' => BCH_VERSION, 'title' => $w['title'], 'config' => $w['config'], 'rules' => $rules );
	}

	public function wheel_import( \WP_REST_Request $r ) {
		$data = $r['data'];
		if ( is_string( $data ) ) {
			$data = json_decode( $data, true );
		}
		if ( ! is_array( $data ) || empty( $data['config'] ) || ! is_array( $data['config'] ) ) {
			return new \WP_Error( 'invalid', Lang::t( 'فایل معتبر نیست.', 'Invalid file.' ), array( 'status' => 400 ) );
		}
		$cfg = Schema::sanitize( Schema::merge( Schema::defaults(), $data['config'] ) );
		$id  = becharkhoon()->wheels->create( sanitize_text_field( $data['title'] ?? 'Imported wheel' ), $cfg, 'draft' );
		if ( $id && ! empty( $data['rules'] ) && is_array( $data['rules'] ) ) {
			$rules = Rules::all();
			foreach ( $data['rules'] as $rule ) {
				if ( is_array( $rule ) ) {
					$rule['id']       = '';
					$rule['wheel_id'] = $id;
					$rules[]          = $rule;
				}
			}
			Rules::save_all( $rules );
		}
		return array( 'id' => $id );
	}

	public function wheel_codes( \WP_REST_Request $r ) {
		$id    = (int) $r['id'];
		$slice = substr( preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $r['slice_id'] ), 0, 40 );
		if ( 'clear' === $r['action'] ) {
			CodePool::clear_unused( $id, $slice );
		} elseif ( 'import' === $r['action'] ) {
			CodePool::import( $id, $slice, (string) $r['codes'] );
		}
		return array( 'pools' => CodePool::summary( $id ) );
	}

	/* ---------- spins ---------- */

	public function spins( \WP_REST_Request $r ) {
		global $wpdb;
		$where  = array( '1=1' );
		$params = array();
		if ( $r['wheel_id'] ) {
			$where[]  = 'wheel_id = %d';
			$params[] = absint( $r['wheel_id'] );
		}
		if ( $r['result'] ) {
			$where[]  = 'result = %s';
			$params[] = sanitize_key( $r['result'] );
		}
		if ( $r['status'] ) {
			$where[]  = 'status = %s';
			$params[] = sanitize_key( $r['status'] );
		}
		if ( $r['search'] ) {
			$s        = '%' . $wpdb->esc_like( Helpers::latin_digits( sanitize_text_field( $r['search'] ) ) ) . '%';
			$where[]  = '(phone LIKE %s OR email LIKE %s OR name LIKE %s OR coupon_code LIKE %s OR slice_label LIKE %s OR ip LIKE %s)';
			$params   = array_merge( $params, array( $s, $s, $s, $s, $s, $s ) );
		}
		if ( $r['from'] ) {
			$where[]  = 'created_at >= %s';
			$params[] = Stats::utc( sanitize_text_field( $r['from'] ) . ' 00:00:00' );
		}
		if ( $r['to'] ) {
			$where[]  = 'created_at <= %s';
			$params[] = Stats::utc( sanitize_text_field( $r['to'] ) . ' 23:59:59' );
		}
		$w     = implode( ' AND ', $where );
		$per   = max( 1, min( 200, (int) ( $r['per_page'] ?? 25 ) ) );
		$page  = max( 1, (int) ( $r['page'] ?? 1 ) );
		$total = (int) $wpdb->get_var( $params ? $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}bch_spins WHERE $w", $params ) : "SELECT COUNT(*) FROM {$wpdb->prefix}bch_spins WHERE $w" ); // phpcs:ignore
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bch_spins WHERE $w ORDER BY id DESC LIMIT %d OFFSET %d", array_merge( $params, array( $per, ( $page - 1 ) * $per ) ) ), ARRAY_A ); // phpcs:ignore
		$titles = array();
		foreach ( becharkhoon()->wheels->all() as $wh ) {
			$titles[ $wh['id'] ] = $wh['title'];
		}
		foreach ( $rows as &$row ) {
			$row['meta']   = Helpers::json_decode_array( $row['meta'] );
			$row['wheel']  = $titles[ (int) $row['wheel_id'] ] ?? '#' . $row['wheel_id'];
			$row['created_local'] = get_date_from_gmt( $row['created_at'] );
			$row['coupon_state']  = $row['coupon_id'] ? \Becharkhoon\Prizes\Coupons::state( $row['coupon_code'] ) : '';
			$row['edit_coupon']   = $row['coupon_id'] ? admin_url( 'post.php?post=' . (int) $row['coupon_id'] . '&action=edit' ) : '';
			$row['edit_order']    = $row['order_id'] ? admin_url( 'post.php?post=' . (int) $row['order_id'] . '&action=edit' ) : '';
		}
		return array( 'items' => $rows, 'total' => $total );
	}

	public function spin_update( \WP_REST_Request $r ) {
		global $wpdb;
		$status = sanitize_key( (string) $r['status'] );
		if ( ! in_array( $status, array( 'issued', 'pending', 'claimed', 'delivered', 'redeemed', 'expired', 'revoked' ), true ) ) {
			return new \WP_Error( 'invalid', 'Invalid status', array( 'status' => 400 ) );
		}
		$id   = (int) $r['id'];
		$spin = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bch_spins WHERE id = %d", $id ), ARRAY_A );
		if ( ! $spin ) {
			return new \WP_Error( 'not_found', 'Not found', array( 'status' => 404 ) );
		}
		$wpdb->update( $wpdb->prefix . 'bch_spins', array( 'status' => $status ), array( 'id' => $id ) );
		if ( 'revoked' === $status && $spin['coupon_id'] ) {
			wp_trash_post( (int) $spin['coupon_id'] );
		}
		if ( null !== $r['note'] ) {
			$meta         = Helpers::json_decode_array( $spin['meta'] );
			$meta['note'] = sanitize_textarea_field( (string) $r['note'] );
			$wpdb->update( $wpdb->prefix . 'bch_spins', array( 'meta' => wp_json_encode( $meta, JSON_UNESCAPED_UNICODE ) ), array( 'id' => $id ) );
		}
		return array( 'ok' => true );
	}

	public function spin_delete( \WP_REST_Request $r ) {
		global $wpdb;
		$wpdb->delete( $wpdb->prefix . 'bch_spins', array( 'id' => (int) $r['id'] ) );
		return array( 'ok' => true );
	}

	public function spin_resend( \WP_REST_Request $r ) {
		global $wpdb;
		$spin = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bch_spins WHERE id = %d", (int) $r['id'] ), ARRAY_A );
		$w    = $spin ? becharkhoon()->wheels->get( (int) $spin['wheel_id'] ) : null;
		if ( ! $spin || ! $w ) {
			return new \WP_Error( 'not_found', 'Not found', array( 'status' => 404 ) );
		}
		$n    = $w['config']['notify'];
		$vars = becharkhoon()->notifier->vars_for_spin( $spin, $w );
		$ok   = false;
		if ( 'email' === $r['channel'] && is_email( $spin['email'] ) ) {
			$ok = becharkhoon()->notifier->email( $spin['email'], Helpers::tpl( $n['email_subject'], $vars ), $n['email_heading'], Helpers::tpl( $n['email_body'], array_map( 'esc_html', $vars ) ), $vars['link'], $n['email_button'] );
		} elseif ( '' !== $spin['phone'] ) {
			$res = Sms::send_event( 'lose' === $spin['result'] ? 'lose' : 'win', $vars, $spin['phone'], array( 'force' => true, 'context' => 'resend', 'wheel_id' => (int) $w['id'], 'override' => \Becharkhoon\Notify\Notifier::wheel_override( $w, 'lose' === $spin['result'] ? 'lose' : 'win' ) ) );
			$ok  = $res['sent'] > 0;
		}
		return array( 'ok' => (bool) $ok );
	}

	/* ---------- leads ---------- */

	public function leads( \WP_REST_Request $r ) {
		return Leads::query( array( 'search' => sanitize_text_field( (string) $r['search'] ), 'wheel_id' => absint( $r['wheel_id'] ), 'marketing' => (bool) $r['marketing'], 'verified' => (bool) $r['verified'], 'page' => (int) $r['page'], 'per_page' => (int) ( $r['per_page'] ?? 25 ) ) );
	}

	public function lead_delete( \WP_REST_Request $r ) {
		global $wpdb;
		$wpdb->delete( $wpdb->prefix . 'bch_leads', array( 'id' => (int) $r['id'] ) );
		return array( 'ok' => true );
	}

	/** Bulk SMS to leads who opted in to marketing (max 500 per call). */
	public function leads_sms( \WP_REST_Request $r ) {
		$text = sanitize_textarea_field( (string) $r['text'] );
		if ( '' === trim( $text ) ) {
			return new \WP_Error( 'invalid', 'Empty text', array( 'status' => 400 ) );
		}
		$res  = Leads::query( array( 'marketing' => ! empty( $r['only_marketing'] ), 'verified' => ! empty( $r['only_verified'] ), 'per_page' => 500, 'page' => max( 1, (int) $r['page'] ) ) );
		$msgs = array();
		$gen  = SmsEvents::general_vars();
		foreach ( $res['items'] as $l ) {
			if ( '' !== $l['phone'] ) {
				$msgs[] = array( 'mobile' => $l['phone'], 'text' => Sms::render( $text, array_merge( $gen, array( 'name' => '' !== trim( (string) $l['name'] ) ? $l['name'] : Lang::t( 'مشتری', 'customer' ), 'mobile' => $l['phone'], 'email' => $l['email'] ) ) ) );
			}
		}
		$out = $msgs ? Sms::send_many( $msgs, 'bulk' ) : array( 'sent' => 0, 'failed' => 0, 'mode' => Sms::mode() );
		return array( 'sent' => $out['sent'], 'failed' => $out['failed'], 'mode' => $out['mode'], 'total' => $res['total'] );
	}

	/* ---------- advanced bulk SMS (+ real spin grants) ---------- */

	public function bulk_preview( \WP_REST_Request $r ) {
		return \Becharkhoon\Notify\Bulk::preview( (array) $r->get_json_params() );
	}

	public function bulk_start( \WP_REST_Request $r ) {
		return \Becharkhoon\Notify\Bulk::start( (array) $r->get_json_params() );
	}

	public function bulk_step( \WP_REST_Request $r ) {
		return \Becharkhoon\Notify\Bulk::step( (string) $r['job'] );
	}

	public function bulk_campaigns( \WP_REST_Request $r ) {
		return \Becharkhoon\Notify\Bulk::campaigns( array( 'page' => (int) $r['page'], 'per_page' => (int) ( $r['per_page'] ?? 20 ), 'status' => (string) $r['status'], 'search' => sanitize_text_field( (string) $r['search'] ) ) );
	}

	/** The open admin page keeps due batches moving even when WP-Cron is slow. */
	public function bulk_tick( \WP_REST_Request $r ) {
		$n = \Becharkhoon\Notify\Bulk::run( absint( $r['id'] ) );
		return array( 'processed' => $n, 'campaign' => absint( $r['id'] ) ? \Becharkhoon\Notify\Bulk::get( absint( $r['id'] ) ) : null );
	}

	public function bulk_get( \WP_REST_Request $r ) {
		$c = \Becharkhoon\Notify\Bulk::get( absint( $r['id'] ) );
		return $c ? $c : new \WP_Error( 'not_found', 'Not found', array( 'status' => 404 ) );
	}

	public function bulk_items( \WP_REST_Request $r ) {
		return \Becharkhoon\Notify\Bulk::items( absint( $r['id'] ), array( 'page' => (int) $r['page'], 'per_page' => (int) ( $r['per_page'] ?? 50 ), 'status' => (string) $r['status'], 'batch' => (int) $r['batch'], 'search' => sanitize_text_field( (string) $r['search'] ) ) );
	}

	public function bulk_action( \WP_REST_Request $r ) {
		$p = (array) $r->get_json_params();
		return \Becharkhoon\Notify\Bulk::action( absint( $r['id'] ), sanitize_key( (string) ( $p['do'] ?? '' ) ), array( 'scope' => sanitize_key( (string) ( $p['scope'] ?? 'problem' ) ), 'ids' => (array) ( $p['ids'] ?? array() ) ) );
	}

	/* ---------- credits ---------- */

	public function credits( \WP_REST_Request $r ) {
		return Ledger::query( array( 'search' => sanitize_text_field( (string) $r['search'] ), 'wheel_id' => absint( $r['wheel_id'] ), 'status' => sanitize_key( (string) $r['status'] ), 'reason' => sanitize_key( (string) $r['reason'] ), 'page' => (int) $r['page'], 'per_page' => (int) ( $r['per_page'] ?? 25 ) ) );
	}

	/* ---------- people (user spins) ---------- */

	private function period( \WP_REST_Request $r ) {
		return \Becharkhoon\Stats\Reports::period( (string) $r['from'], (string) $r['to'] );
	}

	public function people( \WP_REST_Request $r ) {
		$p = $this->period( $r );
		return array_merge(
			\Becharkhoon\Stats\People::query( array( 'from_utc' => $p['from_utc'], 'to_utc' => $p['to_utc'], 'wheel_id' => absint( $r['wheel_id'] ), 'search' => sanitize_text_field( (string) $r['search'] ), 'only' => sanitize_key( (string) $r['only'] ), 'sort' => sanitize_key( (string) $r['sort'] ), 'page' => (int) $r['page'], 'per_page' => (int) ( $r['per_page'] ?? 25 ) ) ),
			array( 'period' => $p, 'credits' => Ledger::totals() )
		);
	}

	public function people_events( \WP_REST_Request $r ) {
		$p = $this->period( $r );
		return \Becharkhoon\Stats\People::events( array( 'from_utc' => $p['from_utc'], 'to_utc' => $p['to_utc'], 'wheel_id' => absint( $r['wheel_id'] ), 'search' => sanitize_text_field( (string) $r['search'] ), 'person' => sanitize_text_field( (string) $r['person'] ), 'type' => sanitize_key( (string) $r['type'] ), 'page' => (int) $r['page'], 'per_page' => (int) ( $r['per_page'] ?? 30 ) ) );
	}

	/** How many numbers an export will contain (preview in the export dialog). */
	public function contacts_count( \WP_REST_Request $r ) {
		$all = '' === (string) $r['from'] && '' === (string) $r['to'];
		$p   = $all ? array( 'from_utc' => '1970-01-01 00:00:00', 'to_utc' => '2999-12-31 23:59:59' ) : $this->period( $r );
		$res = \Becharkhoon\Stats\People::contacts( array( 'source' => sanitize_key( (string) $r['source'] ), 'from_utc' => $p['from_utc'], 'to_utc' => $p['to_utc'], 'wheel_id' => absint( $r['wheel_id'] ), 'marketing' => ! empty( $r['marketing'] ), 'verified' => ! empty( $r['verified'] ), 'winners' => ! empty( $r['winners'] ), 'need_phone' => ! empty( $r['need_phone'] ) ) );
		$ph  = 0;
		foreach ( $res['rows'] as $c ) {
			if ( '' !== $c['phone'] ) {
				++$ph;
			}
		}
		return array( 'total' => count( $res['rows'] ), 'phones' => $ph, 'fields' => $res['fields'] );
	}

	/* ---------- advanced reports (real WooCommerce money) ---------- */

	public function reports( \WP_REST_Request $r ) {
		return \Becharkhoon\Stats\Reports::build( array( 'from' => (string) $r['from'], 'to' => (string) $r['to'], 'wheel' => absint( $r['wheel'] ), 'basis' => sanitize_key( (string) $r['basis'] ), 'statuses' => (string) $r['statuses'] ) );
	}

	public function reports_orders( \WP_REST_Request $r ) {
		$p = $this->period( $r );
		return \Becharkhoon\Stats\Orders::query( $p['from_utc'], $p['to_utc'], \Becharkhoon\Stats\Reports::statuses( (string) $r['statuses'] ), sanitize_key( (string) $r['basis'] ), absint( $r['wheel'] ), sanitize_text_field( (string) $r['search'] ), (int) $r['page'], (int) ( $r['per_page'] ?? 20 ) );
	}

	/** Sync past WooCommerce orders in batches (the page calls this until done). */
	public function reports_sync( \WP_REST_Request $r ) {
		if ( ! empty( $r['restart'] ) ) {
			\Becharkhoon\Stats\Orders::restart( false );
		}
		$t = microtime( true );
		do {
			$s = \Becharkhoon\Stats\Orders::backfill( 500 );
		} while ( ! $s['done'] && microtime( true ) - $t < 8 );
		return $s;
	}

	/** Manual grant to users / phones / emails (lists). */
	public function credits_grant( \WP_REST_Request $r ) {
		$qty   = max( 1, min( 100, (int) $r['qty'] ) );
		$wheel = absint( $r['wheel_id'] );
		$days  = max( 0, (int) $r['expires_days'] );
		$note  = sanitize_text_field( (string) $r['note'] );
		$n     = 0;
		$args  = array( 'wheel_id' => $wheel, 'qty' => $qty, 'reason' => 'manual', 'note' => $note, 'expires_days' => $days, 'created_by' => get_current_user_id() );
		foreach ( array_slice( array_map( 'absint', (array) $r['user_ids'] ), 0, 500 ) as $uid ) {
			if ( $uid && get_userdata( $uid ) && Ledger::grant( array_merge( $args, array( 'user_id' => $uid ) ) ) ) {
				++$n;
				$this->notify_manual( $args, $uid, '', ! empty( $r['notify'] ) );
			}
		}
		foreach ( array_slice( Helpers::lines( (string) $r['phones'] ), 0, 2000 ) as $p ) {
			$p = Helpers::phone( $p );
			if ( '' !== $p && Ledger::grant( array_merge( $args, array( 'phone' => $p ) ) ) ) {
				++$n;
				$this->notify_manual( $args, 0, $p, ! empty( $r['notify'] ) );
			}
		}
		foreach ( array_slice( Helpers::lines( (string) $r['emails'] ), 0, 2000 ) as $e ) {
			$e    = Helpers::email( $e );
			$user = $e ? get_user_by( 'email', $e ) : null;
			if ( '' !== $e && Ledger::grant( array_merge( $args, array( 'email' => $e, 'user_id' => $user ? $user->ID : 0 ) ) ) ) {
				++$n;
			}
		}
		return array( 'granted' => $n );
	}

	private function notify_manual( array $args, $uid, $phone, $notify ) {
		if ( ! $notify ) {
			return;
		}
		$rule = array_merge( Rules::rule_defaults(), array( 'id' => 'manual', 'title' => $args['note'], 'wheel_id' => $args['wheel_id'], 'notify_sms' => true ) );
		becharkhoon()->notifier->credit_granted( 0, $rule, $args['qty'], array( 'user_id' => $uid, 'phone' => $phone ) );
	}

	/** Bulk grant to a segment (batched by offset). */
	public function credits_bulk( \WP_REST_Request $r ) {
		$qty    = max( 1, min( 100, (int) $r['qty'] ) );
		$wheel  = absint( $r['wheel_id'] );
		$offset = max( 0, (int) $r['offset'] );
		$batch  = 100;
		$role   = sanitize_key( (string) $r['role'] );
		$args   = array( 'number' => $batch, 'offset' => $offset, 'fields' => 'ID', 'orderby' => 'ID' );
		if ( '' !== $role ) {
			$args['role'] = $role;
		}
		$ids        = get_users( $args );
		$min_spent  = (float) $r['min_spent'];
		$min_orders = (int) $r['min_orders'];
		$campaign   = 'bulk:' . sanitize_key( (string) $r['campaign'] );
		$n          = 0;
		foreach ( $ids as $uid ) {
			if ( $min_spent > 0 || $min_orders > 0 ) {
				$ctx          = new \Becharkhoon\Engine\Context();
				$ctx->user_id = (int) $uid;
				if ( $min_orders > 0 && $ctx->order_count() < $min_orders ) {
					continue;
				}
				if ( $min_spent > 0 && $ctx->total_spent() < $min_spent ) {
					continue;
				}
			}
			$ok = Ledger::grant(
				array(
					'wheel_id'     => $wheel,
					'user_id'      => (int) $uid,
					'qty'          => $qty,
					'reason'       => 'bulk',
					'note'         => sanitize_text_field( (string) $r['note'] ),
					'expires_days' => max( 0, (int) $r['expires_days'] ),
					'uniq'         => $campaign . ':' . $uid,
					'created_by'   => get_current_user_id(),
				)
			);
			if ( $ok ) {
				++$n;
			}
		}
		return array( 'granted' => $n, 'next' => count( $ids ) === $batch ? $offset + $batch : 0, 'done' => count( $ids ) < $batch );
	}

	public function credit_revoke( \WP_REST_Request $r ) {
		return array( 'ok' => Ledger::revoke( (int) $r['id'] ) );
	}

	/* ---------- rules ---------- */

	public function rules() {
		return array( 'rules' => Rules::all() );
	}

	public function rules_save( \WP_REST_Request $r ) {
		return array( 'rules' => Rules::save_all( (array) $r['rules'] ) );
	}

	/** Apply an order rule to orders paid in the last N days (one-time catch-up). */
	public function rules_backfill( \WP_REST_Request $r ) {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return new \WP_Error( 'woo', 'WooCommerce required', array( 'status' => 400 ) );
		}
		$rule = null;
		foreach ( Rules::all() as $x ) {
			if ( $x['id'] === sanitize_key( (string) $r['rule_id'] ) ) {
				$rule = $x;
			}
		}
		if ( ! $rule ) {
			return new \WP_Error( 'not_found', 'Rule not found', array( 'status' => 404 ) );
		}
		$days   = max( 1, min( 365, (int) $r['days'] ) );
		$page   = max( 1, (int) $r['page'] );
		$status = $rule['statuses'] ? $rule['statuses'] : (array) becharkhoon()->settings->get( 'order_statuses' );
		$ids    = wc_get_orders(
			array(
				'limit'        => 50,
				'paged'        => $page,
				'return'       => 'ids',
				'status'       => array_map( static function ( $s ) {
					return 'wc-' . $s;
				}, $status ),
				'date_created' => '>' . ( time() - $days * DAY_IN_SECONDS ),
				'orderby'      => 'date',
				'order'        => 'ASC',
			)
		);
		$n = 0;
		foreach ( $ids as $id ) {
			$o = wc_get_order( $id );
			if ( $o && becharkhoon()->rules->apply_order_rule( $rule, $o ) ) {
				++$n;
			}
		}
		return array( 'granted' => $n, 'next' => count( $ids ) === 50 ? $page + 1 : 0 );
	}

	/* ---------- settings ---------- */

	public function settings() {
		return becharkhoon()->settings->for_admin();
	}

	public function settings_save( \WP_REST_Request $r ) {
		$in = $r->get_json_params();
		becharkhoon()->settings->update( is_array( $in ) ? $in : array() );
		Lang::reset();
		if ( isset( $in['myaccount_slug'] ) ) {
			\Becharkhoon\Front\Account::add_endpoint();
			flush_rewrite_rules( false );
		}
		return becharkhoon()->settings->for_admin();
	}

	public function test( \WP_REST_Request $r ) {
		$what = (string) $r['what'];
		$n    = becharkhoon()->notifier;
		switch ( $what ) {
			case 'sms':
				$to = Helpers::phone( (string) $r['to'] );
				if ( '' === $to ) {
					return new \WP_Error( 'invalid', Lang::t( 'شماره موبایل معتبر نیست.', 'Invalid mobile number.' ), array( 'status' => 400 ) );
				}
				$event = sanitize_key( (string) $r['event'] );
				$vars  = array_merge( SmsEvents::sample_vars(), array( 'mobile' => $to ) );
				if ( '' !== $event && SmsEvents::get( $event ) ) {
					$msg = Sms::build( $event, $vars, $to, is_array( $r['template'] ) ? $r['template'] : null );
				} else {
					$msg = array( 'mobile' => $to, 'text' => '' !== trim( (string) $r['text'] ) ? Sms::render( sanitize_textarea_field( (string) $r['text'] ), $vars ) : Lang::t( 'پیامک آزمایشی بچرخون ✓', 'Becharkhoon test SMS ✓' ) . "\n" . $vars['site'] );
				}
				$res = Sms::send_many( array( $msg ), 'test' );
				return array(
					'ok'       => $res['sent'] > 0,
					'mode'     => $res['mode'],
					'message'  => isset( $msg['pattern'] ) ? '[' . $msg['pattern']['code'] . '] ' . wp_json_encode( $msg['pattern']['params'], JSON_UNESCAPED_UNICODE ) : $msg['text'],
					'response' => $res['response'],
				);
			case 'credit':
				$c = SmsGateways::credit( (string) becharkhoon()->settings->get( 'sms_driver' ) );
				return is_wp_error( $c ) ? array( 'ok' => false, 'message' => wp_strip_all_tags( $c->get_error_message() ) ) : array( 'ok' => true, 'message' => (string) $c );
			case 'otp':
				$to = Helpers::phone( (string) $r['to'] );
				return array( 'ok' => '' !== $to && $n->otp( $to, '12345' ), 'mode' => Sms::mode() );
			case 'email':
				$to = is_email( (string) $r['to'] ) ? (string) $r['to'] : get_option( 'admin_email' );
				return array( 'ok' => $n->email( $to, Lang::t( 'ایمیل آزمایشی بچرخون', 'Becharkhoon test email' ), Lang::t( 'تبریک! ایمیل کار می‌کند', 'It works!' ), '<p>' . esc_html( Lang::t( 'این یک ایمیل آزمایشی است.', 'This is a test email.' ) ) . '</p>', home_url( '/' ), Lang::t( 'مشاهده سایت', 'Visit site' ) ) );
			case 'messenger':
				return array( 'ok' => $n->messenger( '🎡 ARIAGH.BECHARKHOON ✓ ' . get_bloginfo( 'name' ) ) );
			case 'webhook':
				$n->webhook( 'spin', array( 'test' => true, 'prize' => '10%', 'code' => 'TEST-1234' ) );
				return array( 'ok' => true );
		}
		return new \WP_Error( 'invalid', 'Unknown test', array( 'status' => 400 ) );
	}

	/* ---------- SMS log + preview ---------- */

	public function sms_log( \WP_REST_Request $r ) {
		return Sms::log_query( array( 'search' => sanitize_text_field( (string) $r['search'] ), 'status' => sanitize_key( (string) $r['status'] ), 'context' => sanitize_key( (string) $r['context'] ), 'page' => (int) $r['page'], 'per_page' => (int) ( $r['per_page'] ?? 30 ) ) );
	}

	public function sms_log_clear() {
		Sms::clear_log();
		return array( 'ok' => true );
	}

	/** Render an (unsaved) template with sample values exactly as the sender will. */
	public function sms_preview( \WP_REST_Request $r ) {
		$event = sanitize_key( (string) $r['event'] );
		$tpl   = is_array( $r['template'] ) ? $r['template'] : array();
		$msg   = Sms::build( $event, SmsEvents::sample_vars(), '09120000000', $tpl );
		return array( 'text' => $msg['text'], 'pattern' => $msg['pattern'] ?? null, 'unknown' => SmsEvents::unknown_vars( $event, (string) ( $tpl['text'] ?? '' ) . "\n" . (string) ( $tpl['params'] ?? '' ) ) );
	}

	/* ---------- logs ---------- */

	public function logs( \WP_REST_Request $r ) {
		return Logger::query( array( 'channel' => sanitize_key( (string) $r['channel'] ), 'level' => sanitize_key( (string) $r['level'] ), 'page' => (int) $r['page'], 'per_page' => (int) ( $r['per_page'] ?? 50 ) ) );
	}

	public function logs_clear() {
		global $wpdb;
		$wpdb->query( "DELETE FROM {$wpdb->prefix}bch_log" );
		return array( 'ok' => true );
	}

	/* ---------- search (pickers) ---------- */

	public function search( \WP_REST_Request $r ) {
		$q    = sanitize_text_field( (string) $r['q'] );
		$ids  = array_filter( array_map( 'absint', explode( ',', (string) $r['ids'] ) ) );
		$out  = array();
		switch ( (string) $r['what'] ) {
			case 'products':
				$args = array( 'post_type' => array( 'product', 'product_variation' ), 'posts_per_page' => 20, 'post_status' => 'publish', 'fields' => 'ids' );
				if ( $ids ) {
					$args['post__in'] = $ids;
				} else {
					$args['s'] = $q;
				}
				foreach ( get_posts( $args ) as $id ) {
					$out[] = array( 'value' => $id, 'label' => html_entity_decode( get_the_title( $id ) ) . ' (#' . $id . ')' );
				}
				break;
			case 'categories':
				$args = array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'number' => 30 );
				if ( $ids ) {
					$args['include'] = $ids;
				} else {
					$args['search'] = $q;
				}
				foreach ( (array) get_terms( $args ) as $t ) {
					if ( $t instanceof \WP_Term ) {
						$out[] = array( 'value' => $t->term_id, 'label' => html_entity_decode( $t->name ) );
					}
				}
				break;
			case 'users':
				$args = array( 'number' => 20, 'fields' => array( 'ID', 'display_name', 'user_email' ) );
				if ( $ids ) {
					$args['include'] = $ids;
				} else {
					$args['search']         = '*' . $q . '*';
					$args['search_columns'] = array( 'user_login', 'user_email', 'display_name', 'user_nicename' );
				}
				$users = get_users( $args );
				if ( ! $ids && preg_match( '/\d{6,}/', Helpers::latin_digits( $q ) ) ) {
					$users = array_merge( $users, get_users( array( 'number' => 10, 'meta_key' => 'billing_phone', 'meta_value' => Helpers::phone( $q ) ? Helpers::phone( $q ) : Helpers::latin_digits( $q ), 'fields' => array( 'ID', 'display_name', 'user_email' ) ) ) ); // phpcs:ignore
				}
				foreach ( $users as $u ) {
					$out[ $u->ID ] = array( 'value' => (int) $u->ID, 'label' => $u->display_name . ' — ' . $u->user_email );
				}
				$out = array_values( $out );
				break;
			case 'coupons':
				foreach ( get_posts( array( 'post_type' => 'shop_coupon', 'posts_per_page' => 20, 's' => $q, 'post_status' => 'publish' ) ) as $p ) {
					$out[] = array( 'value' => strtolower( $p->post_title ), 'label' => $p->post_title );
				}
				break;
			case 'pages':
				foreach ( get_posts( array( 'post_type' => array( 'page', 'post', 'product' ), 'posts_per_page' => 20, 's' => $q, 'post_status' => 'publish' ) ) as $p ) {
					$out[] = array( 'value' => $p->ID, 'label' => html_entity_decode( $p->post_title ) . ' (#' . $p->ID . ', ' . $p->post_type . ')' );
				}
				break;
		}
		return $out;
	}

	/* ---------- tools ---------- */

	public function status() {
		global $wpdb;
		$tables = array();
		foreach ( Installer::tables() as $t ) {
			$tables[ $t ] = (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->prefix . $t ) );
		}
		$caches = array();
		foreach ( array( 'LSCWP_V' => 'LiteSpeed Cache', 'WP_ROCKET_VERSION' => 'WP Rocket', 'W3TC' => 'W3 Total Cache', 'WPCACHEHOME' => 'WP Super Cache', 'WPFC_MAIN_PATH' => 'WP Fastest Cache', 'AUTOPTIMIZE_PLUGIN_VERSION' => 'Autoptimize' ) as $c => $n ) {
			if ( defined( $c ) ) {
				$caches[] = $n;
			}
		}
		if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
			$caches[] = 'SiteGround Optimizer';
		}
		return array(
			'php'       => PHP_VERSION,
			'wp'        => get_bloginfo( 'version' ),
			'woo'       => defined( 'WC_VERSION' ) ? WC_VERSION : '',
			'plugin'    => BCH_VERSION,
			'db'        => (int) get_option( Installer::OPTION_DB ),
			'tables'    => $tables,
			'cron'      => wp_next_scheduled( \Becharkhoon\Core\Cron::HOOK ),
			'cron_disabled' => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON,
			'object_cache' => wp_using_ext_object_cache(),
			'caches'    => $caches,
			'cdn'       => array( 'cloudflare' => ! empty( $_SERVER['HTTP_CF_RAY'] ), 'arvan' => ! empty( $_SERVER['HTTP_AR_REAL_IP'] ) ),
			'ip'        => Helpers::ip( becharkhoon()->settings->get( 'ip_source' ) ),
			'integrations' => Integrations::detected(),
			'timezone'  => wp_timezone_string(),
			'time'      => wp_date( 'Y-m-d H:i' ),
			'counts'    => array(
				'spins'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}bch_spins" ),
				'leads'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}bch_leads" ),
				'credits' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}bch_credits" ),
			),
		);
	}

	public function tool( \WP_REST_Request $r ) {
		switch ( (string) $r['what'] ) {
			case 'reset_stats':
				Stats::reset( absint( $r['wheel_id'] ) );
				return array( 'ok' => true );
			case 'repair':
				Installer::install();
				return array( 'ok' => true );
			case 'run_cron':
				( new \Becharkhoon\Core\Cron() )->run();
				return array( 'ok' => true );
			case 'flush_cache':
				becharkhoon()->wheels->flush();
				foreach ( array( 'litespeed_purge_all', 'rocket_clean_domain', 'w3tc_flush_all', 'wp_cache_clear_cache', 'sg_cachepress_purge_cache' ) as $fn ) {
					if ( function_exists( $fn ) ) {
						call_user_func( $fn );
					}
				}
				do_action( 'litespeed_purge_all' );
				return array( 'ok' => true );
			case 'export_all':
				$wheels = array();
				foreach ( becharkhoon()->wheels->all() as $w ) {
					$wheels[] = array( 'title' => $w['title'], 'status' => $w['status'], 'config' => $w['config'] );
				}
				$settings = becharkhoon()->settings->all();
				foreach ( Settings_Secrets::keys() as $k ) {
					unset( $settings[ $k ] );
				}
				unset( $settings['sms_fields'] );
				return array( 'becharkhoon' => BCH_VERSION, 'settings' => $settings, 'rules' => Rules::all(), 'wheels' => $wheels );
			case 'import_all':
				$data = is_string( $r['data'] ) ? json_decode( $r['data'], true ) : $r['data'];
				if ( ! is_array( $data ) ) {
					return new \WP_Error( 'invalid', Lang::t( 'فایل معتبر نیست.', 'Invalid file.' ), array( 'status' => 400 ) );
				}
				if ( ! empty( $data['settings'] ) && is_array( $data['settings'] ) ) {
					becharkhoon()->settings->update( $data['settings'] );
				}
				$n = 0;
				foreach ( (array) ( $data['wheels'] ?? array() ) as $w ) {
					if ( is_array( $w ) && ! empty( $w['config'] ) ) {
						becharkhoon()->wheels->create( (string) ( $w['title'] ?? 'Imported' ), Schema::sanitize( Schema::merge( Schema::defaults(), (array) $w['config'] ) ), 'draft' );
						++$n;
					}
				}
				if ( ! empty( $data['rules'] ) && is_array( $data['rules'] ) && ! empty( $r['with_rules'] ) ) {
					Rules::save_all( array_merge( Rules::all(), $data['rules'] ) );
				}
				return array( 'ok' => true, 'wheels' => $n );
			case 'erase_person':
				$email = Helpers::email( (string) $r['email'] );
				$phone = Helpers::phone( (string) $r['phone'] );
				global $wpdb;
				$n = 0;
				if ( '' !== $phone ) {
					$n += Sms::erase_phone( $phone );
					$n += (int) $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}bch_spins SET phone = '', name = '', email = '', ip = '', device = '' WHERE phone = %s", $phone ) );
					$n += (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}bch_leads WHERE phone = %s", $phone ) );
				}
				if ( '' !== $email ) {
					$n += (int) $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}bch_spins SET phone = '', name = '', email = '', ip = '', device = '' WHERE email = %s", $email ) );
					$n += (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}bch_leads WHERE email = %s", $email ) );
				}
				return array( 'ok' => true, 'rows' => $n );
		}
		return new \WP_Error( 'invalid', 'Unknown tool', array( 'status' => 400 ) );
	}

	public function user_block( \WP_REST_Request $r ) {
		$uid = (int) $r['id'];
		if ( ! get_userdata( $uid ) ) {
			return new \WP_Error( 'not_found', 'User not found', array( 'status' => 404 ) );
		}
		if ( $r['blocked'] ) {
			update_user_meta( $uid, 'bch_blocked', 1 );
		} else {
			delete_user_meta( $uid, 'bch_blocked' );
		}
		return array( 'ok' => true );
	}
}

/** Secret setting keys stripped from exports. */
final class Settings_Secrets {
	public static function keys() {
		return array_merge( \Becharkhoon\Core\Settings::secret_keys(), array( 'captcha_site_key' ) );
	}
}
