<?php
/**
 * Fixed-window rate limiter (object cache when available, transients otherwise).
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Core;

defined( 'ABSPATH' ) || exit;

final class RateLimit {

	/**
	 * Count a hit and report whether the caller is still under the limit.
	 *
	 * @param string $bucket Bucket name (e.g. "spin:1.2.3.4").
	 * @param int    $limit  Max hits per window (0 = unlimited).
	 * @param int    $window Window in seconds.
	 */
	public static function hit( $bucket, $limit, $window = 60 ) {
		$limit = (int) $limit;
		if ( $limit <= 0 ) {
			return true;
		}
		$key = 'bch_rl_' . md5( $bucket . '|' . (int) floor( time() / $window ) );
		if ( wp_using_ext_object_cache() ) {
			wp_cache_add( $key, 0, 'bch', $window + 5 );
			$n = (int) wp_cache_incr( $key, 1, 'bch' );
		} else {
			$n = (int) get_transient( $key ) + 1;
			set_transient( $key, $n, $window + 5 );
		}
		return $n <= $limit;
	}
}
