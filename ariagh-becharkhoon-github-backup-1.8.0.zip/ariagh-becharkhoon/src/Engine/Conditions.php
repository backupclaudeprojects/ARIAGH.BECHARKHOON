<?php
/**
 * Conditions engine shared by targeting, spin eligibility, prize (slice) rules and earning rules.
 * A set = { enabled, groups: [ [cond, cond], [cond] ] } → OR between groups, AND inside a group.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Engine;

use Becharkhoon\Core\Helpers;

defined( 'ABSPATH' ) || exit;

final class Conditions {

	const NUM  = array( 'gte', 'gt', 'lte', 'lt', 'eq', 'neq', 'between' );
	const LIST = array( 'in', 'not_in' );
	const BOOL = array( 'is_true', 'is_false' );
	const TEXT = array( 'contains', 'not_contains', 'eq', 'neq', 'starts', 'ends', 'empty', 'not_empty' );

	/**
	 * Catalog: type => [group, input, ops, contexts].
	 * input: number|money|bool|text|roles|users|products|cats|devices|weekdays|page_types|payment|shipping|kv|date|countries|langs|browsers|os
	 * contexts: any = all; order = only earning rules (needs an order).
	 */
	public static function catalog() {
		return array(
			// User.
			'logged_in'        => array( 'user', 'bool', self::BOOL, 'any' ),
			'user_role'        => array( 'user', 'roles', self::LIST, 'any' ),
			'user_id'          => array( 'user', 'users', self::LIST, 'any' ),
			'registered_days'  => array( 'user', 'number', self::NUM, 'any' ),
			'order_count'      => array( 'user', 'number', self::NUM, 'any' ),
			'total_spent'      => array( 'user', 'money', self::NUM, 'any' ),
			'avg_order'        => array( 'user', 'money', self::NUM, 'any' ),
			'last_order_days'  => array( 'user', 'number', self::NUM, 'any' ),
			'bought_product'   => array( 'user', 'products', self::LIST, 'any' ),
			'bought_category'  => array( 'user', 'cats', self::LIST, 'any' ),
			'phone_verified'   => array( 'user', 'bool', self::BOOL, 'any' ),
			'has_phone'        => array( 'user', 'bool', self::BOOL, 'any' ),
			'user_meta'        => array( 'user', 'kv', self::TEXT, 'any' ),
			'wheel_spins'      => array( 'user', 'number', self::NUM, 'any' ),
			'wheel_wins'       => array( 'user', 'number', self::NUM, 'any' ),
			// Cart.
			'cart_total'       => array( 'cart', 'money', self::NUM, 'any' ),
			'cart_subtotal'    => array( 'cart', 'money', self::NUM, 'any' ),
			'cart_items'       => array( 'cart', 'number', self::NUM, 'any' ),
			'cart_product'     => array( 'cart', 'products', self::LIST, 'any' ),
			'cart_category'    => array( 'cart', 'cats', self::LIST, 'any' ),
			'cart_has_coupon'  => array( 'cart', 'bool', self::BOOL, 'any' ),
			// Order (earning rules).
			'order_total'      => array( 'order', 'money', self::NUM, 'order' ),
			'order_subtotal'   => array( 'order', 'money', self::NUM, 'order' ),
			'order_items'      => array( 'order', 'number', self::NUM, 'order' ),
			'order_number'     => array( 'order', 'number', self::NUM, 'order' ),
			'order_product'    => array( 'order', 'products', self::LIST, 'order' ),
			'order_category'   => array( 'order', 'cats', self::LIST, 'order' ),
			'payment_method'   => array( 'order', 'payment', self::LIST, 'order' ),
			'shipping_method'  => array( 'order', 'shipping', self::LIST, 'order' ),
			'order_coupon'     => array( 'order', 'text', self::TEXT, 'order' ),
			'billing_city'     => array( 'order', 'text', self::TEXT, 'order' ),
			'billing_state'    => array( 'order', 'text', self::TEXT, 'order' ),
			'created_via'      => array( 'order', 'text', self::TEXT, 'order' ),
			// Visitor / page.
			'device'           => array( 'visitor', 'devices', self::LIST, 'any' ),
			'page_type'        => array( 'visitor', 'page_types', self::LIST, 'any' ),
			'url'              => array( 'visitor', 'text', self::TEXT, 'any' ),
			'referrer'         => array( 'visitor', 'text', self::TEXT, 'any' ),
			'utm_source'       => array( 'visitor', 'text', self::TEXT, 'any' ),
			'utm_medium'       => array( 'visitor', 'text', self::TEXT, 'any' ),
			'utm_campaign'     => array( 'visitor', 'text', self::TEXT, 'any' ),
			'query_param'      => array( 'visitor', 'kv', self::TEXT, 'any' ),
			'cookie'           => array( 'visitor', 'kv', self::TEXT, 'any' ),
			'visit_count'      => array( 'visitor', 'number', self::NUM, 'any' ),
			'new_visitor'      => array( 'visitor', 'bool', self::BOOL, 'any' ),
			'country'          => array( 'visitor', 'countries', self::LIST, 'any' ),
			'language'         => array( 'visitor', 'langs', self::LIST, 'any' ),
			'browser'          => array( 'visitor', 'browsers', self::LIST, 'any' ),
			'os'               => array( 'visitor', 'os', self::LIST, 'any' ),
			// Time (site timezone).
			'weekday'          => array( 'time', 'weekdays', self::LIST, 'any' ),
			'hour'             => array( 'time', 'number', self::NUM, 'any' ),
			'date'             => array( 'time', 'date', self::NUM, 'any' ),
		);
	}

	/** Sanitize a condition set coming from the admin. */
	public static function sanitize_set( $set ) {
		$set     = is_array( $set ) ? $set : array();
		$catalog = self::catalog();
		$groups  = array();
		foreach ( array_slice( (array) ( $set['groups'] ?? array() ), 0, 10 ) as $group ) {
			$conds = array();
			foreach ( array_slice( (array) $group, 0, 15 ) as $c ) {
				if ( ! is_array( $c ) || ! isset( $c['type'], $catalog[ $c['type'] ] ) ) {
					continue;
				}
				$ops = $catalog[ $c['type'] ][2];
				$op  = in_array( $c['op'] ?? '', $ops, true ) ? $c['op'] : $ops[0];
				$val = $c['value'] ?? '';
				if ( is_array( $val ) ) {
					$val = array_values( array_map( 'sanitize_text_field', array_map( 'strval', array_slice( $val, 0, 200 ) ) ) );
				} else {
					$val = sanitize_text_field( (string) $val );
				}
				$conds[] = array(
					'type'  => $c['type'],
					'op'    => $op,
					'value' => $val,
					'value2' => isset( $c['value2'] ) ? sanitize_text_field( (string) $c['value2'] ) : '',
					'key'   => isset( $c['key'] ) ? sanitize_text_field( (string) $c['key'] ) : '',
				);
			}
			if ( $conds ) {
				$groups[] = $conds;
			}
		}
		return array(
			'enabled' => ! empty( $set['enabled'] ) && Helpers::bool( $set['enabled'] ),
			'groups'  => $groups,
		);
	}

	/**
	 * Evaluate a set. Disabled/empty sets pass.
	 *
	 * @param array   $set Set.
	 * @param Context $ctx Context.
	 * @param array   $fail Filled with the first failing condition of the closest group (for messages).
	 */
	public static function passes( $set, Context $ctx, &$fail = null ) {
		if ( empty( $set['enabled'] ) || empty( $set['groups'] ) ) {
			return true;
		}
		foreach ( $set['groups'] as $group ) {
			$ok = true;
			foreach ( $group as $cond ) {
				if ( ! self::check( $cond, $ctx ) ) {
					$ok = false;
					if ( null === $fail ) {
						$fail = $cond;
					}
					break;
				}
			}
			if ( $ok ) {
				return true;
			}
		}
		return false;
	}

	public static function check( array $c, Context $ctx ) {
		$type = $c['type'];
		$op   = $c['op'];
		$val  = $c['value'];
		$val2 = $c['value2'] ?? '';
		$key  = $c['key'] ?? '';

		switch ( $type ) {
			case 'logged_in':
				return self::bool_op( $ctx->user_id > 0, $op );
			case 'phone_verified':
				return self::bool_op( $ctx->phone_verified || ( $ctx->user_id && $ctx->phone ), $op );
			case 'has_phone':
				return self::bool_op( '' !== $ctx->phone, $op );
			case 'user_role':
				return self::list_op( $ctx->roles(), $val, $op );
			case 'user_id':
				return self::list_op( array( (string) $ctx->user_id ), $val, $op );
			case 'registered_days':
				return $ctx->user_id ? self::num_op( $ctx->registered_days(), $val, $val2, $op ) : self::num_op( 0, $val, $val2, $op );
			case 'order_count':
				return self::num_op( $ctx->order_count(), $val, $val2, $op );
			case 'total_spent':
				return self::num_op( $ctx->total_spent(), $val, $val2, $op );
			case 'avg_order':
				$n = $ctx->order_count();
				return self::num_op( $n ? $ctx->total_spent() / $n : 0, $val, $val2, $op );
			case 'last_order_days':
				return self::num_op( $ctx->last_order_days(), $val, $val2, $op );
			case 'bought_product':
				return self::list_op( array_map( 'strval', $ctx->bought()['products'] ), $val, $op );
			case 'bought_category':
				return self::list_op( array_map( 'strval', $ctx->bought()['cats'] ), $val, $op );
			case 'user_meta':
				$meta = $ctx->user_id ? get_user_meta( $ctx->user_id, sanitize_key( $key ), true ) : '';
				return self::text_op( is_scalar( $meta ) ? (string) $meta : '', $val, $op );
			case 'wheel_spins':
				return self::num_op( Limits::count_for_context( $ctx, 'spins' ), $val, $val2, $op );
			case 'wheel_wins':
				return self::num_op( Limits::count_for_context( $ctx, 'wins' ), $val, $val2, $op );

			case 'cart_total':
				return self::num_op( $ctx->cart()['total'], $val, $val2, $op );
			case 'cart_subtotal':
				return self::num_op( $ctx->cart()['subtotal'], $val, $val2, $op );
			case 'cart_items':
				return self::num_op( $ctx->cart()['items'], $val, $val2, $op );
			case 'cart_product':
				return self::list_op( array_map( 'strval', $ctx->cart()['products'] ), $val, $op );
			case 'cart_category':
				return self::list_op( array_map( 'strval', $ctx->cart()['cats'] ), $val, $op );
			case 'cart_has_coupon':
				return self::bool_op( ! empty( $ctx->cart()['coupons'] ), $op );

			case 'order_total':
				return self::num_op( $ctx->order_summary()['total'], $val, $val2, $op );
			case 'order_subtotal':
				return self::num_op( $ctx->order_summary()['subtotal'], $val, $val2, $op );
			case 'order_items':
				return self::num_op( $ctx->order_summary()['items'], $val, $val2, $op );
			case 'order_number':
				return self::num_op( $ctx->order_number(), $val, $val2, $op );
			case 'order_product':
				return self::list_op( array_map( 'strval', $ctx->order_summary()['products'] ), $val, $op );
			case 'order_category':
				return self::list_op( array_map( 'strval', $ctx->order_summary()['cats'] ), $val, $op );
			case 'payment_method':
				return self::list_op( array( $ctx->order_summary()['payment'] ), $val, $op );
			case 'shipping_method':
				return self::list_op( $ctx->order_summary()['shipping'], $val, $op );
			case 'order_coupon':
				return self::text_op( implode( ',', $ctx->order_summary()['coupons'] ), $val, $op );
			case 'billing_city':
				return self::text_op( $ctx->order_summary()['city'], $val, $op );
			case 'billing_state':
				return self::text_op( $ctx->order_summary()['state'], $val, $op );
			case 'created_via':
				return self::text_op( $ctx->order_summary()['via'], $val, $op );

			case 'device':
				return self::list_op( array( $ctx->client( 'device', 'desktop' ) ), $val, $op );
			case 'page_type':
				return self::list_op( array( $ctx->client( 'page_type' ) ), $val, $op );
			case 'url':
				return self::text_op( $ctx->client( 'url' ), $val, $op );
			case 'referrer':
				return self::text_op( $ctx->client( 'ref' ), $val, $op );
			case 'utm_source':
			case 'utm_medium':
			case 'utm_campaign':
				return self::text_op( $ctx->client( $type ), $val, $op );
			case 'query_param':
				$q = $ctx->client( 'query', array() );
				return self::text_op( isset( $q[ sanitize_key( $key ) ] ) ? $q[ sanitize_key( $key ) ] : '', $val, $op );
			case 'cookie':
				$ck = $ctx->client( 'cookies', array() );
				return self::text_op( isset( $ck[ sanitize_key( $key ) ] ) ? $ck[ sanitize_key( $key ) ] : '', $val, $op );
			case 'visit_count':
				return self::num_op( (int) $ctx->client( 'visits', 1 ), $val, $val2, $op );
			case 'new_visitor':
				return self::bool_op( (int) $ctx->client( 'visits', 1 ) <= 1, $op );
			case 'country':
				return self::list_op( array( Helpers::country() ), array_map( 'strtoupper', (array) $val ), $op );
			case 'language':
				$lang = $ctx->client( 'lang' );
				return self::list_op( array( substr( '' !== $lang ? $lang : get_locale(), 0, 2 ) ), $val, $op );
			case 'browser':
				return self::list_op( array( $ctx->client( 'browser', 'other' ) ), $val, $op );
			case 'os':
				return self::list_op( array( $ctx->client( 'os', 'other' ) ), $val, $op );

			case 'weekday':
				return self::list_op( array( wp_date( 'w' ) ), $val, $op );
			case 'hour':
				return self::num_op( (int) wp_date( 'G' ), $val, $val2, $op );
			case 'date':
				$today = (int) str_replace( '-', '', wp_date( 'Y-m-d' ) );
				$a     = (int) str_replace( '-', '', (string) $val );
				$b     = (int) str_replace( '-', '', (string) $val2 );
				return self::num_op( $today, $a, $b, $op );
		}
		/**
		 * Custom condition types: return true/false.
		 */
		return (bool) apply_filters( 'becharkhoon_condition_' . $type, false, $c, $ctx );
	}

	public static function bool_op( $actual, $op ) {
		return 'is_false' === $op ? ! $actual : (bool) $actual;
	}

	public static function num_op( $actual, $val, $val2, $op ) {
		$a = (float) $actual;
		$v = (float) Helpers::latin_digits( is_array( $val ) ? ( $val[0] ?? 0 ) : $val );
		switch ( $op ) {
			case 'gt':
				return $a > $v;
			case 'gte':
				return $a >= $v;
			case 'lt':
				return $a < $v;
			case 'lte':
				return $a <= $v;
			case 'eq':
				return abs( $a - $v ) < 0.0001;
			case 'neq':
				return abs( $a - $v ) >= 0.0001;
			case 'between':
				$w = (float) Helpers::latin_digits( $val2 );
				return $a >= min( $v, $w ) && $a <= max( $v, $w );
		}
		return false;
	}

	public static function list_op( array $actual, $val, $op ) {
		$want = is_array( $val ) ? $val : preg_split( '/\s*,\s*/', (string) $val, -1, PREG_SPLIT_NO_EMPTY );
		$want = array_map( 'strval', (array) $want );
		$hit  = (bool) array_intersect( array_map( 'strval', $actual ), $want );
		return 'not_in' === $op ? ! $hit : $hit;
	}

	public static function text_op( $actual, $val, $op ) {
		$a = mb_strtolower( (string) $actual );
		$v = mb_strtolower( is_array( $val ) ? implode( ',', $val ) : (string) $val );
		switch ( $op ) {
			case 'contains':
				return '' !== $v && false !== mb_strpos( $a, $v );
			case 'not_contains':
				return '' === $v || false === mb_strpos( $a, $v );
			case 'eq':
				return $a === $v;
			case 'neq':
				return $a !== $v;
			case 'starts':
				return '' !== $v && 0 === mb_strpos( $a, $v );
			case 'ends':
				return '' !== $v && mb_substr( $a, -mb_strlen( $v ) ) === $v;
			case 'empty':
				return '' === $a;
			case 'not_empty':
				return '' !== $a;
		}
		return false;
	}
}
