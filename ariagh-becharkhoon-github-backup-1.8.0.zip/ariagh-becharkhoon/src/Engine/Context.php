<?php
/**
 * Evaluation context for conditions: visitor, user, purchase history, cart, order, time.
 * Every expensive value is computed lazily and cached for the request.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Engine;

use Becharkhoon\Core\Helpers;

defined( 'ABSPATH' ) || exit;

final class Context {

	/** @var int */
	public $user_id = 0;
	/** @var string Verified phone (OTP) or the logged-in user's billing phone. */
	public $phone = '';
	/** @var bool */
	public $phone_verified = false;
	/** @var string */
	public $email = '';
	/** @var string */
	public $device_id = '';
	/** @var string */
	public $ip = '';
	/** @var array Client data: device, url, ref, utm, visits, page, lang, ... */
	public $client = array();
	/** @var \WC_Order|null Order for earning rules. */
	public $order = null;
	/** @var int Wheel id (for spin/win counts). */
	public $wheel_id = 0;

	/** @var array */
	private $memo = array();

	public static function current( array $client = array() ) {
		$c            = new self();
		$c->user_id   = get_current_user_id();
		$c->ip        = Helpers::ip( becharkhoon()->settings->get( 'ip_source' ) );
		$c->client    = self::clean_client( $client );
		$c->device_id = isset( $c->client['did'] ) ? $c->client['did'] : '';
		if ( $c->user_id ) {
			$u        = get_userdata( $c->user_id );
			$c->email = $u ? strtolower( $u->user_email ) : '';
			$c->phone = Helpers::phone( get_user_meta( $c->user_id, 'billing_phone', true ) );
			if ( ! $c->phone ) {
				// Common Iranian SMS-login plugins (Digits, etc.) store the mobile here.
				foreach ( array( 'digits_phone_no', 'digits_phone', 'mobile', 'phone', 'user_phone' ) as $k ) {
					$p = Helpers::phone( get_user_meta( $c->user_id, $k, true ) );
					if ( $p ) {
						$c->phone = $p;
						break;
					}
				}
			}
		}
		return $c;
	}

	public static function for_order( \WC_Order $order ) {
		$c          = new self();
		$c->order   = $order;
		$c->user_id = (int) $order->get_customer_id();
		$c->email   = strtolower( (string) $order->get_billing_email() );
		$c->phone   = Helpers::phone( $order->get_billing_phone() );
		$c->ip      = (string) $order->get_customer_ip_address();
		return $c;
	}

	/** Whitelist and normalise browser-sent context. */
	public static function clean_client( array $c ) {
		$out = array();
		$str = array( 'device', 'url', 'ref', 'utm_source', 'utm_medium', 'utm_campaign', 'page_type', 'lang', 'did', 'browser', 'os' );
		foreach ( $str as $k ) {
			if ( isset( $c[ $k ] ) && is_scalar( $c[ $k ] ) ) {
				$out[ $k ] = mb_substr( sanitize_text_field( (string) $c[ $k ] ), 0, 300 );
			}
		}
		$out['visits']    = isset( $c['visits'] ) ? max( 0, (int) $c['visits'] ) : 1;
		$out['object_id'] = isset( $c['object_id'] ) ? absint( $c['object_id'] ) : 0;
		$out['terms']     = isset( $c['terms'] ) ? array_map( 'absint', array_slice( (array) $c['terms'], 0, 50 ) ) : array();
		$out['query']     = array();
		if ( isset( $c['query'] ) && is_array( $c['query'] ) ) {
			foreach ( array_slice( $c['query'], 0, 30, true ) as $k => $v ) {
				$out['query'][ sanitize_key( $k ) ] = is_scalar( $v ) ? mb_substr( sanitize_text_field( (string) $v ), 0, 200 ) : '';
			}
		}
		$out['cookies'] = array();
		if ( isset( $c['cookies'] ) && is_array( $c['cookies'] ) ) {
			foreach ( array_slice( $c['cookies'], 0, 30, true ) as $k => $v ) {
				$out['cookies'][ sanitize_key( $k ) ] = is_scalar( $v ) ? mb_substr( sanitize_text_field( (string) $v ), 0, 200 ) : '';
			}
		}
		if ( ! in_array( $out['device'] ?? '', array( 'desktop', 'tablet', 'mobile' ), true ) ) {
			$out['device'] = self::detect_device();
		}
		if ( preg_match( '/^[a-f0-9\-]{16,64}$/i', $out['did'] ?? '' ) !== 1 ) {
			$out['did'] = '';
		}
		return $out;
	}

	public static function detect_device() {
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? strtolower( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) ) : '';
		if ( preg_match( '/ipad|tablet|(android(?!.*mobile))/', $ua ) ) {
			return 'tablet';
		}
		return preg_match( '/mobile|iphone|ipod|android|blackberry|opera mini|iemobile/', $ua ) ? 'mobile' : 'desktop';
	}

	public function client( $key, $default = '' ) {
		return isset( $this->client[ $key ] ) ? $this->client[ $key ] : $default;
	}

	/** Paid order statuses used for purchase history. */
	public static function paid_statuses() {
		$s = (array) becharkhoon()->settings->get( 'order_statuses' );
		return $s ? $s : array( 'processing', 'completed' );
	}

	/**
	 * Orders of this customer (ids, oldest first). Uses account, else verified phone.
	 *
	 * @return int[]
	 */
	public function order_ids() {
		if ( isset( $this->memo['orders'] ) ) {
			return $this->memo['orders'];
		}
		$ids = array();
		if ( function_exists( 'wc_get_orders' ) ) {
			$base = array(
				'limit'   => 500,
				'return'  => 'ids',
				'status'  => array_map( static function ( $s ) {
					return 'wc-' === substr( $s, 0, 3 ) ? $s : 'wc-' . $s;
				}, self::paid_statuses() ),
				'orderby' => 'date',
				'order'   => 'ASC',
				'type'    => 'shop_order',
			);
			if ( $this->user_id ) {
				$ids = wc_get_orders( array_merge( $base, array( 'customer_id' => $this->user_id ) ) );
			}
			if ( ! $ids && $this->phone && ( $this->phone_verified || $this->user_id || $this->order ) ) {
				$ids = wc_get_orders( array_merge( $base, array( 'billing_phone' => $this->phone ) ) );
			}
			if ( ! $ids && $this->email && ( $this->user_id || $this->order ) ) {
				$ids = wc_get_orders( array_merge( $base, array( 'billing_email' => $this->email ) ) );
			}
		}
		$this->memo['orders'] = array_map( 'intval', (array) $ids );
		return $this->memo['orders'];
	}

	public function order_count() {
		return count( $this->order_ids() );
	}

	public function total_spent() {
		if ( ! isset( $this->memo['spent'] ) ) {
			$sum = 0.0;
			foreach ( $this->order_ids() as $id ) {
				$o = wc_get_order( $id );
				if ( $o ) {
					$sum += (float) $o->get_total() - (float) $o->get_total_refunded();
				}
			}
			$this->memo['spent'] = $sum;
		}
		return $this->memo['spent'];
	}

	public function last_order_days() {
		$ids = $this->order_ids();
		if ( ! $ids ) {
			return 99999;
		}
		$o = wc_get_order( end( $ids ) );
		if ( ! $o || ! $o->get_date_created() ) {
			return 99999;
		}
		return (int) floor( ( time() - $o->get_date_created()->getTimestamp() ) / DAY_IN_SECONDS );
	}

	/** Product ids (incl. parents of variations) and category ids ever bought. */
	public function bought() {
		if ( isset( $this->memo['bought'] ) ) {
			return $this->memo['bought'];
		}
		$products = array();
		foreach ( $this->order_ids() as $id ) {
			$o = wc_get_order( $id );
			if ( ! $o ) {
				continue;
			}
			foreach ( $o->get_items() as $item ) {
				$products[] = (int) $item->get_product_id();
				if ( $item->get_variation_id() ) {
					$products[] = (int) $item->get_variation_id();
				}
			}
		}
		$products             = array_values( array_unique( $products ) );
		$this->memo['bought'] = array( 'products' => $products, 'cats' => self::cats_of( $products ) );
		return $this->memo['bought'];
	}

	public static function cats_of( array $product_ids ) {
		$cats = array();
		foreach ( array_slice( $product_ids, 0, 300 ) as $pid ) {
			$terms = wp_get_post_terms( $pid, 'product_cat', array( 'fields' => 'ids' ) );
			if ( ! is_wp_error( $terms ) ) {
				foreach ( $terms as $t ) {
					$cats[] = (int) $t;
					foreach ( get_ancestors( $t, 'product_cat', 'taxonomy' ) as $a ) {
						$cats[] = (int) $a;
					}
				}
			}
		}
		return array_values( array_unique( $cats ) );
	}

	/** Current cart summary (empty when WooCommerce/cart is not available). */
	public function cart() {
		if ( isset( $this->memo['cart'] ) ) {
			return $this->memo['cart'];
		}
		$out = array( 'total' => 0.0, 'subtotal' => 0.0, 'items' => 0, 'products' => array(), 'cats' => array(), 'coupons' => array() );
		if ( function_exists( 'WC' ) && WC()->cart ) {
			$cart            = WC()->cart;
			$out['subtotal'] = (float) $cart->get_subtotal();
			$out['total']    = (float) $cart->get_cart_contents_total() + (float) $cart->get_cart_contents_tax();
			$out['items']    = (int) $cart->get_cart_contents_count();
			foreach ( $cart->get_cart() as $item ) {
				$out['products'][] = (int) $item['product_id'];
				if ( ! empty( $item['variation_id'] ) ) {
					$out['products'][] = (int) $item['variation_id'];
				}
			}
			$out['products'] = array_values( array_unique( $out['products'] ) );
			$out['cats']     = self::cats_of( $out['products'] );
			$out['coupons']  = array_map( 'strval', $cart->get_applied_coupons() );
		}
		$this->memo['cart'] = $out;
		return $out;
	}

	public function roles() {
		if ( ! $this->user_id ) {
			return array( 'guest' );
		}
		$u = get_userdata( $this->user_id );
		return $u ? (array) $u->roles : array();
	}

	public function registered_days() {
		if ( ! $this->user_id ) {
			return 0;
		}
		$u = get_userdata( $this->user_id );
		return $u ? (int) floor( ( time() - strtotime( $u->user_registered . ' UTC' ) ) / DAY_IN_SECONDS ) : 0;
	}

	/** nth paid order of this customer for the order in context (1 = first order). */
	public function order_number() {
		if ( ! $this->order ) {
			return 0;
		}
		$ids = $this->order_ids();
		$pos = array_search( (int) $this->order->get_id(), $ids, true );
		if ( false === $pos ) {
			return count( $ids ) + 1;
		}
		return $pos + 1;
	}

	public function order_summary() {
		if ( isset( $this->memo['order'] ) ) {
			return $this->memo['order'];
		}
		$out = array( 'total' => 0.0, 'subtotal' => 0.0, 'items' => 0, 'products' => array(), 'cats' => array(), 'coupons' => array(), 'payment' => '', 'shipping' => array(), 'city' => '', 'state' => '', 'via' => '' );
		if ( $this->order ) {
			$o               = $this->order;
			$out['total']    = (float) $o->get_total();
			$out['subtotal'] = (float) $o->get_subtotal();
			$out['items']    = (int) $o->get_item_count();
			foreach ( $o->get_items() as $item ) {
				$out['products'][] = (int) $item->get_product_id();
				if ( $item->get_variation_id() ) {
					$out['products'][] = (int) $item->get_variation_id();
				}
			}
			$out['products'] = array_values( array_unique( $out['products'] ) );
			$out['cats']     = self::cats_of( $out['products'] );
			$out['coupons']  = array_map( 'strval', $o->get_coupon_codes() );
			$out['payment']  = (string) $o->get_payment_method();
			foreach ( $o->get_shipping_methods() as $m ) {
				$out['shipping'][] = (string) $m->get_method_id();
			}
			$out['city']  = (string) $o->get_billing_city();
			$out['state'] = (string) $o->get_billing_state();
			$out['via']   = (string) $o->get_created_via();
		}
		$this->memo['order'] = $out;
		return $out;
	}

	public function memo( $key, callable $fn ) {
		if ( ! array_key_exists( $key, $this->memo ) ) {
			$this->memo[ $key ] = $fn();
		}
		return $this->memo[ $key ];
	}
}
