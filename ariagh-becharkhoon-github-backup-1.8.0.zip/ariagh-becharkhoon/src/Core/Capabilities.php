<?php
/**
 * Plugin capabilities.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Core;

defined( 'ABSPATH' ) || exit;

final class Capabilities {

	/** Full management: wheels, settings, rules, credits. */
	const MANAGE = 'bch_manage';
	/** Read-only: dashboard, reports, logs. */
	const VIEW = 'bch_view';

	public static function add() {
		foreach ( array( 'administrator', 'shop_manager' ) as $role_name ) {
			$role = get_role( $role_name );
			if ( $role ) {
				$role->add_cap( self::MANAGE );
				$role->add_cap( self::VIEW );
			}
		}
		$editor = get_role( 'editor' );
		if ( $editor ) {
			$editor->add_cap( self::VIEW );
		}
	}

	public static function remove() {
		foreach ( wp_roles()->role_objects as $role ) {
			$role->remove_cap( self::MANAGE );
			$role->remove_cap( self::VIEW );
		}
	}

	public static function can_manage() {
		return current_user_can( self::MANAGE ) || current_user_can( 'manage_options' );
	}

	public static function can_view() {
		return self::can_manage() || current_user_can( self::VIEW );
	}
}
