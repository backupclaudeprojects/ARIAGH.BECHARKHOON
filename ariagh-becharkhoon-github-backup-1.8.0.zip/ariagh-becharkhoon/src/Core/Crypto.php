<?php
/**
 * At-rest encryption for SMS panel passwords / API keys (libsodium, OpenSSL fallback).
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Core;

defined( 'ABSPATH' ) || exit;

final class Crypto {

	private static function key() {
		$salt = ( defined( 'AUTH_KEY' ) ? AUTH_KEY : '' ) . ( defined( 'SECURE_AUTH_SALT' ) ? SECURE_AUTH_SALT : '' ) . 'becharkhoon';
		return hash( 'sha256', $salt, true );
	}

	public static function encrypt( $plain ) {
		$plain = (string) $plain;
		if ( '' === $plain || 0 === strpos( $plain, 'enc:' ) ) {
			return $plain;
		}
		if ( function_exists( 'sodium_crypto_secretbox' ) ) {
			$nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			return 'enc:s:' . base64_encode( $nonce . sodium_crypto_secretbox( $plain, $nonce, self::key() ) );
		}
		if ( function_exists( 'openssl_encrypt' ) ) {
			$iv  = random_bytes( 16 );
			$ct  = openssl_encrypt( $plain, 'aes-256-cbc', self::key(), OPENSSL_RAW_DATA, $iv );
			$mac = hash_hmac( 'sha256', $iv . $ct, self::key(), true );
			return 'enc:o:' . base64_encode( $iv . $mac . $ct );
		}
		return $plain;
	}

	public static function decrypt( $value ) {
		$value = (string) $value;
		if ( 0 !== strpos( $value, 'enc:' ) ) {
			return $value;
		}
		$raw = base64_decode( substr( $value, 6 ), true );
		if ( false === $raw ) {
			return '';
		}
		if ( 'enc:s:' === substr( $value, 0, 6 ) && function_exists( 'sodium_crypto_secretbox_open' ) ) {
			$nonce = substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			$plain = sodium_crypto_secretbox_open( substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), $nonce, self::key() );
			return false === $plain ? '' : $plain;
		}
		if ( 'enc:o:' === substr( $value, 0, 6 ) && function_exists( 'openssl_decrypt' ) ) {
			$iv  = substr( $raw, 0, 16 );
			$mac = substr( $raw, 16, 32 );
			$ct  = substr( $raw, 48 );
			if ( ! hash_equals( hash_hmac( 'sha256', $iv . $ct, self::key(), true ), $mac ) ) {
				return '';
			}
			$plain = openssl_decrypt( $ct, 'aes-256-cbc', self::key(), OPENSSL_RAW_DATA, $iv );
			return false === $plain ? '' : $plain;
		}
		return '';
	}
}
