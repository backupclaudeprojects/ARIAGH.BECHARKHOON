<?php
/**
 * Automatic SMS messages (events) and their variables — one source of truth for the admin
 * editor, the variable guide, the live preview, the validator and the sender.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Notify;

use Becharkhoon\Core\Helpers;
use Becharkhoon\Core\Lang;

defined( 'ABSPATH' ) || exit;

final class SmsEvents {

	/**
	 * Variable groups: key => [ label, vars => [ name => [ title, description, example ] ] ].
	 */
	public static function variables() {
		$t = array( Lang::class, 't' );
		return array(
			'person'  => array(
				'label' => $t( 'اطلاعات شخص', 'Person' ),
				'vars'  => array(
					'name'   => array( $t( 'نام', 'Name' ), $t( 'نامی که در فرم گردونه یا سفارش وارد شده؛ اگر خالی باشد «مشتری»', 'Name from the wheel form or order; "customer" when empty' ), $t( 'علی', 'Ali' ) ),
					'mobile' => array( $t( 'موبایل', 'Mobile' ), $t( 'شماره موبایل گیرنده با فرمت 09', 'Recipient mobile (09… format)' ), '09121234567' ),
					'email'  => array( $t( 'ایمیل', 'Email' ), $t( 'ایمیل وارد شده (ممکن است خالی باشد)', 'Email entered (may be empty)' ), 'ali@example.com' ),
				),
			),
			'prize'   => array(
				'label' => $t( 'جایزه و گردونه', 'Prize & wheel' ),
				'vars'  => array(
					'prize'       => array( $t( 'نام جایزه', 'Prize' ), $t( 'عنوان بخشی که برنده شده (همان متن روی گردونه)', 'Label of the won slice' ), $t( '۲۰٪ تخفیف', '20% OFF' ) ),
					'prize_type'  => array( $t( 'نوع جایزه', 'Prize type' ), $t( 'کوپن درصدی، ارسال رایگان، کد آماده، جایزه فیزیکی و…', 'Percent coupon, free shipping, code, physical…' ), $t( 'کد تخفیف درصدی', 'Percent coupon' ) ),
					'code'        => array( $t( 'کد جایزه', 'Prize code' ), $t( 'کد تخفیف یا کد آماده؛ برای جوایز بدون کد خالی است', 'Coupon or ready-made code; empty for prizes without a code' ), 'WHEEL-7KQ2M9XA' ),
					'expiry'      => array( $t( 'تاریخ انقضا', 'Expiry date' ), $t( 'آخرین روز اعتبار جایزه (شمسی)؛ بدون انقضا = «نامحدود»', 'Last valid day; "no expiry" when unlimited' ), '۱۴۰۵/۰۸/۰۵' ),
					'expiry_days' => array( $t( 'روزهای باقی‌مانده', 'Days left' ), $t( 'چند روز تا انقضای جایزه مانده', 'Days until the prize expires' ), '۷' ),
					'link'        => array( $t( 'لینک استفاده از جایزه', 'Prize link' ), $t( 'لینکی که کد را خودکار روی سبد خرید اعمال می‌کند؛ برای جایزه لینکی = همان لینک؛ در غیر این صورت آدرس سایت', 'Link that auto-applies the code; the prize URL for link prizes; otherwise the site URL' ), 'https://example.ir/?bch_apply=WHEEL-7KQ2M9XA' ),
					'wheel'       => array( $t( 'نام گردونه', 'Wheel name' ), $t( 'عنوان گردونه در پنل', 'Wheel title' ), $t( 'گردونه یلدا', 'Yalda wheel' ) ),
					'wheel_link'  => array( $t( 'لینک گردونه', 'Wheel link' ), $t( 'لینکی که پاپ‌آپ همان گردونه را باز می‌کند', 'Link that opens this wheel' ), 'https://example.ir/?bch_open=3' ),
				),
			),
			'credit'  => array(
				'label' => $t( 'شانس چرخاندن', 'Earned spins' ),
				'vars'  => array(
					'n'             => array( $t( 'تعداد شانس جدید', 'New spins' ), $t( 'تعداد شانسی که همین الان داده شد', 'Spins just granted' ), '۲' ),
					'spins'         => array( $t( 'کل شانس‌های فعال', 'Total spins' ), $t( 'مجموع شانس‌های استفاده‌نشده این شخص', 'All unused spins of this person' ), '۳' ),
					'rule'          => array( $t( 'دلیل / قانون', 'Reason / rule' ), $t( 'عنوان قانون شانس (مثلاً «خرید بالای ۲ میلیون»)', 'Rule title (e.g. "Orders over 2,000,000")' ), $t( 'خرید بالای ۲ میلیون', 'Orders over 2,000,000' ) ),
					'credit_expiry' => array( $t( 'انقضای شانس', 'Spins expiry' ), $t( 'تا چه تاریخی می‌توان از این شانس استفاده کرد', 'Date the new spins expire' ), '۱۴۰۵/۰۸/۲۰' ),
				),
			),
			'order'   => array(
				'label' => $t( 'سفارش', 'Order' ),
				'vars'  => array(
					'order_id'    => array( $t( 'شماره سفارش', 'Order number' ), $t( 'شماره سفارش ووکامرس', 'WooCommerce order number' ), '1250' ),
					'order_total' => array( $t( 'مبلغ سفارش', 'Order total' ), $t( 'مبلغ نهایی سفارش با واحد پول', 'Order total with currency' ), $t( '۲,۵۰۰,۰۰۰ تومان', '2,500,000' ) ),
				),
			),
			'otp'     => array(
				'label' => $t( 'کد تایید', 'Verification code' ),
				'vars'  => array(
					'otp'     => array( $t( 'کد تایید', 'Code' ), $t( 'کد یک‌بار مصرف تایید شماره', 'One-time verification code' ), '58213' ),
					'minutes' => array( $t( 'مدت اعتبار', 'Valid for' ), $t( 'چند دقیقه کد معتبر است', 'Minutes the code is valid' ), '۳' ),
				),
			),
			'admin'   => array(
				'label' => $t( 'اطلاعات مدیر', 'Admin info' ),
				'vars'  => array(
					'result'  => array( $t( 'نتیجه', 'Result' ), $t( '«برنده»، «پوچ» یا «دوباره»', '"Win", "Lose" or "Again"' ), $t( 'برنده', 'Win' ) ),
					'spin_id' => array( $t( 'شماره چرخش', 'Spin #' ), $t( 'شناسه چرخش در «چرخش‌ها و برندگان»', 'Spin id in the spins list' ), '418' ),
					'claim'   => array( $t( 'اطلاعات تحویل', 'Delivery details' ), $t( 'نام، تلفن، آدرس و توضیحاتی که برنده برای جایزه فیزیکی فرستاده', 'Name, phone, address and note sent for a physical prize' ), $t( 'تهران، خیابان آزادی، پلاک ۱۲', 'Tehran, Azadi St. 12' ) ),
				),
			),
			'general' => array(
				'label' => $t( 'عمومی', 'General' ),
				'vars'  => array(
					'site'     => array( $t( 'نام فروشگاه', 'Store name' ), $t( 'نام برند در تنظیمات افزونه، یا عنوان سایت', 'Brand name from settings, or the site title' ), $t( 'فروشگاه نمونه', 'Sample Store' ) ),
					'site_url' => array( $t( 'آدرس سایت', 'Site URL' ), $t( 'آدرس صفحه اصلی', 'Home page URL' ), 'https://example.ir' ),
					'date'     => array( $t( 'تاریخ امروز', 'Today' ), $t( 'تاریخ امروز (شمسی در سایت فارسی)', 'Today\'s date' ), '۱۴۰۵/۰۷/۲۲' ),
					'time'     => array( $t( 'ساعت', 'Time' ), $t( 'ساعت فعلی', 'Current time' ), '۱۴:۳۰' ),
				),
			),
		);
	}

	/** Human label of a prize type (for {prize_type}). */
	public static function type_label( $type ) {
		$map = array(
			'coupon_percent'       => Lang::t( 'کد تخفیف درصدی', 'Percent coupon' ),
			'coupon_fixed_cart'    => Lang::t( 'کد تخفیف مبلغی', 'Fixed cart coupon' ),
			'coupon_fixed_product' => Lang::t( 'تخفیف مبلغی محصول', 'Fixed product coupon' ),
			'free_shipping'        => Lang::t( 'ارسال رایگان', 'Free shipping' ),
			'existing_coupon'      => Lang::t( 'کد تخفیف', 'Coupon' ),
			'free_product'         => Lang::t( 'محصول هدیه', 'Free product' ),
			'wallet'               => Lang::t( 'شارژ کیف پول', 'Wallet credit' ),
			'points'               => Lang::t( 'امتیاز باشگاه مشتریان', 'Loyalty points' ),
			'extra_spin'           => Lang::t( 'شانس اضافه', 'Extra spins' ),
			'code_pool'            => Lang::t( 'کد آماده', 'Ready-made code' ),
			'custom'               => Lang::t( 'جایزه ویژه', 'Special prize' ),
			'link'                 => Lang::t( 'لینک/فایل', 'Link / file' ),
			'respin'               => Lang::t( 'دوباره بچرخان', 'Spin again' ),
			'lose'                 => Lang::t( 'پوچ', 'No prize' ),
		);
		return $map[ $type ] ?? (string) $type;
	}

	/** Flat list name => [ title, description, example ]. */
	public static function flat_vars() {
		$out = array();
		foreach ( self::variables() as $g ) {
			foreach ( $g['vars'] as $k => $v ) {
				$out[ $k ] = $v;
			}
		}
		return $out;
	}

	/**
	 * Events. to: customer | admins. toggle: global on/off default (null = always, e.g. OTP).
	 * scope: extra on/off that lives elsewhere (wheel notifications tab / rule).
	 */
	public static function all() {
		$t = array( Lang::class, 't' );
		return array(
			'win'         => array(
				'label'   => $t( 'جایزه برنده', 'Prize won' ),
				'desc'    => $t( 'بلافاصله بعد از برنده شدن در گردونه، با کد و تاریخ انقضا', 'Right after a win, with code and expiry' ),
				'to'      => 'customer',
				'groups'  => array( 'person', 'prize', 'general' ),
				'toggle'  => true,
				'scope'   => $t( 'در هر گردونه هم باید «پیامک جایزه به برنده» روشن باشد (تب اعلان‌ها).', 'Also enable "Prize SMS" in each wheel (Notifications tab).' ),
				'default' => $t( "{name} عزیز، تبریک! 🎉\nجایزه گردونه: {prize}\nکد: {code}\nاعتبار تا {expiry}\n{site}", "Congrats {name}! 🎉\nPrize: {prize}\nCode: {code}\nValid until {expiry}\n{site}" ),
				'hint'    => "name={name}\nprize={prize}\ncode={code}",
			),
			'lose'        => array(
				'label'   => $t( 'دلداری بعد از پوچ', 'After a losing spin' ),
				'desc'    => $t( 'وقتی نتیجه «پوچ» است (اختیاری؛ برای جذب دوباره)', 'When the result is a loss (optional)' ),
				'to'      => 'customer',
				'groups'  => array( 'person', 'prize', 'general' ),
				'toggle'  => false,
				'scope'   => $t( 'در هر گردونه هم باید «پیامک بعد از پوچ» روشن باشد.', 'Also enable it in each wheel.' ),
				'default' => $t( "{name} عزیز، این بار شانس با شما نبود! 😅\nفردا دوباره گردونه را بچرخانید:\n{wheel_link}\n{site}", "{name}, not this time! 😅\nTry again tomorrow:\n{wheel_link}\n{site}" ),
				'hint'    => "name={name}",
			),
			'otp'         => array(
				'label'   => $t( 'کد تایید شماره موبایل', 'Mobile verification code' ),
				'desc'    => $t( 'وقتی گردونه «تایید موبایل با کد» دارد؛ قبل از چرخاندن', 'When a wheel requires mobile verification' ),
				'to'      => 'customer',
				'groups'  => array( 'otp', 'general' ),
				'toggle'  => null,
				'scope'   => '',
				'default' => $t( "کد تایید گردونه شانس: {otp}\nاعتبار: {minutes} دقیقه\n{site}", "Verification code: {otp}\nValid for {minutes} min\n{site}" ),
				'hint'    => 'code={otp}',
			),
			'credit'      => array(
				'label'   => $t( 'شانس جدید گرفتید', 'Spins earned' ),
				'desc'    => $t( 'وقتی طبق «قوانین شانس» (اولین سفارش، خرید بالای X، دعوت و…) یا هدیه دستی، شانس داده می‌شود', 'When a spin rule or a manual gift grants spins' ),
				'to'      => 'customer',
				'groups'  => array( 'person', 'credit', 'prize', 'general' ),
				'toggle'  => true,
				'scope'   => $t( 'در هر قانون هم «پیامک شانس گرفتید» باید روشن باشد.', 'Also enable it in each rule.' ),
				'default' => $t( "{name} عزیز، تبریک! {n} شانس چرخاندن گردونه گرفتید ({rule}).\nهمین الان بچرخانید:\n{wheel_link}\n{site}", "{name}, you earned {n} spin(s) ({rule}).\nSpin now:\n{wheel_link}\n{site}" ),
				'hint'    => "name={name}\nn={n}\nlink={wheel_link}",
			),
			'reminder'    => array(
				'label'   => $t( 'یادآوری انقضای جایزه', 'Prize expiry reminder' ),
				'desc'    => $t( 'چند روز قبل از انقضای کد استفاده‌نشده (کران روزانه)', 'Days before an unused code expires (daily)' ),
				'to'      => 'customer',
				'groups'  => array( 'person', 'prize', 'general' ),
				'toggle'  => true,
				'scope'   => $t( 'زمان و روشن/خاموش در تب «اعلان‌ها»ی هر گردونه.', 'Timing and on/off in each wheel\'s Notifications tab.' ),
				'default' => $t( "{name} عزیز، کد {code} ({prize}) تا {expiry_days} روز دیگر منقضی می‌شود.\n{link}\n{site}", "{name}, your code {code} ({prize}) expires in {expiry_days} days.\n{link}\n{site}" ),
				'hint'    => "name={name}\ncode={code}\ndays={expiry_days}",
			),
			'redeemed'    => array(
				'label'   => $t( 'استفاده از جایزه', 'Prize used' ),
				'desc'    => $t( 'وقتی سفارشی با کد گردونه پرداخت شد', 'When an order paid with a wheel code' ),
				'to'      => 'customer',
				'groups'  => array( 'person', 'prize', 'order', 'general' ),
				'toggle'  => false,
				'scope'   => '',
				'default' => $t( "{name} عزیز، جایزه «{prize}» روی سفارش {order_id} اعمال شد. از خرید شما ممنونیم!\n{site}", "{name}, your prize \"{prize}\" was applied to order {order_id}. Thank you!\n{site}" ),
				'hint'    => "name={name}\norder={order_id}",
			),
			'admin_spin'  => array(
				'label'   => $t( 'برنده جدید (به مدیران)', 'New winner (admins)' ),
				'desc'    => $t( 'به «شماره‌های مدیر»؛ فقط برای بردها یا همه چرخش‌ها (طبق تنظیم گردونه)', 'To admin numbers; wins only or every spin (per wheel)' ),
				'to'      => 'admins',
				'groups'  => array( 'person', 'prize', 'admin', 'general' ),
				'toggle'  => true,
				'scope'   => $t( 'در هر گردونه هم «پیامک به مدیر» باید روشن باشد.', 'Also enable "Admin SMS" in each wheel.' ),
				'default' => $t( "🎡 {wheel}\n{result}: {prize}\n{name} {mobile}\nکد: {code}", "🎡 {wheel}\n{result}: {prize}\n{name} {mobile}\nCode: {code}" ),
				'hint'    => "wheel={wheel}\nprize={prize}\nmobile={mobile}",
			),
			'claim_admin' => array(
				'label'   => $t( 'درخواست تحویل جایزه (به مدیران)', 'Prize claim (admins)' ),
				'desc'    => $t( 'وقتی برنده جایزه فیزیکی، اطلاعات تحویل را ثبت کرد', 'When a winner submits delivery details' ),
				'to'      => 'admins',
				'groups'  => array( 'person', 'prize', 'admin', 'general' ),
				'toggle'  => true,
				'scope'   => '',
				'default' => $t( "📦 درخواست تحویل جایزه #{spin_id}\n{prize}\n{name} {mobile}\n{claim}", "📦 Prize claim #{spin_id}\n{prize}\n{name} {mobile}\n{claim}" ),
				'hint'    => "prize={prize}\nmobile={mobile}",
			),
		);
	}

	public static function get( $key ) {
		$all = self::all();
		return isset( $all[ $key ] ) ? $all[ $key ] : null;
	}

	/** Variable names available in an event. */
	public static function allowed_vars( $key ) {
		$e = self::get( $key );
		if ( ! $e ) {
			return array_keys( self::variables()['general']['vars'] );
		}
		$groups = self::variables();
		$out    = array();
		foreach ( $e['groups'] as $g ) {
			$out = array_merge( $out, array_keys( $groups[ $g ]['vars'] ) );
		}
		return array_values( array_unique( $out ) );
	}

	/** {placeholders} in a text that the event cannot fill. */
	public static function unknown_vars( $key, $text ) {
		preg_match_all( '/\{([a-z0-9_]+)\}/i', (string) $text, $m );
		return array_values( array_unique( array_diff( $m[1], self::allowed_vars( $key ) ) ) );
	}

	/** Example values (previews + test sends). */
	public static function sample_vars() {
		$out = array();
		foreach ( self::flat_vars() as $k => $v ) {
			$out[ $k ] = $v[2];
		}
		return array_merge( $out, self::general_vars() );
	}

	public static function general_vars() {
		$brand = trim( (string) becharkhoon()->settings->get( 'brand_name' ) );
		return array(
			'site'     => '' !== $brand ? $brand : wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'site_url' => home_url( '/' ),
			'date'     => Helpers::human_date( Helpers::now() ),
			'time'     => Lang::is_fa() ? Helpers::persian_digits( wp_date( 'H:i' ) ) : wp_date( 'H:i' ),
		);
	}

	/** Parse "param=value" lines into [ param => value template ] (order kept). */
	public static function parse_params( $lines ) {
		$out = array();
		foreach ( preg_split( '/\r?\n/', (string) $lines ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || false === strpos( $line, '=' ) ) {
				continue;
			}
			list( $k, $v ) = array_map( 'trim', explode( '=', $line, 2 ) );
			if ( '' !== $k ) {
				$out[ $k ] = $v;
			}
		}
		return $out;
	}

	/** Catalog for the admin UI. */
	public static function for_admin() {
		$events = array();
		foreach ( self::all() as $k => $e ) {
			$e['key']     = $k;
			$e['allowed'] = self::allowed_vars( $k );
			$events[]     = $e;
		}
		return array(
			'events'    => $events,
			'variables' => self::variables(),
			'samples'   => self::sample_vars(),
		);
	}
}
