<?php
/**
 * Service container and hook wiring.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon;

use Becharkhoon\Core\Settings;

defined( 'ABSPATH' ) || exit;

final class Plugin {

	/** @var Plugin|null */
	private static $instance = null;

	/** @var Settings */
	public $settings;
	/** @var Wheels\Repository */
	public $wheels;
	/** @var Engine\SpinService */
	public $spinner;
	/** @var Notify\Notifier */
	public $notifier;
	/** @var Credits\Rules */
	public $rules;
	/** @var Front\Frontend */
	public $frontend;
	/** @var Prizes\Coupons */
	public $coupons;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->boot();
		}
		return self::$instance;
	}

	private function boot() {
		$this->settings = new Settings();
		$this->wheels   = new Wheels\Repository();
		$this->spinner  = new Engine\SpinService();
		$this->notifier = new Notify\Notifier();
		$this->rules    = new Credits\Rules();
		$this->frontend = new Front\Frontend();
		$this->coupons  = new Prizes\Coupons();

		Core\Installer::maybe_upgrade();
		load_plugin_textdomain( 'becharkhoon', false, dirname( BCH_BASENAME ) . '/languages' );

		$this->rules->register_hooks();
		$this->coupons->register_hooks();
		( new Prizes\Gifts() )->register_hooks();
		( new Stats\Orders() )->register_hooks();
		( new Core\Cron() )->register_hooks();
		Notify\Bulk::register_hooks();
		( new Front\Ajax() )->register_hooks();
		( new Front\Shortcodes() )->register_hooks();
		( new Front\Account() )->register_hooks();
		( new Privacy\Privacy() )->register_hooks();
		( new Integrations\Elementor() )->register_hooks();
		( new Admin\Rest() )->register_hooks();
		$this->frontend->register_hooks();
		if ( is_admin() ) {
			( new Admin\Admin() )->register_hooks();
		} else {
			add_action( 'admin_bar_menu', array( new Admin\Admin(), 'admin_bar' ), 91 );
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'becharkhoon', Cli\Command::class );
		}
		add_action( 'becharkhoon_prize_redeemed', array( $this->notifier, 'redeemed' ), 10, 2 );
		add_action( 'wp_initialize_site', array( $this, 'new_site' ), 20 );
		do_action( 'becharkhoon_loaded', $this );
	}

	public function new_site( $site ) {
		if ( is_plugin_active_for_network( BCH_BASENAME ) ) {
			switch_to_blog( $site->blog_id );
			Core\Installer::install();
			restore_current_blog();
		}
	}
}
