<?php
/**
 * Shortcodes, Gutenberg block, WooCommerce notices (cart / thank-you).
 *
 * [becharkhoon id="1"]                 inline wheel (or popup trigger with mode="button")
 * [becharkhoon_button id="1" text=""]  button that opens a wheel
 * [becharkhoon_spins id="1"]           live "remaining spins" counter
 * [becharkhoon_my_prizes]              prize history of the logged-in customer
 * [becharkhoon_winners id="1" count=""] recent winners (masked)
 * [becharkhoon_referral]               the customer's referral link
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Front;

use Becharkhoon\Core\Helpers;
use Becharkhoon\Core\Lang;
use Becharkhoon\Credits\Ledger;
use Becharkhoon\Credits\Rules;
use Becharkhoon\Engine\Context;
use Becharkhoon\Stats\Stats;

defined( 'ABSPATH' ) || exit;

final class Shortcodes {

	public function register_hooks() {
		add_shortcode( 'becharkhoon', array( $this, 'wheel' ) );
		add_shortcode( 'becharkhoon_button', array( $this, 'button' ) );
		add_shortcode( 'becharkhoon_spins', array( $this, 'spins' ) );
		add_shortcode( 'becharkhoon_my_prizes', array( $this, 'my_prizes' ) );
		add_shortcode( 'becharkhoon_winners', array( $this, 'winners' ) );
		add_shortcode( 'becharkhoon_referral', array( $this, 'referral' ) );
		add_action( 'init', array( $this, 'block' ) );
		add_action( 'woocommerce_before_cart', array( $this, 'cart_notice' ), 5 );
		add_action( 'woocommerce_thankyou', array( $this, 'thankyou_notice' ), 5 );
	}

	public static function ensure_assets() {
		Frontend::$inline = true;
		if ( ! wp_script_is( 'bch-front', 'enqueued' ) ) {
			wp_enqueue_style( 'bch-front', BCH_URL . 'assets/front/wheel.css', array(), BCH_VERSION );
			wp_enqueue_script( 'bch-front', BCH_URL . 'assets/front/wheel.js', array(), BCH_VERSION, true );
			wp_localize_script( 'bch-front', 'BECHARKHOON', Frontend::js_config() );
			if ( ! has_action( 'wp_footer', array( becharkhoon()->frontend, 'footer' ) ) ) {
				add_action( 'wp_footer', array( becharkhoon()->frontend, 'footer' ), 50 );
			}
		}
	}

	public function wheel( $atts ) {
		$a  = shortcode_atts( array( 'id' => 0, 'mode' => 'inline', 'text' => '', 'class' => '' ), $atts, 'becharkhoon' );
		$id = absint( $a['id'] );
		if ( ! $id ) {
			$active = becharkhoon()->wheels->active();
			$id     = $active ? (int) $active[0]['id'] : 0;
		}
		if ( ! $id ) {
			return '';
		}
		self::ensure_assets();
		if ( 'button' === $a['mode'] ) {
			return $this->button( array( 'id' => $id, 'text' => $a['text'], 'class' => $a['class'] ) );
		}
		return '<div class="bch-inline ' . esc_attr( sanitize_html_class( $a['class'] ) ) . '" data-bch-inline="' . esc_attr( $id ) . '"><div class="bch-inline__ph"></div></div>';
	}

	public function button( $atts ) {
		$a  = shortcode_atts( array( 'id' => 0, 'text' => '', 'class' => '' ), $atts, 'becharkhoon_button' );
		$id = absint( $a['id'] );
		if ( ! $id ) {
			$active = becharkhoon()->wheels->active();
			$id     = $active ? (int) $active[0]['id'] : 0;
		}
		self::ensure_assets();
		$text = '' !== $a['text'] ? $a['text'] : Lang::t( '🎡 گردونه شانس را بچرخان', '🎡 Spin the wheel' );
		return '<button type="button" class="bch-open-btn ' . esc_attr( sanitize_html_class( $a['class'] ) ) . '" data-bch-open="' . esc_attr( $id ) . '">' . esc_html( $text ) . '</button>';
	}

	public function spins( $atts ) {
		$a = shortcode_atts( array( 'id' => 0, 'zero' => '' ), $atts, 'becharkhoon_spins' );
		self::ensure_assets();
		// Filled by JavaScript from the uncached boot request (safe with page caching).
		return '<span class="bch-spins-count" data-bch-spins="' . esc_attr( absint( $a['id'] ) ) . '" data-zero="' . esc_attr( $a['zero'] ) . '"></span>';
	}

	public function winners( $atts ) {
		$a  = shortcode_atts( array( 'id' => 0, 'count' => 10 ), $atts, 'becharkhoon_winners' );
		$id = absint( $a['id'] );
		if ( ! $id ) {
			$active = becharkhoon()->wheels->active();
			$id     = $active ? (int) $active[0]['id'] : 0;
		}
		if ( ! $id ) {
			return '';
		}
		$rows = Stats::recent_winners( $id, (int) $a['count'] );
		if ( ! $rows ) {
			return '';
		}
		$out = '<ul class="bch-winners">';
		foreach ( $rows as $r ) {
			$out .= '<li><b>' . esc_html( $r['name'] ) . '</b> — ' . esc_html( $r['prize'] ) . ' <small>' . esc_html( $r['ago'] ) . '</small></li>';
		}
		return $out . '</ul>';
	}

	public function referral() {
		if ( ! is_user_logged_in() || ! becharkhoon()->settings->get( 'referral_enabled' ) ) {
			return '';
		}
		$link = add_query_arg( becharkhoon()->settings->get( 'referral_param' ), Rules::ref_code( get_current_user_id() ), home_url( '/' ) );
		return '<div class="bch-ref"><input type="text" readonly value="' . esc_attr( $link ) . '" onclick="this.select()"> <button type="button" class="bch-copy" data-copy="' . esc_attr( $link ) . '">' . esc_html( Lang::t( 'کپی لینک دعوت', 'Copy invite link' ) ) . '</button></div>';
	}

	/** Prize history table (also used by the My Account tab). */
	public function my_prizes() {
		if ( ! is_user_logged_in() ) {
			return '<p class="bch-muted">' . esc_html( Lang::t( 'برای دیدن جوایز وارد حساب کاربری شوید.', 'Log in to see your prizes.' ) ) . '</p>';
		}
		self::ensure_assets();
		return Account::render_prizes( get_current_user_id() );
	}

	/* ---------- Block ---------- */

	public function block() {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}
		wp_register_script( 'bch-block', BCH_URL . 'assets/blocks/block.js', array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-server-side-render' ), BCH_VERSION, true );
		$wheels = array();
		foreach ( becharkhoon()->wheels->all() as $w ) {
			$wheels[] = array( 'value' => (int) $w['id'], 'label' => $w['title'] . ' (#' . $w['id'] . ')' );
		}
		wp_localize_script( 'bch-block', 'BCH_BLOCK', array( 'wheels' => $wheels, 'fa' => Lang::is_fa() ) );
		register_block_type(
			'becharkhoon/wheel',
			array(
				'editor_script'   => 'bch-block',
				'attributes'      => array(
					'id'   => array( 'type' => 'number', 'default' => 0 ),
					'mode' => array( 'type' => 'string', 'default' => 'inline' ),
					'text' => array( 'type' => 'string', 'default' => '' ),
				),
				'render_callback' => function ( $atts ) {
					if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
						return '<div style="padding:24px;border:2px dashed #93c5fd;border-radius:14px;text-align:center;font-family:Vazirmatn,Tahoma">🎡 ARIAGH.BECHARKHOON — ' . esc_html( Lang::t( 'گردونه', 'Wheel' ) ) . ' #' . (int) $atts['id'] . '</div>';
					}
					return $this->wheel( $atts );
				},
			)
		);
	}

	/* ---------- WooCommerce notices ---------- */

	public function cart_notice() {
		if ( ! becharkhoon()->settings->get( 'cart_notice' ) || ! is_user_logged_in() ) {
			return;
		}
		$ctx = Context::current();
		foreach ( becharkhoon()->wheels->active() as $w ) {
			if ( 'free' === $w['config']['access']['mode'] ) {
				continue;
			}
			$n = Ledger::balance( $ctx, $w['id'], $w['config']['access']['credit_scope'] );
			if ( $n > 0 ) {
				self::ensure_assets();
				$num = Lang::is_fa() ? Helpers::persian_digits( (string) $n ) : (string) $n;
				wc_print_notice( sprintf( Lang::t( '🎡 شما %1$s شانس چرخاندن «%2$s» دارید! %3$s', '🎡 You have %1$s spins on "%2$s"! %3$s' ), $num, esc_html( $w['title'] ), '<a href="#" class="button bch-open-link" data-bch-open="' . (int) $w['id'] . '">' . esc_html( Lang::t( 'بچرخون', 'Spin now' ) ) . '</a>' ), 'notice' );
				return;
			}
		}
	}

	public function thankyou_notice( $order_id ) {
		if ( ! becharkhoon()->settings->get( 'thankyou_notice' ) ) {
			return;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$n = (int) $order->get_meta( '_bch_spins_granted' );
		if ( $n <= 0 ) {
			return;
		}
		self::ensure_assets();
		$wid = (int) $order->get_meta( '_bch_spins_wheel' );
		$num = Lang::is_fa() ? Helpers::persian_digits( (string) $n ) : (string) $n;
		echo '<div class="bch-thankyou">';
		echo '<div class="bch-thankyou__ic">🎁</div><div><b>' . esc_html( sprintf( Lang::t( 'تبریک! با این خرید %s شانس چرخاندن گردونه گرفتید.', 'Congrats! This order earned you %s wheel spin(s).' ), $num ) ) . '</b>';
		echo '<p>' . esc_html( Lang::t( 'همین حالا گردونه را بچرخانید و جایزه‌تان را بگیرید.', 'Spin the wheel now and grab your prize.' ) ) . '</p></div>';
		echo '<button type="button" class="bch-open-btn" data-bch-open="' . esc_attr( $wid ) . '">' . esc_html( Lang::t( 'بچرخون!', 'Spin now!' ) ) . '</button></div>';
	}
}
