<?php
/**
 * Elementor widget: inline wheel or "open wheel" button.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Integrations;

use Becharkhoon\Core\Lang;

defined( 'ABSPATH' ) || exit;

final class ElementorWidget extends \Elementor\Widget_Base {

	public function get_name() {
		return 'becharkhoon_wheel';
	}

	public function get_title() {
		return Lang::t( 'گردونه شانس بچرخون', 'Becharkhoon wheel' );
	}

	public function get_icon() {
		return 'eicon-spinner';
	}

	public function get_categories() {
		return array( 'general' );
	}

	public function get_keywords() {
		return array( 'wheel', 'spin', 'lucky', 'گردونه', 'شانس', 'becharkhoon' );
	}

	protected function register_controls() {
		$options = array( 0 => Lang::t( 'اولین گردونه فعال', 'First active wheel' ) );
		foreach ( becharkhoon()->wheels->all() as $w ) {
			$options[ $w['id'] ] = $w['title'] . ' (#' . $w['id'] . ')';
		}
		$this->start_controls_section( 'content', array( 'label' => Lang::t( 'گردونه', 'Wheel' ) ) );
		$this->add_control( 'wheel', array( 'label' => Lang::t( 'انتخاب گردونه', 'Wheel' ), 'type' => \Elementor\Controls_Manager::SELECT, 'options' => $options, 'default' => 0 ) );
		$this->add_control(
			'mode',
			array(
				'label'   => Lang::t( 'نمایش', 'Display' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => array( 'inline' => Lang::t( 'گردونه داخل صفحه', 'Inline wheel' ), 'button' => Lang::t( 'دکمه باز کردن پاپ‌آپ', 'Button that opens the popup' ) ),
				'default' => 'inline',
			)
		);
		$this->add_control( 'text', array( 'label' => Lang::t( 'متن دکمه', 'Button text' ), 'type' => \Elementor\Controls_Manager::TEXT, 'default' => '', 'condition' => array( 'mode' => 'button' ) ) );
		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();
		if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
			echo '<div style="padding:28px;border:2px dashed #93c5fd;border-radius:14px;text-align:center;font-family:Vazirmatn,Tahoma">🎡 ARIAGH.BECHARKHOON #' . (int) $s['wheel'] . '</div>';
			return;
		}
		echo do_shortcode( '[becharkhoon id="' . (int) $s['wheel'] . '" mode="' . esc_attr( $s['mode'] ) . '" text="' . esc_attr( $s['text'] ) . '"]' );
	}
}
