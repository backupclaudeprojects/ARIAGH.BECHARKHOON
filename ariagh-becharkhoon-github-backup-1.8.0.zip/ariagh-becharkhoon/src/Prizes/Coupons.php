<?php
/**
 * WooCommerce coupon factory + runtime rules (discount cap, first-order-only, auto apply,
 * gift product, redemption tracking, cleanup).
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Prizes;

use Becharkhoon\Core\Helpers;
use Becharkhoon\Core\Lang;
use Becharkhoon\Engine\Context;

defined( 'ABSPATH' ) || exit;

final class Coupons {

	public function register_hooks() {
		add_filter( 'woocommerce_coupon_get_discount_amount', array( $this, 'cap_discount' ), 20, 5 );
		add_filter( 'woocommerce_coupon_is_valid', array( $this, 'validate' ), 20, 3 );
		add_action( 'wp_loaded', array( $this, 'apply_from_url' ), 30 );
		add_action( 'woocommerce_order_status_changed', array( $this, 'track_redemption' ), 30, 4 );
	}

	public static function charset( $name ) {
		switch ( $name ) {
			case 'upper':
				return 'ABCDEFGHJKLMNPQRSTUVWXYZ';
			case 'num':
				return '0123456789';
			case 'lower_num':
				return 'abcdefghjkmnpqrstuvwxyz23456789';
			case 'mixed':
				return 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
		}
		return 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
	}

	/** A code that does not exist yet. */
	public static function unique_code( $prefix, $length, $charset ) {
		for ( $i = 0; $i < 20; $i++ ) {
			$code = $prefix . Helpers::random_string( $length, self::charset( $charset ) );
			if ( ! wc_get_coupon_id_by_code( $code ) ) {
				return $code;
			}
		}
		return $prefix . strtoupper( substr( Helpers::token(), 0, $length + 6 ) );
	}

	/**
	 * Create a coupon for a won slice.
	 *
	 * @param array   $wheel Wheel row.
	 * @param array   $slice Slice.
	 * @param Context $ctx   Winner.
	 * @param int     $spin_id Spin row id (reserved before).
	 * @return array{code:string,id:int,expires:string}|\WP_Error
	 */
	public static function create( array $wheel, array $slice, Context $ctx, $spin_id, $gift = null ) {
		$c = $wheel['config']['coupon'];
		try {
			$code   = self::unique_code( $c['prefix'], (int) $c['length'], $c['charset'] );
			$coupon = new \WC_Coupon();
			$coupon->set_code( $code );
			$type   = 'percent';
			$amount = (float) $slice['value'];
			switch ( $slice['type'] ) {
				case 'coupon_fixed_cart':
					$type = 'fixed_cart';
					break;
				case 'coupon_fixed_product':
					$type = 'fixed_product';
					break;
				case 'free_shipping':
					$type   = 'fixed_cart';
					$amount = 0;
					$coupon->set_free_shipping( true );
					break;
				case 'free_product':
					// The code is only a key: the gift line itself is made free in the cart (Gifts).
					$type   = 'fixed_cart';
					$amount = 0;
					if ( is_array( $gift ) ) {
						$coupon->update_meta_data( '_bch_gift', array( 'kind' => $gift['kind'], 'id' => (int) $gift['id'], 'key' => $gift['key'], 'name' => $gift['name'], 'image' => $gift['image'], 'price' => (float) $gift['price'] ) );
					}
					break;
			}
			$coupon->set_discount_type( $type );
			$coupon->set_amount( $amount );

			$days = (int) $slice['expiry_days'] >= 0 ? (int) $slice['expiry_days'] : (int) $c['expiry_days'];
			$secs = $days * DAY_IN_SECONDS + (int) $c['expiry_hours'] * HOUR_IN_SECONDS;
			$exp  = '';
			if ( $secs > 0 ) {
				$coupon->set_date_expires( time() + $secs );
				$exp = Helpers::now( $secs );
			}
			$coupon->set_individual_use( (bool) $c['individual_use'] );
			$coupon->set_exclude_sale_items( (bool) $c['exclude_sale'] );
			if ( $c['free_shipping'] || ! empty( $slice['free_shipping_too'] ) ) {
				$coupon->set_free_shipping( true );
			}
			$coupon->set_usage_limit( max( 0, (int) $c['usage_limit'] ) );
			$coupon->set_usage_limit_per_user( max( 0, (int) $c['usage_limit_user'] ) );
			if ( 'free_product' !== $slice['type'] ) {
				if ( (int) $c['limit_items'] > 0 ) {
					$coupon->set_limit_usage_to_x_items( (int) $c['limit_items'] );
				}
				$coupon->set_product_ids( $c['product_ids'] );
			}
			$coupon->set_excluded_product_ids( $c['exclude_product_ids'] );
			$coupon->set_product_categories( $c['category_ids'] );
			$coupon->set_excluded_product_categories( $c['exclude_category_ids'] );
			$min = (float) $slice['min_spend'] > 0 ? (float) $slice['min_spend'] : (float) $c['min_spend'];
			if ( $min > 0 ) {
				$coupon->set_minimum_amount( $min );
			}
			if ( (float) $c['max_spend'] > 0 ) {
				$coupon->set_maximum_amount( (float) $c['max_spend'] );
			}
			if ( $c['restrict_email'] && '' !== $ctx->email ) {
				$coupon->set_email_restrictions( array( $ctx->email ) );
			}
			$cap = (float) $slice['max_discount'] > 0 ? (float) $slice['max_discount'] : (float) $c['max_discount'];
			if ( $cap > 0 && 'percent' === $type ) {
				$coupon->update_meta_data( '_bch_max_discount', $cap );
			}
			if ( $c['first_order_only'] ) {
				$coupon->update_meta_data( '_bch_first_order_only', 1 );
			}
			$desc = '' !== $c['description'] ? $c['description'] : sprintf( 'ARIAGH.BECHARKHOON — %s — %s', $wheel['title'], $slice['label'] );
			$coupon->set_description( $desc );
			$coupon->update_meta_data( '_bch_spin_id', (int) $spin_id );
			$coupon->update_meta_data( '_bch_wheel_id', (int) $wheel['id'] );
			$coupon->update_meta_data( '_bch_user_id', (int) $ctx->user_id );
			$coupon->update_meta_data( '_bch_phone', $ctx->phone );
			$id = $coupon->save();
			if ( ! $id ) {
				return new \WP_Error( 'coupon', 'Coupon could not be saved' );
			}
			return array( 'code' => $code, 'id' => (int) $id, 'expires' => $exp );
		} catch ( \Exception $e ) {
			return new \WP_Error( 'coupon', $e->getMessage() );
		}
	}

	/**
	 * Percent coupons with a maximum discount: scale every line so the cart total
	 * discount never exceeds the cap (proportional, deterministic).
	 */
	public function cap_discount( $discount, $discounting_amount, $cart_item, $single, $coupon ) {
		if ( ! $coupon instanceof \WC_Coupon || ! $coupon->is_type( 'percent' ) ) {
			return $discount;
		}
		$cap = (float) $coupon->get_meta( '_bch_max_discount' );
		if ( $cap <= 0 || ! function_exists( 'WC' ) || ! WC()->cart ) {
			return $discount;
		}
		$full = 0.0;
		$pct  = (float) $coupon->get_amount() / 100;
		foreach ( WC()->cart->get_cart() as $item ) {
			$product = $item['data'] ?? null;
			if ( $product && $coupon->is_valid_for_product( $product, $item ) ) {
				$full += (float) $item['line_subtotal'] * $pct;
			}
		}
		if ( $full <= $cap || $full <= 0 ) {
			return $discount;
		}
		return $discount * ( $cap / $full );
	}

	/** First-order-only coupons. */
	public function validate( $valid, $coupon, $discounts = null ) {
		if ( ! $valid || ! $coupon instanceof \WC_Coupon || ! $coupon->get_meta( '_bch_first_order_only' ) ) {
			return $valid;
		}
		$ctx = Context::current();
		if ( ! $ctx->user_id && function_exists( 'WC' ) && WC()->customer ) {
			$ctx->email          = strtolower( (string) WC()->customer->get_billing_email() );
			$ctx->phone          = Helpers::phone( WC()->customer->get_billing_phone() );
			$ctx->phone_verified = true; // Lookup only: stricter for guests.
		}
		$has_orders = $ctx->order_count() > 0;
		if ( ! $has_orders && ! $ctx->user_id && '' !== $ctx->email && function_exists( 'wc_get_orders' ) ) {
			$has_orders = (bool) wc_get_orders( array( 'billing_email' => $ctx->email, 'status' => array_map( static function ( $st ) {
				return 'wc-' . $st;
			}, Context::paid_statuses() ), 'limit' => 1, 'return' => 'ids' ) );
		}
		if ( $has_orders ) {
			throw new \Exception( esc_html( Lang::t( 'این کد فقط برای اولین خرید معتبر است.', 'This code is valid for the first order only.' ) ), 100 ); // phpcs:ignore
		}
		return $valid;
	}

	/** ?bch_apply=CODE → apply to the session cart and go to cart/checkout. */
	public function apply_from_url() {
		$param = (string) becharkhoon()->settings->get( 'auto_apply_param' );
		if ( empty( $_GET[ $param ] ) || ! function_exists( 'WC' ) || is_admin() ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$code = wc_format_coupon_code( sanitize_text_field( wp_unslash( $_GET[ $param ] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! WC()->cart ) {
			if ( function_exists( 'wc_load_cart' ) ) {
				wc_load_cart();
			}
		}
		if ( WC()->session && ! WC()->session->has_session() ) {
			WC()->session->set_customer_session_cookie( true );
		}
		if ( WC()->cart && $code && ! WC()->cart->has_discount( $code ) ) {
			if ( WC()->cart->is_empty() && Gifts::for_code( $code ) ) {
				Gifts::add_line( $code ); // An empty cart can not take a coupon: put the gift in first.
			}
			WC()->cart->apply_coupon( $code );
		}
		$to = isset( $_GET['bch_to'] ) ? sanitize_key( wp_unslash( $_GET['bch_to'] ) ) : 'cart'; // phpcs:ignore WordPress.Security.NonceVerification
		$url = 'checkout' === $to ? wc_get_checkout_url() : ( 'shop' === $to ? wc_get_page_permalink( 'shop' ) : wc_get_cart_url() );
		if ( 'stay' === $to ) {
			$url = remove_query_arg( array( $param, 'bch_to' ) );
		}
		wp_safe_redirect( $url );
		exit;
	}

	/** Mark spins as redeemed when an order using their coupon is paid. */
	public function track_redemption( $order_id, $from, $to, $order = null ) {
		$statuses = (array) becharkhoon()->settings->get( 'order_statuses' );
		if ( ! in_array( $to, $statuses, true ) ) {
			return;
		}
		$order = $order instanceof \WC_Order ? $order : wc_get_order( $order_id );
		if ( ! $order || $order->get_meta( '_bch_redeemed' ) ) {
			return;
		}
		$codes = array_map( 'wc_format_coupon_code', $order->get_coupon_codes() );
		if ( ! $codes ) {
			return;
		}
		global $wpdb;
		$found = false;
		foreach ( $codes as $code ) {
			$spin = $wpdb->get_row( $wpdb->prepare( "SELECT id, wheel_id FROM {$wpdb->prefix}bch_spins WHERE coupon_code = %s AND status = 'issued' LIMIT 1", $code ), ARRAY_A );
			if ( ! $spin ) {
				continue;
			}
			$found = true;
			$wpdb->update(
				$wpdb->prefix . 'bch_spins',
				array( 'status' => 'redeemed', 'order_id' => (int) $order_id, 'revenue' => (float) $order->get_total(), 'redeemed_at' => Helpers::now() ),
				array( 'id' => (int) $spin['id'] )
			);
			\Becharkhoon\Stats\Stats::add( (int) $spin['wheel_id'], 'redeemed', 1 );
			\Becharkhoon\Stats\Stats::add( (int) $spin['wheel_id'], 'revenue', (float) $order->get_total() );
			do_action( 'becharkhoon_prize_redeemed', (int) $spin['id'], $order );
		}
		if ( $found ) {
			$order->update_meta_data( '_bch_redeemed', 1 );
			$order->save_meta_data();
		}
	}

	/** Coupon usage state for "my prizes": used / expired / active. */
	public static function state( $code ) {
		if ( ! function_exists( 'wc_get_coupon_id_by_code' ) || '' === $code ) {
			return '';
		}
		$id = wc_get_coupon_id_by_code( $code );
		if ( ! $id ) {
			return 'deleted';
		}
		$c = new \WC_Coupon( $id );
		if ( $c->get_usage_limit() && $c->get_usage_count() >= $c->get_usage_limit() ) {
			return 'used';
		}
		$exp = $c->get_date_expires();
		if ( $exp && $exp->getTimestamp() < time() ) {
			return 'expired';
		}
		return 'active';
	}

	/** Delete generated, never-used, expired coupons older than N days. */
	public static function cleanup( $days ) {
		if ( $days <= 0 || ! class_exists( 'WooCommerce' ) ) {
			return 0;
		}
		global $wpdb;
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT p.ID FROM {$wpdb->posts} p
				 INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_bch_spin_id'
				 INNER JOIN {$wpdb->postmeta} e ON e.post_id = p.ID AND e.meta_key = 'date_expires'
				 LEFT JOIN {$wpdb->postmeta} u ON u.post_id = p.ID AND u.meta_key = 'usage_count'
				 WHERE p.post_type = 'shop_coupon' AND e.meta_value <> '' AND CAST(e.meta_value AS UNSIGNED) < %d AND (u.meta_value IS NULL OR u.meta_value = '0')
				 LIMIT 300",
				time() - (int) $days * DAY_IN_SECONDS
			)
		);
		foreach ( $ids as $id ) {
			wp_delete_post( (int) $id, true );
		}
		return count( $ids );
	}
}
