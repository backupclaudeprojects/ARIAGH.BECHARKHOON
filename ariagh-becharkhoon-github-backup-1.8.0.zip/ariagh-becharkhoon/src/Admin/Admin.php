<?php
/**
 * Admin shell: menu (SEOLITY-style SPA), assets, CSV exports, activation redirect,
 * dashboard widget, admin-bar item and plugin row links.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Admin;

use Becharkhoon\Core\Capabilities;
use Becharkhoon\Core\Helpers;
use Becharkhoon\Core\Lang;
use Becharkhoon\Credits\Ledger;
use Becharkhoon\Engine\Leads;
use Becharkhoon\Stats\Stats;

defined( 'ABSPATH' ) || exit;

final class Admin {

	const SLUG = 'becharkhoon';

	public static function routes() {
		return array(
			'dashboard' => array( Lang::t( 'داشبورد', 'Dashboard' ), Capabilities::VIEW ),
			'wheels'    => array( Lang::t( 'گردونه‌ها', 'Wheels' ), Capabilities::MANAGE ),
			'rules'     => array( Lang::t( 'قوانین شانس', 'Spin rules' ), Capabilities::MANAGE ),
			'spins'     => array( Lang::t( 'چرخش‌ها و برندگان', 'Spins & winners' ), Capabilities::VIEW ),
			'leads'     => array( Lang::t( 'مخاطبان', 'Leads' ), Capabilities::VIEW ),
			'credits'   => array( Lang::t( 'شانس‌های کاربران', 'User spins' ), Capabilities::MANAGE ),
			'campaigns' => array( Lang::t( 'ارسال‌های گروهی', 'Bulk sends' ), Capabilities::MANAGE ),
			'reports'   => array( Lang::t( 'گزارش‌ها', 'Reports' ), Capabilities::VIEW ),
			'sms'       => array( Lang::t( 'پیامک و اعلان', 'SMS & alerts' ), Capabilities::MANAGE ),
			'settings'  => array( Lang::t( 'تنظیمات', 'Settings' ), Capabilities::MANAGE ),
			'tools'     => array( Lang::t( 'ابزارها', 'Tools' ), Capabilities::MANAGE ),
			'guide'     => array( Lang::t( 'راهنما', 'Guide' ), Capabilities::VIEW ),
		);
	}

	public function register_hooks() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_init', array( $this, 'activation_redirect' ) );
		add_action( 'admin_post_bch_export', array( $this, 'export' ) );
		add_action( 'admin_bar_menu', array( $this, 'admin_bar' ), 91 );
		add_action( 'wp_dashboard_setup', array( $this, 'dashboard_widget' ) );
		add_filter( 'plugin_action_links_' . BCH_BASENAME, array( $this, 'links' ) );
		add_filter( 'admin_body_class', array( $this, 'body_class' ) );
	}

	public function brand() {
		$b = (string) becharkhoon()->settings->get( 'brand_name' );
		return '' !== $b ? $b : Lang::t( 'بچرخون', 'Becharkhoon' );
	}

	public function menu() {
		$icon = 'data:image/svg+xml;base64,' . base64_encode( (string) file_get_contents( BCH_DIR . 'assets/img/menu-icon.svg' ) ); // phpcs:ignore
		add_menu_page( 'ARIAGH.BECHARKHOON', $this->brand(), Capabilities::VIEW, self::SLUG, array( $this, 'render' ), $icon, 56 );
		foreach ( self::routes() as $slug => $r ) {
			add_submenu_page( self::SLUG, $r[0], $r[0], $r[1], 'dashboard' === $slug ? self::SLUG : self::SLUG . '-' . $slug, array( $this, 'render' ) );
		}
	}

	private function is_ours() {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		return self::SLUG === $page || 0 === strpos( $page, self::SLUG . '-' );
	}

	public function body_class( $c ) {
		return $this->is_ours() ? $c . ' bch-screen' : $c;
	}

	public function render() {
		if ( ! Capabilities::can_view() ) {
			wp_die( esc_html__( 'Forbidden', 'becharkhoon' ), 403 );
		}
		echo '<div class="wrap bch-wrap"><div id="bch-app"><div class="bc-boot"><img src="' . esc_url( BCH_URL . 'assets/img/mark.svg' ) . '" width="56" height="56" alt=""><div class="bc-spinner"></div><p>ARIAGH.BECHARKHOON</p></div>';
		echo '<noscript>JavaScript is required.</noscript></div></div>';
	}

	public function assets( $hook ) {
		if ( ! $this->is_ours() ) {
			return;
		}
		$s    = becharkhoon()->settings;
		$deps = array();
		if ( $s->get( 'admin_webfont' ) ) {
			wp_register_style( 'bch-admin-font', 'https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&display=swap', array(), null ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
			$deps[] = 'bch-admin-font';
		}
		wp_enqueue_media();
		wp_enqueue_style( 'bch-admin', BCH_URL . 'assets/admin/app.css', $deps, BCH_VERSION );
		wp_enqueue_style( 'bch-front', BCH_URL . 'assets/front/wheel.css', array(), BCH_VERSION );
		wp_enqueue_script( 'bch-wheel', BCH_URL . 'assets/front/wheel.js', array(), BCH_VERSION, true );
		wp_enqueue_script( 'bch-ui', BCH_URL . 'assets/admin/ui.js', array( 'bch-wheel' ), BCH_VERSION, true );
		wp_enqueue_script( 'bch-charts', BCH_URL . 'assets/admin/charts.js', array( 'bch-ui' ), BCH_VERSION, true );
		wp_enqueue_script( 'bch-fields', BCH_URL . 'assets/admin/fields.js', array( 'bch-charts' ), BCH_VERSION, true );
		wp_enqueue_script( 'bch-editor', BCH_URL . 'assets/admin/editor.js', array( 'bch-fields' ), BCH_VERSION, true );
		wp_enqueue_script( 'bch-pages', BCH_URL . 'assets/admin/pages.js', array( 'bch-editor' ), BCH_VERSION, true );
		wp_enqueue_script( 'bch-app', BCH_URL . 'assets/admin/app.js', array( 'bch-pages' ), BCH_VERSION, true );
		$page  = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : self::SLUG; // phpcs:ignore WordPress.Security.NonceVerification
		$route = self::SLUG === $page ? 'dashboard' : substr( $page, strlen( self::SLUG ) + 1 );
		$lang  = $s->get( 'ui_language' );
		$fa    = 'fa' === $lang ? true : ( 'en' === $lang ? false : 0 === strpos( get_user_locale(), 'fa' ) );
		$routes = array();
		foreach ( self::routes() as $slug => $r ) {
			if ( current_user_can( $r[1] ) || current_user_can( 'manage_options' ) ) {
				$routes[] = $slug;
			}
		}
		wp_localize_script(
			'bch-ui',
			'BCH',
			array(
				'root'      => esc_url_raw( rest_url( 'becharkhoon/v1/' ) ),
				'nonce'     => wp_create_nonce( 'wp_rest' ),
				'exportUrl' => esc_url_raw( wp_nonce_url( admin_url( 'admin-post.php?action=bch_export' ), 'bch_export' ) ),
				'route'     => $route,
				'routes'    => $routes,
				'fa'        => $fa,
				'theme'     => $s->get( 'admin_theme' ),
				'brand'     => $this->brand(),
				'pluginUrl' => BCH_URL,
				'homeUrl'   => home_url( '/' ),
				'adminUrl'  => admin_url(),
				'version'   => BCH_VERSION,
				'woo'       => class_exists( 'WooCommerce' ),
				'canManage' => Capabilities::can_manage(),
				'user'      => wp_get_current_user()->display_name,
			)
		);
		wp_localize_script( 'bch-wheel', 'BECHARKHOON', array_merge( \Becharkhoon\Front\Frontend::js_config(), array( 'admin' => true, 'fa' => $fa, 'rtl' => $fa ) ) );
	}

	public function activation_redirect() {
		if ( get_transient( 'bch_activation_redirect' ) && Capabilities::can_manage() && ! wp_doing_ajax() && ! isset( $_GET['activate-multi'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			delete_transient( 'bch_activation_redirect' );
			wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '#/wheels' ) );
			exit;
		}
	}

	public function links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '-wheels' ) ) . '">' . esc_html( Lang::t( 'گردونه‌ها', 'Wheels' ) ) . '</a>', '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '-settings' ) ) . '">' . esc_html( Lang::t( 'تنظیمات', 'Settings' ) ) . '</a>' );
		return $links;
	}

	public function admin_bar( \WP_Admin_Bar $bar ) {
		if ( ! Capabilities::can_view() || ! is_admin_bar_showing() ) {
			return;
		}
		$today = Stats::totals( Helpers::today(), Helpers::today() );
		$bar->add_node(
			array(
				'id'    => 'becharkhoon',
				'title' => '🎡 ' . esc_html( $this->brand() ) . ( $today['spins'] ? ' <span class="ab-label" style="background:#1D4ED8;border-radius:9px;padding:0 6px;margin-inline-start:4px">' . (int) $today['spins'] . '</span>' : '' ),
				'href'  => admin_url( 'admin.php?page=' . self::SLUG ),
			)
		);
		if ( ! is_admin() ) {
			foreach ( array_slice( becharkhoon()->wheels->all(), 0, 8 ) as $w ) {
				$bar->add_node(
					array(
						'parent' => 'becharkhoon',
						'id'     => 'bch-preview-' . $w['id'],
						'title'  => esc_html( Lang::t( 'پیش‌نمایش: ', 'Preview: ' ) . $w['title'] ),
						'href'   => add_query_arg( 'bch_preview', $w['id'] ),
					)
				);
			}
		}
	}

	public function dashboard_widget() {
		if ( ! Capabilities::can_view() ) {
			return;
		}
		wp_add_dashboard_widget(
			'bch_dashboard',
			'🎡 ARIAGH.BECHARKHOON',
			function () {
				$t = Stats::totals( Helpers::today( ), Helpers::today() );
				$w = Stats::totals( wp_date( 'Y-m-d', time() - 6 * DAY_IN_SECONDS ), Helpers::today() );
				echo '<table class="widefat striped"><thead><tr><th></th><th>' . esc_html( Lang::t( 'امروز', 'Today' ) ) . '</th><th>' . esc_html( Lang::t( '۷ روز', '7 days' ) ) . '</th></tr></thead><tbody>';
				foreach ( array( 'spins' => Lang::t( 'چرخش', 'Spins' ), 'wins' => Lang::t( 'برنده', 'Wins' ), 'leads' => Lang::t( 'مخاطب جدید', 'New leads' ), 'redeemed' => Lang::t( 'استفاده از جایزه', 'Redeemed' ) ) as $k => $l ) {
					echo '<tr><td>' . esc_html( $l ) . '</td><td>' . esc_html( number_format_i18n( $t[ $k ] ) ) . '</td><td>' . esc_html( number_format_i18n( $w[ $k ] ) ) . '</td></tr>';
				}
				echo '<tr><td>' . esc_html( Lang::t( 'فروش از جوایز', 'Revenue from prizes' ) ) . '</td><td>' . esc_html( Helpers::money( $t['revenue'] ) ) . '</td><td>' . esc_html( Helpers::money( $w['revenue'] ) ) . '</td></tr>';
				echo '</tbody></table><p><a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">' . esc_html( Lang::t( 'داشبورد بچرخون', 'Open dashboard' ) ) . '</a></p>';
			}
		);
	}

	/** CSV exports: spins / leads / credits. */
	public function export() {
		check_admin_referer( 'bch_export' );
		if ( ! Capabilities::can_view() ) {
			wp_die( 'Forbidden', 403 );
		}
		global $wpdb;
		$what = isset( $_GET['what'] ) ? sanitize_key( wp_unslash( $_GET['what'] ) ) : 'spins';
		$g    = static function ( $k, $d = '' ) {
			return isset( $_GET[ $k ] ) ? sanitize_text_field( wp_unslash( $_GET[ $k ] ) ) : $d; // phpcs:ignore WordPress.Security.NonceVerification
		};
		$per  = ( '' !== $g( 'from' ) || '' !== $g( 'to' ) ) ? \Becharkhoon\Stats\Reports::period( $g( 'from' ), $g( 'to' ) ) : array( 'from_utc' => '1970-01-01 00:00:00', 'to_utc' => '2999-12-31 23:59:59' );
		$ext  = 'csv';
		$out  = fopen( 'php://temp', 'r+' );
		if ( 'contacts' === $what && 'txt' === $g( 'format' ) ) {
			// Numbers only, one per line: paste/upload into any SMS panel phonebook.
			$ext = 'txt';
			$res = \Becharkhoon\Stats\People::contacts( array( 'source' => $g( 'source', 'all' ), 'from_utc' => $per['from_utc'], 'to_utc' => $per['to_utc'], 'wheel_id' => absint( $g( 'wheel_id', 0 ) ), 'marketing' => '1' === $g( 'marketing' ), 'verified' => '1' === $g( 'verified' ), 'winners' => '1' === $g( 'winners' ), 'need_phone' => true ) );
			foreach ( $res['rows'] as $c ) {
				fwrite( $out, \Becharkhoon\Stats\People::phone_style( $c['phone'], $g( 'style', '09' ) ) . "\r\n" );
			}
		} else {
			fwrite( $out, "\xEF\xBB\xBF" );
		}
		if ( 'contacts' === $what && 'txt' !== $g( 'format' ) ) {
			$res    = \Becharkhoon\Stats\People::contacts( array( 'source' => $g( 'source', 'all' ), 'from_utc' => $per['from_utc'], 'to_utc' => $per['to_utc'], 'wheel_id' => absint( $g( 'wheel_id', 0 ) ), 'marketing' => '1' === $g( 'marketing' ), 'verified' => '1' === $g( 'verified' ), 'winners' => '1' === $g( 'winners' ), 'need_phone' => '1' === $g( 'need_phone' ) ) );
			$fa     = Lang::is_fa();
			$head   = $fa ? array( 'نام', 'موبایل', 'ایمیل', 'شناسه کاربر', 'موبایل تاییدشده', 'موافق دریافت پیشنهاد', 'تعداد چرخش', 'تعداد برد', 'استفاده از جایزه', 'شانس داده‌شده', 'شانس باقی‌مانده', 'اولین فعالیت', 'آخرین فعالیت' ) : array( 'name', 'mobile', 'email', 'user_id', 'verified', 'opt_in', 'spins', 'wins', 'redeemed', 'spins_granted', 'spins_left', 'first_seen', 'last_seen' );
			fputcsv( $out, array_merge( $head, $res['fields'] ) );
			foreach ( $res['rows'] as $c ) {
				$line = array( $c['name'], \Becharkhoon\Stats\People::phone_style( $c['phone'], $g( 'style', '09' ) ), $c['email'], $c['user_id'] ? $c['user_id'] : '', $c['verified'] ? 1 : 0, $c['marketing'] ? 1 : 0, $c['spins'], $c['wins'], $c['redeemed'], $c['granted'], $c['balance'], $c['first_at'] ? get_date_from_gmt( $c['first_at'] ) : '', $c['last_at'] ? get_date_from_gmt( $c['last_at'] ) : '' );
				foreach ( $res['fields'] as $fk ) {
					$line[] = isset( $c['fields'][ $fk ] ) ? $c['fields'][ $fk ] : '';
				}
				fputcsv( $out, $line );
			}
		} elseif ( 'people' === $what ) {
			fputcsv( $out, array( 'user_id', 'user', 'name', 'phone', 'email', 'spins', 'wins', 'credit_spins', 'redeemed', 'granted_in_period', 'spins_left', 'first', 'last' ) );
			$res = \Becharkhoon\Stats\People::query( array( 'from_utc' => $per['from_utc'], 'to_utc' => $per['to_utc'], 'wheel_id' => absint( $g( 'wheel_id', 0 ) ), 'search' => $g( 'search' ), 'only' => sanitize_key( $g( 'only' ) ), 'per_page' => 5000 ) );
			foreach ( $res['items'] as $r ) {
				fputcsv( $out, array( $r['uid'], $r['user_name'], $r['name'], $r['phone'], $r['email'], $r['spins'], $r['wins'], $r['paid'], $r['redeemed'], $r['granted'], $r['balance'], get_date_from_gmt( $r['first_at'] ), get_date_from_gmt( $r['last_at'] ) ) );
			}
		} elseif ( 'orders' === $what ) {
			$st  = \Becharkhoon\Stats\Reports::statuses( $g( 'statuses' ) );
			$res = \Becharkhoon\Stats\Orders::query( $per['from_utc'], $per['to_utc'], $st, $g( 'basis', 'created' ), absint( $g( 'wheel_id', 0 ) ), $g( 'search' ), 1, 5000 );
			fputcsv( $out, array( 'order_id', 'date', 'status', 'codes', 'prize', 'type', 'total', 'discount', 'gift_value', 'refunded', 'net', 'items', 'name', 'phone', 'email', 'won_at' ) );
			foreach ( $res['items'] as $r ) {
				fputcsv( $out, array( $r['order_id'], get_date_from_gmt( $r['d'] ), $r['status'], $r['codes'], $r['prize'], $r['prize_type'], (float) $r['total'], (float) $r['discount'], (float) $r['gift_value'], (float) $r['refunded'], (float) $r['total'] - (float) $r['refunded'], $r['items'], $r['name'], $r['phone'], $r['email'], $r['spin_at'] ? get_date_from_gmt( $r['spin_at'] ) : '' ) );
			}
		} elseif ( 'contacts' === $what ) {
			// Written above (TXT).
		} elseif ( 'leads' === $what ) {
			fputcsv( $out, array( 'id', 'name', 'phone', 'email', 'phone_verified', 'marketing', 'consent', 'spins', 'wins', 'wheel_id', 'fields', 'created_at' ) );
			$res = Leads::query( array( 'per_page' => 5000, 'search' => isset( $_GET['search'] ) ? sanitize_text_field( wp_unslash( $_GET['search'] ) ) : '', 'marketing' => ! empty( $_GET['marketing'] ) ) );
			foreach ( $res['items'] as $r ) {
				fputcsv( $out, array( $r['id'], $r['name'], $r['phone'], $r['email'], $r['phone_verified'], $r['marketing'], $r['consent'], $r['spins'], $r['wins'], $r['wheel_id'], wp_json_encode( $r['fields'], JSON_UNESCAPED_UNICODE ), $r['created_at'] ) );
			}
		} elseif ( 'bulk' === $what ) {
			$st = array( 'pending' => Lang::t( 'در صف', 'Waiting' ), 'sent' => Lang::t( 'ارسال شد', 'Sent' ), 'failed' => Lang::t( 'خطا', 'Failed' ), 'cancelled' => Lang::t( 'ارسال نشد (لغو)', 'Not sent (cancelled)' ), 'done' => Lang::t( 'انجام شد', 'Done' ) );
			fputcsv( $out, array( 'phone', 'name', 'sms_status', 'spin_gift', 'batch', 'tries', 'sent_at', 'message', 'panel_response' ) );
			$res = \Becharkhoon\Notify\Bulk::items( absint( $_GET['id'] ?? 0 ), array( 'per_page' => 5000, 'status' => sanitize_key( wp_unslash( $_GET['status'] ?? '' ) ) ) );
			foreach ( $res['items'] as $r ) {
				fputcsv( $out, array( $r['phone'], $r['name'], $st[ $r['status'] ] ?? $r['status'], $r['grant_status'], $r['batch'], $r['tries'], $r['sent_at'], $r['message'], $r['response'] ) );
			}
		} elseif ( 'credits' === $what ) {
			fputcsv( $out, array( 'id', 'wheel_id', 'user_id', 'user', 'phone', 'email', 'qty', 'used', 'reason', 'note', 'status', 'created_at', 'expires_at' ) );
			$res = Ledger::query( array( 'per_page' => 200, 'page' => 1 ) );
			$pages = (int) ceil( $res['total'] / 200 );
			for ( $p = 1; $p <= min( $pages, 50 ); $p++ ) {
				$res = 1 === $p ? $res : Ledger::query( array( 'per_page' => 200, 'page' => $p ) );
				foreach ( $res['items'] as $r ) {
					fputcsv( $out, array( $r['id'], $r['wheel_id'], $r['user_id'], $r['user_name'], $r['phone'], $r['email'], $r['qty'], $r['used'], $r['reason'], $r['note'], $r['status'], $r['created_at'], $r['expires_at'] ) );
				}
			}
		} else {
			fputcsv( $out, array( 'id', 'wheel_id', 'date', 'result', 'prize', 'type', 'code', 'status', 'name', 'phone', 'email', 'user_id', 'order_id', 'revenue', 'source', 'ip', 'expires_at' ) );
			$where  = '1=1';
			$params = array();
			if ( ! empty( $_GET['wheel_id'] ) ) {
				$where   .= ' AND wheel_id = %d';
				$params[] = absint( $_GET['wheel_id'] );
			}
			if ( ! empty( $_GET['from'] ) ) {
				$where   .= ' AND created_at >= %s';
				$params[] = Stats::utc( sanitize_text_field( wp_unslash( $_GET['from'] ) ) . ' 00:00:00' );
			}
			if ( ! empty( $_GET['to'] ) ) {
				$where   .= ' AND created_at <= %s';
				$params[] = Stats::utc( sanitize_text_field( wp_unslash( $_GET['to'] ) ) . ' 23:59:59' );
			}
			if ( ! empty( $_GET['result'] ) ) {
				$where   .= ' AND result = %s';
				$params[] = sanitize_key( wp_unslash( $_GET['result'] ) );
			}
			$sql  = "SELECT * FROM {$wpdb->prefix}bch_spins WHERE $where ORDER BY id DESC LIMIT 50000";
			$rows = $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ) : $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore
			foreach ( (array) $rows as $r ) {
				fputcsv( $out, array( $r['id'], $r['wheel_id'], get_date_from_gmt( $r['created_at'] ), $r['result'], $r['slice_label'], $r['prize_type'], $r['coupon_code'], $r['status'], $r['name'], $r['phone'], $r['email'], $r['user_id'], $r['order_id'], $r['revenue'], $r['source'], $r['ip'], $r['expires_at'] ? get_date_from_gmt( $r['expires_at'] ) : '' ) );
			}
		}
		rewind( $out );
		$csv = stream_get_contents( $out );
		fclose( $out );
		nocache_headers();
		header( 'Content-Type: ' . ( 'txt' === $ext ? 'text/plain' : 'text/csv' ) . '; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="becharkhoon-' . $what . '-' . gmdate( 'Y-m-d' ) . '.' . $ext . '"' );
		echo $csv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}
}
