<?php
/**
 * Wheel configuration schema: defaults (FA/EN), deep-merge and strict sanitizing.
 * Every option the admin editor shows exists here; unknown keys are dropped.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Wheels;

use Becharkhoon\Core\Helpers;
use Becharkhoon\Core\Lang;
use Becharkhoon\Engine\Conditions;

defined( 'ABSPATH' ) || exit;

final class Schema {

	const MAX_SLICES = 24;
	const MIN_SLICES = 2;

	/** Slice (prize) types. */
	public static function prize_types() {
		return array( 'coupon_percent', 'coupon_fixed_cart', 'coupon_fixed_product', 'free_shipping', 'existing_coupon', 'free_product', 'wallet', 'points', 'extra_spin', 'code_pool', 'custom', 'link', 'lose', 'respin' );
	}

	/** Keys whose value may contain limited HTML. */
	public static function html_keys() {
		return array( 'popup.description', 'popup.footer_text', 'form.consent.text', 'form.marketing.text', 'messages.win_text', 'messages.lose_text', 'messages.earn_text', 'messages.closed_text', 'notify.email_body', 'notify.reminder_email_body', 'messages.claim_success' );
	}

	public static function t( $fa, $en, $is_fa ) {
		return $is_fa ? $fa : $en;
	}

	public static function slice_defaults( $is_fa = null ) {
		$fa = null === $is_fa ? Lang::is_fa() : $is_fa;
		return array(
			'id'           => '',
			'label'        => self::t( 'جایزه', 'Prize', $fa ),
			'sublabel'     => '',
			'type'         => 'coupon_percent',
			'value'        => 10,
			'coupon_code'  => '',
			'product_ids'  => array(),
			'gift_items'   => array(),
			'link_url'     => '',
			'link_text'    => '',
			'custom_text'  => '',
			'codes_text'   => '',
			'weight'       => 10,
			'stock'        => -1,
			'daily_cap'    => 0,
			'user_cap'     => 0,
			'color'        => '',
			'color2'       => '',
			'text_color'   => '',
			'icon'         => '',
			'image'        => '',
			'image_size'   => 34,
			'highlight'    => false,
			'hidden_label' => false,
			'message'      => '',
			'requires_claim' => false,
			'claim_fields' => 'address',
			'expiry_days'  => -1,
			'coupon_override' => false,
			'min_spend'    => 0,
			'max_discount' => 0,
			'free_shipping_too' => false,
			'conditions'   => array( 'enabled' => false, 'groups' => array() ),
		);
	}

	public static function field_defaults() {
		return array(
			'id'          => '',
			'type'        => 'text',
			'map'         => 'custom',
			'label'       => '',
			'placeholder' => '',
			'required'    => false,
			'enabled'     => true,
			'options'     => '',
			'width'       => 'full',
			'mobile'      => true,
			'desktop'     => true,
		);
	}

	public static function default_palette() {
		return array( '#1D4ED8', '#F59E0B', '#10B981', '#EF4444', '#8B5CF6', '#0EA5E9', '#EC4899', '#F97316' );
	}

	/** Default starter slices (8). */
	public static function default_slices( $is_fa = null ) {
		$fa   = null === $is_fa ? Lang::is_fa() : $is_fa;
		$base = self::slice_defaults( $fa );
		$rows = array(
			array( 'label' => self::t( '۱۰٪ تخفیف', '10% OFF', $fa ), 'type' => 'coupon_percent', 'value' => 10, 'weight' => 30 ),
			array( 'label' => self::t( 'پوچ', 'No luck', $fa ), 'type' => 'lose', 'value' => 0, 'weight' => 25, 'icon' => '😅' ),
			array( 'label' => self::t( '۱۵٪ تخفیف', '15% OFF', $fa ), 'type' => 'coupon_percent', 'value' => 15, 'weight' => 15 ),
			array( 'label' => self::t( 'ارسال رایگان', 'Free shipping', $fa ), 'type' => 'free_shipping', 'value' => 0, 'weight' => 12, 'icon' => '🚚' ),
			array( 'label' => self::t( '۲۰٪ تخفیف', '20% OFF', $fa ), 'type' => 'coupon_percent', 'value' => 20, 'weight' => 6 ),
			array( 'label' => self::t( 'یک شانس دیگر', 'Spin again', $fa ), 'type' => 'respin', 'value' => 0, 'weight' => 8, 'icon' => '🔁' ),
			array( 'label' => self::t( '۳۰٪ تخفیف', '30% OFF', $fa ), 'type' => 'coupon_percent', 'value' => 30, 'weight' => 3, 'highlight' => true ),
			array( 'label' => self::t( 'جایزه ویژه', 'Jackpot', $fa ), 'type' => 'coupon_percent', 'value' => 50, 'weight' => 1, 'stock' => 5, 'icon' => '🎁', 'highlight' => true ),
		);
		$out = array();
		foreach ( $rows as $i => $r ) {
			$out[] = array_merge( $base, $r, array( 'id' => 's' . ( $i + 1 ) ) );
		}
		return $out;
	}

	public static function default_fields( $is_fa ) {
		$f = self::field_defaults();
		return array(
			array_merge( $f, array( 'id' => 'name', 'type' => 'text', 'map' => 'name', 'label' => self::t( 'نام', 'Name', $is_fa ), 'placeholder' => self::t( 'نام شما', 'Your name', $is_fa ), 'required' => false, 'width' => 'full' ) ),
			array_merge( $f, array( 'id' => 'phone', 'type' => 'tel', 'map' => 'phone', 'label' => self::t( 'شماره موبایل', 'Mobile number', $is_fa ), 'placeholder' => '09xxxxxxxxx', 'required' => true ) ),
			array_merge( $f, array( 'id' => 'email', 'type' => 'email', 'map' => 'email', 'label' => self::t( 'ایمیل', 'Email', $is_fa ), 'placeholder' => 'you@example.com', 'required' => false, 'enabled' => ! $is_fa ) ),
		);
	}

	/**
	 * Full defaults for a new wheel.
	 *
	 * @param bool|null $is_fa Language of default texts.
	 */
	public static function defaults( $is_fa = null ) {
		$fa = null === $is_fa ? Lang::is_fa() : (bool) $is_fa;
		return array(
			'lang'      => 'auto',
			'note'      => '',
			'slices'    => self::default_slices( $fa ),
			'design'    => array(
				'theme'            => 'classic',
				'size'             => 400,
				'size_mobile'      => 300,
				'palette'          => self::default_palette(),
				'text_color'       => '#ffffff',
				'font_size'        => 15,
				'font_weight'      => 800,
				'text_orientation' => 'radial',
				'text_position'    => 0.6,
				'text_shadow'      => true,
				'icon_size'        => 22,
				'slice_border_color' => 'rgba(255,255,255,.35)',
				'slice_border_width' => 2,
				'slice_gradient'   => true,
				'gloss'            => true,
				'shadow'           => true,
				'glow'             => true,
				'glow_color'       => 'rgba(29,78,216,.45)',
				'rim_style'        => 'lights',
				'rim_color'        => '#0B1B3F',
				'rim_color2'       => '#1D4ED8',
				'rim_width'        => 16,
				'light_color'      => '#FFF7CC',
				'light_color2'     => '#FBBF24',
				'light_count'      => 16,
				'light_animation'  => 'chase',
				'pegs'             => true,
				'center_style'     => 'button',
				'center_color'     => '#ffffff',
				'center_color2'    => '#dbeafe',
				'center_border'    => '#0B1B3F',
				'center_size'      => 0.2,
				'center_image'     => '',
				'center_text'      => self::t( 'بچرخون', 'SPIN', $fa ),
				'center_text_color' => '#0B1B3F',
				'center_clickable' => true,
				'pointer_style'    => 'arrow',
				'pointer_position' => 'top',
				'pointer_color'    => '#EF4444',
				'pointer_stroke'   => '#ffffff',
				'pointer_image'    => '',
				'pointer_size'     => 1,
				'pointer_bounce'   => true,
				'custom_mode'      => false,
				'custom_image'     => '',
				'custom_offset'    => 0,
				'custom_labels'    => false,
				'frame_image'      => '',
				'spin_duration'    => 6,
				'spin_rotations'   => 8,
				'spin_easing'      => 'quint',
				'idle_rotate'      => true,
				'idle_speed'       => 30,
				'land_random'      => true,
				'win_effect'       => 'confetti',
				'win_emoji'        => '🎉',
				'lose_effect'      => 'shake',
				'highlight_win'    => true,
				'dim_others'       => true,
				'sound'            => true,
				'sound_tick'       => true,
				'sound_win'        => true,
				'sound_lose'       => true,
				'sound_volume'     => 0.5,
				'sound_tick_url'   => '',
				'sound_win_url'    => '',
				'sound_lose_url'   => '',
				'mute_button'      => true,
				'reduce_motion'    => true,
			),
			'popup'     => array(
				'mode'             => 'modal',
				'layout'           => 'split',
				'wheel_side'       => 'start',
				'width'            => 880,
				'radius'           => 24,
				'padding'          => 32,
				'bg_type'          => 'gradient',
				'bg_color'         => '#ffffff',
				'bg_color2'        => '#eff6ff',
				'bg_angle'         => 135,
				'bg_image'         => '',
				'bg_image_opacity' => 1,
				'pattern'          => 'confetti',
				'pattern_color'    => 'rgba(29,78,216,.10)',
				'text_color'       => '#0f172a',
				'muted_color'      => '#64748b',
				'accent_color'     => '#1D4ED8',
				'border_color'     => 'transparent',
				'border_width'     => 0,
				'shadow'           => 'xl',
				'overlay_color'    => '#0b1220',
				'overlay_opacity'  => 0.62,
				'overlay_blur'     => 4,
				'close_overlay'    => true,
				'close_esc'        => true,
				'anim_in'          => 'zoom',
				'anim_out'         => 'fade',
				'anim_duration'    => 450,
				'close_show'       => true,
				'close_position'   => 'end',
				'close_style'      => 'circle',
				'close_color'      => '#334155',
				'close_bg'         => 'rgba(15,23,42,.06)',
				'close_delay'      => 0,
				'logo'             => '',
				'logo_width'       => 110,
				'badge'            => self::t( 'فقط امروز', 'Today only', $fa ),
				'badge_bg'         => '#FEF3C7',
				'badge_color'      => '#B45309',
				'title'            => self::t( 'گردونه شانس رو بچرخون! 🎁', 'Spin to win a prize! 🎁', $fa ),
				'title_color'      => '#0f172a',
				'title_size'       => 28,
				'title_weight'     => 900,
				'subtitle'         => self::t( 'همین حالا شانس‌ات رو امتحان کن و تخفیف ویژه بگیر', 'Try your luck now and win an exclusive discount', $fa ),
				'subtitle_color'   => '#334155',
				'description'      => self::t( 'شماره موبایل‌ات را وارد کن و گردونه را بچرخان. جایزه‌ات فوراً نمایش داده و پیامک می‌شود.', 'Enter your details and spin the wheel. Your prize is shown instantly.', $fa ),
				'countdown'        => false,
				'countdown_mode'   => 'evergreen',
				'countdown_minutes' => 15,
				'countdown_deadline' => '',
				'countdown_label'  => self::t( 'فرصت باقی‌مانده:', 'Offer ends in:', $fa ),
				'countdown_style'  => 'boxes',
				'social_proof'     => true,
				'social_text'      => self::t( '{count} نفر امروز گردونه را چرخاندند', '{count} people spun the wheel today', $fa ),
				'social_min'       => 3,
				'ticker'           => false,
				'ticker_text'      => self::t( '{name} برنده «{prize}» شد', '{name} won "{prize}"', $fa ),
				'ticker_count'     => 10,
				'trust_items'      => array(),
				'footer_text'      => '',
				'no_thanks'        => true,
				'no_thanks_text'   => self::t( 'نه ممنون، بعداً', 'No thanks, maybe later', $fa ),
				'no_thanks_days'   => 3,
				'font_scale'       => 1,
				'direction'        => 'auto',
				'mobile_mode'      => 'sheet',
				'mobile_hide_desc' => false,
				'mobile_wheel_first' => true,
				'fit_screen'       => true,
				'custom_css'       => '',
				'custom_class'     => '',
				'code_style'       => 'dashed',
				'code_bg'          => '',
				'code_border'      => '',
				'code_color'       => '',
				'copy_bg'          => '',
				'copy_color'       => '',
				'apply_bg'         => '',
				'apply_bg2'        => '',
				'apply_color'      => '',
				'ghost_color'      => '',
				'link_color'       => '',
				'msg_bg'           => '',
				'msg_color'        => '',
				'icon_login'       => '🔐',
				'icon_wait'        => '⏳',
				'icon_earn'        => '🎟️',
				'icon_closed'      => '🏁',
				'next_color'       => '',
				'share_style'      => 'brand',
				'ticker_bg'        => '',
				'ticker_color'     => '',
				'social_color'     => '',
				'social_dot_color' => '#22c55e',
				'countdown_bg'     => '',
				'countdown_color'  => '',
			),
			'form'      => array(
				'fields'            => self::default_fields( $fa ),
				'phone_otp'         => false,
				'prefill_user'      => true,
				'hide_known'        => true,
				'consent'           => array(
					'enabled'  => false,
					'required' => true,
					'text'     => self::t( 'با <a href="/terms" target="_blank">قوانین و شرایط</a> موافقم', 'I agree to the <a href="/terms" target="_blank">terms</a>', $fa ),
				),
				'marketing'         => array(
					'enabled' => false,
					'checked' => true,
					'text'    => self::t( 'پیشنهادهای ویژه را برایم پیامک کن', 'Send me special offers', $fa ),
				),
				'button_text'       => self::t( 'بچرخون!', 'SPIN NOW!', $fa ),
				'button_bg'         => '#1D4ED8',
				'button_bg2'        => '#7C3AED',
				'button_color'      => '#ffffff',
				'button_radius'     => 14,
				'button_size'       => 'lg',
				'button_animation'  => 'shine',
				'button_full'       => true,
				'field_bg'          => '#ffffff',
				'field_border'      => '#d7dbe7',
				'field_text'        => '#0f172a',
				'field_radius'      => 12,
				'otp_send_text'     => self::t( 'ارسال کد تایید', 'Send code', $fa ),
				'otp_label'         => self::t( 'کد تایید پیامک‌شده', 'Verification code', $fa ),
				'login_text'        => self::t( 'برای چرخاندن گردونه وارد حساب کاربری شوید', 'Log in to spin the wheel', $fa ),
				'login_button'      => self::t( 'ورود / ثبت‌نام', 'Log in / Register', $fa ),
				'login_url'         => '',
				'otp_bg'            => '',
				'otp_color'         => '',
				'label_color'       => '',
			),
			'display'   => array(
				'mode'              => 'popup',
				'on_load'           => true,
				'delay'             => 6,
				'delay_max'         => 0,
				'scroll'            => false,
				'scroll_percent'    => 40,
				'exit_intent'       => true,
				'exit_mobile'       => true,
				'inactivity'        => false,
				'inactivity_seconds' => 30,
				'pageviews'         => 0,
				'click_selector'    => '',
				'add_to_cart'       => false,
				'thankyou'          => true,
				'frequency'         => 'days',
				'frequency_days'    => 1,
				'max_impressions'   => 0,
				'hide_after_close_days' => 1,
				'hide_after_spin_days'  => 0,
				'hide_when_no_spins' => false,
				'devices'           => array( 'desktop', 'tablet', 'mobile' ),
				'launcher'          => true,
				'launcher_position' => 'bottom-start',
				'launcher_style'    => 'wheel',
				'launcher_image'    => '',
				'launcher_text'     => self::t( 'گردونه شانس', 'Spin & win', $fa ),
				'launcher_bg'       => '#1D4ED8',
				'launcher_color'    => '#ffffff',
				'launcher_size'     => 62,
				'launcher_animation' => 'spin',
				'launcher_badge'    => true,
				'launcher_hide_after_spin' => false,
				'launcher_offset_x' => 20,
				'launcher_offset_y' => 20,
				'launcher_mobile'   => true,
				'launcher_desktop'  => true,
				'launcher_delay'    => 0,
				'coupon_bar'        => true,
				'coupon_bar_position' => 'bottom',
				'coupon_bar_text'   => self::t( '🎁 کد {code} ({prize}) برای شما فعال است', '🎁 Your code {code} ({prize}) is active', $fa ),
				'coupon_bar_bg'     => '#0B1B3F',
				'coupon_bar_color'  => '#ffffff',
				'coupon_bar_countdown' => true,
				'coupon_bar_apply'  => true,
				'coupon_bar_layout' => 'full',
				'coupon_bar_style'  => 'solid',
				'coupon_bar_bg2'    => '#1D4ED8',
				'coupon_bar_icon'   => '',
				'coupon_bar_code_style' => 'chip',
				'coupon_bar_code_bg' => 'rgba(255,255,255,.14)',
				'coupon_bar_code_color' => '#FBBF24',
				'coupon_bar_copy'   => true,
				'coupon_bar_copy_label' => '',
				'coupon_bar_copy_bg' => '',
				'coupon_bar_copy_color' => '',
				'coupon_bar_apply_label' => '',
				'coupon_bar_apply_bg' => '#ffffff',
				'coupon_bar_apply_color' => '#0f172a',
				'coupon_bar_btn_radius' => 999,
				'coupon_bar_radius' => 16,
				'coupon_bar_font'   => 14,
				'coupon_bar_shadow' => 'soft',
				'coupon_bar_border' => '',
				'coupon_bar_close'  => true,
				'coupon_bar_close_color' => '',
				'coupon_bar_cd_style' => 'text',
				'coupon_bar_cd_color' => '',
				'coupon_bar_anim'   => 'slide',
				'coupon_bar_mobile_compact' => true,
				'coupon_bar_hide_applied' => true,
				'coupon_bar_account' => true,
			),
			'targeting' => array(
				'pages'      => 'all',
				'page_rules' => array(),
				'audience'   => array( 'enabled' => false, 'groups' => array() ),
			),
			'access'    => array(
				'mode'             => 'free',
				'require_login'    => false,
				'require_otp'      => false,
				'limit_user'       => true,
				'limit_phone'      => true,
				'limit_email'      => true,
				'limit_device'     => true,
				'limit_ip'         => false,
				'limits'           => array(
					array( 'count' => 1, 'period' => 'day', 'hours' => 24 ),
				),
				'cooldown_minutes' => 0,
				'max_wins'         => 0,
				'max_wins_period'  => 'lifetime',
				'credit_scope'     => 'any',
				'cap_credits'      => false,
				'conditions'       => array( 'enabled' => false, 'groups' => array() ),
				'blocked_roles'    => array(),
				'show_how_to_earn' => true,
				'earn_hint'        => '',
			),
			'engine'    => array(
				'first_spin_win'   => false,
				'pity_after'       => 0,
				'respin_counts'    => false,
				'max_respins'      => 3,
				'daily_win_cap'    => 0,
				'total_win_cap'    => 0,
				'fallback_slice'   => '',
				'personal_odds'    => false,
				'vip_boost'        => 0,
			),
			'coupon'    => array(
				'prefix'            => 'WHEEL-',
				'length'            => 8,
				'charset'           => 'upper_num',
				'expiry_days'       => 7,
				'expiry_hours'      => 0,
				'min_spend'         => 0,
				'max_spend'         => 0,
				'max_discount'      => 0,
				'individual_use'    => true,
				'exclude_sale'      => false,
				'free_shipping'     => false,
				'usage_limit'       => 1,
				'usage_limit_user'  => 1,
				'limit_items'       => 0,
				'product_ids'       => array(),
				'exclude_product_ids' => array(),
				'category_ids'      => array(),
				'exclude_category_ids' => array(),
				'restrict_email'    => true,
				'auto_apply'        => true,
				'first_order_only'  => false,
				'description'       => '',
			),
			'messages'  => array(
				'win_title'      => self::t( 'تبریک {name}! 🎉', 'Congratulations {name}! 🎉', $fa ),
				'win_text'       => self::t( 'شما برنده <b>{prize}</b> شدید', 'You won <b>{prize}</b>', $fa ),
				'code_label'     => self::t( 'کد جایزه شما', 'Your code', $fa ),
				'copy_text'      => self::t( 'کپی', 'Copy', $fa ),
				'copied_text'    => self::t( 'کپی شد ✓', 'Copied ✓', $fa ),
				'apply_text'     => self::t( 'اعمال در سبد خرید', 'Apply to cart', $fa ),
				'apply_redirect' => 'cart',
				'apply_url'      => '',
				'continue_text'  => self::t( 'ادامه خرید', 'Continue shopping', $fa ),
				'expires_text'   => self::t( 'معتبر تا {expiry}', 'Valid until {expiry}', $fa ),
				'lose_title'     => self::t( 'ای بابا! 😅', 'So close! 😅', $fa ),
				'lose_text'      => self::t( 'این بار شانس با شما نبود. دفعه بعد حتماً!', 'Not this time. Better luck next time!', $fa ),
				'respin_text'    => self::t( 'یک شانس مجدد گرفتید، دوباره بچرخانید!', 'You got a free re-spin. Spin again!', $fa ),
				'spins_left_text' => self::t( '{n} شانس دیگر دارید', 'You have {n} more spins', $fa ),
				'spin_again_text' => self::t( 'دوباره بچرخون', 'Spin again', $fa ),
				'no_spins_text'  => self::t( 'فعلاً شانسی برای چرخاندن ندارید.', 'You have no spins right now.', $fa ),
				'cooldown_text'  => self::t( 'شانس بعدی شما: {time}', 'Next spin in: {time}', $fa ),
				'limit_text'     => self::t( 'سهمیه چرخاندن شما تمام شده است.', 'You have used all your spins.', $fa ),
				'not_eligible_text' => self::t( 'این گردونه شامل حساب شما نمی‌شود.', 'You are not eligible for this wheel.', $fa ),
				'closed_text'    => self::t( 'این کمپین به پایان رسیده است.', 'This campaign has ended.', $fa ),
				'earn_title'     => self::t( 'چطور شانس چرخاندن بگیرم؟', 'How do I earn spins?', $fa ),
				'earn_text'      => '',
				'spinning_text'  => self::t( 'در حال چرخش...', 'Spinning…', $fa ),
				'error_text'     => self::t( 'خطایی رخ داد، دوباره تلاش کنید.', 'Something went wrong, please try again.', $fa ),
				'share_text'     => self::t( 'دوستانت را دعوت کن و شانس بیشتر بگیر', 'Invite friends to earn more spins', $fa ),
				'gift_text'      => self::t( '🎁 این محصول برات جایزه اومد!', '🎁 This product is your gift!', $fa ),
				'gift_hint'      => self::t( 'کد را در سبد خرید بزنید تا محصول رایگان به سبدتان اضافه شود.', 'Apply the code in your cart and the product is added for free.', $fa ),
				'claim_title'    => self::t( 'برای دریافت جایزه اطلاعات تحویل را وارد کنید', 'Enter delivery details to claim your prize', $fa ),
				'claim_button'   => self::t( 'ثبت و دریافت جایزه', 'Claim prize', $fa ),
				'claim_success'  => self::t( 'اطلاعات شما ثبت شد. به‌زودی با شما تماس می‌گیریم.', 'Saved! We will contact you soon.', $fa ),
				'auto_close'     => 0,
				'show_share'     => true,
			),
			'notify'    => array(
				'email_customer'   => true,
				'email_subject'    => self::t( '🎁 جایزه گردونه شانس شما: {prize}', '🎁 Your wheel prize: {prize}', $fa ),
				'email_heading'    => self::t( 'تبریک! برنده شدید', 'Congratulations!', $fa ),
				'email_body'       => self::t( '<p>سلام {name} عزیز،</p><p>شما در گردونه شانس {site} برنده <b>{prize}</b> شدید.</p><p>کد شما: <b>{code}</b></p><p>اعتبار تا: {expiry}</p>', '<p>Hi {name},</p><p>You won <b>{prize}</b> on the {site} wheel.</p><p>Your code: <b>{code}</b></p><p>Valid until: {expiry}</p>', $fa ),
				'email_button'     => self::t( 'استفاده از جایزه', 'Use my prize', $fa ),
				'sms_customer'     => true,
				'sms_override'     => false,
				'credit_override'  => false,
				'sms_mode'         => 'text',
				'sms_text'         => self::t( "{name} عزیز، تبریک!\nجایزه گردونه: {prize}\nکد: {code}\nاعتبار تا {expiry}\n{site}", "Congrats {name}!\nPrize: {prize}\nCode: {code}\nValid until {expiry}\n{site}", $fa ),
				'sms_pattern'      => '',
				'sms_pattern_vars' => "prize={prize}\ncode={code}\nexpiry={expiry}",
				'sms_lose'         => false,
				'sms_lose_text'    => '',
				'admin_email'      => false,
				'admin_sms'        => false,
				'admin_messenger'  => false,
				'admin_only_wins'  => true,
				'reminder'         => false,
				'reminder_days'    => 1,
				'reminder_channel' => 'sms',
				'reminder_text'    => self::t( "{name} عزیز، کد {code} ({prize}) فردا منقضی می‌شود. {link}", "{name}, your code {code} ({prize}) expires soon. {link}", $fa ),
				'reminder_email_body' => '',
				'credit_sms'       => false,
				'credit_text'      => self::t( "تبریک! {n} شانس چرخاندن گردونه {site} گرفتید:\n{link}", "You earned {n} spins at {site}:\n{link}", $fa ),
				'webhooks'         => true,
			),
			'schedule'  => array(
				'start'      => '',
				'end'        => '',
				'days'       => array( 0, 1, 2, 3, 4, 5, 6 ),
				'hour_from'  => 0,
				'hour_to'    => 24,
			),
			'advanced'  => array(
				'track_ga'        => true,
				'track_pixel'     => false,
				'redirect_win'    => '',
				'shortcode_only'  => false,
				'ab_weight'       => 50,
				'inline_autoload' => true,
				'preload'         => false,
				'landing_url'     => '',
				'landing_open'    => false,
			),
			// Elementor-like positioning per element: { el: {x,y,mt,mb,w,align,hide} } (desktop/base).
			'layout'     => array(),
			// Per-device overrides, dotted paths → value: { tablet: {"form.button_radius": 30, "layout.button.x": 12}, mobile: {...} }.
			'responsive' => array( 'tablet' => array(), 'mobile' => array() ),
		);
	}

	/** Elements that can be moved / aligned / resized / hidden in the live editor. */
	public static function layout_elements() {
		return array( 'logo', 'badge', 'title', 'subtitle', 'desc', 'countdown', 'social', 'fields', 'otp', 'button', 'nothanks', 'close', 'wheel', 'trust', 'footer', 'result', 'code', 'actions' );
	}

	/** One element's layout props. */
	public static function sanitize_layout_item( $raw ) {
		$raw = is_array( $raw ) ? $raw : array();
		$out = array();
		foreach ( array( 'x' => 800, 'y' => 800 ) as $k => $lim ) {
			if ( isset( $raw[ $k ] ) && is_numeric( $raw[ $k ] ) && 0 !== (int) $raw[ $k ] ) {
				$out[ $k ] = max( -$lim, min( $lim, (int) $raw[ $k ] ) );
			}
		}
		foreach ( array( 'mt', 'mb' ) as $k ) {
			if ( isset( $raw[ $k ] ) && is_numeric( $raw[ $k ] ) && '' !== $raw[ $k ] ) {
				$out[ $k ] = max( -200, min( 300, (int) $raw[ $k ] ) );
			}
		}
		if ( isset( $raw['w'] ) && is_numeric( $raw['w'] ) && (int) $raw['w'] > 0 ) {
			$out['w'] = max( 10, min( 100, (int) $raw['w'] ) );
		}
		if ( isset( $raw['align'] ) && in_array( $raw['align'], array( 'start', 'center', 'end' ), true ) ) {
			$out['align'] = $raw['align'];
		}
		if ( ! empty( $raw['hide'] ) ) {
			$out['hide'] = true;
		}
		return $out;
	}

	public static function sanitize_layout( $raw ) {
		$out = array();
		foreach ( self::layout_elements() as $el ) {
			if ( isset( $raw[ $el ] ) ) {
				$it = self::sanitize_layout_item( $raw[ $el ] );
				if ( $it ) {
					$out[ $el ] = $it;
				}
			}
		}
		return $out;
	}

	/** May this dotted path differ per device? (style only — texts, links, images and lists stay shared). */
	public static function responsive_ok( $path ) {
		if ( ! preg_match( '/^(design|popup|form|display|layout)\.[a-z0-9_]+(\.[a-z0-9_]+)?$/', $path ) ) {
			return false;
		}
		if ( preg_match( '/^form\.(fields|consent|marketing)/', $path ) ) {
			return false;
		}
		return ! preg_match( '/(_text|title|subtitle|description|badge|label|placeholder|_button|_url|_image|image|logo|_css|_class|_html|palette|trust_items|deadline|_selector|devices)$/', $path );
	}

	private static function get_path( array $a, $path ) {
		foreach ( explode( '.', $path ) as $p ) {
			if ( ! is_array( $a ) || ! array_key_exists( $p, $a ) ) {
				return null;
			}
			$a = $a[ $p ];
		}
		return $a;
	}

	private static function set_path( array &$a, $path, $v ) {
		$ref = &$a;
		foreach ( explode( '.', $path ) as $p ) {
			if ( ! isset( $ref[ $p ] ) || ! is_array( $ref[ $p ] ) ) {
				$ref[ $p ] = isset( $ref[ $p ] ) ? $ref[ $p ] : array();
			}
			$ref = &$ref[ $p ];
		}
		$ref = $v;
		unset( $ref );
	}

	/**
	 * Per-device overrides: keep only allowed, valid values that differ from the base config.
	 * Values are validated by sanitizing the merged config (same rules as the base).
	 */
	public static function sanitize_responsive( $raw, array $cfg ) {
		$out = array( 'tablet' => array(), 'mobile' => array() );
		$raw = is_array( $raw ) ? $raw : array();
		foreach ( array( 'tablet', 'mobile' ) as $dev ) {
			$ov = isset( $raw[ $dev ] ) && is_array( $raw[ $dev ] ) ? array_slice( $raw[ $dev ], 0, 400, true ) : array();
			if ( ! $ov ) {
				continue;
			}
			$merged = $cfg;
			$keys   = array();
			foreach ( $ov as $path => $v ) {
				$path = (string) $path;
				if ( ! self::responsive_ok( $path ) || is_array( $v ) || is_object( $v ) ) {
					continue;
				}
				if ( 0 === strpos( $path, 'layout.' ) ) {
					$parts = explode( '.', $path );
					if ( 3 !== count( $parts ) || ! in_array( $parts[1], self::layout_elements(), true ) ) {
						continue;
					}
					$item = self::sanitize_layout_item( array( $parts[2] => $v ) );
					if ( array_key_exists( $parts[2], $item ) ) {
						$out[ $dev ][ $path ] = $item[ $parts[2] ];
					} elseif ( in_array( $parts[2], array( 'x', 'y', 'w', 'align', 'hide', 'mt', 'mb' ), true ) ) {
						$out[ $dev ][ $path ] = 'hide' === $parts[2] ? false : ( 'align' === $parts[2] ? '' : 0 ); // Explicit reset on this device.
					}
					continue;
				}
				$base = self::get_path( $cfg, $path );
				if ( null === $base || is_array( $base ) ) {
					continue;
				}
				self::set_path( $merged, $path, $v );
				$keys[] = $path;
			}
			if ( $keys ) {
				$clean = self::sanitize( $merged, true );
				foreach ( $keys as $path ) {
					$val = self::get_path( $clean, $path );
					$bv  = self::get_path( $cfg, $path );
					if ( null !== $val && $val !== $bv && ! ( is_string( $val ) && is_string( $bv ) && strtolower( $val ) === strtolower( $bv ) ) ) {
						$out[ $dev ][ $path ] = $val;
					}
				}
			}
		}
		return $out;
	}

	/** Merge a stored config onto defaults (lists replace, maps merge). */
	public static function merge( array $base, array $over ) {
		foreach ( $over as $k => $v ) {
			if ( ! array_key_exists( $k, $base ) ) {
				continue;
			}
			if ( is_array( $v ) && is_array( $base[ $k ] ) && self::is_assoc( $base[ $k ] ) && self::is_assoc( $v ) ) {
				$base[ $k ] = self::merge( $base[ $k ], $v );
			} else {
				$base[ $k ] = $v;
			}
		}
		return $base;
	}

	public static function is_assoc( array $a ) {
		if ( array() === $a ) {
			return false;
		}
		return array_keys( $a ) !== range( 0, count( $a ) - 1 );
	}

	/** Load-time normalisation: defaults + stored (no re-sanitizing). */
	public static function hydrate( $stored, $is_fa = null ) {
		$stored = Helpers::json_decode_array( $stored );
		$cfg    = self::merge( self::defaults( $is_fa ), $stored );
		$sd     = self::slice_defaults( $is_fa );
		foreach ( $cfg['slices'] as $i => $s ) {
			$cfg['slices'][ $i ] = self::merge( $sd, is_array( $s ) ? $s : array() );
		}
		return $cfg;
	}

	/**
	 * Sanitize a complete config coming from the admin.
	 *
	 * @param array $input Raw config.
	 */
	public static function sanitize( array $input, $nested = false ) {
		$defaults = self::defaults();
		$cfg      = self::sanitize_map( $defaults, $input, '' );
		$cfg['layout']     = self::sanitize_layout( $input['layout'] ?? array() );
		$cfg['responsive'] = array( 'tablet' => array(), 'mobile' => array() );

		// Slices.
		$slices = array();
		$seen   = array();
		foreach ( array_slice( (array) ( $input['slices'] ?? array() ), 0, self::MAX_SLICES ) as $raw ) {
			if ( ! is_array( $raw ) ) {
				continue;
			}
			$s = self::sanitize_slice( $raw );
			if ( '' === $s['id'] || isset( $seen[ $s['id'] ] ) ) {
				$s['id'] = 's' . substr( md5( uniqid( '', true ) ), 0, 8 );
			}
			$seen[ $s['id'] ] = true;
			$slices[]         = $s;
		}
		if ( count( $slices ) < self::MIN_SLICES ) {
			$slices = self::default_slices();
		}
		$cfg['slices'] = $slices;

		// Form fields.
		$fields = array();
		$fd     = self::field_defaults();
		$ids    = array();
		foreach ( array_slice( (array) ( $input['form']['fields'] ?? array() ), 0, 20 ) as $raw ) {
			if ( ! is_array( $raw ) ) {
				continue;
			}
			$f        = self::sanitize_map( $fd, $raw, 'field' );
			$f['id']  = sanitize_key( $f['id'] ) ? sanitize_key( $f['id'] ) : 'f' . substr( md5( uniqid( '', true ) ), 0, 6 );
			$f['type'] = in_array( $f['type'], array( 'text', 'email', 'tel', 'number', 'date', 'select', 'radio', 'checkbox', 'textarea' ), true ) ? $f['type'] : 'text';
			$f['map']  = in_array( $f['map'], array( 'name', 'email', 'phone', 'birthday', 'city', 'gender', 'custom' ), true ) ? $f['map'] : 'custom';
			$f['width'] = 'half' === $f['width'] ? 'half' : 'full';
			$f['options'] = sanitize_textarea_field( (string) ( $raw['options'] ?? '' ) );
			if ( isset( $ids[ $f['id'] ] ) ) {
				continue;
			}
			$ids[ $f['id'] ] = true;
			$fields[]        = $f;
		}
		$cfg['form']['fields'] = $fields;

		// Lists.
		$cfg['design']['palette'] = array_values( array_filter( array_map( array( Helpers::class, 'color' ), array_slice( (array) ( $input['design']['palette'] ?? array() ), 0, 24 ) ) ) );
		if ( ! $cfg['design']['palette'] ) {
			$cfg['design']['palette'] = self::default_palette();
		}
		$cfg['popup']['trust_items'] = array_values( array_filter( array_map( 'sanitize_text_field', array_slice( (array) ( $input['popup']['trust_items'] ?? array() ), 0, 6 ) ) ) );
		$cfg['display']['devices']   = array_values( array_intersect( (array) ( $input['display']['devices'] ?? array() ), array( 'desktop', 'tablet', 'mobile' ) ) );
		$cfg['schedule']['days']     = array_values( array_unique( array_filter( array_map( 'intval', (array) ( $input['schedule']['days'] ?? array() ) ), static function ( $d ) {
			return $d >= 0 && $d <= 6;
		} ) ) );
		$cfg['access']['blocked_roles'] = array_values( array_map( 'sanitize_key', (array) ( $input['access']['blocked_roles'] ?? array() ) ) );

		$limits = array();
		foreach ( array_slice( (array) ( $input['access']['limits'] ?? array() ), 0, 6 ) as $l ) {
			if ( ! is_array( $l ) ) {
				continue;
			}
			$period = in_array( $l['period'] ?? '', array( 'lifetime', 'hour', 'day', 'week', 'month', 'rolling' ), true ) ? $l['period'] : 'day';
			$limits[] = array( 'count' => max( 0, (int) ( $l['count'] ?? 1 ) ), 'period' => $period, 'hours' => max( 1, (int) ( $l['hours'] ?? 24 ) ) );
		}
		$cfg['access']['limits'] = $limits;

		$cfg['targeting']['page_rules'] = self::sanitize_page_rules( $input['targeting']['page_rules'] ?? array() );
		$cfg['targeting']['audience']   = Conditions::sanitize_set( $input['targeting']['audience'] ?? array() );
		$cfg['access']['conditions']    = Conditions::sanitize_set( $input['access']['conditions'] ?? array() );

		foreach ( array( 'product_ids', 'exclude_product_ids', 'category_ids', 'exclude_category_ids' ) as $k ) {
			$cfg['coupon'][ $k ] = self::id_list( $input['coupon'][ $k ] ?? array() );
		}

		// Enumerations.
		$enums = array(
			'design.text_orientation' => array( 'radial', 'horizontal', 'curved' ),
			'design.rim_style'        => array( 'lights', 'solid', 'double', 'dots', 'metal', 'neon', 'none' ),
			'design.light_animation'  => array( 'chase', 'blink', 'alternate', 'pulse', 'none' ),
			'design.center_style'     => array( 'button', 'circle', 'star', 'logo', 'gem', 'none' ),
			'design.pointer_style'    => array( 'arrow', 'pin', 'triangle', 'drop', 'diamond', 'ticker', 'image' ),
			'design.pointer_position' => array( 'top', 'right', 'bottom', 'left' ),
			'design.spin_easing'      => array( 'quint', 'cubic', 'expo', 'back', 'elastic', 'bounce' ),
			'design.win_effect'       => array( 'confetti', 'fireworks', 'coins', 'stars', 'hearts', 'snow', 'emoji', 'balloons', 'none' ),
			'design.lose_effect'      => array( 'shake', 'fade', 'none' ),
			'popup.mode'              => array( 'modal', 'fullscreen', 'slidein', 'sheet', 'half', 'sidebar' ),
			'popup.layout'            => array( 'split', 'stack', 'wheel-only', 'overlap' ),
			'popup.wheel_side'        => array( 'start', 'end' ),
			'popup.bg_type'           => array( 'color', 'gradient', 'image', 'glass' ),
			'popup.pattern'           => array( 'none', 'dots', 'confetti', 'stars', 'grid', 'waves', 'diagonal', 'snow', 'hearts' ),
			'popup.shadow'            => array( 'none', 'md', 'lg', 'xl', 'glow' ),
			'popup.anim_in'           => array( 'zoom', 'fade', 'slide-up', 'slide-down', 'slide-side', 'bounce', 'flip', 'rotate', 'none' ),
			'popup.anim_out'          => array( 'fade', 'zoom', 'slide-down', 'none' ),
			'popup.close_position'    => array( 'end', 'start', 'outside' ),
			'popup.close_style'       => array( 'circle', 'square', 'plain', 'text' ),
			'popup.countdown_mode'    => array( 'evergreen', 'fixed' ),
			'popup.countdown_style'   => array( 'boxes', 'inline' ),
			'popup.direction'         => array( 'auto', 'rtl', 'ltr' ),
			'popup.mobile_mode'       => array( 'sheet', 'modal', 'fullscreen' ),
			'form.button_size'        => array( 'md', 'lg', 'xl' ),
			'form.button_animation'   => array( 'shine', 'pulse', 'bounce', 'glow', 'none' ),
			'display.mode'            => array( 'popup', 'inline', 'both' ),
			'display.frequency'       => array( 'always', 'session', 'days', 'once' ),
			'display.launcher_position' => array( 'bottom-start', 'bottom-end', 'middle-start', 'middle-end', 'top-start', 'top-end' ),
			'display.launcher_style'  => array( 'wheel', 'gift', 'image', 'pill', 'tab' ),
			'display.launcher_animation' => array( 'spin', 'pulse', 'shake', 'bounce', 'none' ),
			'display.coupon_bar_position' => array( 'top', 'bottom' ),
			'display.coupon_bar_layout' => array( 'full', 'floating', 'pill' ),
			'display.coupon_bar_style' => array( 'solid', 'gradient', 'glass', 'ticket' ),
			'display.coupon_bar_code_style' => array( 'chip', 'dashed', 'plain' ),
			'display.coupon_bar_shadow' => array( 'none', 'soft', 'strong' ),
			'display.coupon_bar_cd_style' => array( 'text', 'chip' ),
			'display.coupon_bar_anim' => array( 'slide', 'fade', 'bounce', 'none' ),
			'popup.code_style'        => array( 'dashed', 'solid', 'ticket', 'glow', 'plain' ),
			'popup.share_style'       => array( 'brand', 'mono', 'outline' ),
			'targeting.pages'         => array( 'all', 'include', 'exclude' ),
			'access.mode'             => array( 'free', 'credits', 'hybrid' ),
			'access.max_wins_period'  => array( 'lifetime', 'day', 'week', 'month' ),
			'access.credit_scope'     => array( 'any', 'this' ),
			'coupon.charset'          => array( 'upper_num', 'upper', 'num', 'lower_num', 'mixed' ),
			'messages.apply_redirect' => array( 'cart', 'checkout', 'shop', 'stay', 'custom' ),
			'notify.sms_mode'         => array( 'text', 'pattern' ),
			'notify.reminder_channel' => array( 'sms', 'email', 'both' ),
			'lang'                    => array( 'auto', 'fa', 'en' ),
		);
		foreach ( $enums as $path => $allowed ) {
			$parts = explode( '.', $path );
			$ref   = &$cfg;
			foreach ( $parts as $p ) {
				$ref = &$ref[ $p ];
			}
			if ( ! in_array( $ref, $allowed, true ) ) {
				$def = $defaults;
				foreach ( $parts as $p ) {
					$def = $def[ $p ];
				}
				$ref = $def;
			}
			unset( $ref );
		}

		// Ranges.
		$cfg['design']['size']           = self::clamp( $cfg['design']['size'], 220, 700 );
		$cfg['design']['size_mobile']    = self::clamp( $cfg['design']['size_mobile'], 180, 520 );
		$cfg['design']['font_size']      = self::clamp( $cfg['design']['font_size'], 8, 40 );
		$cfg['design']['text_position']  = self::clamp( $cfg['design']['text_position'], 0.3, 0.92, true );
		$cfg['design']['center_size']    = self::clamp( $cfg['design']['center_size'], 0.08, 0.4, true );
		$cfg['design']['pointer_size']   = self::clamp( $cfg['design']['pointer_size'], 0.5, 2, true );
		$cfg['design']['rim_width']      = self::clamp( $cfg['design']['rim_width'], 0, 40 );
		$cfg['design']['light_count']    = self::clamp( $cfg['design']['light_count'], 0, 48 );
		$cfg['design']['spin_duration']  = self::clamp( $cfg['design']['spin_duration'], 2, 20, true );
		$cfg['design']['spin_rotations'] = self::clamp( $cfg['design']['spin_rotations'], 2, 30 );
		$cfg['design']['sound_volume']   = self::clamp( $cfg['design']['sound_volume'], 0, 1, true );
		$cfg['design']['idle_speed']     = self::clamp( $cfg['design']['idle_speed'], 5, 120 );
		$cfg['popup']['width']           = self::clamp( $cfg['popup']['width'], 320, 1400 );
		$cfg['popup']['overlay_opacity'] = self::clamp( $cfg['popup']['overlay_opacity'], 0, 1, true );
		$cfg['popup']['font_scale']      = self::clamp( $cfg['popup']['font_scale'], 0.7, 1.5, true );
		$cfg['popup']['bg_image_opacity'] = self::clamp( $cfg['popup']['bg_image_opacity'], 0, 1, true );
		$cfg['coupon']['length']         = self::clamp( $cfg['coupon']['length'], 4, 24 );
		$cfg['display']['launcher_size'] = self::clamp( $cfg['display']['launcher_size'], 36, 120 );
		$cfg['display']['coupon_bar_font'] = self::clamp( $cfg['display']['coupon_bar_font'], 11, 22 );
		$cfg['display']['coupon_bar_radius'] = self::clamp( $cfg['display']['coupon_bar_radius'], 0, 40 );
		$cfg['display']['coupon_bar_btn_radius'] = self::clamp( $cfg['display']['coupon_bar_btn_radius'], 0, 999 );
		foreach ( array( 'icon_login', 'icon_wait', 'icon_earn', 'icon_closed' ) as $ik ) {
			$cfg['popup'][ $ik ] = mb_substr( wp_strip_all_tags( (string) $cfg['popup'][ $ik ] ), 0, 8 );
		}
		$cfg['display']['coupon_bar_icon'] = mb_substr( wp_strip_all_tags( (string) $cfg['display']['coupon_bar_icon'] ), 0, 8 );
		$cfg['schedule']['hour_from']    = self::clamp( $cfg['schedule']['hour_from'], 0, 23 );
		$cfg['schedule']['hour_to']      = self::clamp( $cfg['schedule']['hour_to'], 1, 24 );
		$cfg['advanced']['ab_weight']    = self::clamp( $cfg['advanced']['ab_weight'], 1, 100 );
		$cfg['coupon']['prefix']         = strtoupper( preg_replace( '/[^A-Za-z0-9\-_]/', '', $cfg['coupon']['prefix'] ) );
		$cfg['popup']['custom_css']      = self::css( $input['popup']['custom_css'] ?? '' );
		$cfg['popup']['custom_class']    = implode( ' ', array_map( 'sanitize_html_class', preg_split( '/\s+/', (string) $cfg['popup']['custom_class'] ) ) );
		$cfg['display']['click_selector'] = self::selector( $cfg['display']['click_selector'] );
		$cfg['notify']['sms_text']       = sanitize_textarea_field( (string) ( $input['notify']['sms_text'] ?? $cfg['notify']['sms_text'] ) );
		$cfg['notify']['sms_pattern_vars'] = sanitize_textarea_field( (string) ( $input['notify']['sms_pattern_vars'] ?? '' ) );
		$cfg['notify']['sms_lose_text']  = sanitize_textarea_field( (string) ( $input['notify']['sms_lose_text'] ?? '' ) );
		$cfg['notify']['reminder_text']  = sanitize_textarea_field( (string) ( $input['notify']['reminder_text'] ?? $cfg['notify']['reminder_text'] ) );
		$cfg['notify']['credit_text']    = sanitize_textarea_field( (string) ( $input['notify']['credit_text'] ?? $cfg['notify']['credit_text'] ) );
		$cfg['access']['earn_hint']      = sanitize_textarea_field( (string) ( $input['access']['earn_hint'] ?? '' ) );
		if ( ! $nested ) {
			$cfg['responsive'] = self::sanitize_responsive( $input['responsive'] ?? array(), $cfg );
		}
		return $cfg;
	}

	public static function sanitize_slice( array $raw ) {
		$d = self::slice_defaults();
		$s = self::sanitize_map( $d, $raw, 'slice' );
		$s['id']   = substr( preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $s['id'] ), 0, 40 );
		$s['type'] = in_array( $s['type'], self::prize_types(), true ) ? $s['type'] : 'lose';
		$s['value'] = max( 0, (float) $s['value'] );
		if ( 'coupon_percent' === $s['type'] ) {
			$s['value'] = min( 100, $s['value'] );
		}
		$s['weight']      = max( 0, round( (float) $s['weight'], 3 ) );
		$s['stock']       = (int) $s['stock'] < 0 ? -1 : (int) $s['stock'];
		$s['daily_cap']   = max( 0, (int) $s['daily_cap'] );
		$s['user_cap']    = max( 0, (int) $s['user_cap'] );
		$s['image_size']  = self::clamp( $s['image_size'], 12, 120 );
		$s['expiry_days'] = (int) $s['expiry_days'] < 0 ? -1 : (int) $s['expiry_days'];
		$s['product_ids'] = self::id_list( $raw['product_ids'] ?? array() );
		$s['gift_items']  = \Becharkhoon\Prizes\Gifts::sanitize_items( $raw['gift_items'] ?? array() );
		$s['link_url']    = esc_url_raw( (string) ( $raw['link_url'] ?? '' ) );
		$s['image']       = esc_url_raw( (string) ( $raw['image'] ?? '' ) );
		$s['icon']        = mb_substr( wp_strip_all_tags( (string) ( $raw['icon'] ?? '' ) ), 0, 8 );
		$s['custom_text'] = wp_kses_post( (string) ( $raw['custom_text'] ?? '' ) );
		$s['message']     = wp_kses_post( (string) ( $raw['message'] ?? '' ) );
		$s['codes_text']  = sanitize_textarea_field( (string) ( $raw['codes_text'] ?? '' ) );
		$s['claim_fields'] = in_array( $s['claim_fields'], array( 'address', 'phone', 'note' ), true ) ? $s['claim_fields'] : 'address';
		$s['coupon_code'] = wc_strtolower_safe( $s['coupon_code'] );
		$s['conditions']  = Conditions::sanitize_set( $raw['conditions'] ?? array() );
		foreach ( array( 'color', 'color2', 'text_color' ) as $c ) {
			$s[ $c ] = Helpers::color( $s[ $c ], '' );
		}
		return $s;
	}

	/**
	 * Recursive typed sanitizer against a defaults map.
	 *
	 * @param array  $defaults Shape.
	 * @param mixed  $input    Raw.
	 * @param string $path     Dotted path for html/css rules.
	 */
	private static function sanitize_map( array $defaults, $input, $path ) {
		$input = is_array( $input ) ? $input : array();
		$out   = array();
		foreach ( $defaults as $k => $def ) {
			$p   = '' === $path ? $k : $path . '.' . $k;
			$has = array_key_exists( $k, $input );
			$v   = $has ? $input[ $k ] : $def;
			if ( is_array( $def ) ) {
				// Lists (and nested maps) are handled by dedicated code; nested assoc maps recurse.
				$out[ $k ] = self::is_assoc( $def ) ? self::sanitize_map( $def, $v, $p ) : ( is_array( $v ) ? $v : $def );
				continue;
			}
			if ( is_bool( $def ) ) {
				$out[ $k ] = Helpers::bool( $v );
			} elseif ( is_int( $def ) ) {
				$out[ $k ] = is_numeric( $v ) ? (int) $v : $def;
			} elseif ( is_float( $def ) ) {
				$out[ $k ] = is_numeric( $v ) ? (float) $v : $def;
			} elseif ( in_array( $p, self::html_keys(), true ) ) {
				$out[ $k ] = wp_kses_post( (string) $v );
			} elseif ( self::looks_color_key( $k ) ) {
				$out[ $k ] = Helpers::color( $v, $has ? ( '' === trim( (string) $v ) ? '' : $def ) : $def );
			} elseif ( self::looks_url_key( $k ) ) {
				$out[ $k ] = esc_url_raw( (string) $v );
			} else {
				$out[ $k ] = sanitize_text_field( (string) $v );
			}
		}
		return $out;
	}

	private static function looks_color_key( $k ) {
		return (bool) preg_match( '/(^|_)(color|color2|bg|bg2|border|stroke|text)$/', $k ) && ! in_array( $k, array( 'center_text', 'button_text', 'otp_send_text', 'launcher_text', 'login_text', 'coupon_bar_text', 'copy_text', 'apply_text', 'continue_text', 'expires_text', 'lose_text', 'win_text', 'respin_text', 'spins_left_text', 'spin_again_text', 'no_spins_text', 'cooldown_text', 'limit_text', 'not_eligible_text', 'closed_text', 'earn_text', 'spinning_text', 'error_text', 'share_text', 'social_text', 'ticker_text', 'footer_text', 'no_thanks_text', 'sms_text', 'sms_lose_text', 'reminder_text', 'credit_text', 'custom_text', 'link_text', 'copied_text', 'codes_text', 'gift_text' ), true );
	}

	private static function looks_url_key( $k ) {
		return (bool) preg_match( '/(_url|^url|_image|^image|^logo|_logo)$/', $k ) || in_array( $k, array( 'redirect_win', 'login_url', 'apply_url' ), true );
	}

	public static function clamp( $v, $min, $max, $float = false ) {
		$v = $float ? (float) $v : (int) $v;
		return max( $min, min( $max, $v ) );
	}

	public static function id_list( $v ) {
		if ( is_string( $v ) ) {
			$v = preg_split( '/[\s,]+/', $v );
		}
		return array_values( array_unique( array_filter( array_map( 'absint', (array) $v ) ) ) );
	}

	public static function css( $css ) {
		$css = wp_strip_all_tags( (string) $css );
		$css = str_ireplace( array( '</style', '<script', 'expression(', 'javascript:', '@import' ), '', $css );
		return mb_substr( $css, 0, 20000 );
	}

	public static function selector( $sel ) {
		$sel = trim( wp_strip_all_tags( (string) $sel ) );
		return preg_match( '/^[A-Za-z0-9_\-\.#\[\]="\'\s,:>+~*()]*$/', $sel ) ? mb_substr( $sel, 0, 300 ) : '';
	}

	public static function sanitize_page_rules( $rules ) {
		$out   = array();
		$types = array( 'home', 'front', 'blog', 'shop', 'product', 'product_cat', 'product_tag', 'cart', 'checkout', 'thankyou', 'account', 'post', 'page', 'category', 'tag', 'search', '404', 'archive', 'post_type', 'object_id', 'url_contains', 'url_exact', 'url_regex', 'query_param' );
		foreach ( array_slice( (array) $rules, 0, 50 ) as $r ) {
			if ( ! is_array( $r ) || ! in_array( $r['type'] ?? '', $types, true ) ) {
				continue;
			}
			$value = sanitize_text_field( (string) ( $r['value'] ?? '' ) );
			if ( 'url_regex' === $r['type'] && false === @preg_match( '~' . str_replace( '~', '\~', $value ) . '~u', '' ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
				continue;
			}
			$out[] = array( 'type' => $r['type'], 'value' => $value );
		}
		return $out;
	}
}

if ( ! function_exists( __NAMESPACE__ . '\\wc_strtolower_safe' ) ) {
	/** Coupon codes are case-insensitive in WooCommerce. */
	function wc_strtolower_safe( $s ) {
		$s = sanitize_text_field( (string) $s );
		return function_exists( 'wc_strtolower' ) ? wc_strtolower( $s ) : mb_strtolower( $s );
	}
}
