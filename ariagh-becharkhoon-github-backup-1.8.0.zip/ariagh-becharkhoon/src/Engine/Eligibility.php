<?php
/**
 * "Can this visitor spin this wheel right now, and how?" — the single gatekeeper used
 * by the popup boot (preview of the state) and by the spin endpoint (final decision).
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Engine;

use Becharkhoon\Core\Helpers;
use Becharkhoon\Credits\Ledger;

defined( 'ABSPATH' ) || exit;

final class Eligibility {

	/**
	 * @param array   $wheel Wheel row (hydrated).
	 * @param Context $ctx   Context.
	 * @return array{ok:bool,reason:string,via:string,free_left:int,credits:int,bonus:int,next_at:int,fail:array|null}
	 */
	public static function check( array $wheel, Context $ctx ) {
		$cfg   = $wheel['config'];
		$acc   = $cfg['access'];
		$state = array(
			'ok'        => false,
			'reason'    => '',
			'via'       => '',
			'free_left' => 0,
			'credits'   => 0,
			'bonus'     => 0,
			'next_at'   => 0,
			'fail'      => null,
		);
		$ctx->wheel_id = (int) $wheel['id'];

		if ( ! self::is_open( $wheel ) ) {
			$state['reason'] = 'closed';
			return $state;
		}
		if ( self::is_blocked( $ctx ) ) {
			$state['reason'] = 'blocked';
			return $state;
		}
		// Bonus (re-spin) always goes first: the visitor is mid-sequence.
		$state['bonus'] = self::bonus( $wheel['id'], $ctx );
		if ( $state['bonus'] > 0 ) {
			$state['ok']  = true;
			$state['via'] = 'bonus';
			return $state;
		}
		if ( $acc['require_login'] && ! $ctx->user_id ) {
			$state['reason'] = 'login';
			return $state;
		}
		if ( $acc['blocked_roles'] && array_intersect( $ctx->roles(), $acc['blocked_roles'] ) ) {
			$state['reason'] = 'not_eligible';
			return $state;
		}
		$fail = null;
		if ( ! Conditions::passes( $acc['conditions'], $ctx, $fail ) ) {
			$state['reason'] = 'not_eligible';
			$state['fail']   = $fail;
			return $state;
		}
		$s = becharkhoon()->settings;
		if ( (int) $s->get( 'ip_daily_limit' ) > 0 && Limits::ip_spins_today( $ctx->ip ) >= (int) $s->get( 'ip_daily_limit' ) ) {
			$state['reason'] = 'limit';
			$state['next_at'] = Helpers::period_end( 'day' );
			return $state;
		}

		$ids = Limits::identity( $ctx, $acc );

		// Cooldown between two spins.
		if ( (int) $acc['cooldown_minutes'] > 0 ) {
			$last = Limits::last_spin( $wheel['id'], $ids );
			$next = $last + (int) $acc['cooldown_minutes'] * MINUTE_IN_SECONDS;
			if ( $last && $next > time() ) {
				$state['reason']  = 'cooldown';
				$state['next_at'] = $next;
				return $state;
			}
		}
		// Max wins per identity.
		if ( (int) $acc['max_wins'] > 0 ) {
			$since = 'lifetime' === $acc['max_wins_period'] ? '1970-01-01 00:00:00' : Helpers::period_start( $acc['max_wins_period'] );
			if ( Limits::count( $wheel['id'], $ids, $since, null, true ) >= (int) $acc['max_wins'] ) {
				$state['reason']  = 'max_wins';
				$state['next_at'] = 'lifetime' === $acc['max_wins_period'] ? 0 : Helpers::period_end( $acc['max_wins_period'] );
				return $state;
			}
		}

		$mode = $acc['mode'];
		// Limits: in free/hybrid they size the free allowance; in credits mode they cap credit spins.
		$kinds          = 'credits' === $mode ? array( 0, 1 ) : array( 1 );
		$left           = PHP_INT_MAX;
		$next_at        = 0;
		foreach ( $acc['limits'] as $lim ) {
			if ( (int) $lim['count'] <= 0 && 'credits' !== $mode ) {
				$left = 0;
				continue;
			}
			if ( (int) $lim['count'] <= 0 ) {
				continue;
			}
			$used = Limits::count( $wheel['id'], $ids, Helpers::period_start( $lim['period'], $lim['hours'] ), $kinds );
			$l    = max( 0, (int) $lim['count'] - $used );
			if ( $l < $left ) {
				$left = $l;
			}
			if ( 0 === $l ) {
				$end = 'rolling' === $lim['period'] ? self::rolling_next( $wheel['id'], $ids, $lim, $kinds ) : Helpers::period_end( $lim['period'] );
				if ( $end > $next_at ) {
					$next_at = $end;
				}
			}
		}
		if ( PHP_INT_MAX === $left ) {
			$left = 'credits' === $mode ? PHP_INT_MAX : 999; // No limits configured = unlimited free spins.
		}

		$state['credits'] = Ledger::balance( $ctx, $wheel['id'], $acc['credit_scope'] );
		if ( 'free' === $mode ) {
			// Free quota first; spins granted by the admin / rules / bulk SMS still work after it is used up.
			$state['free_left'] = $left;
			if ( $left > 0 ) {
				$state['ok']  = true;
				$state['via'] = 'free';
			} elseif ( $state['credits'] > 0 ) {
				$state['ok']  = true;
				$state['via'] = 'credit';
			} else {
				$state['reason']  = self::may_have_phone_credits( $wheel['id'], $ctx ) ? 'identify' : 'limit';
				$state['next_at'] = $next_at;
			}
			return $state;
		}
		if ( 'hybrid' === $mode ) {
			$state['free_left'] = $left;
			if ( $left > 0 ) {
				$state['ok']  = true;
				$state['via'] = 'free';
			} elseif ( $state['credits'] > 0 ) {
				$state['ok']  = true;
				$state['via'] = 'credit';
			} else {
				$state['reason']  = self::may_have_phone_credits( $wheel['id'], $ctx ) ? 'identify' : 'no_credits';
				$state['next_at'] = $next_at;
			}
			return $state;
		}

		// Credits mode.
		if ( $state['credits'] <= 0 ) {
			$state['reason'] = ( ! $ctx->user_id && ! $ctx->phone_verified ) ? 'identify' : 'no_credits';
			return $state;
		}
		// Limits cap credit spins only when the admin asks for it: a granted spin must be spendable.
		if ( ! empty( $acc['cap_credits'] ) && $left <= 0 ) {
			$state['reason']  = 'limit';
			$state['next_at'] = $next_at;
			return $state;
		}
		$state['ok']  = true;
		$state['via'] = 'credit';
		return $state;
	}

	/** A guest we can not identify yet, while spins were granted to mobile numbers → ask for the mobile (OTP). */
	private static function may_have_phone_credits( $wheel_id, Context $ctx ) {
		if ( $ctx->user_id || $ctx->phone_verified ) {
			return false;
		}
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}bch_credits WHERE user_id = 0 AND phone <> '' AND status = 'active' AND used < qty AND (wheel_id = %d OR wheel_id = 0) AND (expires_at IS NULL OR expires_at > %s) LIMIT 1", (int) $wheel_id, Helpers::now() ) );
	}

	/** Next opening of a rolling window: oldest counted spin inside it + window length. */
	private static function rolling_next( $wheel_id, array $ids, array $lim, array $kinds ) {
		global $wpdb;
		$since = Helpers::period_start( 'rolling', $lim['hours'] );
		$parts = array();
		$p     = array( (int) $wheel_id, $since );
		foreach ( $ids as $col => $val ) {
			$parts[] = 'user_id' === $col ? 'user_id = %d' : $col . ' = %s';
			$p[]     = $val;
		}
		$sql    = "SELECT created_at FROM {$wpdb->prefix}bch_spins WHERE wheel_id = %d AND created_at >= %s AND (" . implode( ' OR ', $parts ) . ') AND is_free IN (' . implode( ',', array_map( 'intval', $kinds ) ) . ') ORDER BY created_at ASC LIMIT 1';
		$oldest = $wpdb->get_var( $wpdb->prepare( $sql, $p ) ); // phpcs:ignore
		return $oldest ? strtotime( $oldest . ' UTC' ) + (int) $lim['hours'] * HOUR_IN_SECONDS : 0;
	}

	/** Active, inside its schedule. */
	public static function is_open( array $wheel ) {
		if ( 'active' !== $wheel['status'] ) {
			return false;
		}
		$sch = $wheel['config']['schedule'];
		$now = time();
		if ( '' !== $sch['start'] ) {
			$st = self::local_ts( $sch['start'] );
			if ( $st && $now < $st ) {
				return false;
			}
		}
		if ( '' !== $sch['end'] ) {
			$en = self::local_ts( $sch['end'] );
			if ( $en && $now > $en ) {
				return false;
			}
		}
		if ( $sch['days'] && count( $sch['days'] ) < 7 && ! in_array( (int) wp_date( 'w' ), array_map( 'intval', $sch['days'] ), true ) ) {
			return false;
		}
		$h = (int) wp_date( 'G' );
		if ( (int) $sch['hour_from'] > 0 || (int) $sch['hour_to'] < 24 ) {
			$from = (int) $sch['hour_from'];
			$to   = (int) $sch['hour_to'];
			$in   = $from <= $to ? ( $h >= $from && $h < $to ) : ( $h >= $from || $h < $to ); // Overnight windows.
			if ( ! $in ) {
				return false;
			}
		}
		return true;
	}

	/** "Y-m-d H:i" (site timezone) → unix. */
	public static function local_ts( $s ) {
		try {
			$d = new \DateTimeImmutable( str_replace( 'T', ' ', (string) $s ), wp_timezone() );
			return $d->getTimestamp();
		} catch ( \Exception $e ) {
			return 0;
		}
	}

	public static function is_blocked( Context $ctx ) {
		$s = becharkhoon()->settings;
		if ( in_array( $ctx->ip, Helpers::lines( $s->get( 'block_ips' ) ), true ) ) {
			return true;
		}
		foreach ( Helpers::lines( $s->get( 'block_ips' ) ) as $rule ) {
			if ( false !== strpos( $rule, '*' ) && fnmatch( $rule, $ctx->ip ) ) {
				return true;
			}
		}
		if ( '' !== $ctx->email && in_array( $ctx->email, array_map( 'strtolower', Helpers::lines( $s->get( 'block_emails' ) ) ), true ) ) {
			return true;
		}
		if ( '' !== $ctx->phone ) {
			$phones = array_map(
				static function ( $p ) {
					return Helpers::phone( $p );
				},
				Helpers::lines( $s->get( 'block_phones' ) )
			);
			if ( in_array( $ctx->phone, $phones, true ) ) {
				return true;
			}
		}
		if ( $ctx->user_id && get_user_meta( $ctx->user_id, 'bch_blocked', true ) ) {
			return true;
		}
		return false;
	}

	/* ---------- Bonus (re-spin) tokens ---------- */

	private static function bonus_key( $wheel_id, Context $ctx ) {
		return 'bch_bonus_' . md5( $wheel_id . '|' . Limits::primary_key( $ctx ) );
	}

	public static function bonus( $wheel_id, Context $ctx ) {
		return (int) get_transient( self::bonus_key( $wheel_id, $ctx ) );
	}

	public static function add_bonus( $wheel_id, Context $ctx, $n = 1 ) {
		$k = self::bonus_key( $wheel_id, $ctx );
		set_transient( $k, (int) get_transient( $k ) + (int) $n, 2 * HOUR_IN_SECONDS );
	}

	public static function use_bonus( $wheel_id, Context $ctx ) {
		$k = self::bonus_key( $wheel_id, $ctx );
		$n = (int) get_transient( $k );
		if ( $n <= 1 ) {
			delete_transient( $k );
		} else {
			set_transient( $k, $n - 1, 2 * HOUR_IN_SECONDS );
		}
		return $n > 0;
	}
}
