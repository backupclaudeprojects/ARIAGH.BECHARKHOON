<?php
/**
 * Daily counters per wheel (impressions, opens, spins, wins, leads, redeemed, revenue…)
 * and report queries.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Stats;

use Becharkhoon\Core\Helpers;

defined( 'ABSPATH' ) || exit;

final class Stats {

	const METRICS = array( 'impressions', 'opens', 'closes', 'launcher', 'form_starts', 'spins', 'wins', 'losses', 'leads', 'redeemed', 'revenue', 'otp_sent', 'claims', 'shares' );

	public static function add( $wheel_id, $metric, $value = 1 ) {
		global $wpdb;
		if ( ! in_array( $metric, self::METRICS, true ) ) {
			return;
		}
		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO {$wpdb->prefix}bch_stats (wheel_id, day, metric, value) VALUES (%d, %s, %s, %f) ON DUPLICATE KEY UPDATE value = value + VALUES(value)",
				(int) $wheel_id,
				Helpers::today(),
				$metric,
				(float) $value
			)
		);
	}

	/**
	 * Totals between two dates (Y-m-d, inclusive).
	 *
	 * @param int $wheel_id 0 = all wheels.
	 */
	public static function totals( $from, $to, $wheel_id = 0 ) {
		global $wpdb;
		$sql    = "SELECT metric, SUM(value) AS v FROM {$wpdb->prefix}bch_stats WHERE day BETWEEN %s AND %s";
		$params = array( $from, $to );
		if ( $wheel_id ) {
			$sql     .= ' AND wheel_id = %d';
			$params[] = (int) $wheel_id;
		}
		$sql .= ' GROUP BY metric';
		$out  = array_fill_keys( self::METRICS, 0 );
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ) as $r ) { // phpcs:ignore
			$out[ $r['metric'] ] = (float) $r['v'];
		}
		$out['conversion']  = $out['opens'] > 0 ? round( $out['spins'] / $out['opens'] * 100, 1 ) : 0;
		$out['win_rate']    = $out['spins'] > 0 ? round( $out['wins'] / $out['spins'] * 100, 1 ) : 0;
		$out['redeem_rate'] = $out['wins'] > 0 ? round( $out['redeemed'] / $out['wins'] * 100, 1 ) : 0;
		$out['open_rate']   = $out['impressions'] > 0 ? round( $out['opens'] / $out['impressions'] * 100, 1 ) : 0;
		return $out;
	}

	/** Daily series: [ day => [metric => value] ]. */
	public static function series( $from, $to, $wheel_id = 0, array $metrics = array( 'impressions', 'opens', 'spins', 'wins', 'leads', 'redeemed', 'revenue' ) ) {
		global $wpdb;
		$sql    = "SELECT day, metric, SUM(value) AS v FROM {$wpdb->prefix}bch_stats WHERE day BETWEEN %s AND %s";
		$params = array( $from, $to );
		if ( $wheel_id ) {
			$sql     .= ' AND wheel_id = %d';
			$params[] = (int) $wheel_id;
		}
		$sql .= ' GROUP BY day, metric ORDER BY day ASC';
		$days = array();
		$d    = new \DateTimeImmutable( $from );
		$end  = new \DateTimeImmutable( $to );
		$i    = 0;
		while ( $d <= $end && $i++ < 400 ) {
			$days[ $d->format( 'Y-m-d' ) ] = array_fill_keys( $metrics, 0 );
			$d                             = $d->modify( '+1 day' );
		}
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ) as $r ) { // phpcs:ignore
			if ( isset( $days[ $r['day'] ] ) && in_array( $r['metric'], $metrics, true ) ) {
				$days[ $r['day'] ][ $r['metric'] ] = (float) $r['v'];
			}
		}
		return $days;
	}

	/** Prize distribution (from the spins table). */
	public static function prizes( $from, $to, $wheel_id = 0 ) {
		global $wpdb;
		$sql    = "SELECT wheel_id, slice_id, slice_label, prize_type, result, COUNT(*) AS n, SUM(status = 'redeemed') AS redeemed, SUM(revenue) AS revenue FROM {$wpdb->prefix}bch_spins WHERE created_at BETWEEN %s AND %s";
		$params = self::bounds( $from, $to );
		if ( $wheel_id ) {
			$sql     .= ' AND wheel_id = %d';
			$params[] = (int) $wheel_id;
		}
		$sql .= ' GROUP BY wheel_id, slice_id, slice_label, prize_type, result ORDER BY n DESC LIMIT 100';
		return (array) $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ); // phpcs:ignore
	}

	/** Breakdown by source / device stored in spins meta. */
	public static function by_source( $from, $to, $wheel_id = 0 ) {
		global $wpdb;
		$sql    = "SELECT source, COUNT(*) AS n, SUM(result = 'win') AS wins FROM {$wpdb->prefix}bch_spins WHERE created_at BETWEEN %s AND %s";
		$params = self::bounds( $from, $to );
		if ( $wheel_id ) {
			$sql     .= ' AND wheel_id = %d';
			$params[] = (int) $wheel_id;
		}
		$sql .= ' GROUP BY source ORDER BY n DESC';
		return (array) $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ); // phpcs:ignore
	}

	/** Spins by hour of day (site time) — best time to run campaigns. */
	public static function by_hour( $from, $to, $wheel_id = 0 ) {
		global $wpdb;
		$sql    = "SELECT created_at FROM {$wpdb->prefix}bch_spins WHERE created_at BETWEEN %s AND %s";
		$params = self::bounds( $from, $to );
		if ( $wheel_id ) {
			$sql     .= ' AND wheel_id = %d';
			$params[] = (int) $wheel_id;
		}
		$sql  .= ' ORDER BY id DESC LIMIT 20000';
		$hours = array_fill( 0, 24, 0 );
		foreach ( (array) $wpdb->get_col( $wpdb->prepare( $sql, $params ) ) as $t ) { // phpcs:ignore
			++$hours[ (int) wp_date( 'G', strtotime( $t . ' UTC' ) ) ];
		}
		return $hours;
	}

	/** Spins today on a wheel (social proof), cached 5 minutes. */
	public static function spins_today( $wheel_id ) {
		$k = 'bch_today_' . (int) $wheel_id . '_' . Helpers::today();
		$v = get_transient( $k );
		if ( false === $v ) {
			global $wpdb;
			$v = (int) $wpdb->get_var( $wpdb->prepare( "SELECT value FROM {$wpdb->prefix}bch_stats WHERE wheel_id = %d AND day = %s AND metric = 'spins'", $wheel_id, Helpers::today() ) );
			set_transient( $k, $v, 5 * MINUTE_IN_SECONDS );
		}
		return (int) $v;
	}

	/** Recent winners for the public ticker (masked), cached 5 minutes. */
	public static function recent_winners( $wheel_id, $n = 10 ) {
		$k = 'bch_winners_' . (int) $wheel_id;
		$v = get_transient( $k );
		if ( false === $v ) {
			global $wpdb;
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT name, phone, slice_label, created_at FROM {$wpdb->prefix}bch_spins WHERE wheel_id = %d AND result = 'win' ORDER BY id DESC LIMIT %d", $wheel_id, max( 1, min( 30, (int) $n ) ) ), ARRAY_A );
			$v    = array();
			foreach ( (array) $rows as $r ) {
				$who = '' !== trim( $r['name'] ) ? Helpers::mask( $r['name'] ) : Helpers::mask( $r['phone'] );
				$v[] = array( 'name' => '' !== $who ? $who : '***', 'prize' => $r['slice_label'], 'ago' => human_time_diff( strtotime( $r['created_at'] . ' UTC' ) ) );
			}
			set_transient( $k, $v, 5 * MINUTE_IN_SECONDS );
		}
		return $v;
	}

	/** 'Y-m-d' (whole days) or 'Y-m-d H:i:s' (exact) site-local → UTC bounds. */
	public static function bounds( $from, $to ) {
		return array( self::utc( strlen( $from ) > 10 ? $from : $from . ' 00:00:00' ), self::utc( strlen( $to ) > 10 ? $to : $to . ' 23:59:59' ) );
	}

	/** Site-local datetime → UTC MySQL. */
	public static function utc( $local ) {
		try {
			$d = new \DateTimeImmutable( $local, wp_timezone() );
			return $d->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
		} catch ( \Exception $e ) {
			return $local;
		}
	}

	public static function reset( $wheel_id = 0 ) {
		global $wpdb;
		if ( $wheel_id ) {
			$wpdb->delete( $wpdb->prefix . 'bch_stats', array( 'wheel_id' => (int) $wheel_id ) );
		} else {
			$wpdb->query( "DELETE FROM {$wpdb->prefix}bch_stats" );
		}
	}
}
