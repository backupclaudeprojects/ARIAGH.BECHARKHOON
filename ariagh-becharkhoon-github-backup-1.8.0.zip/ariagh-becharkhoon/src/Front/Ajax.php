<?php
/**
 * Public endpoints (admin-ajax by default, REST fallback): boot, spin, OTP, track, claim.
 * Every response is sent with no-cache headers so page/CDN caches never store it.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Front;

use Becharkhoon\Core\Capabilities;
use Becharkhoon\Core\Helpers;
use Becharkhoon\Core\Lang;
use Becharkhoon\Core\RateLimit;
use Becharkhoon\Engine\Context;
use Becharkhoon\Engine\Eligibility;
use Becharkhoon\Engine\SpinService;
use Becharkhoon\Stats\Stats;

defined( 'ABSPATH' ) || exit;

final class Ajax {

	const ACTIONS = array( 'boot', 'spin', 'otp_send', 'otp_verify', 'track', 'claim', 'state', 'bar' );

	public function register_hooks() {
		foreach ( self::ACTIONS as $a ) {
			add_action( 'wp_ajax_bch_' . $a, array( $this, 'ajax' ) );
			add_action( 'wp_ajax_nopriv_bch_' . $a, array( $this, 'ajax' ) );
		}
		add_action( 'rest_api_init', array( $this, 'rest_routes' ) );
	}

	public function rest_routes() {
		register_rest_route(
			'becharkhoon/v1',
			'/front/(?P<action>[a-z_]+)',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => function ( \WP_REST_Request $r ) {
					$action = (string) $r['action'];
					if ( ! in_array( $action, self::ACTIONS, true ) ) {
						return new \WP_REST_Response( array( 'ok' => false ), 404 );
					}
					$p   = $r->get_json_params();
					$p   = is_array( $p ) ? $p : Helpers::json_decode_array( $r->get_param( 'payload' ) );
					$res = $this->dispatch( $action, $p );
					$out = new \WP_REST_Response( $res[1], $res[0] );
					foreach ( self::no_cache_headers() as $k => $v ) {
						$out->header( $k, $v );
					}
					return $out;
				},
			)
		);
	}

	public static function no_cache_headers() {
		return array(
			'Cache-Control'             => 'no-store, no-cache, must-revalidate, max-age=0, private',
			'Pragma'                    => 'no-cache',
			'Expires'                   => 'Wed, 11 Jan 1984 05:00:00 GMT',
			'CDN-Cache-Control'         => 'no-store',
			'Cloudflare-CDN-Cache-Control' => 'no-store',
			'X-LiteSpeed-Cache-Control' => 'no-cache',
			'X-Accel-Expires'           => '0',
		);
	}

	public function ajax() {
		$action = isset( $_REQUEST['action'] ) ? substr( sanitize_key( wp_unslash( $_REQUEST['action'] ) ), 4 ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$raw    = isset( $_POST['payload'] ) ? wp_unslash( $_POST['payload'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$p      = Helpers::json_decode_array( $raw );
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		if ( ! headers_sent() ) {
			foreach ( self::no_cache_headers() as $k => $v ) {
				header( $k . ': ' . $v );
			}
		}
		$res = $this->dispatch( $action, $p );
		wp_send_json( $res[1], $res[0] );
	}

	/**
	 * @return array{0:int,1:array}
	 */
	public function dispatch( $action, array $p ) {
		$s = becharkhoon()->settings;
		if ( ! $s->get( 'enabled' ) ) {
			return array( 403, array( 'ok' => false, 'message' => 'disabled' ) );
		}
		Lang::use_site_locale();
		$ip = Helpers::ip( $s->get( 'ip_source' ) );
		if ( 'track' !== $action && ! RateLimit::hit( 'front:' . $ip, max( 10, (int) $s->get( 'rate_limit_per_minute' ) ) * 3, 60 ) ) {
			return array( 429, array( 'ok' => false, 'message' => Lang::t( 'درخواست‌ها زیاد است، کمی صبر کنید.', 'Too many requests, please slow down.' ) ) );
		}
		if ( function_exists( 'wc_load_cart' ) && function_exists( 'WC' ) && null === WC()->cart && did_action( 'woocommerce_init' ) ) {
			wc_load_cart();
		}
		try {
			switch ( $action ) {
				case 'boot':
					return $this->boot( $p );
				case 'bar':
					return array( 200, array( 'ok' => true, 'bar' => CouponBar::state( $this->ctx( $p ), $p['bar'] ?? null ) ) );
				case 'spin':
					return $this->spin( $p, $ip );
				case 'otp_send':
					return $this->otp_send( $p, $ip );
				case 'otp_verify':
					return $this->otp_verify( $p );
				case 'track':
					return $this->track( $p, $ip );
				case 'claim':
					return $this->claim( $p );
				case 'state':
					return $this->state( $p );
			}
		} catch ( \Throwable $e ) {
			\Becharkhoon\Core\Logger::log( 'system', 'error', 'Front ' . $action . ': ' . $e->getMessage(), array( 'file' => basename( $e->getFile() ) . ':' . $e->getLine() ) );
			return array( 500, array( 'ok' => false, 'message' => Lang::t( 'خطایی رخ داد، دوباره تلاش کنید.', 'Something went wrong, please try again.' ) ) );
		}
		return array( 400, array( 'ok' => false ) );
	}

	private function ctx( array $p ) {
		$client        = isset( $p['ctx'] ) && is_array( $p['ctx'] ) ? $p['ctx'] : array();
		$client['did'] = $p['did'] ?? ( $client['did'] ?? '' );
		$ctx           = Context::current( $client );
		$vphone        = Guard::verified_phone( (string) ( $p['otp_token'] ?? '' ) );
		if ( '' !== $vphone ) {
			if ( ! $ctx->user_id || '' === $ctx->phone ) {
				$ctx->phone = $vphone;
			}
			$ctx->phone_verified = $ctx->phone === $vphone;
		} elseif ( $ctx->user_id && '' !== $ctx->phone ) {
			$ctx->phone_verified = true; // Account phone: the account itself is the proof.
		}
		return $ctx;
	}

	/* ---------- boot ---------- */

	private function boot( array $p ) {
		$ctx     = $this->ctx( $p );
		$inline  = array_map( 'absint', (array) ( $p['inline'] ?? array() ) );
		$preview = absint( $p['preview'] ?? 0 );
		$open    = absint( $p['open'] ?? 0 );
		if ( $open ) {
			$inline[] = $open; // ?bch_open=ID or a "spin now" link: always available when active.
		}
		$list = array();
		foreach ( Frontend::visible_wheels( $ctx, $inline, $preview ) as $w ) {
			Frontend::lang_for( $w );
			$list[] = Frontend::boot_wheel( $w, $ctx );
		}
		$bar = CouponBar::state( $ctx, $p['bar'] ?? null );
		Lang::use_site_locale();
		return array(
			200,
			array(
				'ok'      => true,
				'token'   => Guard::issue_token( $ctx->device_id ),
				'wheels'  => $list,
				'bar'     => $bar,
				'user'    => array(
					'logged_in' => $ctx->user_id > 0,
					'verified'  => $ctx->phone_verified ? $ctx->phone : '',
					'prefill'   => Frontend::prefill( $ctx ),
					'admin'     => Capabilities::can_manage(),
				),
				'time'    => time(),
			)
		);
	}

	/* ---------- state (after OTP / login) ---------- */

	private function state( array $p ) {
		$ctx   = $this->ctx( $p );
		$wheel = becharkhoon()->wheels->get( absint( $p['wheel_id'] ?? 0 ) );
		if ( ! $wheel ) {
			return array( 404, array( 'ok' => false ) );
		}
		Frontend::lang_for( $wheel );
		return array( 200, array( 'ok' => true, 'state' => SpinService::public_state( $wheel, Eligibility::check( $wheel, $ctx ) ) ) );
	}

	/* ---------- spin ---------- */

	private function spin( array $p, $ip ) {
		$s = becharkhoon()->settings;
		if ( ! RateLimit::hit( 'spin:' . $ip, (int) $s->get( 'rate_limit_per_minute' ), 60 ) ) {
			return array( 429, array( 'ok' => false, 'message' => Lang::t( 'درخواست‌ها زیاد است، کمی صبر کنید.', 'Too many requests, please slow down.' ) ) );
		}
		$did = (string) ( $p['did'] ?? '' );
		if ( ! Guard::check_token( (string) ( $p['token'] ?? '' ), $did ) ) {
			return array( 403, array( 'ok' => false, 'code' => 'token', 'message' => Lang::t( 'نشست شما منقضی شده؛ صفحه را تازه کنید.', 'Your session expired; please refresh the page.' ) ) );
		}
		$wheel = becharkhoon()->wheels->get( absint( $p['wheel_id'] ?? 0 ) );
		if ( ! $wheel ) {
			return array( 404, array( 'ok' => false, 'message' => 'wheel' ) );
		}
		$preview = 'active' !== $wheel['status'] && Capabilities::can_manage();
		if ( $preview ) {
			$wheel['status'] = 'active'; // Admin test spin on a draft (still recorded, marked as source "preview").
		}
		Frontend::lang_for( $wheel );
		$cfg = $wheel['config'];

		if ( $s->get( 'honeypot' ) && ! empty( $p['hp'] ) ) {
			return array( 400, array( 'ok' => false, 'message' => SpinService::msg( $wheel, 'error_text' ) ) );
		}
		$ctx = $this->ctx( $p );
		if ( $cfg['form']['fields'] && ! $ctx->user_id && (float) ( $p['t'] ?? 99 ) < (float) $s->get( 'min_fill_seconds' ) ) {
			return array( 400, array( 'ok' => false, 'message' => Lang::t( 'لطفاً فرم را کامل کنید.', 'Please complete the form.' ) ) );
		}
		if ( ! $ctx->user_id && ! Guard::captcha_ok( (string) ( $p['captcha'] ?? '' ), $ip ) ) {
			return array( 400, array( 'ok' => false, 'code' => 'captcha', 'message' => Lang::t( 'تایید «من ربات نیستم» انجام نشد.', 'Captcha verification failed.' ) ) );
		}

		// Form fields.
		$values = isset( $p['fields'] ) && is_array( $p['fields'] ) ? $p['fields'] : array();
		$lead   = array( 'name' => '', 'fields' => array(), 'consent' => ! empty( $p['consent'] ), 'marketing' => ! empty( $p['marketing'] ) );
		$prefill = Frontend::prefill( $ctx );
		$phone_in = '';
		$email_in = '';
		foreach ( $cfg['form']['fields'] as $f ) {
			if ( ! $f['enabled'] ) {
				continue;
			}
			$raw = isset( $values[ $f['id'] ] ) ? $values[ $f['id'] ] : '';
			$raw = is_scalar( $raw ) ? trim( (string) $raw ) : '';
			if ( '' === $raw && $ctx->user_id && $cfg['form']['hide_known'] && isset( $prefill[ $f['map'] ] ) ) {
				$raw = (string) $prefill[ $f['map'] ];
			}
			if ( '' === $raw ) {
				if ( $f['required'] ) {
					return $this->field_error( $f, Lang::t( 'این فیلد الزامی است.', 'This field is required.' ) );
				}
				continue;
			}
			$label = '' !== $f['label'] ? $f['label'] : $f['id'];
			switch ( $f['type'] ) {
				case 'email':
					$email = Helpers::email( $raw );
					if ( '' === $email ) {
						return $this->field_error( $f, Lang::t( 'ایمیل معتبر نیست.', 'Please enter a valid email.' ) );
					}
					$err = Guard::email_error( $email );
					if ( '' !== $err ) {
						return $this->field_error( $f, $err );
					}
					$raw = $email;
					break;
				case 'tel':
					$phone = Helpers::phone( $raw, $s->get( 'phone_country' ) );
					if ( '' === $phone ) {
						return $this->field_error( $f, Lang::t( 'شماره موبایل معتبر نیست (مثال: 09121234567).', 'Please enter a valid mobile number.' ) );
					}
					$raw = $phone;
					break;
				case 'number':
					$raw = (string) (float) Helpers::latin_digits( $raw );
					break;
				case 'date':
					$raw = preg_match( '/^\d{4}-\d{2}-\d{2}$/', Helpers::latin_digits( $raw ) ) ? Helpers::latin_digits( $raw ) : '';
					break;
				case 'select':
				case 'radio':
					$opts = Helpers::lines( $f['options'] );
					if ( $opts && ! in_array( $raw, $opts, true ) ) {
						return $this->field_error( $f, Lang::t( 'گزینه نامعتبر است.', 'Invalid option.' ) );
					}
					break;
				case 'checkbox':
					$raw = Helpers::bool( $raw ) ? '1' : '';
					if ( $f['required'] && '' === $raw ) {
						return $this->field_error( $f, Lang::t( 'این فیلد الزامی است.', 'This field is required.' ) );
					}
					break;
				default:
					$raw = mb_substr( sanitize_text_field( $raw ), 0, 300 );
			}
			switch ( $f['map'] ) {
				case 'name':
					$lead['name'] = $raw;
					break;
				case 'email':
					$email_in = $raw;
					break;
				case 'phone':
					$phone_in = $raw;
					break;
				default:
					$lead['fields'][ $label ] = $raw;
			}
			if ( 'birthday' === $f['map'] && $ctx->user_id && '' !== $raw ) {
				update_user_meta( $ctx->user_id, 'bch_birthday', $raw );
			}
		}
		if ( $cfg['form']['consent']['enabled'] && $cfg['form']['consent']['required'] && empty( $p['consent'] ) ) {
			return array( 400, array( 'ok' => false, 'field' => '_consent', 'message' => Lang::t( 'لطفاً قوانین را بپذیرید.', 'Please accept the terms.' ) ) );
		}

		// Identity from the form.
		if ( '' !== $email_in && ! $ctx->user_id ) {
			$ctx->email = $email_in;
		}
		if ( '' !== $phone_in && $phone_in !== $ctx->phone ) {
			$verified    = Guard::verified_phone( (string) ( $p['otp_token'] ?? '' ) );
			$ctx->phone  = $phone_in;
			$ctx->phone_verified = $verified === $phone_in;
		}
		$need_otp = $cfg['access']['require_otp'] || $cfg['form']['phone_otp'];
		if ( $need_otp && ! $ctx->phone_verified ) {
			return array( 400, array( 'ok' => false, 'code' => 'otp', 'message' => Lang::t( 'لطفاً شماره موبایل را با کد پیامکی تایید کنید.', 'Please verify your mobile number first.' ) ) );
		}
		if ( $ctx->user_id && $ctx->phone_verified && '' !== $ctx->phone && '' === (string) get_user_meta( $ctx->user_id, 'billing_phone', true ) ) {
			update_user_meta( $ctx->user_id, 'billing_phone', $ctx->phone );
		}

		$res = becharkhoon()->spinner->spin(
			$wheel,
			$ctx,
			$lead,
			array(
				'source'   => $preview ? 'preview' : sanitize_key( (string) ( $p['source'] ?? 'popup' ) ),
				'page_url' => (string) ( $p['ctx']['url'] ?? '' ),
			)
		);
		if ( is_wp_error( $res ) ) {
			$data = $res->get_error_data();
			return array( (int) ( $data['status'] ?? 400 ), array( 'ok' => false, 'code' => $res->get_error_code(), 'message' => $res->get_error_message(), 'state' => $data['state'] ?? null ) );
		}
		// Instant auto-apply to the session cart.
		if ( '' !== $res['code'] && '' !== $res['apply_url'] && $cfg['coupon']['auto_apply'] && function_exists( 'WC' ) && WC()->cart && ! WC()->cart->is_empty() ) {
			$code = wc_format_coupon_code( $res['code'] );
			if ( ! WC()->cart->has_discount( $code ) ) {
				WC()->cart->apply_coupon( $code );
				wc_clear_notices();
				$res['applied'] = WC()->cart->has_discount( $code );
			}
		}
		$res['ok'] = true;
		return array( 200, $res );
	}

	private function field_error( array $f, $msg ) {
		return array( 400, array( 'ok' => false, 'field' => $f['id'], 'message' => $msg ) );
	}

	/* ---------- OTP ---------- */

	private function otp_send( array $p, $ip ) {
		if ( ! Guard::check_token( (string) ( $p['token'] ?? '' ), (string) ( $p['did'] ?? '' ) ) ) {
			return array( 403, array( 'ok' => false, 'message' => Lang::t( 'نشست شما منقضی شده؛ صفحه را تازه کنید.', 'Your session expired; please refresh the page.' ) ) );
		}
		$phone = Helpers::phone( (string) ( $p['phone'] ?? '' ), becharkhoon()->settings->get( 'phone_country' ) );
		if ( '' === $phone ) {
			return array( 400, array( 'ok' => false, 'message' => Lang::t( 'شماره موبایل معتبر نیست.', 'Invalid mobile number.' ) ) );
		}
		$ctx        = Context::current( array( 'did' => $p['did'] ?? '' ) );
		$ctx->phone = $phone;
		if ( Eligibility::is_blocked( $ctx ) ) {
			return array( 403, array( 'ok' => false, 'message' => Lang::t( 'امکان استفاده از این شماره وجود ندارد.', 'This number cannot be used.' ) ) );
		}
		$r = Guard::otp_send( $phone, $ip );
		if ( $r['ok'] ) {
			Stats::add( absint( $p['wheel_id'] ?? 0 ), 'otp_sent' );
		}
		return array( $r['ok'] ? 200 : 400, $r );
	}

	private function otp_verify( array $p ) {
		$phone = Helpers::phone( (string) ( $p['phone'] ?? '' ), becharkhoon()->settings->get( 'phone_country' ) );
		if ( '' === $phone ) {
			return array( 400, array( 'ok' => false, 'message' => Lang::t( 'شماره موبایل معتبر نیست.', 'Invalid mobile number.' ) ) );
		}
		$err   = '';
		$token = Guard::otp_verify( $phone, (string) ( $p['code'] ?? '' ), $err );
		if ( '' === $token ) {
			return array( 400, array( 'ok' => false, 'message' => $err ) );
		}
		$p['otp_token'] = $token;
		// Sign in to the site too (existing account with this mobile, or a new customer account).
		$login          = Login::after_otp( $phone, (string) ( $p['name'] ?? '' ) );
		$ctx            = $this->ctx( $p );
		$ctx->phone     = $phone;
		$ctx->phone_verified = true;
		$state = null;
		$wheel = becharkhoon()->wheels->get( absint( $p['wheel_id'] ?? 0 ) );
		if ( $wheel ) {
			Frontend::lang_for( $wheel );
			$state = SpinService::public_state( $wheel, Eligibility::check( $wheel, $ctx ) );
		}
		return array( 200, array( 'ok' => true, 'otp_token' => $token, 'phone' => $phone, 'state' => $state, 'logged_in' => $login['logged_in'], 'user_created' => $login['created'] ) );
	}

	/* ---------- tracking ---------- */

	private function track( array $p, $ip ) {
		$s = becharkhoon()->settings;
		if ( ! $s->get( 'tracking_enabled' ) || ! RateLimit::hit( 'track:' . $ip, 120, 60 ) ) {
			return array( 200, array( 'ok' => true ) );
		}
		$map = array( 'imp' => 'impressions', 'open' => 'opens', 'close' => 'closes', 'launcher' => 'launcher', 'form' => 'form_starts', 'share' => 'shares' );
		$n   = 0;
		foreach ( array_slice( (array) ( $p['events'] ?? array() ), 0, 20 ) as $ev ) {
			if ( ! is_array( $ev ) || ! isset( $map[ $ev['e'] ?? '' ] ) ) {
				continue;
			}
			$wid = absint( $ev['w'] ?? 0 );
			if ( ! $wid || ! becharkhoon()->wheels->get( $wid ) ) {
				continue;
			}
			Stats::add( $wid, $map[ $ev['e'] ] );
			++$n;
		}
		return array( 200, array( 'ok' => true, 'n' => $n ) );
	}

	/* ---------- physical prize claim ---------- */

	private function claim( array $p ) {
		global $wpdb;
		$id    = absint( $p['spin_id'] ?? 0 );
		$token = (string) ( $p['claim'] ?? '' );
		if ( ! $id || ! hash_equals( SpinService::claim_token( $id ), $token ) ) {
			return array( 403, array( 'ok' => false, 'message' => 'invalid' ) );
		}
		$spin = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bch_spins WHERE id = %d", $id ), ARRAY_A );
		if ( ! $spin || 'pending' !== $spin['status'] ) {
			return array( 409, array( 'ok' => false, 'message' => Lang::t( 'این جایزه قبلاً ثبت شده است.', 'This prize was already claimed.' ) ) );
		}
		$wheel = becharkhoon()->wheels->get( (int) $spin['wheel_id'] );
		if ( $wheel ) {
			Frontend::lang_for( $wheel );
		}
		$data = array();
		foreach ( array( 'name', 'phone', 'address', 'postcode', 'note' ) as $k ) {
			if ( isset( $p['data'][ $k ] ) ) {
				$data[ $k ] = mb_substr( sanitize_textarea_field( (string) $p['data'][ $k ] ), 0, 600 );
			}
		}
		if ( isset( $data['phone'] ) && '' !== $data['phone'] && '' === Helpers::phone( $data['phone'] ) ) {
			return array( 400, array( 'ok' => false, 'field' => 'phone', 'message' => Lang::t( 'شماره موبایل معتبر نیست.', 'Invalid mobile number.' ) ) );
		}
		if ( empty( $data['address'] ) && empty( $data['phone'] ) && empty( $data['note'] ) ) {
			return array( 400, array( 'ok' => false, 'message' => Lang::t( 'لطفاً اطلاعات را کامل کنید.', 'Please complete the form.' ) ) );
		}
		$meta          = Helpers::json_decode_array( $spin['meta'] );
		$meta['claim'] = $data;
		$wpdb->update( $wpdb->prefix . 'bch_spins', array( 'status' => 'claimed', 'meta' => wp_json_encode( $meta, JSON_UNESCAPED_UNICODE ) ), array( 'id' => $id ) );
		Stats::add( (int) $spin['wheel_id'], 'claims' );
		$spin['meta']   = wp_json_encode( $meta, JSON_UNESCAPED_UNICODE );
		$spin['status'] = 'claimed';
		becharkhoon()->notifier->claimed( $spin, $wheel );
		return array( 200, array( 'ok' => true, 'message' => $wheel ? $wheel['config']['messages']['claim_success'] : '' ) );
	}
}
