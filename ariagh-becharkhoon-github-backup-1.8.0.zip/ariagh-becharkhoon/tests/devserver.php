<?php
/**
 * Browser dev server for the admin SPA + front wheel, backed by the offline WP stubs.
 * Usage: BCH_ORIGIN=http://127.0.0.1:8899 BCH_STATE=/tmp/bchdev php -S 127.0.0.1:8899 tests/devserver.php
 */
// phpcs:ignoreFile
$uri  = parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH );
$root = dirname( __DIR__ );
if ( preg_match( '#^/wp-content/plugins/[^/]+/(.+)$#', $uri, $m ) ) {
	$f = realpath( $root . '/' . $m[1] );
	if ( ! $f || 0 !== strpos( $f, $root ) || ! is_file( $f ) ) { http_response_code( 404 ); exit; }
	$types = array( 'js' => 'application/javascript', 'css' => 'text/css', 'svg' => 'image/svg+xml', 'png' => 'image/png', 'json' => 'application/json', 'mp3' => 'audio/mpeg' );
	header( 'Content-Type: ' . ( $types[ pathinfo( $f, PATHINFO_EXTENSION ) ] ?? 'application/octet-stream' ) );
	readfile( $f );
	exit;
}
if ( '/favicon.ico' === $uri ) { http_response_code( 204 ); exit; }

ob_start();
require __DIR__ . '/bootstrap.php';
if ( ! get_userdata( 1 ) ) { bch_make_user( 1, 'admin@shop.test', array( 'administrator' ) ); }
bch_make_user( 1, 'admin@shop.test', array( 'administrator' ) );
$GLOBALS['__users'][1]->display_name = 'مدیر سایت';
// Outgoing HTTP (SMS, webhooks…) is not sent: logged to <state>.http.log and answered with 200.
$GLOBALS['__http_responder'] = function ( $url, $args ) {
	file_put_contents( getenv( 'BCH_STATE' ) . '.http.log', date( 'H:i:s' ) . ' ' . $url . ' ' . ( is_array( $args['body'] ?? null ) ? json_encode( $args['body'], JSON_UNESCAPED_UNICODE ) : ( $args['body'] ?? '' ) ) . "\n", FILE_APPEND );
	return array( 'code' => 200, 'body' => '{"status":1,"return":{"status":200},"data":{"messageId":1}}' );
};
if ( getenv( 'BCH_LOCALE' ) ) { $GLOBALS['__locale'] = getenv( 'BCH_LOCALE' ); }
ob_end_clean();

function bch_dev_json( $status, $data ) {
	http_response_code( $status );
	header( 'Content-Type: application/json; charset=utf-8' );
	echo json_encode( $data, JSON_UNESCAPED_UNICODE );
	exit;
}

// REST.
if ( 0 === strpos( $uri, '/wp-json/' ) ) {
	$front = 0 === strpos( $uri, '/wp-json/becharkhoon/v1/front/' );
	$GLOBALS['__uid'] = $front && empty( $_GET['as_admin'] ) ? 0 : 1;
	$body = json_decode( file_get_contents( 'php://input' ), true );
	$q    = $_GET;
	unset( $q['_b'] );
	list( $st, $d ) = bch_rest( $_SERVER['REQUEST_METHOD'], substr( $uri, 8 ), $q, $body );
	bch_dev_json( $st, $d );
}
// Front AJAX.
if ( '/wp-admin/admin-ajax.php' === $uri ) {
	$GLOBALS['__uid'] = 0;
	$GLOBALS['__ajax'] = 1;
	$action = substr( sanitize_key( $_REQUEST['action'] ?? '' ), 4 );
	$p      = json_decode( $_POST['payload'] ?? '', true ) ?: array();
	$res    = ( new \Becharkhoon\Front\Ajax() )->dispatch( $action, $p );
	bch_dev_json( $res[0], $res[1] );
}
// Admin page.
if ( '/wp-admin/admin.php' === $uri ) {
	$GLOBALS['__uid']      = 1;
	$GLOBALS['__is_admin'] = 1;
	$admin = new \Becharkhoon\Admin\Admin();
	$admin->assets( 'toplevel_page_becharkhoon' );
	$a = $GLOBALS['__assets'];
	$rtl = 0 === strpos( get_user_locale(), 'fa' );
	echo '<!doctype html><html lang="' . ( $rtl ? 'fa' : 'en' ) . '" dir="' . ( $rtl ? 'rtl' : 'ltr' ) . '"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>WP Admin</title>';
	echo '<style>body{margin:0;background:#f0f0f1;font-family:system-ui,sans-serif}#wpadminbar{height:32px;background:#1d2327;position:fixed;top:0;left:0;right:0;z-index:99999}#adminmenuwrap{position:fixed;top:32px;bottom:0;' . ( $rtl ? 'right' : 'left' ) . ':0;width:160px;background:#1d2327}#wpcontent{margin-' . ( $rtl ? 'right' : 'left' ) . ':160px;padding-top:32px}@media(max-width:782px){#adminmenuwrap{display:none}#wpcontent{margin:0;padding-top:46px}#wpadminbar{height:46px}}</style>';
	foreach ( $a['css'] as $src ) { if ( false === strpos( $src, 'googleapis' ) ) { echo '<link rel="stylesheet" href="' . htmlspecialchars( $src ) . '">'; } }
	echo '</head><body class="wp-admin bch-screen"><div id="wpadminbar"></div><div id="adminmenuwrap"></div><div id="wpcontent"><div id="wpbody-content">';
	$admin->render();
	echo '</div></div><script>window.wp={media:function(){return{on:function(){},open:function(){},state:function(){return{get:function(){return{first:function(){return{toJSON:function(){return{url:""}}}}}}}}}}};';
	foreach ( $a['l10n'] as $name => $data ) { echo 'var ' . $name . '=' . json_encode( $data, JSON_UNESCAPED_UNICODE ) . ';'; }
	echo '</script>';
	foreach ( $a['js'] as $src ) { echo '<script src="' . htmlspecialchars( $src ) . '"></script>'; }
	echo '</body></html>';
	exit;
}
// Front page (any other path).
$GLOBALS['__uid'] = 0;
do_action( 'wp_enqueue_scripts' );
$a = $GLOBALS['__assets'];
echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Shop</title>';
foreach ( $a['css'] as $src ) { if ( false === strpos( $src, 'googleapis' ) ) { echo '<link rel="stylesheet" href="' . htmlspecialchars( $src ) . '">'; } }
foreach ( $a['js'] as $h => $src ) {
	if ( ! empty( $a['head'][ $h ] ) ) { // Scripts enqueued for <head> (fast start).
		foreach ( $a['l10n'] as $name => $data ) { echo '<script>var ' . $name . '=' . json_encode( $data, JSON_UNESCAPED_UNICODE ) . ';</script>'; }
		foreach ( (array) ( $a['inline'][ $h ] ?? array() ) as $code ) { echo '<script>' . $code . '</script>'; }
		echo '<script async src="' . htmlspecialchars( $src ) . '"></script>';
		unset( $a['js'][ $h ] ); $a['l10n'] = array();
	}
}
echo '<style>body{margin:0;font-family:system-ui,sans-serif;background:#f8fafc}.site{padding:40px;min-height:1600px}</style></head><body><div class="site"><h1>فروشگاه تست</h1><p>صفحه نمونه</p>';
echo isset( $_GET['sc'] ) ? ( new \Becharkhoon\Front\Shortcodes() )->wheel( array( 'id' => (int) $_GET['sc'] ) ) . '<div style="height:1400px;background:linear-gradient(#f8fafc,#cbd5e1)">محتوای پایین صفحه</div>' : '';
echo '</div>';
foreach ( $a['l10n'] as $name => $data ) { echo '<script>var ' . $name . '=' . json_encode( $data, JSON_UNESCAPED_UNICODE ) . ';</script>'; }
do_action( 'wp_footer' );
foreach ( $a['js'] as $src ) { echo '<script src="' . htmlspecialchars( $src ) . '"></script>'; }
echo '</body></html>';
