<?php
/**
 * SMS service (same model as ARIAGH.VISITOR): every automatic message is an "event" whose text
 * or provider pattern is edited in «پیامک و اعلان ← پیامک‌های خودکار». The sender batches plain
 * messages, sends patterns one by one, honours the on/off + test switches and logs every message.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Notify;

use Becharkhoon\Core\Helpers;
use Becharkhoon\Core\Lang;

defined( 'ABSPATH' ) || exit;

final class Sms {

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'bch_sms';
	}

	/** live | test (logged only) | disabled (switched off or no panel). */
	public static function mode() {
		$s = becharkhoon()->settings;
		if ( ! $s->get( 'sms_enabled' ) || '' === (string) $s->get( 'sms_driver' ) || ! SmsGateways::driver( (string) $s->get( 'sms_driver' ) ) ) {
			return 'disabled';
		}
		return $s->get( 'sms_test_mode' ) ? 'test' : 'live';
	}

	/** Saved settings of an event merged with its defaults. */
	public static function template( $event ) {
		$e   = SmsEvents::get( $event );
		$all = (array) becharkhoon()->settings->get( 'sms_tpl' );
		$row = isset( $all[ $event ] ) && is_array( $all[ $event ] ) ? $all[ $event ] : array();
		return array(
			'on'     => array_key_exists( 'on', $row ) ? (bool) $row['on'] : ( $e ? false !== $e['toggle'] : true ),
			'mode'   => isset( $row['mode'] ) && 'pattern' === $row['mode'] ? 'pattern' : 'text',
			'text'   => isset( $row['text'] ) && '' !== trim( (string) $row['text'] ) ? (string) $row['text'] : ( $e ? $e['default'] : '' ),
			'code'   => isset( $row['code'] ) ? trim( (string) $row['code'] ) : '',
			'params'   => isset( $row['params'] ) && '' !== trim( (string) $row['params'] ) ? (string) $row['params'] : ( $e ? $e['hint'] : '' ),
			'fallback' => ! empty( $row['fallback'] ),
		);
	}

	public static function event_enabled( $event ) {
		$e = SmsEvents::get( $event );
		if ( ! $e ) {
			return false;
		}
		return null === $e['toggle'] || self::template( $event )['on'];
	}

	/** Replace {variables}; unknown ones become empty and doubled blank lines are removed. */
	public static function render( $text, array $vars ) {
		$out = Helpers::tpl( (string) $text, $vars );
		$out = preg_replace( '/\{[a-z0-9_]+\}/i', '', $out );
		$out = preg_replace( "/\n{3,}/", "\n\n", str_replace( "\r", '', $out ) );
		return trim( preg_replace( '/[ \t]+\n/', "\n", $out ) );
	}

	/**
	 * One message for an event.
	 *
	 * @param string     $event    Event key.
	 * @param array      $vars     Variables.
	 * @param string     $mobile   Recipient.
	 * @param array|null $override Wheel-level text/pattern { mode, text, code, params } or null.
	 */
	public static function build( $event, array $vars, $mobile, $override = null ) {
		$tpl = self::template( $event );
		if ( is_array( $override ) ) {
			$tpl = array_merge( $tpl, array_filter( $override, static function ( $v ) { return '' !== trim( (string) $v ); } ) );
		}
		$msg = array( 'mobile' => $mobile, 'text' => self::render( $tpl['text'], $vars ) );
		if ( 'pattern' === $tpl['mode'] && '' !== $tpl['code'] ) {
			$params = array();
			foreach ( SmsEvents::parse_params( $tpl['params'] ) as $k => $v ) {
				$v            = self::render( $v, $vars );
				$params[ $k ] = '' === $v ? '-' : $v; // Panels reject empty parameters.
			}
			$msg['pattern'] = array( 'code' => Helpers::latin_digits( $tpl['code'] ), 'params' => $params );
			if ( ! empty( $tpl['fallback'] ) && '' !== $msg['text'] ) {
				$msg['fallback'] = true; // Pattern rejected by the panel → send the text instead.
			}
		}
		return $msg;
	}

	/**
	 * Send an event.
	 *
	 * @param string       $event Event key.
	 * @param array        $vars  Variables (general ones are added).
	 * @param string|array $to    Mobile(s); ignored for admin events (admin numbers are used).
	 * @param array        $opts  force (ignore global on/off), override (wheel text), wheel_id.
	 */
	public static function send_event( $event, array $vars, $to = '', array $opts = array() ) {
		$e = SmsEvents::get( $event );
		if ( ! $e ) {
			return array( 'sent' => 0, 'failed' => 0, 'response' => 'unknown event' );
		}
		if ( empty( $opts['force'] ) && ! self::event_enabled( $event ) ) {
			return array( 'sent' => 0, 'failed' => 0, 'response' => 'off' );
		}
		$vars = array_merge( SmsEvents::general_vars(), $vars );
		$list = 'admins' === $e['to'] ? self::admin_mobiles() : (array) $to;
		$msgs = array();
		foreach ( $list as $m ) {
			$m = Helpers::phone( (string) $m );
			if ( '' !== $m ) {
				$msgs[] = self::build( $event, array_merge( array( 'mobile' => $m ), $vars ), $m, $opts['override'] ?? null );
			}
		}
		if ( ! $msgs ) {
			return array( 'sent' => 0, 'failed' => 0, 'response' => 'no recipient' );
		}
		return self::send_many( $msgs, $opts['context'] ?? $event, (int) ( $opts['wheel_id'] ?? 0 ) );
	}

	public static function admin_mobiles() {
		return array_values( array_unique( array_filter( array_map( array( Helpers::class, 'phone' ), Helpers::lines( (string) becharkhoon()->settings->get( 'admin_phones' ) ) ) ) ) );
	}

	/**
	 * Send a list of messages [ mobile, text, pattern => [ code, params ] ].
	 *
	 * @return array{sent:int,failed:int,response:string,mode:string}
	 */
	public static function send_many( array $messages, $context = 'custom', $wheel_id = 0 ) {
		$sent   = 0;
		$failed = 0;
		$last   = '';
		$valid  = array();
		$per    = array(); // mobile => array( status, response ) for callers that track each message.
		foreach ( $messages as $m ) {
			$mobile = Helpers::phone( (string) ( $m['mobile'] ?? '' ) );
			$text   = (string) ( $m['text'] ?? '' );
			if ( '' !== $mobile && ( '' !== trim( $text ) || ! empty( $m['pattern'] ) ) ) {
				$m['mobile'] = $mobile;
				$m['text']   = $text;
				$valid[]     = $m;
			} else {
				++$failed;
				$per[ (string) ( $m['mobile'] ?? '' ) ] = array( 'status' => 'failed', 'response' => Lang::t( 'شماره یا متن نامعتبر', 'Invalid number or text' ) );
			}
		}
		$mode = self::mode();
		if ( ! $valid ) {
			return array( 'sent' => 0, 'failed' => $failed, 'response' => Lang::t( 'شماره موبایل یا متن پیامک معتبر نیست.', 'Invalid mobile number or empty text.' ), 'mode' => $mode, 'items' => $per );
		}
		$id     = (string) becharkhoon()->settings->get( 'sms_driver' );
		$driver = SmsGateways::driver( $id );
		$cfg    = $driver ? SmsGateways::config( $id ) : array();

		// Pattern messages go one by one; plain messages in provider-sized batches.
		$jobs  = array();
		$plain = array();
		foreach ( $valid as $m ) {
			if ( ! empty( $m['pattern']['code'] ) && $driver && $driver->pattern ) {
				$jobs[] = array( 'type' => 'pattern', 'items' => array( $m ) );
			} else {
				if ( '' === trim( $m['text'] ) && ! empty( $m['pattern'] ) ) {
					$m['text'] = implode( "\n", array_map( 'strval', $m['pattern']['params'] ) ); // Panel without patterns.
				}
				$plain[] = $m;
			}
		}
		foreach ( array_chunk( $plain, max( 1, $driver ? (int) $driver->batch_size() : 1 ) ) as $chunk ) {
			$jobs[] = array( 'type' => 'text', 'items' => $chunk );
		}

		foreach ( $jobs as $job ) {
			$chunk  = $job['items'];
			$status = '';
			if ( 'live' !== $mode ) {
				$results = array_fill( 0, count( $chunk ), array( 'ok' => 'test' === $mode, 'response' => 'test' === $mode ? Lang::t( 'حالت تست — پیامک واقعی ارسال نشد', 'Test mode — not really sent' ) : Lang::t( 'ارسال پیامک خاموش است یا پنلی انتخاب نشده', 'SMS sending is off or no panel is selected' ) ) );
				$status  = $mode;
			} else {
				try {
					if ( 'pattern' === $job['type'] ) {
						$m       = $chunk[0];
						$results = array( $driver->send_pattern( $m['mobile'], (string) $m['pattern']['code'], (array) $m['pattern']['params'], $cfg ) );
					} else {
						$results = $driver->send(
							array_map(
								static function ( $m ) {
									return array( 'mobile' => $m['mobile'], 'text' => $m['text'] );
								},
								$chunk
							),
							$cfg
						);
					}
				} catch ( \Throwable $ex ) {
					$results = array_fill( 0, count( $chunk ), array( 'ok' => false, 'response' => $ex->getMessage() ) );
				}
			}
			// Pattern failed and the message has a text fallback → try plain text once.
			if ( 'pattern' === $job['type'] && 'live' === $mode && empty( $results[0]['ok'] ) && ! empty( $chunk[0]['fallback'] ) ) {
				$m0 = $chunk[0];
				$pr = $results[0]['response'] ?? '';
				self::log( $m0['mobile'], '[' . Lang::t( 'الگو', 'pattern' ) . ' ' . $m0['pattern']['code'] . '] ' . Lang::t( 'ناموفق؛ ارسال متن پشتیبان', 'failed; sending fallback text' ), $context, $id, 'failed', is_string( $pr ) ? $pr : (string) wp_json_encode( $pr ), $wheel_id );
				try {
					$results = $driver->send( array( array( 'mobile' => $m0['mobile'], 'text' => $m0['text'] ) ), $cfg );
				} catch ( \Throwable $ex ) {
					$results = array( array( 'ok' => false, 'response' => $ex->getMessage() ) );
				}
				$job['type'] = 'text';
			}
			foreach ( $chunk as $i => $m ) {
				$r  = $results[ $i ] ?? array( 'ok' => false, 'response' => Lang::t( 'پاسخی از سامانه دریافت نشد', 'No response from the panel' ) );
				$ok = ! empty( $r['ok'] );
				$st = '' !== $status ? $status : ( $ok ? 'sent' : 'failed' );
				if ( 'sent' === $st || 'test' === $st ) {
					++$sent;
				} else {
					++$failed;
				}
				$raw  = $r['response'] ?? '';
				$last = is_string( $raw ) ? $raw : (string) wp_json_encode( $raw, JSON_UNESCAPED_UNICODE );
				$msg  = $m['text'];
				if ( 'pattern' === $job['type'] ) {
					$pairs = array();
					foreach ( (array) $m['pattern']['params'] as $k => $v ) {
						$pairs[] = $k . '=' . $v;
					}
					$msg = '[' . Lang::t( 'الگو', 'pattern' ) . ' ' . $m['pattern']['code'] . '] ' . implode( ' | ', $pairs );
				}
				self::log( $m['mobile'], $msg, $context, $id, $st, $last, $wheel_id );
				$per[ $m['mobile'] ] = array( 'status' => $st, 'response' => $last );
			}
		}
		do_action( 'becharkhoon_sms_sent', $context, $sent, $failed );
		return array( 'sent' => $sent, 'failed' => $failed, 'response' => $last, 'mode' => $mode, 'items' => $per );
	}

	private static function log( $mobile, $message, $context, $provider, $status, $response, $wheel_id ) {
		global $wpdb;
		$wpdb->insert(
			self::table(),
			array(
				'mobile'     => substr( (string) $mobile, 0, 20 ),
				'message'    => mb_substr( (string) $message, 0, 1000 ),
				'context'    => substr( sanitize_key( (string) $context ), 0, 30 ),
				'wheel_id'   => (int) $wheel_id,
				'provider'   => substr( (string) $provider, 0, 40 ),
				'status'     => substr( (string) $status, 0, 12 ),
				'response'   => mb_substr( wp_strip_all_tags( (string) $response ), 0, 1000 ),
				'created_by' => (int) get_current_user_id(),
				'created_at' => Helpers::now(),
			)
		);
	}

	/** Contexts for the log filter. */
	public static function contexts() {
		$out = array();
		foreach ( SmsEvents::all() as $k => $e ) {
			$out[ $k ] = $e['label'];
		}
		$out['bulk'] = Lang::t( 'پیامک گروهی', 'Bulk SMS' );
		$out['test'] = Lang::t( 'تست', 'Test' );
		$out['resend'] = Lang::t( 'ارسال مجدد', 'Resend' );
		return $out;
	}

	public static function log_query( array $args ) {
		global $wpdb;
		$t     = self::table();
		$where = array( '1=1' );
		$vals  = array();
		if ( ! empty( $args['search'] ) ) {
			$s       = '%' . $wpdb->esc_like( Helpers::latin_digits( (string) $args['search'] ) ) . '%';
			$where[] = '(mobile LIKE %s OR message LIKE %s)';
			array_push( $vals, $s, $s );
		}
		foreach ( array( 'status', 'context' ) as $k ) {
			if ( ! empty( $args[ $k ] ) ) {
				$where[] = "$k = %s";
				$vals[]  = sanitize_key( (string) $args[ $k ] );
			}
		}
		$per    = max( 1, min( 200, (int) ( $args['per_page'] ?? 30 ) ) );
		$page   = max( 1, (int) ( $args['page'] ?? 1 ) );
		$off    = ( $page - 1 ) * $per;
		$w      = implode( ' AND ', $where );
		$sql    = "SELECT * FROM $t WHERE $w ORDER BY id DESC LIMIT $off, $per";
		$csql   = "SELECT COUNT(*) FROM $t WHERE $w";
		$items  = $vals ? $wpdb->get_results( $wpdb->prepare( $sql, $vals ), ARRAY_A ) : $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore
		$total  = (int) ( $vals ? $wpdb->get_var( $wpdb->prepare( $csql, $vals ) ) : $wpdb->get_var( $csql ) ); // phpcs:ignore
		$labels = self::contexts();
		$items  = (array) $items;
		foreach ( $items as &$i ) {
			$i['context_label'] = $labels[ $i['context'] ] ?? $i['context'];
		}
		unset( $i );
		$stats = array();
		foreach ( (array) $wpdb->get_results( "SELECT status, COUNT(*) AS n FROM $t GROUP BY status", ARRAY_A ) as $r ) { // phpcs:ignore
			$stats[ $r['status'] ] = (int) $r['n'];
		}
		return array( 'items' => $items, 'total' => $total, 'stats' => $stats );
	}

	public static function clear_log() {
		global $wpdb;
		$wpdb->query( 'DELETE FROM ' . self::table() ); // phpcs:ignore
	}

	public static function prune( $days ) {
		global $wpdb;
		if ( (int) $days > 0 ) {
			$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::table() . ' WHERE created_at < %s', Helpers::now( -1 * (int) $days * DAY_IN_SECONDS ) ) ); // phpcs:ignore
		}
	}

	public static function erase_phone( $phone ) {
		global $wpdb;
		return (int) $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::table() . ' WHERE mobile = %s', $phone ) ); // phpcs:ignore
	}
}
