<?php
/**
 * Thin HTTP wrapper (wp_remote_*) returning a uniform array.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Core;

defined( 'ABSPATH' ) || exit;

final class Http {

	/**
	 * @param string $method  GET|POST|PUT.
	 * @param string $url     URL.
	 * @param array  $opts    headers, body (array → JSON when json=true, form otherwise), json, timeout.
	 * @return array{ok:bool,code:int,body:string,json:mixed,error:string}
	 */
	public static function request( $method, $url, array $opts = array() ) {
		$headers = isset( $opts['headers'] ) ? (array) $opts['headers'] : array();
		$body    = $opts['body'] ?? null;
		if ( ! empty( $opts['json'] ) && is_array( $body ) ) {
			$body                    = wp_json_encode( $body, JSON_UNESCAPED_UNICODE );
			$headers['Content-Type'] = 'application/json';
		}
		if ( ! isset( $headers['Accept'] ) ) {
			$headers['Accept'] = 'application/json';
		}
		$args = array(
			'method'      => strtoupper( $method ),
			'timeout'     => isset( $opts['timeout'] ) ? (int) $opts['timeout'] : 15,
			'headers'     => $headers,
			'redirection' => 3,
			'user-agent'  => 'Becharkhoon/' . BCH_VERSION . '; ' . home_url( '/' ),
		);
		if ( null !== $body && 'GET' !== $args['method'] ) {
			$args['body'] = $body;
		}
		$res = wp_remote_request( $url, $args );
		if ( is_wp_error( $res ) ) {
			return array( 'ok' => false, 'code' => 0, 'body' => '', 'json' => null, 'error' => $res->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$raw  = (string) wp_remote_retrieve_body( $res );
		$json = json_decode( $raw, true );
		return array(
			'ok'    => $code >= 200 && $code < 300,
			'code'  => $code,
			'body'  => $raw,
			'json'  => $json,
			'error' => ( $code >= 200 && $code < 300 ) ? '' : 'HTTP ' . $code,
		);
	}
}
