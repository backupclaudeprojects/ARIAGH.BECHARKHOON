<?php
/**
 * Pre-made code pools (gift cards, mobile top-up PINs, partner vouchers…): one code per winner.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Prizes;

use Becharkhoon\Core\Helpers;

defined( 'ABSPATH' ) || exit;

final class CodePool {

	private static function t() {
		global $wpdb;
		return $wpdb->prefix . 'bch_codes';
	}

	/** Import codes (one per line), skipping duplicates already in the pool. Returns number added. */
	public static function import( $wheel_id, $slice_id, $text ) {
		global $wpdb;
		$codes = array_unique( array_filter( array_map( 'trim', preg_split( '/[\r\n]+/', (string) $text ) ) ) );
		$added = 0;
		foreach ( array_slice( $codes, 0, 20000 ) as $code ) {
			$code = mb_substr( sanitize_text_field( $code ), 0, 190 );
			if ( '' === $code ) {
				continue;
			}
			$exists = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::t() . ' WHERE wheel_id = %d AND slice_id = %s AND code = %s', $wheel_id, $slice_id, $code ) ); // phpcs:ignore
			if ( $exists ) {
				continue;
			}
			$wpdb->insert( self::t(), array( 'wheel_id' => (int) $wheel_id, 'slice_id' => (string) $slice_id, 'code' => $code, 'spin_id' => 0 ) );
			++$added;
		}
		return $added;
	}

	public static function available( $wheel_id, $slice_id ) {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::t() . ' WHERE wheel_id = %d AND slice_id = %s AND spin_id = 0', $wheel_id, $slice_id ) ); // phpcs:ignore
	}

	/** slice_id => [available, used] for one wheel. */
	public static function summary( $wheel_id ) {
		global $wpdb;
		$out = array();
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT slice_id, SUM(spin_id = 0) AS available, SUM(spin_id <> 0) AS used FROM ' . self::t() . ' WHERE wheel_id = %d GROUP BY slice_id', $wheel_id ), ARRAY_A ) as $r ) { // phpcs:ignore
			$out[ $r['slice_id'] ] = array( 'available' => (int) $r['available'], 'used' => (int) $r['used'] );
		}
		return $out;
	}

	/** Atomically assign a free code to a spin. Returns the code or ''. */
	public static function claim( $wheel_id, $slice_id, $spin_id ) {
		global $wpdb;
		for ( $i = 0; $i < 5; $i++ ) {
			$ids = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM ' . self::t() . ' WHERE wheel_id = %d AND slice_id = %s AND spin_id = 0 ORDER BY id ASC LIMIT 5', $wheel_id, $slice_id ) ); // phpcs:ignore
			if ( ! $ids ) {
				return '';
			}
			foreach ( $ids as $id ) {
				if ( $wpdb->query( $wpdb->prepare( 'UPDATE ' . self::t() . ' SET spin_id = %d, assigned_at = %s WHERE id = %d AND spin_id = 0', $spin_id, Helpers::now(), $id ) ) ) { // phpcs:ignore
					return (string) $wpdb->get_var( $wpdb->prepare( 'SELECT code FROM ' . self::t() . ' WHERE id = %d', $id ) ); // phpcs:ignore
				}
			}
		}
		return '';
	}

	public static function clear_unused( $wheel_id, $slice_id ) {
		global $wpdb;
		return (int) $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::t() . ' WHERE wheel_id = %d AND slice_id = %s AND spin_id = 0', $wheel_id, $slice_id ) ); // phpcs:ignore
	}
}
