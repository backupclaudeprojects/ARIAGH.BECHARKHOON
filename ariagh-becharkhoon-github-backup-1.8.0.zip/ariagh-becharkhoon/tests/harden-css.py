import sys, re
src = open(sys.argv[1], encoding='utf-8').read()
TAG = ':not(#bchz)'
out = []; i = 0; n = len(src)
stack = []  # 'kf' or 'block'
def tx_selector(sel):
    parts = []
    depth = 0; cur = ''
    for ch in sel:
        if ch in '([': depth += 1
        if ch in ')]': depth -= 1
        if ch == ',' and depth == 0: parts.append(cur); cur = ''
        else: cur += ch
    parts.append(cur)
    res = []
    for p in parts:
        s = p.strip()
        if not s or TAG in s or s.startswith(':where(') or re.match(r'^(from|to|\d+%)$', s):
            res.append(p); continue
        lead = p[:len(p)-len(p.lstrip())]
        k = s.find('::')
        s = s[:k] + TAG + s[k:] if k >= 0 else s + TAG
        res.append(lead + s)
    return ','.join(res)
buf = ''
while i < n:
    c = src[i]
    if src.startswith('/*', i):
        j = src.index('*/', i) + 2; buf += src[i:j]; i = j; continue
    if c == '{':
        pre = buf; buf = ''
        stripped = pre.strip()
        m = re.search(r'(\s*)$', pre)
        if stripped.startswith('@'):
            kind = 'kf' if 'keyframes' in stripped else 'at'
            stack.append(kind); out.append(pre + '{')
        else:
            inkf = 'kf' in stack
            # keep comments/whitespace before selector
            lead_end = len(pre) - len(pre.lstrip())
            sel_text = pre
            if not inkf:
                # separate leading comments
                mm = re.match(r'^((?:\s|/\*.*?\*/)*)(.*)$', pre, re.S)
                sel_text = mm.group(1) + tx_selector(mm.group(2))
            stack.append('rule'); out.append(sel_text + '{')
        i += 1; continue
    if c == '}':
        out.append(buf + '}'); buf = ''
        if stack: stack.pop()
        i += 1; continue
    buf += c; i += 1
out.append(buf)
open(sys.argv[2], 'w', encoding='utf-8').write(''.join(out))
