<?php
/**
 * WordPress personal-data export / erase (Tools → Export/Erase Personal Data).
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Privacy;

use Becharkhoon\Core\Helpers;

defined( 'ABSPATH' ) || exit;

final class Privacy {

	public function register_hooks() {
		add_filter( 'wp_privacy_personal_data_exporters', array( $this, 'exporters' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( $this, 'erasers' ) );
		add_action( 'admin_init', array( $this, 'policy' ) );
	}

	public function policy() {
		if ( function_exists( 'wp_add_privacy_policy_content' ) ) {
			wp_add_privacy_policy_content( 'ARIAGH.BECHARKHOON', wp_kses_post( __( 'When you spin our lucky wheel we store your name, email, mobile number, IP address, a random device identifier and your prize so we can deliver it, prevent abuse and send you the prize code by SMS/email.', 'becharkhoon' ) ) );
		}
	}

	public function exporters( $e ) {
		$e['becharkhoon'] = array( 'exporter_friendly_name' => 'Lucky wheel (Becharkhoon)', 'callback' => array( $this, 'export' ) );
		return $e;
	}

	public function erasers( $e ) {
		$e['becharkhoon'] = array( 'eraser_friendly_name' => 'Lucky wheel (Becharkhoon)', 'callback' => array( $this, 'erase' ) );
		return $e;
	}

	private function where( $email ) {
		global $wpdb;
		$user  = get_user_by( 'email', $email );
		$phone = $user ? Helpers::phone( get_user_meta( $user->ID, 'billing_phone', true ) ) : '';
		$w     = 'email = %s';
		$p     = array( strtolower( $email ) );
		if ( $user ) {
			$w  .= ' OR user_id = %d';
			$p[] = $user->ID;
		}
		if ( '' !== $phone ) {
			$w  .= ' OR phone = %s';
			$p[] = $phone;
		}
		return array( $w, $p, $wpdb );
	}

	public function export( $email, $page = 1 ) {
		list( $w, $p, $wpdb ) = $this->where( $email );
		$items = array();
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bch_spins WHERE $w ORDER BY id DESC LIMIT 500", $p ), ARRAY_A ); // phpcs:ignore
		foreach ( (array) $rows as $r ) {
			$items[] = array(
				'group_id'    => 'becharkhoon-spins',
				'group_label' => 'Lucky wheel spins',
				'item_id'     => 'bch-spin-' . $r['id'],
				'data'        => array(
					array( 'name' => 'Date', 'value' => $r['created_at'] ),
					array( 'name' => 'Prize', 'value' => $r['slice_label'] ),
					array( 'name' => 'Code', 'value' => $r['coupon_code'] ),
					array( 'name' => 'Name', 'value' => $r['name'] ),
					array( 'name' => 'Phone', 'value' => $r['phone'] ),
					array( 'name' => 'IP', 'value' => $r['ip'] ),
				),
			);
		}
		$leads = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bch_leads WHERE $w", $p ), ARRAY_A ); // phpcs:ignore
		foreach ( (array) $leads as $l ) {
			$data = array(
				array( 'name' => 'Name', 'value' => $l['name'] ),
				array( 'name' => 'Phone', 'value' => $l['phone'] ),
				array( 'name' => 'Email', 'value' => $l['email'] ),
			);
			foreach ( Helpers::json_decode_array( $l['fields'] ) as $k => $v ) {
				$data[] = array( 'name' => (string) $k, 'value' => is_scalar( $v ) ? (string) $v : '' );
			}
			$items[] = array( 'group_id' => 'becharkhoon-leads', 'group_label' => 'Lucky wheel form data', 'item_id' => 'bch-lead-' . $l['id'], 'data' => $data );
		}
		return array( 'data' => $items, 'done' => true );
	}

	public function erase( $email, $page = 1 ) {
		list( $w, $p, $wpdb ) = $this->where( $email );
		$n  = (int) $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}bch_spins SET email = '', phone = '', name = '', ip = '', device = '', meta = NULL WHERE $w", $p ) ); // phpcs:ignore
		$n += (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}bch_leads WHERE $w", $p ) ); // phpcs:ignore
		foreach ( array_slice( $p, 1 ) as $phone ) {
			if ( is_string( $phone ) && '' !== Helpers::phone( $phone ) ) {
				$n += \Becharkhoon\Notify\Sms::erase_phone( $phone );
			}
		}
		return array( 'items_removed' => $n > 0, 'items_retained' => false, 'messages' => array(), 'done' => true );
	}
}
