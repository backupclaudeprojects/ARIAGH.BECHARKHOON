<?php
/**
 * Front-end bootstrap: assets, cache-safe page context, wheel visibility (page rules,
 * audience, devices, A/B groups) and the public (stripped) wheel config.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Front;

use Becharkhoon\Core\Capabilities;
use Becharkhoon\Core\Helpers;
use Becharkhoon\Core\Lang;
use Becharkhoon\Credits\Rules;
use Becharkhoon\Engine\Conditions;
use Becharkhoon\Engine\Context;
use Becharkhoon\Engine\Eligibility;
use Becharkhoon\Engine\SpinService;
use Becharkhoon\Stats\Stats;

defined( 'ABSPATH' ) || exit;

final class Frontend {

	/** @var bool Inline wheel rendered on this page (shortcode/block/widget). */
	public static $inline = false;

	public function register_hooks() {
		add_action( 'wp_enqueue_scripts', array( $this, 'assets' ), 20 );
		add_action( 'wp_footer', array( $this, 'footer' ), 50 );
	}

	private function should_load() {
		$s = becharkhoon()->settings;
		if ( ! $s->get( 'enabled' ) || is_admin() || wp_doing_ajax() ) {
			return false;
		}
		if ( function_exists( 'is_customize_preview' ) && is_customize_preview() ) {
			return false;
		}
		if ( $s->get( 'test_mode' ) && ! Capabilities::can_manage() ) {
			return false;
		}
		$open = (string) $s->get( 'open_param' );
		if ( isset( $_GET['bch_preview'] ) || isset( $_GET[ $open ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return true;
		}
		return (bool) apply_filters( 'becharkhoon_load_on_page', (bool) becharkhoon()->wheels->active() || self::$inline );
	}

	public function assets() {
		if ( ! $this->should_load() ) {
			return;
		}
		$s = becharkhoon()->settings;
		if ( $s->get( 'load_front_webfont' ) && 'vazirmatn' === $s->get( 'front_font' ) ) {
			wp_enqueue_style( 'bch-font', 'https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;600;800;900&display=swap', array(), null ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
		} elseif ( 'custom' === $s->get( 'front_font' ) && '' !== $s->get( 'front_font_url' ) ) {
			wp_enqueue_style( 'bch-font', $s->get( 'front_font_url' ), array(), null ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
		}
		wp_enqueue_style( 'bch-front', BCH_URL . 'assets/front/wheel.css', array(), BCH_VERSION );
		$fast = (bool) $s->get( 'fast_boot' );
		// Fast start: the script runs in <head> and asks the server right away, so the wheel shows as soon as
		// the HTML is parsed — without waiting for images, iframes, fonts or the rest of the page to load.
		wp_enqueue_script( 'bch-front', BCH_URL . 'assets/front/wheel.js', array(), BCH_VERSION, ! $fast );
		wp_localize_script( 'bch-front', 'BECHARKHOON', self::js_config() );
		if ( $fast ) {
			wp_add_inline_script( 'bch-front', 'window.BCH_PAGE=' . wp_json_encode( self::page_context(), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP ) . ';', 'before' );
			if ( function_exists( 'wp_script_add_data' ) ) {
				wp_script_add_data( 'bch-front', 'strategy', 'async' ); // Does not block the page; starts as soon as it arrives.
			}
		} elseif ( function_exists( 'wp_script_add_data' ) ) {
			wp_script_add_data( 'bch-front', 'strategy', 'defer' );
		}
	}

	/** Static, cache-safe config (no user data, no nonces). */
	public static function js_config() {
		$s = becharkhoon()->settings;
		return array(
			'ajax'      => admin_url( 'admin-ajax.php' ),
			'rest'      => esc_url_raw( rest_url( 'becharkhoon/v1/front/' ) ),
			'mode'      => $s->get( 'ajax_mode' ),
			'home'      => home_url( '/' ),
			'rtl'       => is_rtl(),
			'fa'        => 0 === strpos( get_locale(), 'fa' ),
			'digits'    => (bool) $s->get( 'persian_digits' ),
			'font'      => $s->get( 'front_font' ),
			'z'         => (int) $s->get( 'z_index' ),
			'track'     => (bool) $s->get( 'tracking_enabled' ),
			'sample'    => (int) $s->get( 'track_sample' ),
			'dnt'       => (bool) $s->get( 'respect_dnt' ),
			'openParam' => $s->get( 'open_param' ),
			'captcha'   => array( 'type' => $s->get( 'captcha' ), 'key' => $s->get( 'captcha_site_key' ) ),
			'powered'   => (bool) $s->get( 'powered_by' ),
			'otpLen'    => (int) $s->get( 'otp_length' ),
			'fast'      => (bool) $s->get( 'fast_boot' ),
			'ver'       => BCH_VERSION,
		);
	}

	/** Per-URL context printed in the footer (safe to page-cache). */
	public function footer() {
		if ( ! wp_script_is( 'bch-front', 'enqueued' ) ) {
			return;
		}
		$ctx = self::page_context();
		echo '<script id="bch-page" type="application/json">' . wp_json_encode( $ctx, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP ) . '</script>';
		echo '<div id="bch-root" class="bch-root" aria-live="polite"></div>';
	}

	public static function page_context() {
		$type  = 'other';
		$id    = (int) get_queried_object_id();
		$terms = array();
		$woo   = function_exists( 'is_woocommerce' );
		if ( $woo && function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
			$type = 'thankyou';
		} elseif ( $woo && is_cart() ) {
			$type = 'cart';
		} elseif ( $woo && is_checkout() ) {
			$type = 'checkout';
		} elseif ( $woo && is_account_page() ) {
			$type = 'account';
		} elseif ( $woo && is_product() ) {
			$type  = 'product';
			$terms = wp_get_post_terms( $id, 'product_cat', array( 'fields' => 'ids' ) );
		} elseif ( $woo && is_product_category() ) {
			$type  = 'product_cat';
			$terms = array( $id );
		} elseif ( $woo && is_product_tag() ) {
			$type = 'product_tag';
		} elseif ( $woo && is_shop() ) {
			$type = 'shop';
		} elseif ( is_front_page() ) {
			$type = 'front';
		} elseif ( is_home() ) {
			$type = 'blog';
		} elseif ( is_singular( 'post' ) ) {
			$type  = 'post';
			$terms = wp_get_post_categories( $id );
		} elseif ( is_page() ) {
			$type = 'page';
		} elseif ( is_category() ) {
			$type = 'category';
		} elseif ( is_tag() ) {
			$type = 'tag';
		} elseif ( is_search() ) {
			$type = 'search';
		} elseif ( is_404() ) {
			$type = '404';
		} elseif ( is_archive() ) {
			$type = 'archive';
		} elseif ( is_singular() ) {
			$type = 'single';
		}
		$out = array(
			'page_type' => $type,
			'object_id' => $id,
			'post_type' => is_singular() ? get_post_type() : '',
			'terms'     => is_wp_error( $terms ) ? array() : array_map( 'intval', (array) $terms ),
			'is_home'   => is_front_page() || is_home(),
		);
		// Thank-you page: spins just earned by this order (order key verified).
		if ( 'thankyou' === $type && isset( $_GET['key'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			global $wp;
			$order_id = isset( $wp->query_vars['order-received'] ) ? absint( $wp->query_vars['order-received'] ) : 0;
			$order    = $order_id ? wc_get_order( $order_id ) : null;
			if ( $order && hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ) ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				$out['granted']       = (int) $order->get_meta( '_bch_spins_granted' );
				$out['granted_wheel'] = (int) $order->get_meta( '_bch_spins_wheel' );
			}
		}
		return $out;
	}

	/* ---------- Visibility ---------- */

	/** Static page rules (include/exclude) using the client page context. */
	public static function page_matches( array $wheel, Context $ctx ) {
		$t     = $wheel['config']['targeting'];
		$rules = $t['page_rules'];
		if ( 'all' === $t['pages'] || ! $rules ) {
			return true;
		}
		$hit = false;
		foreach ( $rules as $r ) {
			if ( self::rule_hits( $r, $ctx ) ) {
				$hit = true;
				break;
			}
		}
		return 'include' === $t['pages'] ? $hit : ! $hit;
	}

	public static function rule_hits( array $r, Context $ctx ) {
		$type = $ctx->client( 'page_type' );
		$oid  = (int) $ctx->client( 'object_id', 0 );
		$url  = (string) $ctx->client( 'url' );
		$path = (string) wp_parse_url( $url, PHP_URL_PATH ) . ( wp_parse_url( $url, PHP_URL_QUERY ) ? '?' . wp_parse_url( $url, PHP_URL_QUERY ) : '' );
		$vals = array_filter( array_map( 'trim', explode( ',', (string) $r['value'] ) ), 'strlen' );
		switch ( $r['type'] ) {
			case 'home':
				return in_array( $type, array( 'front', 'blog' ), true ) && ( 'front' === $type || ! get_option( 'page_on_front' ) );
			case 'front':
				return 'front' === $type;
			case 'blog':
			case 'shop':
			case 'cart':
			case 'checkout':
			case 'thankyou':
			case 'account':
			case 'post':
			case 'page':
			case 'category':
			case 'tag':
			case 'search':
			case '404':
			case 'archive':
				$ok = $type === $r['type'];
				if ( $ok && $vals && in_array( $r['type'], array( 'post', 'page' ), true ) ) {
					$ok = in_array( (string) $oid, $vals, true );
				}
				return $ok;
			case 'product':
				if ( 'product' !== $type ) {
					return false;
				}
				return ! $vals || in_array( (string) $oid, $vals, true );
			case 'product_cat':
				if ( ! $vals ) {
					return 'product_cat' === $type;
				}
				$terms = array_map( 'strval', (array) $ctx->client( 'terms', array() ) );
				return in_array( $type, array( 'product', 'product_cat' ), true ) && (bool) array_intersect( $terms, $vals );
			case 'product_tag':
				return 'product_tag' === $type;
			case 'post_type':
				return in_array( (string) $ctx->client( 'post_type' ), $vals, true );
			case 'object_id':
				return in_array( (string) $oid, $vals, true );
			case 'url_contains':
				foreach ( $vals as $v ) {
					if ( false !== mb_stripos( $url, $v ) ) {
						return true;
					}
				}
				return false;
			case 'url_exact':
				return in_array( untrailingslashit( $path ), array_map( 'untrailingslashit', $vals ), true ) || in_array( untrailingslashit( $url ), array_map( 'untrailingslashit', $vals ), true );
			case 'url_regex':
				return '' !== $r['value'] && (bool) @preg_match( '~' . str_replace( '~', '\~', $r['value'] ) . '~iu', $url ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			case 'query_param':
				$q     = (array) $ctx->client( 'query', array() );
				$parts = explode( '=', (string) $r['value'], 2 );
				$k     = sanitize_key( $parts[0] );
				return isset( $q[ $k ] ) && ( ! isset( $parts[1] ) || (string) $q[ $k ] === $parts[1] );
		}
		return false;
	}

	/** Wheels to show on this page for this visitor (popup + requested inline ids). */
	public static function visible_wheels( Context $ctx, array $inline_ids = array(), $preview = 0 ) {
		$out    = array();
		$repo   = becharkhoon()->wheels;
		$device = $ctx->client( 'device', 'desktop' );
		if ( $preview && Capabilities::can_manage() ) {
			$w = $repo->get( $preview );
			if ( $w ) {
				$w['preview']  = true;
				$out[ $w['id'] ] = $w;
			}
		}
		$groups = array();
		foreach ( $repo->active() as $w ) {
			if ( isset( $out[ $w['id'] ] ) ) {
				continue;
			}
			$cfg    = $w['config'];
			$inline = in_array( (int) $w['id'], $inline_ids, true );
			if ( ! $inline ) {
				if ( 'inline' === $cfg['display']['mode'] || $cfg['advanced']['shortcode_only'] ) {
					continue;
				}
				if ( $cfg['display']['devices'] && ! in_array( $device, $cfg['display']['devices'], true ) ) {
					continue;
				}
				if ( ! self::page_matches( $w, $ctx ) ) {
					continue;
				}
			}
			if ( ! Eligibility::is_open( $w ) ) {
				continue;
			}
			if ( ! Conditions::passes( $cfg['targeting']['audience'], $ctx ) ) {
				continue;
			}
			$w['inline'] = $inline;
			if ( ! $inline && '' !== (string) $w['ab_group'] ) {
				$groups[ $w['ab_group'] ][] = $w;
				continue;
			}
			$out[ $w['id'] ] = $w;
		}
		// A/B: one wheel per group, sticky per device.
		foreach ( $groups as $g => $list ) {
			$total = 0;
			foreach ( $list as $w ) {
				$total += (int) $w['config']['advanced']['ab_weight'];
			}
			$seed = hexdec( substr( md5( $g . '|' . ( '' !== $ctx->device_id ? $ctx->device_id : $ctx->ip ) ), 0, 7 ) ) % max( 1, $total );
			$acc  = 0;
			foreach ( $list as $w ) {
				$acc += (int) $w['config']['advanced']['ab_weight'];
				if ( $seed < $acc ) {
					$w['ab']         = $g;
					$out[ $w['id'] ] = $w;
					break;
				}
			}
		}
		uasort(
			$out,
			static function ( $a, $b ) {
				return ( $a['priority'] <=> $b['priority'] ) ?: ( $a['id'] <=> $b['id'] );
			}
		);
		return array_values( $out );
	}

	/** Config without any server-only data (odds, stock, codes, rules…). */
	public static function public_config( array $wheel ) {
		$c      = $wheel['config'];
		$slices = array();
		foreach ( $c['slices'] as $s ) {
			$slices[] = array(
				'id'        => $s['id'],
				'label'     => $s['label'],
				'sublabel'  => $s['sublabel'],
				'color'     => $s['color'],
				'color2'    => $s['color2'],
				'text_color' => $s['text_color'],
				'icon'      => $s['icon'],
				'image'     => $s['image'],
				'image_size' => (int) $s['image_size'],
				'highlight' => (bool) $s['highlight'],
				'hidden_label' => (bool) $s['hidden_label'],
			);
		}
		$fields = array();
		foreach ( $c['form']['fields'] as $f ) {
			if ( $f['enabled'] ) {
				$fields[] = $f;
			}
		}
		$form           = $c['form'];
		$form['fields'] = $fields;
		$popup          = $c['popup'];
		$popup['countdown_ts'] = 'fixed' === $popup['countdown_mode'] && '' !== $popup['countdown_deadline'] ? Eligibility::local_ts( $popup['countdown_deadline'] ) : 0;
		return array(
			'id'       => (int) $wheel['id'],
			'title'    => $wheel['title'],
			'lang'     => $c['lang'],
			'slices'   => $slices,
			'design'   => $c['design'],
			'popup'    => $popup,
			'form'     => $form,
			'display'  => $c['display'],
			'messages' => $c['messages'],
			'layout'   => (object) ( $c['layout'] ?? array() ),
			'responsive' => array(
				'tablet' => (object) ( $c['responsive']['tablet'] ?? array() ),
				'mobile' => (object) ( $c['responsive']['mobile'] ?? array() ),
			),
			'access'   => array(
				'mode'          => $c['access']['mode'],
				'require_login' => (bool) $c['access']['require_login'],
				'require_otp'   => (bool) ( $c['access']['require_otp'] || $c['form']['phone_otp'] ),
				'how_to_earn'   => (bool) $c['access']['show_how_to_earn'],
			),
			'advanced' => array(
				'track_ga'    => (bool) $c['advanced']['track_ga'],
				'track_pixel' => (bool) $c['advanced']['track_pixel'],
				'inline_autoload' => (bool) $c['advanced']['inline_autoload'],
			),
		);
	}

	/** Everything the browser needs for one wheel. */
	public static function boot_wheel( array $w, Context $ctx ) {
		$elig  = Eligibility::check( $w, $ctx );
		$cfg   = $w['config'];
		$out   = self::public_config( $w );
		$out['state']   = SpinService::public_state( $w, $elig );
		$out['inline']  = ! empty( $w['inline'] );
		$out['preview'] = ! empty( $w['preview'] );
		$out['ab']      = $w['ab'] ?? '';
		if ( $cfg['popup']['social_proof'] ) {
			$out['social'] = Stats::spins_today( $w['id'] );
		}
		if ( $cfg['popup']['ticker'] ) {
			$out['winners'] = Stats::recent_winners( $w['id'], (int) $cfg['popup']['ticker_count'] );
		}
		if ( $cfg['access']['show_how_to_earn'] && 'free' !== $cfg['access']['mode'] ) {
			$hints        = Helpers::lines( $cfg['access']['earn_hint'] );
			$out['earn'] = $hints ? $hints : Rules::earn_hints( $w['id'] );
		}
		if ( 'credit' === $elig['via'] || $elig['credits'] > 0 ) {
			$out['state']['credits'] = (int) $elig['credits'];
		}
		if ( becharkhoon()->settings->get( 'referral_enabled' ) && $ctx->user_id ) {
			$out['ref_link'] = add_query_arg( becharkhoon()->settings->get( 'referral_param' ), Rules::ref_code( $ctx->user_id ), home_url( '/' ) );
		}
		$out['login_url'] = '' !== $cfg['form']['login_url'] ? $cfg['form']['login_url'] : ( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : wp_login_url() );
		return $out;
	}

	/** Prefill values for logged-in visitors. */
	public static function prefill( Context $ctx ) {
		if ( ! $ctx->user_id ) {
			return array();
		}
		$u    = get_userdata( $ctx->user_id );
		$name = trim( get_user_meta( $ctx->user_id, 'first_name', true ) . ' ' . get_user_meta( $ctx->user_id, 'last_name', true ) );
		return array(
			'name'  => '' !== $name ? $name : ( $u ? $u->display_name : '' ),
			'email' => $u ? $u->user_email : '',
			'phone' => $ctx->phone,
		);
	}

	/**
	 * The link sent to people for this wheel (SMS / email / bulk): the wheel's own page if the admin set one
	 * (e.g. the page holding its shortcode), else the home page with ?bch-open=ID which opens the popup.
	 */
	public static function wheel_url( $wheel ) {
		$param = (string) becharkhoon()->settings->get( 'open_param' );
		if ( ! is_array( $wheel ) ) {
			return home_url( '/' );
		}
		$adv = $wheel['config']['advanced'] ?? array();
		if ( ! empty( $adv['landing_url'] ) ) {
			$url = (string) $adv['landing_url'];
			return ! empty( $adv['landing_open'] ) ? add_query_arg( $param, (int) $wheel['id'], $url ) : $url;
		}
		return add_query_arg( $param, (int) $wheel['id'], home_url( '/' ) );
	}

	public static function lang_for( array $wheel ) {
		Lang::use_site_locale( $wheel['config']['lang'] );
	}
}
