<?php
/**
 * SMS gateway registry + adapter over the Iranian panel drivers (sms-drivers.php):
 * 26 connections covering 60+ brands, plain text and pattern/template sending,
 * balance check, step-by-step guides, encrypted credentials per panel.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Notify;

use Becharkhoon\Core\Crypto;
use Becharkhoon\Core\Helpers;

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/sms-drivers.php';

final class SmsGateways {

	/** @var array<string,\BCH_SMS_Driver>|null */
	private static $drivers = null;

	public static function families() {
		return array(
			'main'     => array( 'سامانه‌های اصلی (REST)', 'Main providers (REST)' ),
			'reseller' => array( 'سایر سامانه‌ها و نمایندگی‌ها', 'Other providers & resellers' ),
			'soap'     => array( 'سامانه‌های مبتنی بر SOAP / وب‌سرویس قدیمی', 'SOAP / legacy web services' ),
			'custom'   => array( 'اتصال دستی', 'Manual connection' ),
		);
	}

	/** @return array<string,\BCH_SMS_Driver> */
	public static function drivers() {
		if ( null === self::$drivers ) {
			$classes = array(
				'Smsir', 'IPPanel', 'Faraz', 'Kavenegar', 'Melipayamak', 'Melipayamak_Console', 'Ghasedak', 'Magfa', 'IPPanel_Legacy',
				'Trez', 'Sabanovin', 'Asanak', 'Payamresan', 'Sms18', 'Sunway', 'Isms', 'Logistic',
				'PayamakPanel_Soap', 'IPPanel_Soap', 'SendSmsAsmx', 'SmsServicePhp', 'HiroSoap', 'ParsGreen', '0098', 'Candoo',
				'Generic',
			);
			$list = array();
			foreach ( $classes as $c ) {
				$cls = 'BCH_SMS_Driver_' . $c;
				if ( class_exists( $cls ) ) {
					$list[] = new $cls();
				}
			}
			/**
			 * Add custom drivers (instances of BCH_SMS_Driver).
			 */
			$list          = apply_filters( 'becharkhoon_sms_drivers', $list );
			self::$drivers = array();
			foreach ( $list as $d ) {
				if ( $d instanceof \BCH_SMS_Driver ) {
					self::$drivers[ $d->id ] = $d;
				}
			}
		}
		return self::$drivers;
	}

	public static function driver( $id ) {
		$d = self::drivers();
		return isset( $d[ $id ] ) ? $d[ $id ] : null;
	}

	/** Catalog for the admin UI (no secrets). */
	public static function catalog() {
		$out = array();
		foreach ( self::drivers() as $id => $d ) {
			$fields = array();
			foreach ( $d->fields() as $k => $f ) {
				$fields[ $k ] = array(
					'label'   => $f[0],
					'type'    => $f[1],
					'help'    => $f[2] ?? '',
					'options' => $f[3] ?? null,
				);
			}
			$out[ $id ] = array(
				'name'         => $d->label,
				'family'       => $d->family,
				'site'         => $d->site,
				'brands'       => $d->brands,
				'pattern'      => $d->pattern,
				'soap'         => (bool) $d->soap,
				'soap_ok'      => class_exists( 'SoapClient' ),
				'fields'       => $fields,
				'guide'        => $d->guide(),
				'pattern_help' => $d->pattern_help(),
				'marker'       => self::marker( $id, $d->pattern ),
			);
		}
		return $out;
	}

	/**
	 * How variables are written inside a pattern on that panel ("{}" = the name).
	 * Used to suggest the exact pattern text to register and to detect variables in a pasted pattern.
	 */
	public static function marker( $id, $style ) {
		$map = array(
			'smsir'               => '#{}#',
			'melipayamak'         => '{{}}',
			'melipayamak_console' => '{{}}',
			'kavenegar'           => '%{}%',
		);
		if ( isset( $map[ $id ] ) ) {
			return $map[ $id ];
		}
		return 'positional' === $style ? '{{}}' : '%{}%';
	}

	/** Field keys stored encrypted (type "password"). */
	public static function secret_fields( $id ) {
		$d = self::driver( $id );
		if ( ! $d ) {
			return array();
		}
		$out = array();
		foreach ( $d->fields() as $k => $f ) {
			if ( 'password' === $f[1] ) {
				$out[] = $k;
			}
		}
		return $out;
	}

	/** Decrypted config of a driver (memory only). */
	public static function config( $id ) {
		$all = (array) becharkhoon()->settings->get( 'sms_fields' );
		$cfg = isset( $all[ $id ] ) && is_array( $all[ $id ] ) ? $all[ $id ] : array();
		foreach ( self::secret_fields( $id ) as $k ) {
			if ( isset( $cfg[ $k ] ) ) {
				$cfg[ $k ] = Crypto::decrypt( $cfg[ $k ] );
			}
		}
		return $cfg;
	}

	private static function out( $r ) {
		$ok  = ! empty( $r['ok'] );
		$raw = isset( $r['response'] ) ? ( is_string( $r['response'] ) ? $r['response'] : wp_json_encode( $r['response'], JSON_UNESCAPED_UNICODE ) ) : '';
		return array( 'ok' => $ok, 'error' => $ok ? '' : ( '' !== $raw ? mb_substr( wp_strip_all_tags( $raw ), 0, 200 ) : 'failed' ), 'raw' => mb_substr( (string) $raw, 0, 800 ) );
	}

	/**
	 * Plain text SMS.
	 *
	 * @param string $id  Driver id.
	 * @param array  $cfg Driver config (decrypted); empty = stored config.
	 */
	public static function send( $id, array $cfg, $to, $text ) {
		$d  = self::driver( $id );
		$to = Helpers::phone( $to );
		if ( ! $d ) {
			return array( 'ok' => false, 'error' => 'no gateway', 'raw' => '' );
		}
		if ( '' === $to ) {
			return array( 'ok' => false, 'error' => 'invalid mobile', 'raw' => '' );
		}
		$cfg = $cfg ? $cfg : self::config( $id );
		try {
			$res = $d->send( array( array( 'mobile' => $to, 'text' => (string) $text ) ), $cfg );
			return self::out( $res[0] ?? array( 'ok' => false, 'response' => 'empty' ) );
		} catch ( \Throwable $e ) {
			return array( 'ok' => false, 'error' => $e->getMessage(), 'raw' => '' );
		}
	}

	/**
	 * Pattern / template SMS. $vars keeps the admin's order (positional drivers use it).
	 */
	public static function pattern( $id, array $cfg, $to, $code, array $vars ) {
		$d  = self::driver( $id );
		$to = Helpers::phone( $to );
		if ( ! $d ) {
			return array( 'ok' => false, 'error' => 'no gateway', 'raw' => '' );
		}
		if ( '' === $to || '' === trim( (string) $code ) ) {
			return array( 'ok' => false, 'error' => 'invalid mobile or pattern', 'raw' => '' );
		}
		$cfg = $cfg ? $cfg : self::config( $id );
		if ( ! $d->pattern ) {
			// No pattern support on this panel: send the values as plain text instead.
			return self::send( $id, $cfg, $to, implode( "\n", array_map( 'strval', array_values( $vars ) ) ) );
		}
		try {
			return self::out( $d->send_pattern( $to, (string) $code, $vars, $cfg ) );
		} catch ( \Throwable $e ) {
			return array( 'ok' => false, 'error' => $e->getMessage(), 'raw' => '' );
		}
	}

	/** Panel balance (string) or WP_Error. */
	public static function credit( $id ) {
		$d = self::driver( $id );
		if ( ! $d ) {
			return new \WP_Error( 'bch_sms', 'no gateway' );
		}
		try {
			return $d->credit( self::config( $id ) );
		} catch ( \Throwable $e ) {
			return new \WP_Error( 'bch_sms', $e->getMessage() );
		}
	}

	/** Parse "name=value" lines into an ordered map and render placeholders. */
	public static function pattern_vars( $lines, array $vars ) {
		$out = array();
		foreach ( preg_split( '/[\r\n]+/', (string) $lines ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || false === strpos( $line, '=' ) ) {
				continue;
			}
			list( $k, $v ) = array_map( 'trim', explode( '=', $line, 2 ) );
			if ( '' !== $k ) {
				$val       = Helpers::tpl( $v, $vars );
				$out[ $k ] = '' !== $val ? $val : '-';
			}
		}
		return $out;
	}
}
