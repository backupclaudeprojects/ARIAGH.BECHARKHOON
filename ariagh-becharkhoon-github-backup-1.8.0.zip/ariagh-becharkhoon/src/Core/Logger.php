<?php
/**
 * Persistent log for SMS / email / webhooks / errors (visible in the admin).
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Core;

defined( 'ABSPATH' ) || exit;

final class Logger {

	/**
	 * @param string $channel sms|email|webhook|messenger|system|admin|security.
	 * @param string $level   info|ok|warn|error.
	 * @param string $message Human message.
	 * @param array  $context Extra data (secrets must already be stripped).
	 */
	public static function log( $channel, $level, $message, array $context = array() ) {
		global $wpdb;
		$wpdb->insert(
			$wpdb->prefix . 'bch_log',
			array(
				'channel'    => substr( (string) $channel, 0, 20 ),
				'level'      => substr( (string) $level, 0, 10 ),
				'message'    => mb_substr( (string) $message, 0, 2000 ),
				'context'    => $context ? wp_json_encode( self::scrub( $context ), JSON_UNESCAPED_UNICODE ) : null,
				'created_at' => Helpers::now(),
			)
		);
	}

	/** Remove anything that looks like a credential before storing it. */
	public static function scrub( $data ) {
		if ( is_array( $data ) ) {
			foreach ( $data as $k => $v ) {
				if ( is_string( $k ) && preg_match( '/(key|pass|token|secret|authorization)/i', $k ) ) {
					$data[ $k ] = '***';
				} else {
					$data[ $k ] = self::scrub( $v );
				}
			}
			return $data;
		}
		if ( is_string( $data ) && strlen( $data ) > 4000 ) {
			return substr( $data, 0, 4000 ) . '…';
		}
		return $data;
	}

	public static function query( $args ) {
		global $wpdb;
		$t      = $wpdb->prefix . 'bch_log';
		$where  = '1=1';
		$params = array();
		if ( ! empty( $args['channel'] ) ) {
			$where   .= ' AND channel = %s';
			$params[] = $args['channel'];
		}
		if ( ! empty( $args['level'] ) ) {
			$where   .= ' AND level = %s';
			$params[] = $args['level'];
		}
		$per    = max( 1, min( 200, (int) ( $args['per_page'] ?? 50 ) ) );
		$page   = max( 1, (int) ( $args['page'] ?? 1 ) );
		$total  = (int) $wpdb->get_var( $params ? $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE $where", $params ) : "SELECT COUNT(*) FROM $t WHERE $where" ); // phpcs:ignore
		$params[] = $per;
		$params[] = ( $page - 1 ) * $per;
		$rows   = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $t WHERE $where ORDER BY id DESC LIMIT %d OFFSET %d", $params ), ARRAY_A ); // phpcs:ignore
		foreach ( $rows as &$r ) {
			$r['context'] = $r['context'] ? json_decode( $r['context'], true ) : null;
		}
		return array( 'items' => $rows, 'total' => $total );
	}
}
