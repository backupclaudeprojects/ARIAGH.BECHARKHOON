<?php
/**
 * Wheels persistence (custom table) + stock / code-pool synchronisation.
 *
 * @package Becharkhoon
 */

namespace Becharkhoon\Wheels;

use Becharkhoon\Core\Helpers;

defined( 'ABSPATH' ) || exit;

final class Repository {

	const CACHE_KEY = 'bch_active_wheels_v1';

	/** @var array<int,array> */
	private $loaded = array();

	private function table() {
		global $wpdb;
		return $wpdb->prefix . 'bch_wheels';
	}

	private function hydrate_row( $row ) {
		if ( ! $row ) {
			return null;
		}
		$row             = (array) $row;
		$row['id']       = (int) $row['id'];
		$row['priority'] = (int) $row['priority'];
		$stored          = Helpers::json_decode_array( $row['config'] );
		$lang            = $stored['lang'] ?? 'auto';
		$is_fa           = 'fa' === $lang ? true : ( 'en' === $lang ? false : 0 === strpos( (string) get_locale(), 'fa' ) );
		$row['config']   = Schema::hydrate( $stored, $is_fa );
		return $row;
	}

	public function get( $id ) {
		global $wpdb;
		$id = (int) $id;
		if ( ! isset( $this->loaded[ $id ] ) ) {
			$this->loaded[ $id ] = $this->hydrate_row( $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table()} WHERE id = %d", $id ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}
		return $this->loaded[ $id ];
	}

	/** Lightweight list for the admin. */
	public function all() {
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT * FROM {$this->table()} ORDER BY priority ASC, id DESC" ); // phpcs:ignore
		return array_map( array( $this, 'hydrate_row' ), (array) $rows );
	}

	/** Active wheels (cached; invalidated on every save). */
	public function active() {
		$cached = wp_cache_get( self::CACHE_KEY, 'bch' );
		if ( false === $cached ) {
			$cached = get_transient( self::CACHE_KEY );
		}
		if ( false === $cached || ! is_array( $cached ) ) {
			global $wpdb;
			$rows   = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table()} WHERE status = %s ORDER BY priority ASC, id ASC", 'active' ) ); // phpcs:ignore
			$cached = array_map( array( $this, 'hydrate_row' ), (array) $rows );
			set_transient( self::CACHE_KEY, $cached, HOUR_IN_SECONDS );
			wp_cache_set( self::CACHE_KEY, $cached, 'bch', HOUR_IN_SECONDS );
		}
		return $cached;
	}

	public function flush() {
		delete_transient( self::CACHE_KEY );
		wp_cache_delete( self::CACHE_KEY, 'bch' );
		$this->loaded = array();
		do_action( 'becharkhoon_wheels_changed' );
	}

	/**
	 * Create a wheel.
	 *
	 * @param string $title  Title.
	 * @param array  $config Sanitized config.
	 * @param string $status Status.
	 */
	public function create( $title, array $config, $status = 'draft' ) {
		global $wpdb;
		$now = Helpers::now();
		$wpdb->insert(
			$this->table(),
			array(
				'title'      => mb_substr( sanitize_text_field( $title ), 0, 190 ),
				'status'     => in_array( $status, array( 'active', 'draft', 'paused' ), true ) ? $status : 'draft',
				'priority'   => 10,
				'config'     => wp_json_encode( $config, JSON_UNESCAPED_UNICODE ),
				'created_at' => $now,
				'updated_at' => $now,
			)
		);
		$id = (int) $wpdb->insert_id;
		if ( $id ) {
			$this->after_save( $id, $config );
		}
		return $id;
	}

	/**
	 * Update fields of a wheel.
	 *
	 * @param int   $id   Id.
	 * @param array $data title/status/priority/ab_group/config.
	 */
	public function update( $id, array $data ) {
		global $wpdb;
		$row = array( 'updated_at' => Helpers::now() );
		if ( isset( $data['title'] ) ) {
			$row['title'] = mb_substr( sanitize_text_field( $data['title'] ), 0, 190 );
		}
		if ( isset( $data['status'] ) && in_array( $data['status'], array( 'active', 'draft', 'paused' ), true ) ) {
			$row['status'] = $data['status'];
		}
		if ( isset( $data['priority'] ) ) {
			$row['priority'] = (int) $data['priority'];
		}
		if ( isset( $data['ab_group'] ) ) {
			$row['ab_group'] = sanitize_key( $data['ab_group'] );
		}
		if ( isset( $data['config'] ) && is_array( $data['config'] ) ) {
			$row['config'] = wp_json_encode( $data['config'], JSON_UNESCAPED_UNICODE );
		}
		$ok = false !== $wpdb->update( $this->table(), $row, array( 'id' => (int) $id ) );
		if ( $ok && isset( $data['config'] ) ) {
			$this->after_save( (int) $id, $data['config'] );
		} else {
			$this->flush();
		}
		return $ok;
	}

	public function delete( $id ) {
		global $wpdb;
		$id = (int) $id;
		$wpdb->delete( $this->table(), array( 'id' => $id ) );
		$wpdb->delete( $wpdb->prefix . 'bch_stock', array( 'wheel_id' => $id ) );
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}bch_codes WHERE wheel_id = %d AND spin_id = 0", $id ) );
		$this->flush();
	}

	public function duplicate( $id ) {
		$w = $this->get( $id );
		if ( ! $w ) {
			return 0;
		}
		$cfg = $w['config'];
		foreach ( $cfg['slices'] as &$s ) {
			$s['codes_text'] = '';
		}
		unset( $s );
		$new = $this->create( $w['title'] . ' (copy)', $cfg, 'draft' );
		return $new;
	}

	/** Keep stock rows and code pools in sync with the config; strip imported codes from it. */
	private function after_save( $id, array $config ) {
		global $wpdb;
		$stock_t = $wpdb->prefix . 'bch_stock';
		$keep    = array();
		$changed = false;
		foreach ( $config['slices'] as $i => $s ) {
			$sid = (string) $s['id'];
			if ( (int) $s['stock'] >= 0 ) {
				$keep[] = $sid;
				$exists = $wpdb->get_var( $wpdb->prepare( "SELECT total FROM $stock_t WHERE wheel_id = %d AND slice_id = %s", $id, $sid ) ); // phpcs:ignore
				if ( null === $exists ) {
					$wpdb->insert( $stock_t, array( 'wheel_id' => $id, 'slice_id' => $sid, 'total' => (int) $s['stock'], 'won' => 0 ) );
				} elseif ( (int) $exists !== (int) $s['stock'] ) {
					$wpdb->update( $stock_t, array( 'total' => (int) $s['stock'] ), array( 'wheel_id' => $id, 'slice_id' => $sid ) );
				}
			}
			if ( 'code_pool' === $s['type'] && '' !== trim( (string) $s['codes_text'] ) ) {
				\Becharkhoon\Prizes\CodePool::import( $id, $sid, $s['codes_text'] );
				$config['slices'][ $i ]['codes_text'] = '';
				$changed                              = true;
			}
		}
		if ( $keep ) {
			$in = implode( ',', array_fill( 0, count( $keep ), '%s' ) );
			$wpdb->query( $wpdb->prepare( "DELETE FROM $stock_t WHERE wheel_id = %d AND slice_id NOT IN ($in)", array_merge( array( $id ), $keep ) ) ); // phpcs:ignore
		} else {
			$wpdb->delete( $stock_t, array( 'wheel_id' => $id ) );
		}
		if ( $changed ) {
			$wpdb->update( $this->table(), array( 'config' => wp_json_encode( $config, JSON_UNESCAPED_UNICODE ) ), array( 'id' => $id ) );
		}
		$this->flush();
	}

	/** Stock state per slice: slice_id => [total, won, left]. */
	public function stock( $wheel_id ) {
		global $wpdb;
		$out = array();
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT slice_id, total, won FROM {$wpdb->prefix}bch_stock WHERE wheel_id = %d", $wheel_id ), ARRAY_A ) as $r ) {
			$out[ $r['slice_id'] ] = array( 'total' => (int) $r['total'], 'won' => (int) $r['won'], 'left' => max( 0, (int) $r['total'] - (int) $r['won'] ) );
		}
		return $out;
	}

	/** Atomically take one unit of stock. */
	public function take_stock( $wheel_id, $slice_id ) {
		global $wpdb;
		return (bool) $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}bch_stock SET won = won + 1 WHERE wheel_id = %d AND slice_id = %s AND won < total", $wheel_id, $slice_id ) );
	}

	public function give_back_stock( $wheel_id, $slice_id ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}bch_stock SET won = won - 1 WHERE wheel_id = %d AND slice_id = %s AND won > 0", $wheel_id, $slice_id ) );
	}

	public function reset_stock( $wheel_id ) {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}bch_stock SET won = 0 WHERE wheel_id = %d", $wheel_id ) );
	}
}
