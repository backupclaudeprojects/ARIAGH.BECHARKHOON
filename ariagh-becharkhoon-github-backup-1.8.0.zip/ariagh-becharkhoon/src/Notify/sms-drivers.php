<?php
/**
 * Iranian SMS gateway drivers (ported from ARIAGH.VISITOR 2.1 — same APIs, patterns and guides).
 *
 * @package Becharkhoon
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'BCH_SMS_Driver' ) ) {
	return;
}

/**
 * SMS gateway drivers for Iranian SMS panels.
 *
 * Normal send: send( [ [ 'mobile' => '09..', 'text' => '..' ], ... ], $cfg ) returns
 * [ [ 'ok' => bool, 'response' => string ], ... ] in the same order.
 * Pattern (template / service line) send: send_pattern( '09..', $code, [ param => value ], $cfg ).
 *
 * Sources: each provider's official developer documentation and its maintained official / open-source SDKs.
 */
abstract class BCH_SMS_Driver {
	public $id      = '';
	public $label   = '';
	public $family  = 'main';   // main | reseller | soap | custom.
	public $site    = '';
	public $brands  = array();  // Other brands that use the same platform/API.
	public $pattern = false;    // false | 'named' | 'positional' | 'tokens'.
	public $soap    = false;

	/** key => [ label, type text|password|select|textarea|url, help, options ]. password = stored encrypted. */
	abstract public function fields();

	abstract public function send( array $messages, array $cfg );

	/** Step-by-step setup guide (HTML, Persian). */
	abstract public function guide();

	public function send_pattern( $mobile, $code, array $params, array $cfg ) {
		return array( 'ok' => false, 'response' => 'این سامانه ارسال الگو (پترن) را پشتیبانی نمی‌کند.' );
	}

	public function credit( array $cfg ) {
		return new WP_Error( 'bch_na', 'این سامانه استعلام اعتبار را پشتیبانی نمی‌کند.' );
	}

	public function batch_size() {
		return 1;
	}

	/** Help for the pattern parameter mapping box. */
	public function pattern_help() {
		return '';
	}

	/* ---------------- helpers ---------------- */

	protected function cfg( $cfg, $key, $default = '' ) {
		return isset( $cfg[ $key ] ) && '' !== trim( (string) $cfg[ $key ] ) ? trim( (string) $cfg[ $key ] ) : $default;
	}

	protected function request( $url, $args ) {
		$args = wp_parse_args( $args, array( 'timeout' => 20, 'redirection' => 2, 'user-agent' => 'ARIAGH.BECHARKHOON/' . BCH_VERSION ) );
		$res  = wp_remote_request( $url, $args );
		if ( is_wp_error( $res ) ) {
			return array( 'code' => 0, 'body' => 'خطای اتصال: ' . $res->get_error_message(), 'json' => null );
		}
		$body = (string) wp_remote_retrieve_body( $res );
		return array( 'code' => (int) wp_remote_retrieve_response_code( $res ), 'body' => $body, 'json' => json_decode( $body, true ) );
	}

	protected function json_post( $url, $data, $headers = array() ) {
		return $this->request( $url, array(
			'method'  => 'POST',
			'headers' => array_merge( array( 'Content-Type' => 'application/json', 'Accept' => 'application/json' ), $headers ),
			'body'    => wp_json_encode( $data, JSON_UNESCAPED_UNICODE ),
		) );
	}

	protected function form_post( $url, $data, $headers = array() ) {
		return $this->request( $url, array( 'method' => 'POST', 'headers' => $headers, 'body' => $data ) );
	}

	protected function soap( $wsdl ) {
		if ( ! class_exists( 'SoapClient' ) ) {
			throw new Exception( 'افزونه SOAP روی PHP هاست فعال نیست. از پشتیبانی هاست بخواهید php-soap را فعال کند.' );
		}
		return new SoapClient( $wsdl, array( 'encoding' => 'UTF-8', 'exceptions' => true, 'connection_timeout' => 20, 'cache_wsdl' => WSDL_CACHE_BOTH ) );
	}

	/** +989121234567 */
	protected function e164( $mobile ) {
		return '+98' . substr( $mobile, 1 );
	}

	/** 989121234567 */
	protected function intl( $mobile ) {
		return '98' . substr( $mobile, 1 );
	}

	protected function fill( $count, $ok, $response ) {
		return array_fill( 0, $count, array( 'ok' => (bool) $ok, 'response' => is_string( $response ) ? $response : wp_json_encode( $response, JSON_UNESCAPED_UNICODE ) ) );
	}

	protected function each( array $messages, callable $fn ) {
		$out = array();
		foreach ( $messages as $m ) {
			try {
				$out[] = $fn( $m );
			} catch ( Exception $e ) {
				$out[] = array( 'ok' => false, 'response' => $e->getMessage() );
			}
		}
		return $out;
	}

	/** Positional values: sorted by key when all keys are numbers (0,1,2…), otherwise in the order written. */
	protected function positional( array $params ) {
		$numeric = true;
		foreach ( array_keys( $params ) as $k ) {
			if ( ! is_numeric( $k ) ) {
				$numeric = false;
				break;
			}
		}
		if ( $numeric ) {
			ksort( $params, SORT_NUMERIC );
		}
		return array_values( $params );
	}

	/** Build a standard guide. */
	protected function build_guide( array $steps, $pattern = '', $notes = array() ) {
		$ip = isset( $_SERVER['SERVER_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_ADDR'] ) ) : '';
		$h  = '<ol class="bc-guide-steps">';
		foreach ( $steps as $s ) {
			$h .= '<li>' . $s . '</li>';
		}
		$h .= '</ol>';
		if ( $pattern ) {
			$h .= '<h4>ارسال با الگو (پترن / خط خدماتی)</h4>' . $pattern;
		}
		$notes[] = 'اگر پنل از شما «IP مجاز وب‌سرویس» خواست، IP سرور سایت را ثبت کنید' . ( $ip ? ': <code dir="ltr">' . esc_html( $ip ) . '</code> (اگر هاست شما IP خروجی دیگری دارد، از پشتیبانی هاست بپرسید).' : '.' );
		$notes[] = 'بعد از ذخیره، با دکمه «ارسال پیامک تست» یک پیامک به موبایل خودتان بفرستید. پاسخ خام سامانه در «گزارش ارسال» نمایش داده می‌شود.';
		$h      .= '<h4>نکات</h4><ul>';
		foreach ( $notes as $n ) {
			$h .= '<li>' . $n . '</li>';
		}
		$h .= '</ul><h4>اگر ارسال ناموفق بود (به ترتیب بررسی کنید)</h4><ol>';
		foreach ( array(
			'«پیامک و اعلان ← گزارش ارسال» را باز کنید؛ ستون «پاسخ سامانه» کد/پیام خطای خود پنل را نشان می‌دهد.',
			'<b>دسترسی وب‌سرویس:</b> در بیشتر پنل‌ها باید در پروفایل/تنظیمات حساب، گزینه «دسترسی وب‌سرویس / API» فعال باشد؛ اگر نمی‌بینید از پشتیبانی پنل بخواهید فعال کنند.',
			'<b>نام کاربری/رمز یا کلید:</b> بدون فاصله اضافه کپی کنید. در بعضی پنل‌ها رمز وب‌سرویس با رمز ورود به پنل فرق دارد.',
			'<b>شماره خط:</b> باید متعلق به همین حساب و فعال باشد؛ بدون صفر یا با پیش‌شماره همان‌طور که در پنل نوشته شده وارد کنید.',
			'<b>IP مجاز:</b> اگر در پنل محدودیت IP فعال است، IP سرور سایت را اضافه کنید.',
			'<b>اعتبار:</b> با دکمه «استعلام اعتبار پنل» مطمئن شوید شارژ کافی دارید.',
			'<b>لینک و بلک‌لیست:</b> خطوط عمومی/تبلیغاتی پیامک لینک‌دار و ارسال به شماره‌های بلک‌لیست مخابرات را رد می‌کنند؛ از خط خدماتی یا «الگو» استفاده کنید.',
		) as $t ) {
			$h .= '<li>' . $t . '</li>';
		}
		return $h . '</ol>';
	}
}

/* ====================================================================== */
/* SMS.ir — REST v1                                                         */
/* ====================================================================== */
class BCH_SMS_Driver_Smsir extends BCH_SMS_Driver {
	public $id      = 'smsir';
	public $label   = 'SMS.ir (اس‌ام‌اس دات آی‌آر)';
	public $site    = 'https://sms.ir';
	public $pattern = 'named';

	public function fields() {
		return array(
			'api_key' => array( 'کلید API (X-API-KEY)', 'password', 'از پنل sms.ir ← برنامه‌نویسان ← لیست کلیدهای API' ),
			'line'    => array( 'شماره خط ارسال', 'text', 'مثال: 30007732000000 (از منوی «خطوط من»)' ),
		);
	}

	public function batch_size() {
		return 100;
	}

	public function send( array $messages, array $cfg ) {
		$r  = $this->json_post( 'https://api.sms.ir/v1/send/likeToLike', array(
			'lineNumber'   => (int) $this->cfg( $cfg, 'line' ),
			'messageTexts' => array_values( wp_list_pluck( $messages, 'text' ) ),
			'mobiles'      => array_values( wp_list_pluck( $messages, 'mobile' ) ),
		), array( 'X-API-KEY' => $this->cfg( $cfg, 'api_key' ) ) );
		$ok = 200 === $r['code'] && isset( $r['json']['status'] ) && 1 === (int) $r['json']['status'];
		return $this->fill( count( $messages ), $ok, $r['body'] );
	}

	public function send_pattern( $mobile, $code, array $params, array $cfg ) {
		$p = array();
		foreach ( $params as $k => $v ) {
			$p[] = array( 'name' => (string) $k, 'value' => (string) $v );
		}
		$r = $this->json_post( 'https://api.sms.ir/v1/send/verify', array(
			'mobile'     => $mobile,
			'templateId' => (int) $code,
			'parameters' => $p,
		), array( 'X-API-KEY' => $this->cfg( $cfg, 'api_key' ) ) );
		return array( 'ok' => 200 === $r['code'] && isset( $r['json']['status'] ) && 1 === (int) $r['json']['status'], 'response' => $r['body'] );
	}

	public function credit( array $cfg ) {
		$r = $this->request( 'https://api.sms.ir/v1/credit', array( 'method' => 'GET', 'headers' => array( 'X-API-KEY' => $this->cfg( $cfg, 'api_key' ), 'Accept' => 'application/json' ) ) );
		return isset( $r['json']['data'] ) ? 'اعتبار: ' . $r['json']['data'] : new WP_Error( 'bch_sms', $r['body'] );
	}

	public function pattern_help() {
		return 'کد الگو = «شناسه قالب» (templateId، عدد). نام پارامترها همان نام‌هایی است که در قالب بین # نوشته‌اید، بدون #. مثال: اگر متن قالب «سلام #NAME# کد شما #CODE#» است بنویسید:<br><code>NAME={name}<br>CODE={code}</code>';
	}

	public function guide() {
		return $this->build_guide( array(
			'وارد <a href="https://app.sms.ir" target="_blank" rel="noopener">پنل sms.ir</a> شوید.',
			'از منوی <b>برنامه‌نویسان ← لیست کلیدهای API</b> یک کلید جدید بسازید (در صورت تمایل IP سرور را محدود کنید) و آن را در فیلد «کلید API» بگذارید.',
			'از منوی <b>خطوط من</b> شماره خط اختصاصی/خدماتی را کپی کنید و در «شماره خط ارسال» بگذارید.',
			'برای ارسال لینک (مثل لینک ورود پنل) از خط خدماتی یا الگو استفاده کنید؛ خطوط عمومی معمولاً لینک را مسدود می‌کنند.',
		), '<ol><li>از <b>برنامه‌نویسان ← قالب‌ها (ارسال سریع/Verify)</b> قالب جدید بسازید؛ متغیرها را بین # بنویسید، مثلاً: <code>سلام #NAME#، کد شما #CODE# است.</code></li><li>بعد از تأیید قالب، «شناسه قالب» (عدد) را در افزونه در کادر «کد الگو» بنویسید.</li><li>در «پارامترهای الگو» هر خط: نام پارامتر = متغیر افزونه؛ مثل <code>NAME={name}</code></li></ol>' );
	}
}

/* ====================================================================== */
/* IPPanel Edge                                                             */
/* ====================================================================== */
class BCH_SMS_Driver_IPPanel extends BCH_SMS_Driver {
	public $id      = 'ippanel';
	public $label   = 'IPPanel / مدیانا و پنل‌های مبتنی بر IPPanel (API جدید Edge)';
	public $site    = 'https://ippanel.com';
	public $brands  = array( 'IPPanel', 'مدیانا (Mediana)', 'مکس اس‌ام‌اس', 'پنل‌های سفید IPPanel' );
	public $pattern = 'named';

	public function fields() {
		return array(
			'api_key' => array( 'کلید دسترسی (API Key)', 'password', 'پنل ← توسعه‌دهندگان ← کلیدهای دسترسی' ),
			'line'    => array( 'شماره فرستنده', 'text', 'مثال: +983000505 یا 3000505' ),
		);
	}

	public function batch_size() {
		return 100;
	}

	protected function from( $cfg ) {
		$f = preg_replace( '/[^\d+]/', '', \Becharkhoon\Core\Helpers::latin_digits( $this->cfg( $cfg, 'line' ) ) );
		if ( $f && '+' !== $f[0] ) {
			$f = '+98' . ltrim( preg_replace( '/^(0098|98)/', '', $f ), '0' );
		}
		return $f;
	}

	protected function ok( $r ) {
		return $r['code'] >= 200 && $r['code'] < 300 && isset( $r['json']['meta']['status'] ) && true === $r['json']['meta']['status'];
	}

	public function send( array $messages, array $cfg ) {
		// peer_to_peer: a different text for each recipient in one request.
		$params = array();
		foreach ( $messages as $m ) {
			$params[] = array( 'recipients' => array( $this->e164( $m['mobile'] ) ), 'message' => $m['text'] );
		}
		$r = $this->json_post( 'https://edge.ippanel.com/v1/api/send', array(
			'sending_type' => 'peer_to_peer',
			'from_number'  => $this->from( $cfg ),
			'params'       => $params,
		), array( 'Authorization' => $this->cfg( $cfg, 'api_key' ) ) );
		return $this->fill( count( $messages ), $this->ok( $r ), $r['body'] );
	}

	public function send_pattern( $mobile, $code, array $params, array $cfg ) {
		$r = $this->json_post( 'https://edge.ippanel.com/v1/api/send', array(
			'sending_type' => 'pattern',
			'from_number'  => $this->from( $cfg ),
			'code'         => (string) $code,
			'recipients'   => array( $this->e164( $mobile ) ),
			'params'       => (object) array_map( 'strval', $params ),
		), array( 'Authorization' => $this->cfg( $cfg, 'api_key' ) ) );
		return array( 'ok' => $this->ok( $r ), 'response' => $r['body'] );
	}

	public function credit( array $cfg ) {
		$r = $this->request( 'https://edge.ippanel.com/v1/api/payment/credit/mine', array( 'method' => 'GET', 'headers' => array( 'Authorization' => $this->cfg( $cfg, 'api_key' ), 'Accept' => 'application/json' ) ) );
		return isset( $r['json']['data']['credit'] ) ? 'اعتبار: ' . number_format( (float) $r['json']['data']['credit'] ) : new WP_Error( 'bch_sms', $r['body'] );
	}

	public function pattern_help() {
		return 'کد الگو = «کد پترن» (رشته‌ای مثل t2cfmnyo0c). نام پارامترها دقیقاً همان متغیرهای داخل پترن است (بدون %). مثال برای پترن «سلام %name% کد شما %code%»:<br><code>name={name}<br>code={code}</code>';
	}

	public function guide() {
		return $this->build_guide( array(
			'وارد پنل IPPanel یا پنل نماینده (مثلاً مدیانا) شوید.',
			'از بخش <b>توسعه‌دهندگان / وب‌سرویس ← کلید دسترسی</b> یک کلید API بسازید و در «کلید دسترسی» بگذارید.',
			'شماره خطی را که به حسابتان اختصاص دارد در «شماره فرستنده» بنویسید؛ افزونه آن را خودکار به فرمت +98 تبدیل می‌کند.',
			'ارسال معمولی با روش peer_to_peer انجام می‌شود (متن جدا برای هر مشتری در یک درخواست، حداکثر ۱۰۰ پیامک در هر مرحله).',
		), '<ol><li>از بخش <b>پترن‌ها (الگوها)</b> پترن جدید بسازید و متغیرها را به شکل <code>%name%</code> بنویسید.</li><li>بعد از تأیید، «کد پترن» را در کادر «کد الگو» بگذارید.</li><li>در «پارامترهای الگو» برای هر متغیر یک خط بنویسید: <code>name={name}</code></li><li>در پترن فقط یک گیرنده در هر درخواست مجاز است؛ افزونه این را خودش رعایت می‌کند.</li></ol>' );
	}
}

/* ====================================================================== */
/* Faraz SMS (IranPayamak API)                                              */
/* ====================================================================== */
class BCH_SMS_Driver_Faraz extends BCH_SMS_Driver {
	public $id      = 'farazsms';
	public $label   = 'فراز اس‌ام‌اس / ایران پیامک (API جدید)';
	public $site    = 'https://farazsms.com';
	public $pattern = 'named';

	public function fields() {
		return array(
			'api_key' => array( 'کلید API (Api-Key)', 'password', 'پنل ← وب‌سرویس ← کلید API' ),
			'line'    => array( 'شماره خط ارسال', 'text', 'مثال: 3000505 یا 50002178584000' ),
		);
	}

	protected function headers( $cfg ) {
		return array( 'Api-Key' => $this->cfg( $cfg, 'api_key' ) );
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$r = $this->json_post( 'https://api.iranpayamak.com/ws/v1/sms/simple', array(
				'text'          => $m['text'],
				'line_number'   => $this->cfg( $cfg, 'line' ),
				'recipients'    => array( $m['mobile'] ),
				'number_format' => 'english',
			), $this->headers( $cfg ) );
			return array( 'ok' => isset( $r['json']['status'] ) && 'success' === $r['json']['status'], 'response' => $r['body'] );
		} );
	}

	public function send_pattern( $mobile, $code, array $params, array $cfg ) {
		$r = $this->json_post( 'https://api.iranpayamak.com/ws/v1/sms/pattern', array(
			'code'          => (string) $code,
			'attributes'    => (object) array_map( 'strval', $params ),
			'recipient'     => $mobile,
			'line_number'   => $this->cfg( $cfg, 'line' ),
			'number_format' => 'english',
		), $this->headers( $cfg ) );
		return array( 'ok' => isset( $r['json']['status'] ) && 'success' === $r['json']['status'], 'response' => $r['body'] );
	}

	public function credit( array $cfg ) {
		$r = $this->request( 'https://api.iranpayamak.com/ws/v1/account/balance', array( 'method' => 'GET', 'headers' => array_merge( $this->headers( $cfg ), array( 'Accept' => 'application/json' ) ) ) );
		return isset( $r['json']['data']['balance_amount'] ) ? 'اعتبار: ' . $r['json']['data']['balance_amount'] : new WP_Error( 'bch_sms', $r['body'] );
	}

	public function pattern_help() {
		return 'کد الگو = کد پترن تأییدشده. نام پارامترها همان نام متغیرهای داخل پترن است. مثال: <code>name={name}<br>code={code}</code>';
	}

	public function guide() {
		return $this->build_guide( array(
			'وارد پنل فراز اس‌ام‌اس شوید.',
			'از بخش <b>وب‌سرویس / توسعه‌دهندگان</b> کلید API بسازید و در «کلید API» قرار دهید.',
			'شماره خط فعال حساب را در «شماره خط ارسال» بنویسید.',
			'اگر پنل شما هنوز نسخه قدیمی IPPanel است، گزینه «IPPanel (API جدید Edge)» یا «IPPanel (REST قدیمی)» را امتحان کنید.',
		), '<ol><li>در بخش <b>پترن‌ها</b> الگو بسازید و متغیرها را تعریف کنید.</li><li>کد پترن را در «کد الگو» بگذارید و پارامترها را به شکل <code>name={name}</code> نگاشت کنید.</li></ol>' );
	}
}

/* ====================================================================== */
/* IPPanel legacy REST                                                     */
/* ====================================================================== */
class BCH_SMS_Driver_IPPanel_Legacy extends BCH_SMS_Driver {
	public $id      = 'ippanel_legacy';
	public $label   = 'IPPanel / فراز (API قدیمی REST با AccessKey)';
	public $family  = 'reseller';
	public $pattern = 'named';

	public function fields() {
		return array(
			'api_key' => array( 'AccessKey', 'password', 'کلید دسترسی پنل قدیمی' ),
			'line'    => array( 'شماره فرستنده', 'text', 'مثال: +983000505' ),
		);
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$r = $this->json_post( 'https://rest.ippanel.com/v1/messages', array( 'originator' => $this->cfg( $cfg, 'line' ), 'recipients' => array( $this->intl( $m['mobile'] ) ), 'message' => $m['text'] ), array( 'Authorization' => 'AccessKey ' . $this->cfg( $cfg, 'api_key' ) ) );
			return array( 'ok' => $r['code'] >= 200 && $r['code'] < 300 && isset( $r['json']['status'] ) && 'OK' === $r['json']['status'], 'response' => $r['body'] );
		} );
	}

	public function send_pattern( $mobile, $code, array $params, array $cfg ) {
		$r = $this->json_post( 'https://rest.ippanel.com/v1/messages/patterns/send', array( 'pattern_code' => (string) $code, 'originator' => $this->cfg( $cfg, 'line' ), 'recipient' => $this->intl( $mobile ), 'values' => (object) array_map( 'strval', $params ) ), array( 'Authorization' => 'AccessKey ' . $this->cfg( $cfg, 'api_key' ) ) );
		return array( 'ok' => $r['code'] >= 200 && $r['code'] < 300 && isset( $r['json']['status'] ) && 'OK' === $r['json']['status'], 'response' => $r['body'] );
	}

	public function pattern_help() {
		return 'کد الگو = pattern_code. پارامترها = نام متغیرهای پترن. مثال: <code>name={name}</code>';
	}

	public function guide() {
		return $this->build_guide( array( 'فقط برای حساب‌های قدیمی IPPanel که هنوز AccessKey دارند.', 'AccessKey را از بخش وب‌سرویس پنل بردارید.', 'برای حساب‌های جدید از گزینه «IPPanel (API جدید Edge)» استفاده کنید.' ) );
	}
}

/* ====================================================================== */
/* Kavenegar                                                               */
/* ====================================================================== */
class BCH_SMS_Driver_Kavenegar extends BCH_SMS_Driver {
	public $id      = 'kavenegar';
	public $label   = 'کاوه‌نگار (Kavenegar)';
	public $site    = 'https://kavenegar.com';
	public $brands  = array( 'کاوه‌نگار', 'پنل‌های نماینده با API کاوه‌نگار' );
	public $pattern = 'tokens';

	public function fields() {
		return array(
			'api_key' => array( 'API Key', 'password', 'پنل کاوه‌نگار ← تنظیمات ← حساب کاربری' ),
			'line'    => array( 'شماره خط ارسال', 'text', 'مثال: 10004346 (خالی = خط پیش‌فرض حساب)' ),
			'space'   => array( 'جایگزین فاصله در توکن‌ها', 'select', 'در token، token2 و token3 فاصله مجاز نیست', array( 'zwnj' => 'نیم‌فاصله', 'underscore' => 'زیرخط (_)' ) ),
		);
	}

	public function batch_size() {
		return 100;
	}

	protected function base( $cfg ) {
		return 'https://api.kavenegar.com/v1/' . rawurlencode( $this->cfg( $cfg, 'api_key' ) ) . '/';
	}

	protected function ok( $r ) {
		return isset( $r['json']['return']['status'] ) && 200 === (int) $r['json']['return']['status'];
	}

	public function send( array $messages, array $cfg ) {
		$line = $this->cfg( $cfg, 'line' );
		$body = array(
			'receptor' => wp_json_encode( array_values( wp_list_pluck( $messages, 'mobile' ) ) ),
			'message'  => wp_json_encode( array_values( wp_list_pluck( $messages, 'text' ) ), JSON_UNESCAPED_UNICODE ),
		);
		if ( $line ) {
			$body['sender'] = wp_json_encode( array_fill( 0, count( $messages ), $line ) );
		}
		$r = $this->form_post( $this->base( $cfg ) . 'sms/sendarray.json', $body );
		return $this->fill( count( $messages ), $this->ok( $r ), $r['body'] );
	}

	public function send_pattern( $mobile, $code, array $params, array $cfg ) {
		$space = 'underscore' === $this->cfg( $cfg, 'space', 'zwnj' ) ? '_' : "\xE2\x80\x8C";
		$body  = array( 'receptor' => $mobile, 'template' => (string) $code );
		foreach ( array( 'token', 'token2', 'token3', 'token10', 'token20' ) as $t ) {
			if ( isset( $params[ $t ] ) && '' !== (string) $params[ $t ] ) {
				$v          = (string) $params[ $t ];
				$body[ $t ] = in_array( $t, array( 'token', 'token2', 'token3' ), true ) ? preg_replace( '/\s+/u', $space, trim( $v ) ) : $v;
			}
		}
		if ( ! isset( $body['token'] ) ) {
			return array( 'ok' => false, 'response' => 'در الگوی کاوه‌نگار پارامتر token الزامی است.' );
		}
		$r = $this->form_post( $this->base( $cfg ) . 'verify/lookup.json', $body );
		return array( 'ok' => $this->ok( $r ), 'response' => $r['body'] );
	}

	public function credit( array $cfg ) {
		$r = $this->request( $this->base( $cfg ) . 'account/info.json', array( 'method' => 'GET' ) );
		return isset( $r['json']['entries']['remaincredit'] ) ? 'اعتبار: ' . number_format( $r['json']['entries']['remaincredit'] ) . ' ریال' : new WP_Error( 'bch_sms', $r['body'] );
	}

	public function pattern_help() {
		return 'کد الگو = «نام الگو» (template) که در پنل کاوه‌نگار ساخته‌اید. پارامترها فقط این نام‌ها هستند: <code>token</code>، <code>token2</code>، <code>token3</code>، <code>token10</code>، <code>token20</code>. مثال:<br><code>token={code}<br>token2={name}</code><br>در token تا token3 فاصله مجاز نیست (افزونه خودکار به نیم‌فاصله تبدیل می‌کند)؛ token10 تا ۵ فاصله و token20 تا ۸ فاصله را می‌پذیرد.';
	}

	public function guide() {
		return $this->build_guide( array(
			'وارد <a href="https://panel.kavenegar.com" target="_blank" rel="noopener">پنل کاوه‌نگار</a> شوید.',
			'از <b>تنظیمات ← حساب کاربری</b> مقدار <b>API Key</b> را کپی و در افزونه بگذارید.',
			'شماره خط را از بخش <b>خطوط</b> بردارید (اگر خالی بماند خط پیش‌فرض حساب استفاده می‌شود).',
			'ارسال معمولی با sendarray انجام می‌شود (متن جدا برای هر مشتری، تا ۱۰۰ پیامک در هر مرحله).',
		), '<ol><li>از <b>اعتبارسنجی ← ایجاد الگو</b> الگو بسازید؛ متغیرها در متن الگو <code>%token</code>، <code>%token2</code>، <code>%token3</code>، <code>%token10</code>، <code>%token20</code> هستند.</li><li>نام الگو را در «کد الگو» بنویسید.</li><li>در «پارامترهای الگو»: <code>token={code}</code> و <code>token2={name}</code> و …</li></ol>' );
	}
}

/* ====================================================================== */
/* Melipayamak / payamak-panel REST                                        */
/* ====================================================================== */
class BCH_SMS_Driver_Melipayamak extends BCH_SMS_Driver {
	public $id      = 'melipayamak';
	public $label   = 'ملی پیامک، فراپیامک و پنل‌های payamak-panel (REST)';
	public $site    = 'https://www.melipayamak.com';
	public $brands  = array( 'ملی پیامک', 'فراپیامک', 'پیامک پنل', 'رایان اس‌ام‌اس', 'مرکز پیامک', 'آرکا پیامک', 'پیامک آریا', 'راز پیامک', 'هاست ایران', 'نمایندگان payamak-panel' );
	public $pattern = 'positional';

	public function fields() {
		return array(
			'username' => array( 'نام کاربری', 'text', 'نام کاربری ورود به پنل' ),
			'password' => array( 'رمز وب‌سرویس / رمز پنل', 'password', 'ترجیحاً «رمز وب‌سرویس» (API Key) از بخش توسعه‌دهندگان' ),
			'line'     => array( 'شماره خط ارسال', 'text', 'مثال: 50004001…' ),
			'base'     => array( 'آدرس سرویس REST', 'url', 'پیش‌فرض: https://rest.payamak-panel.com/api/ — فقط اگر نماینده آدرس دیگری داده تغییر دهید' ),
		);
	}

	protected function base( $cfg ) {
		return trailingslashit( $this->cfg( $cfg, 'base', 'https://rest.payamak-panel.com/api/' ) );
	}

	protected function ok( $r ) {
		if ( ! isset( $r['json']['RetStatus'] ) || 1 !== (int) $r['json']['RetStatus'] ) {
			return false;
		}
		$v = isset( $r['json']['Value'] ) ? (string) $r['json']['Value'] : '';
		return '' !== $v && ! in_array( $v, array( '0', '2', '3', '4', '5', '6', '7', '9', '10', '11', '12', '14', '15', '16', '17', '18', '35', '-1', '-2', '-3', '-4', '-5', '-6', '-7', '-10' ), true );
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$r = $this->form_post( $this->base( $cfg ) . 'SendSMS/SendSMS', array(
				'username' => $this->cfg( $cfg, 'username' ),
				'password' => $this->cfg( $cfg, 'password' ),
				'to'       => $m['mobile'],
				'from'     => $this->cfg( $cfg, 'line' ),
				'text'     => $m['text'],
				'isflash'  => 'false',
			) );
			return array( 'ok' => $this->ok( $r ), 'response' => $r['body'] );
		} );
	}

	public function send_pattern( $mobile, $code, array $params, array $cfg ) {
		$r = $this->form_post( $this->base( $cfg ) . 'SendSMS/BaseServiceNumber', array(
			'username' => $this->cfg( $cfg, 'username' ),
			'password' => $this->cfg( $cfg, 'password' ),
			'text'     => implode( ';', array_map( function ( $v ) {
				return str_replace( ';', '،', (string) $v );
			}, $this->positional( $params ) ) ),
			'to'       => $mobile,
			'bodyId'   => (int) $code,
		) );
		return array( 'ok' => $this->ok( $r ), 'response' => $r['body'] );
	}

	public function credit( array $cfg ) {
		$r = $this->form_post( $this->base( $cfg ) . 'SendSMS/GetCredit', array( 'username' => $this->cfg( $cfg, 'username' ), 'password' => $this->cfg( $cfg, 'password' ) ) );
		return isset( $r['json']['Value'] ) && isset( $r['json']['RetStatus'] ) && 1 === (int) $r['json']['RetStatus'] ? 'اعتبار: ' . $r['json']['Value'] : new WP_Error( 'bch_sms', $r['body'] );
	}

	public function pattern_help() {
		return 'کد الگو = «کد متن» (bodyId، عدد) از بخش «وب‌سرویس خدماتی». متغیرهای الگو در پنل به ترتیب <code>{0}</code>، <code>{1}</code>، <code>{2}</code> … هستند؛ پس نام پارامترها را عدد بنویسید:<br><code>0={name}<br>1={code}</code><br>(کاراکتر ; داخل مقدارها خودکار حذف می‌شود چون جداکننده است.)';
	}

	public function guide() {
		return $this->build_guide( array(
			'وارد پنل (ملی پیامک یا پنل نماینده‌ای که روی payamak-panel است) شوید.',
			'نام کاربری پنل را در «نام کاربری» بنویسید. از <b>توسعه‌دهندگان / وب‌سرویس</b> «رمز وب‌سرویس» (API Key) را بسازید و در «رمز» بگذارید (رمز ورود پنل هم کار می‌کند ولی امن‌تر نیست).',
			'شماره خط را از «خطوط من» در «شماره خط ارسال» بگذارید.',
			'اگر پنل شما ارسال از وب‌سرویس با خط عمومی را نمی‌پذیرد (خطای ۹)، از خط اختصاصی یا الگو استفاده کنید. ارسال لینک در خطوط عمومی معمولاً مسدود است (خطای ۱۴).',
		), '<ol><li>از <b>وب‌سرویس خدماتی (اشتراکی) ← ثبت متن</b> متن الگو را با متغیرهای <code>{0}</code>، <code>{1}</code> … ثبت کنید.</li><li>بعد از تأیید، «کد متن» (bodyId) را در «کد الگو» بنویسید.</li><li>در «پارامترهای الگو» به ترتیب: <code>0={name}</code>، <code>1={code}</code></li></ol>', array( 'کدهای خطای پرتکرار: ۰ نام کاربری/رمز اشتباه، ۲ اعتبار کافی نیست، ۵ شماره فرستنده نامعتبر، ۷ کلمه فیلترشده، ۹ ارسال از خط عمومی با وب‌سرویس مجاز نیست، ۱۴ متن حاوی لینک، ‎-4‎ کد متن تأیید نشده، ‎-5‎ تعداد متغیرها با الگو نمی‌خواند.' ) );
	}
}

/* ====================================================================== */
/* Melipayamak console (API key)                                           */
/* ====================================================================== */
class BCH_SMS_Driver_Melipayamak_Console extends BCH_SMS_Driver {
	public $id      = 'melipayamak_console';
	public $label   = 'ملی پیامک (کنسول جدید — کلید API)';
	public $site    = 'https://console.melipayamak.com';
	public $pattern = 'positional';

	public function fields() {
		return array(
			'api_key' => array( 'کلید کنسول', 'password', 'console.melipayamak.com ← وب‌سرویس ← کلید' ),
			'line'    => array( 'شماره خط ارسال', 'text', '' ),
		);
	}

	protected function ok( $r ) {
		return $r['code'] >= 200 && $r['code'] < 300 && ! empty( $r['json']['recId'] ) && (float) $r['json']['recId'] > 1000;
	}

	public function send( array $messages, array $cfg ) {
		$key = rawurlencode( $this->cfg( $cfg, 'api_key' ) );
		return $this->each( $messages, function ( $m ) use ( $cfg, $key ) {
			$r = $this->json_post( "https://console.melipayamak.com/api/send/simple/{$key}", array( 'from' => $this->cfg( $cfg, 'line' ), 'to' => $m['mobile'], 'text' => $m['text'] ) );
			return array( 'ok' => $this->ok( $r ), 'response' => $r['body'] );
		} );
	}

	public function send_pattern( $mobile, $code, array $params, array $cfg ) {
		$key = rawurlencode( $this->cfg( $cfg, 'api_key' ) );
		$r   = $this->json_post( "https://console.melipayamak.com/api/send/shared/{$key}", array( 'bodyId' => (int) $code, 'to' => $mobile, 'args' => array_map( 'strval', $this->positional( $params ) ) ) );
		return array( 'ok' => $this->ok( $r ), 'response' => $r['body'] );
	}

	public function pattern_help() {
		return 'مانند ملی پیامک: کد الگو = bodyId و پارامترها به ترتیب <code>0={name}</code>، <code>1={code}</code>.';
	}

	public function guide() {
		return $this->build_guide( array( 'وارد <a href="https://console.melipayamak.com" target="_blank" rel="noopener">کنسول ملی پیامک</a> شوید.', 'از بخش وب‌سرویس کلید بسازید و در «کلید کنسول» بگذارید.', 'شماره خط را وارد کنید.' ), '<p>الگو را در بخش «خدماتی» ثبت کنید و bodyId را در «کد الگو» بنویسید؛ پارامترها به ترتیب 0، 1، 2.</p>' );
	}
}

/* ====================================================================== */
/* Ghasedak                                                                */
/* ====================================================================== */
class BCH_SMS_Driver_Ghasedak extends BCH_SMS_Driver {
	public $id      = 'ghasedak';
	public $label   = 'قاصدک (Ghasedak)';
	public $site    = 'https://ghasedak.me';
	public $pattern = 'named';

	public function fields() {
		return array(
			'api_key' => array( 'ApiKey', 'password', 'پنل قاصدک ← تنظیمات ← کلید وب‌سرویس' ),
			'line'    => array( 'شماره خط ارسال', 'text', 'مثال: 30005088' ),
		);
	}

	protected function base() {
		return 'https://gateway.ghasedak.me/rest/api/v1/WebService/';
	}

	protected function ok( $r ) {
		return isset( $r['json']['isSuccess'] ) ? (bool) $r['json']['isSuccess'] : false;
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$r = $this->json_post( $this->base() . 'SendSingleSMS', array(
				'sendDate'          => gmdate( 'Y-m-d\TH:i:s\Z' ),
				'lineNumber'        => $this->cfg( $cfg, 'line' ),
				'receptor'          => $m['mobile'],
				'message'           => $m['text'],
				'clientReferenceId' => wp_generate_uuid4(),
			), array( 'ApiKey' => $this->cfg( $cfg, 'api_key' ) ) );
			return array( 'ok' => $this->ok( $r ), 'response' => $r['body'] );
		} );
	}

	public function send_pattern( $mobile, $code, array $params, array $cfg ) {
		$inputs = array();
		foreach ( $params as $k => $v ) {
			$inputs[] = array( 'param' => (string) $k, 'value' => (string) $v );
		}
		$r = $this->json_post( $this->base() . 'SendOtpSMS', array(
			'receptors'    => array( array( 'mobile' => $mobile, 'clientReferenceId' => wp_generate_uuid4() ) ),
			'templateName' => (string) $code,
			'inputs'       => $inputs,
		), array( 'ApiKey' => $this->cfg( $cfg, 'api_key' ) ) );
		return array( 'ok' => $this->ok( $r ), 'response' => $r['body'] );
	}

	public function credit( array $cfg ) {
		$r = $this->request( $this->base() . 'GetAccountInformation', array( 'method' => 'GET', 'headers' => array( 'ApiKey' => $this->cfg( $cfg, 'api_key' ), 'Accept' => 'application/json' ) ) );
		return isset( $r['json']['data']['credit'] ) ? 'اعتبار: ' . $r['json']['data']['credit'] : new WP_Error( 'bch_sms', $r['body'] );
	}

	public function pattern_help() {
		return 'کد الگو = «نام قالب» (templateName). نام پارامترها همان نام متغیرهای قالب است. مثال:<br><code>Code={otp}</code> یا <code>Name={name}</code>';
	}

	public function guide() {
		return $this->build_guide( array(
			'وارد پنل قاصدک شوید.',
			'از <b>تنظیمات ← کلید وب‌سرویس (API Key)</b> کلید را بردارید و در «ApiKey» بگذارید.',
			'شماره خط را در «شماره خط ارسال» بگذارید.',
		), '<ol><li>از بخش <b>قالب‌ها (OTP / خدماتی)</b> قالب بسازید و متغیرها را تعریف کنید.</li><li>«نام قالب» را در «کد الگو» بنویسید و پارامترها را به شکل <code>Name={name}</code> نگاشت کنید.</li></ol>' );
	}
}

/* ====================================================================== */
/* Magfa HTTP v2                                                           */
/* ====================================================================== */
class BCH_SMS_Driver_Magfa extends BCH_SMS_Driver {
	public $id    = 'magfa';
	public $label = 'مگفا (Magfa)';
	public $site  = 'https://magfa.com';

	public function fields() {
		return array(
			'username' => array( 'نام کاربری', 'text', '' ),
			'domain'   => array( 'دامنه (Domain)', 'text', 'دامنه حساب مگفا، مثل magfa' ),
			'password' => array( 'رمز عبور', 'password', '' ),
			'line'     => array( 'شماره خط ارسال', 'text', 'مثال: 3000xxxx' ),
		);
	}

	public function batch_size() {
		return 100;
	}

	protected function auth( $cfg ) {
		return array( 'Authorization' => 'Basic ' . base64_encode( $this->cfg( $cfg, 'username' ) . '/' . $this->cfg( $cfg, 'domain' ) . ':' . $this->cfg( $cfg, 'password' ) ) );
	}

	public function send( array $messages, array $cfg ) {
		$r   = $this->json_post( 'https://sms.magfa.com/api/http/sms/v2/send', array(
			'senders'    => array_fill( 0, count( $messages ), $this->cfg( $cfg, 'line' ) ),
			'recipients' => array_values( wp_list_pluck( $messages, 'mobile' ) ),
			'messages'   => array_values( wp_list_pluck( $messages, 'text' ) ),
		), $this->auth( $cfg ) );
		$out = array();
		foreach ( array_values( $messages ) as $i => $m ) {
			$st    = isset( $r['json']['messages'][ $i ]['status'] ) ? (int) $r['json']['messages'][ $i ]['status'] : ( isset( $r['json']['status'] ) ? (int) $r['json']['status'] : -1 );
			$out[] = array( 'ok' => 200 === $r['code'] && 0 === $st, 'response' => $r['body'] );
		}
		return $out;
	}

	public function credit( array $cfg ) {
		$r = $this->request( 'https://sms.magfa.com/api/http/sms/v2/balance', array( 'method' => 'GET', 'headers' => array_merge( $this->auth( $cfg ), array( 'Accept' => 'application/json' ) ) ) );
		return isset( $r['json']['balance'] ) ? 'اعتبار: ' . $r['json']['balance'] : new WP_Error( 'bch_sms', $r['body'] );
	}

	public function guide() {
		return $this->build_guide( array( 'نام کاربری، دامنه (domain) و رمز حساب مگفا را از پشتیبانی/پنل مگفا دریافت کنید.', 'احراز هویت به شکل «username/domain» و رمز انجام می‌شود؛ هر سه را جداگانه وارد کنید.', 'شماره خط را وارد کنید. ارسال گروهی با متن جدا برای هر نفر در یک درخواست انجام می‌شود.' ), '', array( 'وضعیت ۰ یعنی موفق؛ ۱۸ یعنی نام کاربری یا رمز اشتباه است.' ) );
	}
}

/* ====================================================================== */
/* Trez (Raygansms)                                                        */
/* ====================================================================== */
class BCH_SMS_Driver_Trez extends BCH_SMS_Driver {
	public $id     = 'trez';
	public $label  = 'ترز / رایگان اس‌ام‌اس (Trez)';
	public $family = 'reseller';
	public $brands = array( 'رایگان اس‌ام‌اس (raygansms)', 'ترز (trez)' );

	public function fields() {
		return array(
			'username' => array( 'نام کاربری', 'text', '' ),
			'password' => array( 'رمز عبور', 'password', '' ),
			'line'     => array( 'شماره خط', 'text', '' ),
			'base'     => array( 'آدرس سرویس', 'url', 'پیش‌فرض: http://smspanel.trez.ir/api/' ),
		);
	}

	protected function base( $cfg ) {
		return trailingslashit( $this->cfg( $cfg, 'base', 'http://smspanel.trez.ir/api/' ) );
	}

	protected function auth( $cfg ) {
		return array( 'authorization' => 'Basic ' . base64_encode( $this->cfg( $cfg, 'username' ) . ':' . $this->cfg( $cfg, 'password' ) ) );
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$r = $this->json_post( $this->base( $cfg ) . 'smsAPI/SendMessage', array(
				'PhoneNumber'         => $this->cfg( $cfg, 'line' ),
				'Message'             => $m['text'],
				'Mobiles'             => array( $m['mobile'] ),
				'UserGroupID'         => uniqid(),
				'SendDateInTimeStamp' => time(),
			), $this->auth( $cfg ) );
			return array( 'ok' => 200 === $r['code'] && isset( $r['json']['Code'] ) && 0 === (int) $r['json']['Code'], 'response' => $r['body'] );
		} );
	}

	public function credit( array $cfg ) {
		$r = $this->json_post( $this->base( $cfg ) . 'smsAPI/GetCredit', array(), $this->auth( $cfg ) );
		return isset( $r['json']['Result'] ) ? 'اعتبار: ' . $r['json']['Result'] : new WP_Error( 'bch_sms', $r['body'] );
	}

	public function guide() {
		return $this->build_guide( array( 'وارد پنل (raygansms.com یا trez.ir) شوید.', 'از «تنظیمات ← وب‌سرویس» دسترسی API را فعال کنید.', 'نام کاربری و رمز پنل را وارد کنید (احراز هویت Basic).', 'شماره خط را از «خطوط من» بنویسید.', 'اگر نماینده آدرس سرویس دیگری داده، در «آدرس سرویس» وارد کنید.' ), '', array( 'کد ۰ در پاسخ یعنی موفق.' ) );
	}
}

/* ====================================================================== */
/* SabaNovin                                                               */
/* ====================================================================== */
class BCH_SMS_Driver_Sabanovin extends BCH_SMS_Driver {
	public $id     = 'sabanovin';
	public $label  = 'صبانوین (SabaNovin)';
	public $family = 'reseller';

	public function fields() {
		return array(
			'api_key' => array( 'API Key', 'password', '' ),
			'line'    => array( 'شماره خط (gateway)', 'text', '' ),
			'base'    => array( 'آدرس سرویس', 'url', 'پیش‌فرض: http://api.sabanovin.com/v1/' ),
		);
	}

	protected function base( $cfg ) {
		return trailingslashit( $this->cfg( $cfg, 'base', 'http://api.sabanovin.com/v1/' ) ) . rawurlencode( $this->cfg( $cfg, 'api_key' ) ) . '/';
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$url = add_query_arg( array( 'gateway' => rawurlencode( $this->cfg( $cfg, 'line' ) ), 'to' => $m['mobile'], 'text' => rawurlencode( $m['text'] ) ), $this->base( $cfg ) . 'sms/send.json' );
			$r   = $this->request( $url, array( 'method' => 'GET' ) );
			return array( 'ok' => isset( $r['json']['status']['code'] ) && 200 === (int) $r['json']['status']['code'], 'response' => $r['body'] );
		} );
	}

	public function credit( array $cfg ) {
		$r = $this->request( $this->base( $cfg ) . 'credit.json', array( 'method' => 'GET' ) );
		return isset( $r['json']['entry']['credit'] ) ? 'اعتبار: ' . $r['json']['entry']['credit'] : new WP_Error( 'bch_sms', $r['body'] );
	}

	public function guide() {
		return $this->build_guide( array( 'وارد پنل صبانوین شوید.', 'از منوی «تنظیمات حساب / وب‌سرویس» کلید API (API Key) را کپی و در فیلد «API Key» بگذارید.', 'از «خطوط من» شماره خط را کپی و در «شماره خط (gateway)» وارد کنید.', 'اگر نماینده صبانوین آدرس سرویس اختصاصی داده، در «آدرس سرویس» وارد کنید؛ در غیر این صورت خالی بگذارید.', 'ذخیره و «استعلام اعتبار» را بزنید؛ نمایش اعتبار یعنی کلید درست است.' ) );
	}
}

/* ====================================================================== */
/* Asanak                                                                  */
/* ====================================================================== */
class BCH_SMS_Driver_Asanak extends BCH_SMS_Driver {
	public $id     = 'asanak';
	public $label  = 'آسانک (Asanak)';
	public $family = 'reseller';

	public function fields() {
		return array(
			'username' => array( 'نام کاربری', 'text', '' ),
			'password' => array( 'رمز عبور', 'password', '' ),
			'line'     => array( 'شماره خط', 'text', '' ),
			'base'     => array( 'آدرس سرویس', 'url', 'پیش‌فرض: http://panel.asanak.ir/webservice/v1rest/sendsms' ),
		);
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$url = add_query_arg( array(
				'username'    => rawurlencode( $this->cfg( $cfg, 'username' ) ),
				'password'    => rawurlencode( $this->cfg( $cfg, 'password' ) ),
				'source'      => rawurlencode( $this->cfg( $cfg, 'line' ) ),
				'destination' => $m['mobile'],
				'message'     => rawurlencode( $m['text'] ),
			), $this->cfg( $cfg, 'base', 'http://panel.asanak.ir/webservice/v1rest/sendsms' ) );
			$r   = $this->request( $url, array( 'method' => 'GET' ) );
			$ok  = 200 === $r['code'] && '' !== trim( $r['body'] ) && false === stripos( $r['body'], 'error' ) && false === stripos( $r['body'], 'meta' );
			return array( 'ok' => $ok, 'response' => $r['body'] );
		} );
	}

	public function guide() {
		return $this->build_guide( array( 'وارد پنل آسانک (panel.asanak.ir) شوید و از بخش «وب‌سرویس» دسترسی API را فعال کنید.', 'نام کاربری و رمز وب‌سرویس را در افزونه وارد کنید.', 'شماره خط اختصاصی/خدماتی را از «خطوط من» در «شماره خط» بنویسید.', 'اگر آدرس سرویس دیگری به شما داده‌اند، در «آدرس سرویس» وارد کنید.', 'در پاسخ موفق، شناسه پیامک (عدد) برگردانده می‌شود؛ پیام متنی یعنی خطا.' ) );
	}
}

/* ====================================================================== */
/* Simple HTTP providers                                                   */
/* ====================================================================== */
class BCH_SMS_Driver_Payamresan extends BCH_SMS_Driver {
	public $id     = 'payamresan';
	public $label  = 'پیام‌رسان (payam-resan.com)';
	public $family = 'reseller';

	public function fields() {
		return array(
			'username' => array( 'نام کاربری', 'text', '' ),
			'password' => array( 'رمز عبور', 'password', '' ),
			'line'     => array( 'شماره خط', 'text', '' ),
		);
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$url = add_query_arg( array( 'Username' => rawurlencode( $this->cfg( $cfg, 'username' ) ), 'Password' => rawurlencode( $this->cfg( $cfg, 'password' ) ), 'From' => rawurlencode( $this->cfg( $cfg, 'line' ) ), 'To' => $m['mobile'], 'Text' => rawurlencode( $m['text'] ) ), 'http://www.payam-resan.com/APISend.aspx' );
			$r   = $this->request( $url, array( 'method' => 'GET' ) );
			$b   = trim( wp_strip_all_tags( $r['body'] ) );
			return array( 'ok' => 200 === $r['code'] && is_numeric( $b ) && (float) $b > 0, 'response' => $r['body'] );
		} );
	}

	public function guide() {
		return $this->build_guide( array( 'وارد پنل payam-resan.com شوید و از بخش «وب‌سرویس / API» مطمئن شوید دسترسی HTTP فعال است.', 'نام کاربری و رمز حساب را در افزونه وارد کنید.', 'شماره خط ارسال را از «خطوط» کپی کنید.', 'ذخیره و تست کنید؛ پاسخ عددی بزرگ (شناسه ارسال) یعنی موفق، عدد کوچک یا متن یعنی کد خطا.' ) );
	}
}

class BCH_SMS_Driver_Sms18 extends BCH_SMS_Driver {
	public $id     = 'sms18';
	public $label  = '18SMS';
	public $family = 'reseller';

	public function fields() {
		return array(
			'username' => array( 'نام کاربری', 'text', '' ),
			'password' => array( 'رمز عبور', 'password', '' ),
			'line'     => array( 'شماره خط', 'text', '' ),
		);
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$url = 'http://18sms.ir/webservice/rest/sms_send?' . http_build_query( array( 'login_username' => $this->cfg( $cfg, 'username' ), 'login_password' => $this->cfg( $cfg, 'password' ), 'receiver_number' => $m['mobile'], 'note_arr' => array( $m['text'] ), 'sender_number' => $this->cfg( $cfg, 'line' ) ) );
			$r   = $this->request( $url, array( 'method' => 'GET' ) );
			return array( 'ok' => 200 === $r['code'] && isset( $r['json']['status'] ) && 'ERR' !== $r['json']['status'], 'response' => $r['body'] );
		} );
	}

	public function guide() {
		return $this->build_guide( array( 'وارد پنل 18sms.ir شوید.', 'در «تنظیمات ← وب‌سرویس» دسترسی REST را فعال کنید (در صورت نیاز IP سرور را ثبت کنید).', 'نام کاربری، رمز و شماره خط را در افزونه وارد کنید.', 'ذخیره و تست کنید.' ) );
	}
}

class BCH_SMS_Driver_Sunway extends BCH_SMS_Driver {
	public $id     = 'sunway';
	public $label  = 'سان‌وی (SunwaySMS)';
	public $family = 'reseller';

	public function fields() {
		return array(
			'username' => array( 'نام کاربری', 'text', '' ),
			'password' => array( 'رمز عبور', 'password', '' ),
			'line'     => array( 'شماره خط', 'text', '' ),
		);
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$url = add_query_arg( array( 'service' => 'SendArray', 'UserName' => rawurlencode( $this->cfg( $cfg, 'username' ) ), 'Password' => rawurlencode( $this->cfg( $cfg, 'password' ) ), 'To' => $m['mobile'], 'Message' => rawurlencode( $m['text'] ), 'From' => rawurlencode( $this->cfg( $cfg, 'line' ) ), 'Flash' => 'false' ), 'http://sms.sunwaysms.com/smsws/HttpService.ashx' );
			$r   = $this->request( $url, array( 'method' => 'GET' ) );
			$b   = trim( $r['body'] );
			return array( 'ok' => 200 === $r['code'] && strlen( preg_replace( '/\D/', '', $b ) ) > 3, 'response' => $r['body'] );
		} );
	}

	public function guide() {
		return $this->build_guide( array( 'وارد پنل سان‌وی (sms.sunwaysms.com) شوید.', 'از «پروفایل ← تنظیمات وب‌سرویس» دسترسی HTTP Service را فعال کنید.', 'نام کاربری، رمز و شماره خط را در افزونه وارد کنید.', 'در پاسخ موفق شناسه پیامک (عدد چندرقمی) برمی‌گردد؛ اعداد ۱ تا ۳ رقمی کد خطا هستند (جدول کدها در راهنمای وب‌سرویس سان‌وی).' ) );
	}
}

class BCH_SMS_Driver_Isms extends BCH_SMS_Driver {
	public $id     = 'isms';
	public $label  = 'iSMS (isms.ir)';
	public $family = 'reseller';

	public function fields() {
		return array(
			'username' => array( 'نام کاربری', 'text', '' ),
			'password' => array( 'رمز عبور', 'password', '' ),
		);
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$r = $this->form_post( 'http://ws3584.isms.ir/sendWS', array( 'username' => $this->cfg( $cfg, 'username' ), 'password' => $this->cfg( $cfg, 'password' ), 'mobiles' => array( $m['mobile'] ), 'body' => $m['text'] ) );
			$ok = 200 === $r['code'] && is_array( $r['json'] ) && empty( $r['json']['code'] ) && empty( $r['json']['error'] );
			return array( 'ok' => $ok, 'response' => $r['body'] );
		} );
	}

	public function guide() {
		return $this->build_guide( array( 'وارد پنل isms.ir شوید.', 'دسترسی وب‌سرویس را از تنظیمات حساب فعال کنید.', 'نام کاربری و رمز را در افزونه وارد کنید (شماره خط پیش‌فرض حساب استفاده می‌شود؛ خط پیش‌فرض را در پنل تعیین کنید).', 'ذخیره و تست کنید.' ) );
	}
}

class BCH_SMS_Driver_Logistic extends BCH_SMS_Driver {
	public $id     = 'logisticsms';
	public $label  = 'لجستیک اس‌ام‌اس (LogisticSMS)';
	public $family = 'reseller';

	public function fields() {
		return array(
			'username' => array( 'نام کاربری', 'text', '' ),
			'password' => array( 'رمز عبور', 'password', '' ),
			'line'     => array( 'شماره فرستنده', 'text', '' ),
		);
	}

	protected function token( $cfg ) {
		$r = $this->request( 'https://api.logisticsms.ir/api/v1/login', array( 'method' => 'POST', 'headers' => array( 'Accept' => 'application/json' ), 'body' => array( 'username' => $this->cfg( $cfg, 'username' ), 'password' => $this->cfg( $cfg, 'password' ) ) ) );
		if ( isset( $r['json']['msg'], $r['json']['data']['token'] ) && 'success' === $r['json']['msg'] ) {
			return $r['json']['data']['token'];
		}
		throw new Exception( 'ورود به LogisticSMS ناموفق بود: ' . $r['body'] );
	}

	public function send( array $messages, array $cfg ) {
		try {
			$token = $this->token( $cfg );
		} catch ( Exception $e ) {
			return $this->fill( count( $messages ), false, $e->getMessage() );
		}
		return $this->each( $messages, function ( $m ) use ( $cfg, $token ) {
			$r = $this->request( 'https://api.logisticsms.ir/api/v1/sms/send', array( 'method' => 'POST', 'headers' => array( 'X-API-TOKEN' => $token, 'Accept' => 'application/json' ), 'body' => array( 'receptor' => $m['mobile'], 'message' => $m['text'], 'sender' => $this->cfg( $cfg, 'line' ) ) ) );
			return array( 'ok' => isset( $r['json']['msg'] ) && 'success' === $r['json']['msg'], 'response' => $r['body'] );
		} );
	}

	public function guide() {
		return $this->build_guide( array( 'وارد پنل LogisticSMS شوید و از بخش «API» دسترسی را فعال کنید.', 'نام کاربری و رمز را در افزونه وارد کنید؛ افزونه قبل از هر ارسال توکن (X-API-TOKEN) را خودکار می‌گیرد.', 'شماره فرستنده (خط) را بنویسید.', 'ذخیره و تست کنید؛ خطای «ورود ناموفق» یعنی نام کاربری/رمز اشتباه است.' ) );
	}
}

/* ====================================================================== */
/* SOAP families (resellers of shared platforms)                           */
/* ====================================================================== */
class BCH_SMS_Driver_PayamakPanel_Soap extends BCH_SMS_Driver {
	public $id     = 'payamakpanel_soap';
	public $label  = 'نمایندگان payamak-panel با آدرس اختصاصی (SOAP post/send.asmx)';
	public $family = 'soap';
	public $soap   = true;
	public $brands = array( 'آراد اس‌ام‌اس', 'پاز', 'لاگین پنل', 'اس‌ام‌اس کلیک', 'ایران اسپیک', 'آنلاین پنل', 'اس‌ام‌اس طوس' );

	public function fields() {
		return array(
			'wsdl'     => array( 'آدرس WSDL', 'url', 'مثال: http://panel.arad-sms.ir/post/send.asmx?wsdl (از پشتیبانی پنل بپرسید)' ),
			'username' => array( 'نام کاربری', 'text', '' ),
			'password' => array( 'رمز عبور', 'password', '' ),
			'line'     => array( 'شماره خط', 'text', '' ),
		);
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$c = $this->soap( $this->cfg( $cfg, 'wsdl', 'http://api.payamak-panel.com/post/send.asmx?wsdl' ) );
			$r = $c->SendSms( array( 'username' => $this->cfg( $cfg, 'username' ), 'password' => $this->cfg( $cfg, 'password' ), 'from' => $this->cfg( $cfg, 'line' ), 'to' => array( $m['mobile'] ), 'text' => $m['text'], 'isflash' => false, 'udh' => '', 'recId' => array( 0 ), 'status' => 0x0 ) );
			$v = isset( $r->SendSmsResult ) ? (int) $r->SendSmsResult : -99;
			return array( 'ok' => 1 === $v, 'response' => 'SendSmsResult=' . $v );
		} );
	}

	public function guide() {
		return $this->build_guide( array( 'این گزینه برای پنل‌هایی است که روی پلتفرم payamak-panel هستند ولی آدرس اختصاصی دارند. آدرس WSDL را از پشتیبانی پنل بگیرید (معمولاً با /post/send.asmx?wsdl تمام می‌شود).', 'اگر پنل شما REST هم دارد، گزینه «ملی پیامک، فراپیامک و پنل‌های payamak-panel (REST)» سریع‌تر و بهتر است.', 'نیاز به فعال بودن php-soap روی هاست دارد.' ), '', array( 'نتیجه ۱ یعنی موفق؛ بقیه کدها مانند کدهای خطای ملی پیامک است.' ) );
	}
}

class BCH_SMS_Driver_IPPanel_Soap extends BCH_SMS_Driver {
	public $id     = 'ippanel_soap';
	public $label  = 'نمایندگان IPPanel قدیمی (SOAP wssimple)';
	public $family = 'soap';
	public $soap   = true;
	public $brands = array( 'اول پیام', 'بندر اس‌ام‌اس', 'نصر پیام', 'ام‌دی پنل' );

	public function fields() {
		return array(
			'wsdl'     => array( 'آدرس WSDL', 'url', 'مثال: http://www.avalpayam.com/class/sms/wssimple/server.php?wsdl' ),
			'username' => array( 'نام کاربری', 'text', '' ),
			'password' => array( 'رمز عبور', 'password', '' ),
			'line'     => array( 'شماره خط', 'text', '' ),
		);
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$c = $this->soap( $this->cfg( $cfg, 'wsdl' ) );
			$r = $c->__soapCall( 'SendSMS', array( 'Username' => $this->cfg( $cfg, 'username' ), 'Password' => $this->cfg( $cfg, 'password' ), 'SenderNumber' => $this->cfg( $cfg, 'line' ), 'RecipientNumbers' => array( $m['mobile'] ), 'Message' => $m['text'], 'Type' => 'normal' ) );
			$s = is_scalar( $r ) ? (string) $r : wp_json_encode( $r );
			return array( 'ok' => ! empty( $r ) && ( ! is_numeric( $s ) || (float) $s > 1000 ), 'response' => $s );
		} );
	}

	public function guide() {
		return $this->build_guide( array( 'برای پنل‌های قدیمی IPPanel که آدرسشان به /class/sms/wssimple/server.php?wsdl ختم می‌شود.', 'آدرس WSDL، نام کاربری، رمز و خط را وارد کنید. نیاز به php-soap دارد.' ) );
	}
}

class BCH_SMS_Driver_SendSmsAsmx extends BCH_SMS_Driver {
	public $id     = 'sendsms_asmx';
	public $label  = 'خانواده API/SendSMS.asmx (جهان پیامک، اس‌ام‌اس بان، پرشین اس‌ام‌اس)';
	public $family = 'soap';
	public $soap   = true;

	public function fields() {
		return array(
			'wsdl'     => array( 'آدرس WSDL', 'url', 'مثال: http://jahanpayamak.ir/API/SendSMS.asmx?WSDL' ),
			'username' => array( 'نام کاربری', 'text', '' ),
			'password' => array( 'رمز عبور', 'password', '' ),
			'line'     => array( 'شماره خط', 'text', '' ),
			'api'      => array( 'کد API (اختیاری)', 'text', 'اگر پنل کد API داده' ),
		);
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$c = $this->soap( $this->cfg( $cfg, 'wsdl' ) );
			$r = $c->Send_Sms4( array( 'USERNAME' => $this->cfg( $cfg, 'username' ), 'PASSWORD' => $this->cfg( $cfg, 'password' ), 'TO' => $m['mobile'], 'FROM' => $this->cfg( $cfg, 'line' ), 'TEXT' => $m['text'], 'API' => $this->cfg( $cfg, 'api' ), 'API_CHANGE_ALLOW' => 1, 'FLASH' => false, 'Internation' => false ) );
			$v = isset( $r->Send_Sms4Result ) ? $r->Send_Sms4Result : '';
			$s = is_scalar( $v ) ? (string) $v : wp_json_encode( $v );
			return array( 'ok' => '' !== $s && ( ! is_numeric( $s ) || (float) $s > 100 ), 'response' => $s );
		} );
	}

	public function guide() {
		return $this->build_guide( array( 'برای پنل‌هایی که آدرس وب‌سرویسشان /API/SendSMS.asmx است.', 'آدرس WSDL، نام کاربری، رمز و خط را وارد کنید. نیاز به php-soap دارد.' ) );
	}
}

class BCH_SMS_Driver_SmsServicePhp extends BCH_SMS_Driver {
	public $id     = 'smsservice_php';
	public $label  = 'خانواده webservice/smsService.php (نوین ۱، SSMSS، تکست اس‌ام‌اس)';
	public $family = 'soap';
	public $soap   = true;

	public function fields() {
		return array(
			'wsdl'     => array( 'آدرس WSDL', 'url', 'مثال: http://www.novin1sms.ir/webservice/smsService.php?wsdl' ),
			'username' => array( 'نام کاربری', 'text', '' ),
			'password' => array( 'رمز عبور', 'password', '' ),
			'line'     => array( 'شماره خط', 'text', '' ),
		);
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$c = $this->soap( $this->cfg( $cfg, 'wsdl' ) );
			$r = $c->send_sms( $this->cfg( $cfg, 'username' ), $this->cfg( $cfg, 'password' ), $this->cfg( $cfg, 'line' ), $m['mobile'], $m['text'] );
			$s = is_scalar( $r ) ? (string) $r : wp_json_encode( $r );
			return array( 'ok' => '' !== $s && ( ! is_numeric( $s ) || (float) $s > 100 ), 'response' => $s );
		} );
	}

	public function guide() {
		return $this->build_guide( array( 'برای پنل‌هایی که آدرس وب‌سرویسشان /webservice/smsService.php?wsdl است.', 'نیاز به php-soap دارد.' ) );
	}
}

class BCH_SMS_Driver_HiroSoap extends BCH_SMS_Driver {
	public $id     = 'hiro_soap';
	public $label  = 'خانواده webservice/send.php (هیرو اس‌ام‌اس، ایده پیام)';
	public $family = 'soap';
	public $soap   = true;

	public function fields() {
		return array(
			'wsdl'     => array( 'آدرس WSDL', 'url', 'مثال: http://my.hiro-sms.com/webservice/send.php?wsdl' ),
			'username' => array( 'نام کاربری', 'text', '' ),
			'password' => array( 'رمز عبور', 'password', '' ),
			'line'     => array( 'شماره خط', 'text', '' ),
		);
	}

	public function batch_size() {
		return 50;
	}

	public function send( array $messages, array $cfg ) {
		try {
			$c = $this->soap( $this->cfg( $cfg, 'wsdl' ) );
			$n = count( $messages );
			$r = $c->SendMultiSMS( array_fill( 0, $n, $this->cfg( $cfg, 'line' ) ), array_values( wp_list_pluck( $messages, 'mobile' ) ), array_values( wp_list_pluck( $messages, 'text' ) ), array_fill( 0, $n, 0 ), $this->cfg( $cfg, 'username' ), $this->cfg( $cfg, 'password' ) );
			$s = is_scalar( $r ) ? (string) $r : wp_json_encode( $r );
			return $this->fill( $n, ! empty( $r ) && ( ! is_numeric( $s ) || (float) $s > 100 ), $s );
		} catch ( Exception $e ) {
			return $this->fill( count( $messages ), false, $e->getMessage() );
		}
	}

	public function guide() {
		return $this->build_guide( array( 'برای پنل‌هایی که آدرس وب‌سرویسشان /webservice/send.php?wsdl است.', 'نیاز به php-soap دارد.' ) );
	}
}

class BCH_SMS_Driver_ParsGreen extends BCH_SMS_Driver {
	public $id     = 'parsgreen';
	public $label  = 'پارس گرین (ParsGreen)';
	public $family = 'soap';
	public $soap   = true;

	public function fields() {
		return array(
			'signature' => array( 'امضا (Signature)', 'password', 'کد امضای وب‌سرویس از پنل پارس گرین' ),
			'line'      => array( 'شماره خط', 'text', '' ),
		);
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$c = $this->soap( 'http://login.parsgreen.com/Api/SendSMS.asmx?WSDL' );
			$r = (array) $c->SendGroupSMS( array( 'signature' => $this->cfg( $cfg, 'signature' ), 'from' => $this->cfg( $cfg, 'line' ), 'to' => array( $m['mobile'] ), 'text' => $m['text'], 'isFlash' => false, 'udh' => '', 'success' => 0x0, 'retStr' => array( 0 ) ) );
			$v = isset( $r['SendGroupSMSResult'] ) ? (int) $r['SendGroupSMSResult'] : -1;
			return array( 'ok' => 1 === $v, 'response' => 'SendGroupSMSResult=' . $v );
		} );
	}

	public function guide() {
		return $this->build_guide( array( 'از پنل پارس گرین «امضا / Signature» وب‌سرویس را بردارید.', 'شماره خط را وارد کنید. نیاز به php-soap دارد.' ) );
	}
}

class BCH_SMS_Driver_0098 extends BCH_SMS_Driver {
	public $id     = 'sms0098';
	public $label  = '0098 اس‌ام‌اس (0098sms)';
	public $family = 'soap';
	public $soap   = true;

	public function fields() {
		return array(
			'username' => array( 'نام کاربری', 'text', '' ),
			'password' => array( 'رمز عبور', 'password', '' ),
			'line'     => array( 'شماره پنل/خط (pnlno)', 'text', '' ),
		);
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$c = $this->soap( 'https://webservice.0098sms.com/service.asmx?wsdl' );
			$r = $c->SendSMS( array( 'username' => $this->cfg( $cfg, 'username' ), 'password' => $this->cfg( $cfg, 'password' ), 'mobileno' => $m['mobile'], 'pnlno' => $this->cfg( $cfg, 'line' ), 'text' => $m['text'], 'isflash' => false ) );
			$v = isset( $r->SendSMSResult ) ? (string) $r->SendSMSResult : '';
			return array( 'ok' => '0' === $v || 1 === preg_match( '/^\d{5,}$/', $v ), 'response' => 'SendSMSResult=' . $v );
		} );
	}

	public function guide() {
		return $this->build_guide( array( 'نام کاربری، رمز و شماره پنل 0098 را وارد کنید. نیاز به php-soap دارد.' ) );
	}
}

class BCH_SMS_Driver_Candoo extends BCH_SMS_Driver {
	public $id     = 'candoo';
	public $label  = 'کندو اس‌ام‌اس (Candoo)';
	public $family = 'soap';
	public $soap   = true;

	public function fields() {
		return array(
			'username' => array( 'نام کاربری', 'text', '' ),
			'password' => array( 'رمز عبور', 'password', '' ),
			'line'     => array( 'شماره خط', 'text', '' ),
		);
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			$c = $this->soap( 'http://my.candoosms.com/services/?wsdl' );
			$r = $c->__soapCall( 'Send', array( 'username' => $this->cfg( $cfg, 'username' ), 'password' => $this->cfg( $cfg, 'password' ), 'srcNumber' => $this->cfg( $cfg, 'line' ), 'body' => $m['text'], 'destNo' => array( $m['mobile'] ), 'flash' => '0' ) );
			$s = is_scalar( $r ) ? (string) $r : wp_json_encode( $r );
			return array( 'ok' => ! empty( $r ), 'response' => $s );
		} );
	}

	public function guide() {
		return $this->build_guide( array( 'نام کاربری، رمز و خط پنل کندو را وارد کنید. نیاز به php-soap دارد.' ) );
	}
}

/* ====================================================================== */
/* Generic HTTP — any other panel                                          */
/* ====================================================================== */
class BCH_SMS_Driver_Generic extends BCH_SMS_Driver {
	public $id      = 'generic';
	public $label   = 'سایر پنل‌ها — اتصال دستی وب‌سرویس (HTTP / REST)';
	public $family  = 'custom';
	public $pattern = 'named';

	public function fields() {
		return array(
			'url'          => array( 'آدرس ارسال (URL)', 'url', 'مثال: https://api.example.ir/sms/send' ),
			'method'       => array( 'متد', 'select', '', array( 'POST' => 'POST', 'GET' => 'GET' ) ),
			'content_type' => array( 'نوع بدنه', 'select', '', array( 'json' => 'JSON', 'form' => 'Form (x-www-form-urlencoded)' ) ),
			'headers'      => array( 'هدرها (هر خط: Name: Value)', 'textarea', 'مثال: Authorization: Bearer {api_key}' ),
			'body'         => array( 'قالب بدنه', 'textarea', 'JSON مثل {"to":"{to}","text":"{text}","from":"{from}"} — Form مثل to={to}&text={text}' ),
			'api_key'      => array( 'کلید API ← {api_key}', 'password', '' ),
			'username'     => array( 'نام کاربری ← {username}', 'text', '' ),
			'password'     => array( 'رمز ← {password}', 'password', '' ),
			'line'         => array( 'شماره فرستنده ← {from}', 'text', '' ),
			'success'      => array( 'نشانه موفقیت در پاسخ', 'text', 'مثال: "status":1 — خالی = هر پاسخ HTTP 200 تا 299 موفق است' ),
			'p_url'        => array( 'آدرس ارسال الگو (اختیاری)', 'url', 'اگر پنل ارسال پترن دارد' ),
			'p_body'       => array( 'قالب بدنه الگو', 'textarea', 'مثال: {"to":"{to}","code":"{pattern}","params":{params_json}}' ),
		);
	}

	/**
	 * Placeholder values. $encode: url | json | raw.
	 */
	protected function vars( $mobile, $text, $cfg, $encode, $extra = array() ) {
		$v = array_merge( array(
			'{to}'       => $mobile,
			'{to98}'     => $this->intl( $mobile ),
			'{to_plus}'  => $this->e164( $mobile ),
			'{to_10}'    => substr( $mobile, 1 ),
			'{text}'     => $text,
			'{from}'     => $this->cfg( $cfg, 'line' ),
			'{api_key}'  => $this->cfg( $cfg, 'api_key' ),
			'{username}' => $this->cfg( $cfg, 'username' ),
			'{password}' => $this->cfg( $cfg, 'password' ),
			'{uid}'      => wp_generate_uuid4(),
			'{time}'     => (string) time(),
		), $extra );
		$raw_json = array( '{params_json}', '{params_array}' );
		foreach ( $v as $k => $s ) {
			if ( in_array( $k, $raw_json, true ) ) {
				continue;
			}
			if ( 'url' === $encode ) {
				$v[ $k ] = rawurlencode( (string) $s );
			} elseif ( 'json' === $encode ) {
				$v[ $k ] = substr( wp_json_encode( (string) $s, JSON_UNESCAPED_UNICODE ), 1, -1 );
			}
		}
		return $v;
	}

	protected function call( $url, $body_tpl, $mobile, $text, $cfg, $extra = array() ) {
		$method  = 'GET' === $this->cfg( $cfg, 'method', 'POST' ) ? 'GET' : 'POST';
		$ctype   = $this->cfg( $cfg, 'content_type', 'json' );
		$url     = strtr( $url, $this->vars( $mobile, $text, $cfg, 'url', $extra ) );
		$headers = array();
		foreach ( preg_split( '/\r?\n/', (string) $this->cfg( $cfg, 'headers' ) ) as $line ) {
			if ( strpos( $line, ':' ) ) {
				list( $k, $val ) = array_map( 'trim', explode( ':', $line, 2 ) );
				$headers[ $k ]   = strtr( $val, $this->vars( $mobile, $text, $cfg, 'raw', $extra ) );
			}
		}
		$args = array( 'method' => $method, 'headers' => $headers );
		if ( 'POST' === $method && $body_tpl ) {
			if ( 'json' === $ctype ) {
				$args['headers']['Content-Type'] = 'application/json';
				$args['body']                    = strtr( $body_tpl, $this->vars( $mobile, $text, $cfg, 'json', $extra ) );
			} else {
				$args['headers']['Content-Type'] = 'application/x-www-form-urlencoded';
				$args['body']                    = strtr( $body_tpl, $this->vars( $mobile, $text, $cfg, 'url', $extra ) );
			}
		}
		$r       = $this->request( $url, $args );
		$success = $this->cfg( $cfg, 'success' );
		return array( 'ok' => $r['code'] >= 200 && $r['code'] < 300 && ( '' === $success || false !== strpos( $r['body'], $success ) ), 'response' => $r['body'] );
	}

	public function send( array $messages, array $cfg ) {
		return $this->each( $messages, function ( $m ) use ( $cfg ) {
			return $this->call( $this->cfg( $cfg, 'url' ), $this->cfg( $cfg, 'body' ), $m['mobile'], $m['text'], $cfg );
		} );
	}

	public function send_pattern( $mobile, $code, array $params, array $cfg ) {
		if ( ! $this->cfg( $cfg, 'p_url' ) ) {
			return array( 'ok' => false, 'response' => 'آدرس ارسال الگو در تنظیمات اتصال دستی خالی است.' );
		}
		$list = array();
		foreach ( $params as $k => $v ) {
			$list[] = array( 'name' => (string) $k, 'value' => (string) $v );
		}
		$extra = array(
			'{pattern}'      => (string) $code,
			'{params_json}'  => wp_json_encode( (object) array_map( 'strval', $params ), JSON_UNESCAPED_UNICODE ),
			'{params_array}' => wp_json_encode( $list, JSON_UNESCAPED_UNICODE ),
		);
		foreach ( $params as $k => $v ) {
			$extra[ '{p:' . $k . '}' ] = (string) $v;
		}
		return $this->call( $this->cfg( $cfg, 'p_url' ), $this->cfg( $cfg, 'p_body' ), $mobile, '', $cfg, $extra );
	}

	public function pattern_help() {
		return 'در قالب بدنه الگو از <code>{pattern}</code> (کد الگو)، <code>{params_json}</code> (شیء {"name":"…"})، <code>{params_array}</code> (آرایه [{"name":"…","value":"…"}]) یا <code>{p:نام_پارامتر}</code> استفاده کنید.';
	}

	public function guide() {
		return '<p>با این گزینه هر سامانه پیامکی که وب‌سرویس HTTP/REST دارد (حتی اگر در لیست نیست) وصل می‌شود. مستندات وب‌سرویس پنل خودتان را باز کنید و مقادیر زیر را مطابق آن پر کنید:</p>
<ol class="bc-guide-steps">
<li><b>آدرس ارسال</b>: آدرس متد «ارسال پیامک تکی/ساده» در مستندات. اگر متد GET است پارامترها را در خود آدرس بنویسید، مثلاً<br><code dir="ltr">https://panel.example.ir/api/send?user={username}&amp;pass={password}&amp;to={to}&amp;from={from}&amp;text={text}</code><br>(در آدرس، مقادیر خودکار URL-encode می‌شوند.)</li>
<li><b>متد و نوع بدنه</b>: مطابق مستندات (اکثر سرویس‌های جدید POST + JSON هستند).</li>
<li><b>هدرها</b>: اگر کلید API باید در هدر برود، هر هدر را در یک خط بنویسید: <code dir="ltr">Authorization: Bearer {api_key}</code> یا <code dir="ltr">X-API-KEY: {api_key}</code></li>
<li><b>قالب بدنه</b>: نمونه درخواست مستندات را کپی کنید و مقادیر را با متغیرها جایگزین کنید، مثلاً:<br><code dir="ltr">{"lineNumber":"{from}","receptor":"{to}","message":"{text}"}</code><br>مقادیر داخل JSON خودکار escape می‌شوند؛ دور متغیرها حتماً "" بگذارید.</li>
<li><b>نشانه موفقیت</b>: بخشی از پاسخ موفق که در پاسخ خطا نیست، مثل <code dir="ltr">"status":1</code> یا <code dir="ltr">"isSuccess":true</code>. اگر خالی باشد فقط کد HTTP 2xx بررسی می‌شود (دقیق نیست).</li>
<li>ذخیره کنید و با «ارسال پیامک تست» امتحان کنید؛ پاسخ خام سامانه نمایش داده می‌شود تا نشانه موفقیت را دقیق تنظیم کنید.</li>
</ol>
<h4>متغیرهای قابل استفاده در آدرس، هدر و بدنه</h4>
<table class="bc-table"><tbody>
<tr><td><code>{to}</code></td><td>موبایل گیرنده 09121234567</td></tr>
<tr><td><code>{to98}</code></td><td>989121234567</td></tr>
<tr><td><code>{to_plus}</code></td><td>+989121234567</td></tr>
<tr><td><code>{to_10}</code></td><td>9121234567</td></tr>
<tr><td><code>{text}</code></td><td>متن پیامک</td></tr>
<tr><td><code>{from}</code></td><td>شماره فرستنده</td></tr>
<tr><td><code>{api_key}</code> <code>{username}</code> <code>{password}</code></td><td>اطلاعات حساب</td></tr>
<tr><td><code>{uid}</code> <code>{time}</code></td><td>شناسه یکتای درخواست و زمان یونیکس</td></tr>
<tr><td><code>{pattern}</code> <code>{params_json}</code> <code>{params_array}</code> <code>{p:نام}</code></td><td>فقط در ارسال الگو</td></tr>
</tbody></table>
<h4>چند نمونه آماده</h4>
<p><b>REST با کلید در هدر:</b> URL <code dir="ltr">https://api.example.ir/v1/send</code> — POST/JSON — هدر <code dir="ltr">X-API-KEY: {api_key}</code> — بدنه <code dir="ltr">{"from":"{from}","to":["{to}"],"text":"{text}"}</code> — نشانه موفقیت <code dir="ltr">"status":1</code></p>
<p><b>URL ساده GET:</b> متد GET و آدرس <code dir="ltr">https://sms.example.ir/send.php?username={username}&amp;password={password}&amp;from={from}&amp;to={to}&amp;text={text}</code></p>';
	}
}
